local MinBuild, MaxBuild, Build = 40000, 0, select(4, GetBuildInfo())
if Build < MinBuild or ( MaxBuild > 0 and Build > MaxBuild ) then return end
local AddonName, a = ...
local AddonTitle = select(2, GetAddOnInfo(AddonName))
local PlainAddonTitle = AddonTitle:gsub("|c........", ""):gsub("|r", "")
local L = a.Localize
local s = SpellFlashAddon
local x = s.UpdatedVariables

-- SpellFlash API:
-- http://wow.curseforge.com/addons/spellflash/pages/api/

-- Updated variable references:
-- http://wow.curseforge.com/addons/spellflash/pages/api/#w-local-x-spell-flash-addon-updated-variables
-- x.Enemy, x.ActiveEnemy, x.NoCC, x.InInstance, x.InstanceType, x.PetAlive, x.PetActiveEnemy, x.PetNoCC, x.Lag, x.DoubleLag, x.ThreatPercent, x.EnemyDetected, x.ShouldPermanentBuff, x.ShouldTemporaryBuff

-- Spell table references:
-- http://wow.curseforge.com/addons/spellflash/pages/api/#w-s-castable


a.spells["Auto Attack"] = {
	ID = 6603--[[Auto Attack]],
	EnemyTargetNeeded = 1,
	Melee = 1,
	NotIfActive = 1,
	CheckFirst = function(z)
		z.FlashColor = s.If(x.ActiveEnemy, "White", "Pink")
		return x.NoCC and not s.Shooting()
	end,
}

a.spells["Auto Shot"] = {
	ID = 75--[[Auto Shot]],
	EnemyTargetNeeded = 1,
	NotIfActive = 1,
	CheckFirst = function(z)
		z.FlashColor = s.If(x.ActiveEnemy, "White", "Pink")
		return x.NoCC and not s.Shooting() and not s.CurrentSpell(6603--[[Auto Attack]])
	end
}


a.spells["Counterattack"] = {
	ID = 19306--[[Counterattack]],
	EnemyTargetNeeded = 1,
	CheckFirst = function(z)
		z.FlashColor = s.If(x.ActiveEnemy, "White", "Pink")
		return x.NoCC
	end,
}

a.spells["Wing Clip"] = {
	ID = 2974--[[Wing Clip]],
	Debuff = 2974--[[Wing Clip]],
	EnemyTargetNeeded = 1,
	CheckFirst = function(z)
		z.FlashColor = s.If(x.ActiveEnemy, "White", "Pink")
		return x.NoCC
	end,
}

a.spells["Raptor Strike"] = {
	ID = 2973--[[Raptor Strike]],
	EnemyTargetNeeded = 1,
	CheckFirst = function(z)
		z.FlashColor = s.If(x.ActiveEnemy, "White", "Pink")
		return x.NoCC
	end,
}

a.spells["Serpent Sting - Noxious Stings"] = {
	ID = 1978--[[Serpent Sting]],
	MyDebuff = {
		1978--[[Serpent Sting]],
		19386--[[Wyvern Sting]],
	},
	EarlyRefresh = 1,
	EnemyTargetNeeded = 1,
	CheckFirst = function(z)
		z.FlashColor = s.If(x.ActiveEnemy, "White", "Pink")
		return x.NoCC and s.HasTalent(53295--[[Noxious Stings]])
	end,
}

a.spells["Serpent Sting"] = {
	ID = 1978--[[Serpent Sting]],
	MyDebuff = {
		1978--[[Serpent Sting]],
		19386--[[Wyvern Sting]],
	},
	EarlyRefresh = 1,
	EnemyTargetNeeded = 1,
	CheckFirst = function(z)
		z.FlashColor = s.If(x.ActiveEnemy, "White", "Pink")
		return x.NoCC
	end,
}

a.spells["Wyvern Sting"] = {
	ID = 19386--[[Wyvern Sting]],
	EnemyTargetNeeded = 1,
	CheckFirst = function(z)
		z.FlashColor = s.If(x.ActiveEnemy, "White", "Pink")
		return x.NoCC
	end,
}

a.spells["Aimed Shot - Fire!"] = {
	ID = 19434--[[Aimed Shot]],
	EnemyTargetNeeded = 1,
	NotIfActive = 1,
	CheckFirst = function(z)
		z.NotWhileMoving = not s.Buff(82926--[[Fire!]], "player")
		z.FlashColor = s.If(x.ActiveEnemy, "Yellow", "Pink")
		return x.NoCC
	end,
}

a.spells["Aimed Shot - Starter"] = {
	ID = 19434--[[Aimed Shot]],
	EnemyTargetNeeded = 1,
	NotIfActive = {
		19434--[[Aimed Shot]],
		56641--[[Steady Shot]],
		77767--[[Cobra Shot]],
	},
	FlashColor = "Pink",
	CheckFirst = function(z)
		z.NotWhileMoving = not s.Buff(82926--[[Fire!]], "player")
		return x.NoCC and a.IdleTarget(z.ID)
	end,
}

a.spells["Aimed Shot"] = {
	ID = 19434--[[Aimed Shot]],
	EnemyTargetNeeded = 1,
	CheckFirst = function(z)
		z.NotWhileMoving = not s.Buff(82926--[[Fire!]], "player")
		z.FlashColor = s.If(x.ActiveEnemy, "White", "Pink")
		return x.NoCC and a.EnoughFocus(19434--[[Aimed Shot]]) and ( ( s.HasTalent(34482--[[Careful Aim]]) and s.HealthPercent() > 80 ) or s.Buff(a.HasteBuffs, "player") )
	end,
}

a.spells["Arcane Shot"] = {
	ID = 3044--[[Arcane Shot]],
	EnemyTargetNeeded = 1,
	CheckFirst = function(z)
		z.FlashColor = s.If(x.ActiveEnemy, "White", "Pink")
		return x.NoCC and a.EnoughFocus(3044--[[Arcane Shot]])
	end,
}

a.spells["Aspect of the Fox"] = {
	Type = "form",
	ID = 82661--[[Aspect of the Fox]],
	CheckFirst = function(z)
		z.FlashColor = s.If(s.Form(), "Pink", "Green")
		return ( not s.Form() or ( x.ActiveEnemy and s.Form(13165--[[Aspect of the Hawk]]) ) ) and ( GetUnitSpeed("player") > 0 or ( s.MeleeDistance() and ( not s.Form() or x.ActiveEnemy ) ) )
	end,
}

a.spells["Aspect of the Hawk"] = {
	Type = "form",
	ID = 13165--[[Aspect of the Hawk]],
	CheckFirst = function(z)
		z.FlashColor = s.If(s.Form(), "Pink", "Green")
		return ( not s.Form() or ( x.ActiveEnemy and s.Form(82661--[[Aspect of the Fox]]) ) ) and ( not x.Enemy or not s.MeleeDistance() )
	end,
}

a.spells["Camouflage"] = {
	ID = 51753--[[Camouflage]],
	Buff = 51753--[[Camouflage]],
	BuffUnit = "player",
}

a.spells["Cobra Shot - Starter"] = {
	ID = 77767--[[Cobra Shot]],
	EnemyTargetNeeded = 1,
	NotIfActive = {
		19434--[[Aimed Shot]],
		56641--[[Steady Shot]],
		77767--[[Cobra Shot]],
	},
	Continue = 1,
	FlashColor = "Pink",
	CheckFirst = function(z)
		z.NotWhileMoving = not s.Buff(82661--[[Aspect of the Fox]], "player")
		return x.NoCC and not s.HasTalent(53221--[[Improved Steady Shot]]) and a.IdleTarget(z.ID)
	end,
}

a.spells["Cobra Shot"] = {
	ID = 77767--[[Cobra Shot]],
	EnemyTargetNeeded = 1,
	Continue = 1,
	CheckFirst = function(z)
		z.NotWhileMoving = not s.Buff(82661--[[Aspect of the Fox]], "player")
		z.FlashColor = s.If(x.ActiveEnemy, "White", "Pink")
		return x.NoCC and not s.HasTalent(53221--[[Improved Steady Shot]])
	end,
}

a.spells["Concussive Shot"] = {
	ID = 5116--[[Concussive Shot]],
	EnemyTargetNeeded = 1,
	CheckFirst = function(z)
		z.FlashColor = s.If(x.ActiveEnemy, "White", "Pink")
		return ( GetUnitSpeed("target") > 0 or not s.CastingOrChanneling() ) and s.EnemyTargetingYou() and not s.MovementImpaired()
	end,
}

a.spells["Disengage"] = {
	ID = 781--[[Disengage]],
	EnemyTargetNeeded = 1,
	NoRangeCheck = 1,
	Continue = 1,
	FlashColor = "Red",
	CheckFirst = function(z)
		return x.ActiveEnemy and s.MeleeDistance()
	end,
}

a.spells["Hunter's Mark - Starter"] = {
	ID = 1130--[[Hunter's Mark]],
	Debuff = {
		1130--[[Hunter's Mark]],
		53241--[[Marked for Death]],
	},
	EarlyRefresh = 5,
	EnemyTargetNeeded = 1,
	FlashColor = "White",
	CheckFirst = function(z)
		return ( not x.NoCC or not s.Player() ) and not s.InCombat()
	end,
}

a.spells["Hunter's Mark"] = {
	ID = 1130--[[Hunter's Mark]],
	Debuff = {
		1130--[[Hunter's Mark]],
		53241--[[Marked for Death]],
	},
	EarlyRefresh = 5,
	EnemyTargetNeeded = 1,
	Run = function(z)
		z.FlashColor = s.If(x.ActiveEnemy, "White", "Pink")
	end,
}

a.spells["Kill Command"] = {
	ID = 34026--[[Kill Command]],
	NoRangeCheck = 1,
	Continue = 1,
	CheckFirst = function(z)
		if s.TalentMastery(1) then
			z.FlashColor = s.If(x.PetActiveEnemy, "Yellow", "Pink")
		else
			z.FlashColor = s.If(x.PetActiveEnemy, "White", "Pink")
		end
		return x.PetNoCC and s.Enemy("pettarget")
	end,
}

a.spells["Kill Shot"] = {
	ID = 53351--[[Kill Shot]],
	EnemyTargetNeeded = 1,
	CheckFirst = function(z)
		z.FlashColor = s.If(x.ActiveEnemy, "White", "Pink")
		return x.NoCC
	end,
}

a.spells["Master's Call"] = {
	ID = 53271--[[Master's Call]],
	NoRangeCheck = 1,
}

a.spells["Mend Pet"] = {
	ID = 136--[[Mend Pet]],
	Buff = 136--[[Mend Pet]],
	Unit = "pet",
	NotIfActive = 1,
	NoGCD = 1,
	CheckFirst = function(z)
		z.FlashColor = s.If(s.InCombat() or UnitExists("pettarget"), "Yellow", "Green")
		return x.PetAlive and ( s.HealthPercent("pet") <= 95  or ( s.HasTalent(19572--[[Improved Mend Pet]]) and s.Debuff(nil,"pet",nil,nil,1) ) )
	end,
}

a.spells["Multi-Shot"] = {
	ID = 2643--[[Multi-Shot]],
	EnemyTargetNeeded = 1,
	Continue = 1,
	CheckFirst = function(z)
		z.FlashColor = s.If(x.ActiveEnemy, "Purple", "Pink")
		return x.NoCC and a.EnoughFocus(2643--[[Multi-Shot]])
	end,
}

a.spells["Rapid Fire"] = {
	ID = 3045--[[Rapid Fire]],
	Buff = 3045--[[Rapid Fire]],
	BuffUnit = "player",
	EnemyTargetNeeded = 1,
	FlashColor = "Green",
	CheckFirst = function(z)
		return x.ActiveEnemy and s.InCombat() and s.SpellInRange(75--[[Auto Shot]]) and ( s.HealthPercent() > 25 or s.Player() or s.Boss() )
	end,
}

a.spells["Readiness"] = {
	ID = 23989--[[Readiness]],
	Buff = 3045--[[Rapid Fire]],
	BuffUnit = "player",
	EnemyTargetNeeded = 1,
	FlashColor = "Green",
	CheckFirst = function(z)
		return x.ActiveEnemy and s.InCombat() and s.SpellInRange(75--[[Auto Shot]]) and ( s.HealthPercent() > 25 or s.Player() or s.Boss() )
	end,
}

a.spells["Silencing Shot"] = {
	ID = 34490--[[Silencing Shot]],
	EnemyTargetNeeded = 1,
	Interrupt = 1,
	FlashColor = "Aqua",
}

a.spells["Scatter Shot"] = {
	ID = 19503--[[Scatter Shot]],
	EnemyTargetNeeded = 1,
	CheckFirst = function(z)
		if x.ActiveEnemy then
			if s.GetCastingOrChanneling(nil, nil, 1) > s.SpellCooldown(19503--[[Scatter Shot]]) + x.DoubleLag then
				z.FlashColor = "Aqua"
				return true
			elseif s.MeleeDistance() and not s.Feared() and not s.Rooted() then
				z.FlashColor = "Yellow"
				return true
			end
		end
		return false
	end,
}

a.spells["Improved Steady Shot"] = {
	ID = 56641--[[Steady Shot]],
	BuffUnit = "player",
	EnemyTargetNeeded = 1,
	CheckFirst = function(z)
		if x.NoCC and s.HasTalent(53221--[[Improved Steady Shot]]) then
			if a.FIRST_STEADY_SHOT then
				if not s.Casting(a.BreakImprovedSteadyShotSpells) and not s.SpellDelay(a.BreakImprovedSteadyShotSpells, nil, 1) then
					z.Buff = 53221--[[Improved Steady Shot]]
					z.NotIfActive = 1
					return true
				end
			elseif s.SpellDelay(56641--[[Steady Shot]]) then
				z.Buff = 53221--[[Improved Steady Shot]]
				z.NotIfActive = 1
				return true
			elseif s.Casting(56641--[[Steady Shot]], "player") then
				z.Buff = nil
				z.NotIfActive = nil
				return true
			end
		end
		return false
	end,
	Run = function(z)
		z.NotWhileMoving = not s.Buff(82661--[[Aspect of the Fox]], "player")
		z.FlashColor = s.If(x.ActiveEnemy, "Yellow", "Pink")
	end,
}

a.spells["Steady Shot - Starter"] = {
	ID = 56641--[[Steady Shot]],
	EnemyTargetNeeded = 1,
	NotIfActive = {
		19434--[[Aimed Shot]],
		56641--[[Steady Shot]],
		77767--[[Cobra Shot]],
	},
	FlashColor = "Pink",
	CheckFirst = function(z)
		z.NotWhileMoving = not s.Buff(82661--[[Aspect of the Fox]], "player")
		return x.NoCC and a.IdleTarget(z.ID)
	end,
}

a.spells["Steady Shot"] = {
	ID = 56641--[[Steady Shot]],
	EnemyTargetNeeded = 1,
	CheckFirst = function(z)
		z.NotWhileMoving = not s.Buff(82661--[[Aspect of the Fox]], "player")
		z.FlashColor = s.If(x.ActiveEnemy, "White", "Pink")
		return x.NoCC
	end,
}

a.spells["Tranquilizing Shot"] = {
	ID = 19801--[[Tranquilizing Shot]],
	EnemyTargetNeeded = 1,
}

a.spells["Widow Venom"] = {
	ID = 82654--[[Widow Venom]],
	Debuff = 82654--[[Widow Venom]],
	EnemyTargetNeeded = 1,
	CheckFirst = function(z)
		if x.ActiveEnemy then
			if s.Class(nil, a.HealingClasses) then
				z.FlashColor = "Yellow"
				return true
			elseif s.Player() then
				z.FlashColor = "White"
				return true
			end
		end
		return false
	end,
}

a.spells["Explosive Shot"] = {
	ID = 53301--[[Explosive Shot]],
	EnemyTargetNeeded = 1,
	CheckFirst = function(z)
		z.FlashColor = s.If(x.ActiveEnemy, "White", "Pink")
		return x.NoCC
	end,
}

a.spells["Intimidation"] = {
	ID = 19577--[[Intimidation]],
	CheckFirst = function(z)
		local interrupt = s.GetCastingOrChanneling(nil, "pettarget", 1) > s.SpellCooldown(z.ID) + x.DoubleLag
		z.FlashColor = s.If(interrupt, "Aqua", "Red")
		return x.PetActiveEnemy and ( interrupt or ( ( not UnitPlayerControlled("pettarget") or s.MeleeDistance("pettarget") ) and s.EnemyTargetingYou("pettarget") ) )
	end,
}

a.spells["Bestial Wrath"] = {
	ID = 19574--[[Bestial Wrath]],
	FlashColor = "Green",
	CheckFirst = function(z)
		return x.PetActiveEnemy and ( s.HealthPercent("pettarget") > 25 or UnitIsPlayer("pettarget") or s.Boss("pettarget") )
	end,
}

a.spells["Black Arrow"] = {
	ID = 3674--[[Black Arrow]],
	EnemyTargetNeeded = 1,
	CheckFirst = function(z)
		z.FlashColor = s.If(x.ActiveEnemy, "White", "Pink")
		return x.NoCC
	end,
}

a.spells["Chimera Shot"] = {
	ID = 53209--[[Chimera Shot]],
	RequireMyDebuff = {
		1978--[[Serpent Sting]],
		19386--[[Wyvern Sting]],
	},
	EnemyTargetNeeded = 1,
	CheckFirst = function(z)
		z.FlashColor = s.If(x.ActiveEnemy, "White", "Pink")
		return x.NoCC
	end,
}

a.spells["Fervor"] = {
	ID = 82726--[[Fervor]],
	EnemyTargetNeeded = 1,
	FlashColor = "Yellow",
	CheckFirst = function(z)
		return x.ActiveEnemy and s.PowerMissing("player") >= 50 and ( not UnitExists("pettarget") or s.PowerMissing("pet") >= 50 ) and ( s.HealthPercent() > 25 or s.Player() or s.Boss() )
	end,
}

a.spells["Focus Fire"] = {
	ID = 82692--[[Focus Fire]],
	RequireBuff = 19615--[[Frenzy Effect]],
	RequireBuffUnit = "pet",
	RequireStack = 5,
	NotIfActive = 1,
	FlashColor = "Yellow",
}

a.spells["Attack"] = {
	Type = "pet",
	ID = "Attack",
	FlashColor = "Pink",
	CheckFirst = function(z)
		return x.PetAlive and x.ActiveEnemy and not x.PetActiveEnemy
	end,
}

a.spells["Follow"] = {
	Type = "pet",
	ID = "Follow",
	CheckFirst = function(z)
		return x.PetAlive and x.PetActiveEnemy and not UnitPlayerControlled("pettarget") and not UnitExists("pettargettarget") and s.HealthPercent("pettarget") <= 25
	end,
}

a.spells["Stay"] = {
	Type = "pet",
	ID = "Stay",
	CheckFirst = function(z)
		return x.PetAlive and not x.PetNoCC
	end,
}


