local MinBuild, MaxBuild, Build = 40000, 0, select(4, GetBuildInfo())
if Build < MinBuild or ( MaxBuild > 0 and Build > MaxBuild ) then return end
local AddonName, a = ...
local AddonTitle = select(2, GetAddOnInfo(AddonName))
local PlainAddonTitle = AddonTitle:gsub("|c........", ""):gsub("|r", "")
local L = a.Localize
local s = SpellFlashAddon
local x = s.UpdatedVariables

-- SpellFlash API:
-- http://wow.curseforge.com/addons/spellflash/pages/api/

-- Updated variable references:
-- http://wow.curseforge.com/addons/spellflash/pages/api/#w-local-x-spell-flash-addon-updated-variables
-- x.Enemy, x.ActiveEnemy, x.NoCC, x.InInstance, x.InstanceType, x.PetAlive, x.PetActiveEnemy, x.PetNoCC, x.Lag, x.DoubleLag, x.ThreatPercent, x.EnemyDetected, x.ShouldPermanentBuff, x.ShouldTemporaryBuff


-- Use this single spam function and remove the multiple spam table below, or just use the multiple spam table below and leave this function in place.
s.Spam[AddonName] = function()

	if x.PetAlive then
		
		if s.HasSpell(93321--[[Control Pet]]) then
			a.Flash("Attack", "Follow", "Stay")
		end
		
		a.FlashAll("Mend Pet", "Bestial Wrath", "Intimidation")
		
	end
	
	a.Flash("Aspect of the Fox", "Aspect of the Hawk")
	
	if a.Flash(
		"Hunter's Mark - Starter",
		"Aimed Shot - Starter",
		"Cobra Shot - Starter",
		"Steady Shot - Starter",
	nil) then return end
	
	a.FlashAll("Focus Fire", "Fervor")
	a.Flash("Rapid Fire", "Readiness")
	a.Flash("Silencing Shot", "Scatter Shot")
	
	a.Flash(
		"Concussive Shot",
		"Improved Steady Shot",
		"Aimed Shot - Fire!",
		"Chimera Shot",
		"Serpent Sting - Noxious Stings",
		"Kill Shot",
		"Explosive Shot",
		"Kill Command", -- Continue
		"Counterattack",
		"Wing Clip",
		"Disengage", -- Continue
		"Raptor Strike",
		"Serpent Sting",
		"Black Arrow",
		"Hunter's Mark",
		"Widow Venom",
		"Multi-Shot", -- Continue
		"Aimed Shot",
		"Arcane Shot",
		"Cobra Shot", -- Continue
		"Steady Shot",
		"Auto Attack",
		"Auto Shot",
	nil)
	
end

