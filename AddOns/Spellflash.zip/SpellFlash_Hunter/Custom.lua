local MinBuild, MaxBuild, Build = 40000, 0, select(4, GetBuildInfo())
if Build < MinBuild or ( MaxBuild > 0 and Build > MaxBuild ) then return end
local AddonName, a = ...
local AddonTitle = select(2, GetAddOnInfo(AddonName))
local PlainAddonTitle = AddonTitle:gsub("|c........", ""):gsub("|r", "")
local L = a.Localize
local s = SpellFlashAddon
local x = s.UpdatedVariables


a.BreakImprovedSteadyShotSpells = {
	56641--[[Steady Shot]],
	1978--[[Serpent Sting]],
	19386--[[Wyvern Sting]], -- unconfirmed
	19434--[[Aimed Shot]],
	3044--[[Arcane Shot]],
	77767--[[Cobra Shot]],
	5116--[[Concussive Shot]],
	53351--[[Kill Shot]],
	2643--[[Multi-Shot]],
	19503--[[Scatter Shot]],
	19801--[[Tranquilizing Shot]],
	82654--[[Widow Venom]],
	53301--[[Explosive Shot]], -- unconfirmed
	3674--[[Black Arrow]], -- unconfirmed
	53209--[[Chimera Shot]],
	--19306--[[Counterattack]], -- unconfirmed
	--2974--[[Wing Clip]],
	--2973--[[Raptor Strike]],
	--781--[[Disengage]],
	--34490--[[Silencing Shot]],
	--1130--[[Hunter's Mark]],
	--34026--[[Kill Command]],
	--53271--[[Master's Call]],
	--136--[[Mend Pet]],
	--3045--[[Rapid Fire]],
	--19577--[[Intimidation]],
	--19574--[[Bestial Wrath]],
	--82726--[[Fervor]],
	--82692--[[Focus Fire]],
	--23989--[[Readiness]],
}

a.HealingClasses = {
	"DRUID",
	"PALADIN",
	"PRIEST",
	"SHAMAN",
}

a.HasteBuffs = {
	3045--[[Rapid Fire]],
	32182--[[Heroism]],
	2825--[[Bloodlust]],
	80353--[[Time Warp]],
	90355--[[Ancient Hysteria]],
	28507--[[Haste]],
}

local ImmunityDebuffs = {
	710--[[Banish]],
	33786--[[Cyclone]],
}
function a.IdleTarget(SpellID)
	return not s.InCombat() and not s.SpellDelay(SpellID) and (
		( not x.ActiveEnemy and s.Debuff(1130--[[Hunter's Mark]]) )
		or
		(
			s.Player()
			and
			(
				(
					x.NoCC and not s.EnemyTargetingYou()
				)
				or
				(
					not x.NoCC and s.DebuffDuration(ImmunityDebuffs) <= s.CastTime(SpellID) + s.SpellCooldown(SpellID) + x.Lag
				)
			)
		)
	)
end

function a.EnoughFocus(SpellName)
	if s.TalentMastery(1) then
		return not UnitExists("pettarget") or s.Power("player") >= s.SpellCost(34026--[[Kill Command]]) + s.SpellCost(SpellName)
	elseif s.TalentMastery(2) then
		return s.Power("player") >= s.SpellCost(53209--[[Chimera Shot]]) + s.SpellCost(SpellName)
	elseif s.TalentMastery(3) then
		return s.Power("player") >= s.SpellCost(53301--[[Explosive Shot]]) + s.SpellCost(SpellName)
	end
	return true
end

