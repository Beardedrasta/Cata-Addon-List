local MinBuild, MaxBuild, Build = 40000, 0, select(4, GetBuildInfo())
if Build < MinBuild or ( MaxBuild > 0 and Build > MaxBuild ) then return end
local AddonName, a = ...
local AddonTitle = select(2, GetAddOnInfo(AddonName))
local PlainAddonTitle = AddonTitle:gsub("|c........", ""):gsub("|r", "")
local L = a.Localize
local s = SpellFlashAddon
local x = SpellFlashAddon.UpdatedVariables
local z = {}


-- SpellFlash API: http://wow.curseforge.com/addons/spellflash/pages/api/
-- x.Enemy, x.ActiveEnemy, x.NoCC, x.InInstance, x.InstanceType, x.PetAlive, x.PetActiveEnemy, x.PetNoCC, x.Lag, x.DoubleLag, x.ThreatPercent, x.EnemyDetected, x.ShouldPermanentBuff, x.ShouldTemporaryBuff


-- Example function:
a.Castable["English_Spell_Name"] = function()
	wipe(z)
	z.SpellID = GlobalSpellID--[[English_Spell_Name]]   --this is for defining the correct name of the spell
	z.DebuffSlotNeeded = 1   --use this if you want to make sure that a debuff slot is free on the target so that you do not replace other debuffs
	z.Debuff = z.SpellID   --place debuff name or table of names here if the spell has a debuff that may only be on a target once in total from everyone and has a cooldown shorter than the debuff duration
	z.MyDebuff = z.SpellID   --place debuff name or table of names here if the spell has a debuff that may be on the target multiple times by many people and has a cooldown shorter than the debuff duration
	z.Buff = z.SpellID   --place buff name or table of names here if the spell has a buff that may only be on yourself once in total from everyone and has a cooldown shorter than the buff duration
	z.MyBuff = z.SpellID   --place buff name or table of names here if the spell has a buff that may be on the target multiple times by many people and has a cooldown shorter than the buff duration
	z.BuffUnit = "player"   --you will need to use this if the buff or debuff is not applied to your target
	z.Stack = 2   --use this if the buff or debuff requires more than one application
	z.EarlyRefresh = 5   --use this to indicate the buff or debuff early for a desired number of seconds
	z.CastTime = s.CastTime(z.SpellID)   --use this only if you want to replace the spell cast time used for early indication of a buff or debuff
	z.EnemyTargetNeeded = 1   --use this if the spell should have an enemy targeted
	z.TargetThatUsesManaNeeded = 1   --use this if the spell is only useful on a target that uses mana such as mana draining spells
	z.NoRangeCheck = 1   --use this to disable range detection if the spell has a limited range but the detection in this function is not working correctly for the particular spell
	z.NotIfActive = 1   --use this if the spell may be toggled on such as auto attack or on next swing spells, or to disable when casting or channeling, or if the spell has a cooldown
	z.NotWhileMoving = 1   --use this if the spell is not able to be cast while moving
	z.NoPowerCheck = 1   --use this to disable the power checking in this function
	z.EvenIfNotUsable = 1   --use this to disable the usability checking in this function and may be used if currently in the process of completing a prerequisite that will make the spell usable
	z.Unit = "target"   --this should not be used unless the spell is not to be cast on the target
	z.Interrupt = 1   --use this if the target should be casting or channeling an interruptible ability
	return s.CheckIfSpellCastable(z)
end

-- Example function:
a.ItemCastable["English_Item_Name"] = function()
	wipe(z)
	z.ItemID = ItemID--[[English_Item_Name]]   --this is for defining the correct name of the item
	z.DebuffSlotNeeded = 1   --use this if you want to make sure that a debuff slot is free on the target so that you do not replace other debuffs
	z.Debuff = GlobalSpellID--[[English_Spell_Name]]   --place debuff name or table of names here if the item has a debuff that may only be on a target once in total from everyone and has a cooldown shorter than the debuff duration
	z.MyDebuff = GlobalSpellID--[[English_Spell_Name]]   --place debuff name or table of names here if the item has a debuff that may be on the target multiple times by many people and has a cooldown shorter than the debuff duration
	z.Buff = GlobalSpellID--[[English_Spell_Name]]   --place buff name or table of names here if the item has a buff that may only be on yourself once in total from everyone and has a cooldown shorter than the buff duration
	z.MyBuff = GlobalSpellID--[[English_Spell_Name]]   --place buff name or table of names here if the item has a buff that may be on the target multiple times by many people and has a cooldown shorter than the buff duration
	z.BuffUnit = "player"   --you will need to use this if the buff or debuff is not applied to your target
	z.Stack = 2   --use this if the buff or debuff requires more than one application
	z.EarlyRefresh = 5   --use this to indicate the buff or debuff early for a desired number of seconds
	z.CastTime = 0   --use this if the item has a cast time for indication of a buff or debuff early
	z.EnemyTargetNeeded = 1   --use this if the item should have an enemy targeted
	z.TargetThatUsesManaNeeded = 1   --use this if the item is only useful on a target that uses mana such as mana draining items
	z.NoRangeCheck = 1   --use this to disable range detection if the item has a limited range but the detection in this function is not working correctly for the particular item
	z.NoEquipCheck = 1   --use this to disable equippable detection if the item can be equipped but does not need to be
	z.NotIfActive = 1   --use this if the item may be toggled on such as auto attack or on next swing spells, or to disable when casting or channeling, or if the item has a cooldown
	z.NotWhileMoving = 1   --use this if the item is not able to be used while moving
	z.NoPowerCheck = 1   --use this to disable the power checking in this function
	z.EvenIfNotUsable = 1   --use this to disable the usability checking in this function and may be used if currently in the process of completing a prerequisite that will make the item usable
	z.Unit = "target"   --this should not be used unless the item is not to be cast on the target
	z.Interrupt = 1   --use this if the target should be casting or channeling an interruptible ability
	return s.CheckIfItemCastable(z)
end

-- Example function:
a.VehicleCastable["English_Spell_Name"] = function()
	wipe(z)
	z.SpellID = GlobalSpellID--[[English_Spell_Name]]   --this is for defining the correct name of the spell
	z.DebuffSlotNeeded = 1   --use this if you want to make sure that a debuff slot is free on the target so that you do not replace other debuffs
	z.Debuff = z.SpellID   --place debuff name or table of names here if the spell has a debuff that may only be on a target once in total from everyone and has a cooldown shorter than the debuff duration
	z.MyDebuff = z.SpellID   --place debuff name or table of names here if the spell has a debuff that may be on the target multiple times by many people and has a cooldown shorter than the debuff duration
	z.Buff = z.SpellID   --place buff name or table of names here if the spell has a buff that may only be on yourself once in total from everyone and has a cooldown shorter than the buff duration
	z.MyBuff = z.SpellID   --place buff name or table of names here if the spell has a buff that may be on the target multiple times by many people and has a cooldown shorter than the buff duration
	z.BuffUnit = "vehicle"   --you will need to use this if the buff or debuff is not applied to your target
	z.Stack = 2   --use this if the buff or debuff requires more than one application
	z.EarlyRefresh = 5   --use this to indicate the buff or debuff early for a desired number of seconds
	z.CastTime = 0   --use this if the spell has a cast time for indication of a buff or debuff early
	z.EnemyTargetNeeded = 1   --use this if the spell should have an enemy targeted
	z.TargetThatUsesManaNeeded = 1   --use this if the spell is only useful on a target that uses mana such as mana draining spells
	z.NoRangeCheck = 1   --use this to disable range detection if the spell has a limited range but the detection in this function is not working correctly for the particular spell
	z.NotIfActive = 1   --use this if the spell may be toggled on such as auto attack or on next swing spells, or to disable when casting or channeling, or if the spell has a cooldown
	z.NotWhileMoving = 1   --use this if the spell is not able to be cast while moving
	z.NoPowerCheck = 1   --use this to disable the power checking in this function
	z.EvenIfNotUsable = 1   --use this to disable the usability checking in this function and may be used if currently in the process of completing a prerequisite that will make the spell usable
	z.GlobalVehicleCooldownSpell = GlobalSpellID--[[English_Spell_Name]]   -- use this if spell has more than a global cooldown
	z.Unit = "target"   --this should not be used unless the spell is not to be cast on the target
	z.Interrupt = 1   --use this if the target should be casting or channeling an interruptible ability
	return s.CheckIfVehicleSpellCastable(z)
end



a.Castable["Auto Attack"] = function()
	wipe(z)
	z.SpellID = 6603--[[Auto Attack]]
	z.EnemyTargetNeeded = 1
	z.NotIfActive = 1
	return s.MeleeDistance() and not s.CurrentSpell(88163--[[Attack]]) and s.CheckIfSpellCastable(z)
end

a.Castable["Attack"] = function()
	wipe(z)
	z.SpellID = 88163--[[Attack]]
	z.EnemyTargetNeeded = 1
	z.NotIfActive = 1
	return s.MeleeDistance() and not s.CurrentSpell(6603--[[Auto Attack]]) and s.CheckIfSpellCastable(z)
end

a.Castable["Battle Stance"] = function()
	wipe(z)
	z.SpellID = 2457--[[Battle Stance]]
	return not s.Form(z.SpellID) and s.CheckIfSpellCastable(z)
end

a.Castable["Defensive Stance"] = function()
	wipe(z)
	z.SpellID = 71--[[Defensive Stance]]
	return not s.Form(z.SpellID) and s.CheckIfSpellCastable(z)
end

a.Castable["Berserker Stance"] = function()
	wipe(z)
	z.SpellID = 2458--[[Berserker Stance]]
	return not s.Form(z.SpellID) and s.CheckIfSpellCastable(z)
end

local StrengthAndAgilityBuffs = {
	6673--[[Battle Shout]],
	57330--[[Horn of Winter]],
	93435--[[Roar of Courage]],
	8076--[[Strength of Earth]],
}

local StaminaBuffs = {
	469--[[Commanding Shout]],
	90364--[[Qiraji Fortitude]],
	21562--[[Power Word: Fortitude]],
	6307--[[Blood Pact]],
}

a.Castable["Battle Shout"] = function()
	if not x.ShouldTemporaryBuff or not x.EnemyDetected then
		return false
	end
	wipe(z)
	z.SpellID = 6673--[[Battle Shout]]
	if not ( x.ActiveEnemy and s.Power("player") - s.SpellCost(s.CastingName(nil, "player"), SPELL_POWER_RAGE) < 50 and s.NotDieing() ) then
		z.Buff = StrengthAndAgilityBuffs
	elseif not ( not s.Flashable(469--[[Commanding Shout]]) or s.MyBuff(z.SpellID, "player", x.DoubleLag) or not s.Buff(StrengthAndAgilityBuffs, "player", x.DoubleLag) or s.Buff(StaminaBuffs, "player", x.DoubleLag) ) then
		return false
	end
	z.MyBuff = 469--[[Commanding Shout]]
	z.BuffUnit = "player"
	z.EarlyRefresh = 5
	return s.CheckIfSpellCastable(z)
end

a.Castable["Commanding Shout"] = function()
	if not x.ShouldTemporaryBuff or not x.EnemyDetected then
		return false
	end
	wipe(z)
	z.SpellID = 469--[[Commanding Shout]]
	if not ( x.ActiveEnemy and s.Power("player") - s.SpellCost(s.CastingName(nil, "player"), SPELL_POWER_RAGE) < 50 and s.NotDieing() ) then
		z.Buff = StaminaBuffs
	elseif not ( not s.Flashable(6673--[[Battle Shout]]) or s.MyBuff(z.SpellID, "player", x.DoubleLag) or not s.Buff(StaminaBuffs, "player", x.DoubleLag) or s.Buff(StrengthAndAgilityBuffs, "player", x.DoubleLag) ) then
		return false
	end
	z.MyBuff = 6673--[[Battle Shout]]
	z.BuffUnit = "player"
	z.EarlyRefresh = 5
	return s.CheckIfSpellCastable(z)
end

a.Castable["Berserker Rage"] = function()
	wipe(z)
	z.SpellID = 18499--[[Berserker Rage]]
	return s.CheckIfSpellCastable(z)
end

a.Castable["Charge"] = function()
	wipe(z)
	z.SpellID = 100--[[Charge]]
	z.EnemyTargetNeeded = 1
	return not s.CurrentSpell(20252--[[Intercept]]) and not a:IsTimer("Charge") and s.CheckIfSpellCastable(z)
end

a.Castable["Cleave"] = function()
	wipe(z)
	z.SpellID = 845--[[Cleave]]
	z.EnemyTargetNeeded = 1
	z.NotIfActive = 1
	return ( s.Power("player") - s.SpellCost(s.CastingName(nil, "player"), SPELL_POWER_RAGE) >= 70 or s.BuffDuration(85730--[[Deadly Calm]], "player") > (s.SpellCooldown(z.SpellID) + x.Lag) ) and s.CheckIfSpellCastable(z)
end

a.Castable["Colossus Smash"] = function()
	wipe(z)
	z.SpellID = 86346--[[Colossus Smash]]
	z.EnemyTargetNeeded = 1
	return s.CheckIfSpellCastable(z)
end

local PhysicalDamageReductionDebuffs = {
	702--[[Curse of Weakness]],
	1160--[[Demoralizing Shout]],
	99--[[Demoralizing Roar]],
	24423--[[Demoralizing Screech]],
	26016--[[Vindication]],
}
a.Castable["Demoralizing Shout"] = function()
	wipe(z)
	z.SpellID = 1160--[[Demoralizing Shout]]
	z.Debuff = PhysicalDamageReductionDebuffs
	z.EnemyTargetNeeded = 1
	z.NoRangeCheck = 1
	return CheckInteractDistance(s.UnitSelection(), 3) and s.NotDieing() and s.CheckIfSpellCastable(z)
end

a.Castable["Disarm"] = function()
	wipe(z)
	z.SpellID = 676--[[Disarm]]
	z.Debuff = z.SpellID
	z.EnemyTargetNeeded = 1
	return s.CheckIfSpellCastable(z)
end

a.Castable["Enraged Regeneration"] = function()
	wipe(z)
	z.SpellID = 55694--[[Enraged Regeneration]]
	return ( s.InCombat() or s.EnemyTargetingYou("focus") or s.EnemyTargetingYou("enemy") ) and s.HealthPercent("player") <= 45 and s.CheckIfSpellCastable(z)
end

a.Castable["Execute"] = function()
	wipe(z)
	z.SpellID = 5308--[[Execute]]
	z.EnemyTargetNeeded = 1
	return s.CheckIfSpellCastable(z)
end

a.Castable["Hamstring"] = function()
	wipe(z)
	z.SpellID = 1715--[[Hamstring]]
	z.Debuff = z.SpellID
	z.EarlyRefresh = 2
	z.EnemyTargetNeeded = 1
	return ( s.Player() or not UnitExists(s.UnitSelection().."target") ) and not s.Boss() and s.CheckIfSpellCastable(z)
end

a.Castable["Heroic Strike"] = function()
	wipe(z)
	z.SpellID = 78--[[Heroic Strike]]
	z.EnemyTargetNeeded = 1
	z.NotIfActive = 1
	return ( s.Power("player") - s.SpellCost(s.CastingName(nil, "player"), SPELL_POWER_RAGE) >= 70 or s.BuffDuration(85730--[[Deadly Calm]], "player") > (s.SpellCooldown(z.SpellID) + x.Lag) ) and s.CheckIfSpellCastable(z)
end

a.Castable["Heroic Throw"] = function()
	wipe(z)
	z.SpellID = 57755--[[Heroic Throw]]
	z.EnemyTargetNeeded = 1
	return not s.MeleeDistance() and s.CheckIfSpellCastable(z)
end

a.Castable["Inner Rage"] = function()
	wipe(z)
	z.SpellID = 1134--[[Inner Rage]]
	z.EnemyTargetNeeded = 1
	return s.MeleeDistance() and s.SpellCooldown(78--[[Heroic Strike]]) > x.Lag and s.CheckIfSpellCastable(z)
end

a.Castable["Intercept"] = function()
	wipe(z)
	z.SpellID = 20252--[[Intercept]]
	z.EnemyTargetNeeded = 1
	return not s.CurrentSpell(100--[[Charge]]) and not a:IsTimer("Charge") and s.CheckIfSpellCastable(z)
end

a.Castable["Intervene"] = function()
	wipe(z)
	z.SpellID = 3411--[[Intervene]]
	return UnitIsFriend("player", s.UnitSelection()) and s.CheckIfSpellCastable(z)
end

a.Castable["Overpower"] = function()
	wipe(z)
	z.SpellID = 7384--[[Overpower]]
	z.EnemyTargetNeeded = 1
	return s.CheckIfSpellCastable(z)
end

a.Castable["Pummel"] = function()
	wipe(z)
	z.SpellID = 6552--[[Pummel]]
	z.EnemyTargetNeeded = 1
	z.Interrupt = 1
	return s.CheckIfSpellCastable(z)
end

a.Castable["Recklessness"] = function()
	wipe(z)
	z.SpellID = 1719--[[Recklessness]]
	z.EnemyTargetNeeded = 1
	return s.InCombat() and s.MeleeDistance() and not s.EnemyTargetingYou("focus") and not s.EnemyTargetingYou("enemy") and s.NotDieing() and s.CheckIfSpellCastable(z)
end

a.Castable["Rend"] = function()
	wipe(z)
	z.SpellID = 772--[[Rend]]
	z.DebuffSlotNeeded = 1
	z.MyDebuff = z.SpellID
	z.EarlyRefresh = 1
	z.EnemyTargetNeeded = 1
	return s.CheckIfSpellCastable(z)
end

a.Castable["Retaliation"] = function()
	wipe(z)
	z.SpellID = 20230--[[Retaliation]]
	z.EnemyTargetNeeded = 1
	return s.InCombat() and s.MeleeDistance() and s.EnemyTargetingYou() and s.NotDieing() and s.CheckIfSpellCastable(z)
end

a.Castable["Revenge"] = function()
	wipe(z)
	z.SpellID = 6572--[[Revenge]]
	z.EnemyTargetNeeded = 1
	return s.CheckIfSpellCastable(z)
end

a.Castable["Shattering Throw"] = function()
	wipe(z)
	z.SpellID = 64382--[[Shattering Throw]]
	z.EnemyTargetNeeded = 1
	return s.CheckIfSpellCastable(z)
end

a.Castable["Shield Bash"] = function()
	wipe(z)
	z.SpellID = 72--[[Shield Bash]]
	z.EnemyTargetNeeded = 1
	z.Interrupt = 1
	return s.CheckIfSpellCastable(z)
end

a.Castable["Shield Block"] = function()
	local SpellName, cooldown, duration
	if s.HasTalent(86894--[[Heavy Repercussions]]) then
		SpellName = 23922--[[Shield Slam]]
		cooldown, duration = s.SpellCooldown(SpellName)
	else
		if not s.EnemyTargetingYou("focus") and not s.EnemyTargetingYou("enemy") then
			return false
		end
		SpellName = 6572--[[Revenge]]
		cooldown, duration = s.SpellCooldown(SpellName)
	end
	wipe(z)
	z.SpellID = 2565--[[Shield Block]]
	z.Buff = z.SpellID
	z.BuffUnit = "player"
	return cooldown <= s.SpellCooldown(z.SpellID) + x.DoubleLag and ( s.BuffDuration(85730--[[Deadly Calm]], "player") > 1.5 + x.DoubleLag or s.Power("player") - s.SpellCost(s.CastingName(nil, "player"), SPELL_POWER_RAGE) >= s.SpellCost(z.SpellID) + s.SpellCost(SpellName) ) and s.MeleeDistance() and s.CheckIfSpellCastable(z)
end

a.Castable["Shield Wall"] = function()
	wipe(z)
	z.SpellID = 871--[[Shield Wall]]
	z.EnemyTargetNeeded = 1
	return ( s.InCombat() or s.EnemyTargetingYou("focus") or s.EnemyTargetingYou("enemy") ) and s.HealthPercent("player") <= 35 and s.CheckIfSpellCastable(z)
end

a.Castable["Slam"] = function()
	wipe(z)
	z.SpellID = 1464--[[Slam]]
	z.EnemyTargetNeeded = 1
	return s.SpellCooldown(78--[[Heroic Strike]]) > x.Lag and ( s.Power("player") - s.SpellCost(s.CastingName(nil, "player"), SPELL_POWER_RAGE) >= 70 or s.BuffDuration(85730--[[Deadly Calm]], "player") > (s.SpellCooldown(z.SpellID) + x.Lag) ) and s.CheckIfSpellCastable(z)
end

a.Castable["Spell Reflection"] = function()
	wipe(z)
	z.SpellID = 23920--[[Spell Reflection]]
	z.EnemyTargetNeeded = 1
	return ( ( s.EnemyTargetingYou("focus") and s.GetCasting(nil, "focus") > s.SpellCooldown(z.SpellID) + x.DoubleLag ) or ( s.EnemyTargetingYou("enemy") and s.GetCasting(nil, "enemy") > (s.SpellCooldown(z.SpellID) + x.DoubleLag) ) ) and s.CheckIfSpellCastable(z)
end

a.Castable["Strike"] = function()
	wipe(z)
	z.SpellID = 88161--[[Strike]]
	z.EnemyTargetNeeded = 1
	return not s.TalentMastery() and s.CheckIfSpellCastable(z)
end

local SunderArmorAndFaerieFire = {
	7386--[[Sunder Armor]],
	91565--[[Faerie Fire]],
}
a.Castable["Sunder Armor"] = function()
	wipe(z)
	z.SpellID = 7386--[[Sunder Armor]]
	z.Debuff = SunderArmorAndFaerieFire
	z.Stack = 3
	z.EarlyRefresh = 10
	z.EnemyTargetNeeded = 1
	return s.CheckIfSpellCastable(z)
end

a.Castable["Taunt"] = function()
	wipe(z)
	z.SpellID = 355--[[Taunt]]
	return s.EnemyTargetingYourFriend() and s.CheckIfSpellCastable(z)
end

a.Castable["Thunder Clap"] = function(Debuff)
	wipe(z)
	z.SpellID = 6343--[[Thunder Clap]]
	z.Debuff = Debuff
	z.NoRangeCheck = 1
	z.EnemyTargetNeeded = 1
	return s.MeleeDistance() and s.CheckIfSpellCastable(z)
end

a.Castable["Victory Rush"] = function()
	wipe(z)
	z.SpellID = 34428--[[Victory Rush]]
	z.EnemyTargetNeeded = 1
	return s.CheckIfSpellCastable(z)
end

a.Castable["Whirlwind"] = function()
	wipe(z)
	z.SpellID = 1680--[[Whirlwind]]
	z.NoRangeCheck = 1
	z.EnemyTargetNeeded = 1
	return s.MeleeDistance() and s.CheckIfSpellCastable(z)
end

a.Castable["Bloodthirst"] = function()
	wipe(z)
	z.SpellID = 23881--[[Bloodthirst]]
	z.EnemyTargetNeeded = 1
	return s.CheckIfSpellCastable(z)
end

a.Castable["Mortal Strike"] = function()
	wipe(z)
	z.SpellID = 12294--[[Mortal Strike]]
	z.EnemyTargetNeeded = 1
	return s.CheckIfSpellCastable(z)
end

a.Castable["Shield Slam"] = function()
	wipe(z)
	z.SpellID = 23922--[[Shield Slam]]
	z.EnemyTargetNeeded = 1
	return s.CheckIfSpellCastable(z)
end

a.Castable["Bladestorm"] = function()
	wipe(z)
	z.SpellID = 46924--[[Bladestorm]]
	z.EnemyTargetNeeded = 1
	return s.MeleeDistance() and s.CheckIfSpellCastable(z)
end

a.Castable["Concussion Blow"] = function()
	wipe(z)
	z.SpellID = 12809--[[Concussion Blow]]
	z.EnemyTargetNeeded = 1
	z.Interrupt = 1
	return s.CheckIfSpellCastable(z)
end

a.Castable["Deadly Calm"] = function()
	wipe(z)
	z.SpellID = 85730--[[Deadly Calm]]
	z.EnemyTargetNeeded = 1
	return s.InCombat() and s.Power("player") - s.SpellCost(s.CastingName(nil, "player"), SPELL_POWER_RAGE) < 50 and s.NotDieing() and s.CheckIfSpellCastable(z)
end

a.Castable["Death Wish"] = function()
	wipe(z)
	z.SpellID = 12292--[[Death Wish]]
	z.EnemyTargetNeeded = 1
	return s.InCombat() and s.MeleeDistance() and s.NotDieing() and s.CheckIfSpellCastable(z)
end

a.Castable["Devastate"] = function()
	wipe(z)
	z.SpellID = 20243--[[Devastate]]
	z.EnemyTargetNeeded = 1
	return s.CheckIfSpellCastable(z)
end

a.Castable["Heroic Fury"] = function()
	wipe(z)
	z.SpellID = 60970--[[Heroic Fury]]
	z.EnemyTargetNeeded = 1
	return s.Rooted("player") and s.CheckIfSpellCastable(z)
end

a.Castable["Last Stand"] = function()
	wipe(z)
	z.SpellID = 12975--[[Last Stand]]
	z.EnemyTargetNeeded = 1
	return ( s.InCombat() or s.EnemyTargetingYou("focus") or s.EnemyTargetingYou("enemy") ) and s.HealthPercent("player") <= 10 and s.CheckIfSpellCastable(z)
end

a.Castable["Piercing Howl"] = function()
	wipe(z)
	z.SpellID = 12323--[[Piercing Howl]]
	z.EnemyTargetNeeded = 1
	return CheckInteractDistance(s.UnitSelection(), 3) and s.CheckIfSpellCastable(z)
end

a.Castable["Raging Blow"] = function(EvenIfNotUsable)
	wipe(z)
	z.SpellID = 85288--[[Raging Blow]]
	z.EnemyTargetNeeded = 1
	z.EvenIfNotUsable = EvenIfNotUsable
	return s.CheckIfSpellCastable(z)
end

a.Castable["Shockwave"] = function()
	wipe(z)
	z.SpellID = 46968--[[Shockwave]]
	z.EnemyTargetNeeded = 1
	return CheckInteractDistance(s.UnitSelection(), 3) and s.CheckIfSpellCastable(z)
end

a.Castable["Sweeping Strikes"] = function()
	wipe(z)
	z.SpellID = 12328--[[Sweeping Strikes]]
	z.EnemyTargetNeeded = 1
	return s.MeleeDistance() and s.CheckIfSpellCastable(z)
end

a.Castable["Throwdown"] = function()
	wipe(z)
	z.SpellID = 85388--[[Throwdown]]
	z.EnemyTargetNeeded = 1
	z.Interrupt = 1
	return s.CheckIfSpellCastable(z)
end

