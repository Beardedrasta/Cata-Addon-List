local MinBuild, MaxBuild, Build = 40000, 0, select(4, GetBuildInfo())
if Build < MinBuild or ( MaxBuild > 0 and Build > MaxBuild ) then return end
local AddonName, a = ...
local AddonTitle = select(2, GetAddOnInfo(AddonName))
local PlainAddonTitle = AddonTitle:gsub("|c........", ""):gsub("|r", "")
local L = a.Localize
local s = SpellFlashAddon
local x = SpellFlashAddon.UpdatedVariables

local function SetColor(UseColor, Color, ElseColor)
	if UseColor then
		return Color
	end
	return ElseColor or "Pink"
end

--[[
	White - Default
	Yellow - Limited Time or No Global Cooldown
	Purple - AOE or Positional Damage
	Blue - AOE Debuff
	Orange - Finishing Move
	Aqua - Spell Interrupt, Reflect or Dispel
	Green - Self Buff or Turn Autocast On
	Red - Emergency Mitigation Cooldowns or Turn Autocast Off
	Pink - Optional
]]

-- SpellFlash API: http://wow.curseforge.com/addons/spellflash/pages/api/
-- x.Enemy, x.ActiveEnemy, x.NoCC, x.InInstance, x.InstanceType, x.PetAlive, x.PetActiveEnemy, x.PetNoCC, x.Lag, x.DoubleLag, x.ThreatPercent, x.EnemyDetected, x.ShouldPermanentBuff, x.ShouldTemporaryBuff


local MeleeClasses = {
	"Death Knight",
	"Hunter",
	"Paladin",
	"Rogue",
	"Shaman",
	"Warrior",
}

local HasteDebuffs = {
	6343--[[Thunder Clap]],
	8042--[[Earth Shock]],
	59921--[[Frost Fever]],
	53695--[[Judgements of the Just]],
	50285--[[Dust Cloud]],
	90314--[[Tailspin]],
}

-- Use this single spam function and remove the multiple spam table below, or just use the multiple spam table below and leave this function in place.
s.Spam[AddonName] = function()
	
	if s.MeleeDistance() then a:ClearTimer("Charge") end
	
	if s.Flashable(6673--[[Battle Shout]]) and a.Castable["Battle Shout"]() then
		s.Flash(6673--[[Battle Shout]], SetColor(x.ActiveEnemy and s.Power("player") - s.SpellCost(s.CastingName(nil, "player"), SPELL_POWER_RAGE) < 50 and s.NotDieing(), "Yellow", "Green"))
	end
	if s.Flashable(469--[[Commanding Shout]]) and a.Castable["Commanding Shout"]() then
		s.Flash(469--[[Commanding Shout]], SetColor(x.ActiveEnemy and s.Power("player") - s.SpellCost(s.CastingName(nil, "player"), SPELL_POWER_RAGE) < 50 and s.NotDieing(), "Yellow", "Green"))
	end
	
	if x.ActiveEnemy and s.Flashable(85730--[[Deadly Calm]]) and a.Castable["Deadly Calm"]() then
		s.Flash(85730--[[Deadly Calm]], "Green")
	end
	if x.ActiveEnemy and s.Flashable(1134--[[Inner Rage]]) and a.Castable["Inner Rage"]() then
		s.Flash(1134--[[Inner Rage]], "Green")
	end
	if x.ActiveEnemy and s.Flashable(12292--[[Death Wish]]) and a.Castable["Death Wish"]() then
		s.Flash(12292--[[Death Wish]], "Green")
	elseif x.ActiveEnemy and s.Flashable(20230--[[Retaliation]]) and a.Castable["Retaliation"]() then
		s.Flash(20230--[[Retaliation]], "Pink")
	elseif x.ActiveEnemy and s.Flashable(1719--[[Recklessness]]) and a.Castable["Recklessness"]() then
		s.Flash(1719--[[Recklessness]], "Pink")
	end
	
	if s.Flashable(12975--[[Last Stand]]) and a.Castable["Last Stand"]() then
		s.Flash(12975--[[Last Stand]], "Red")
	elseif s.Flashable(55694--[[Enraged Regeneration]]) and a.Castable["Enraged Regeneration"]() then
		s.Flash(55694--[[Enraged Regeneration]], "Red")
	elseif s.Flashable(871--[[Shield Wall]]) and a.Castable["Shield Wall"]() then
		s.Flash(871--[[Shield Wall]], "Red")
	end
	
	if s.Flashable(18499--[[Berserker Rage]]) and a.Castable["Berserker Rage"]() and s.CrowedControlled("player") then
		s.Flash(18499--[[Berserker Rage]], "Aqua")
	elseif s.Flashable(6552--[[Pummel]]) and a.Castable["Pummel"]() then
		s.Flash(6552--[[Pummel]], SetColor(x.ActiveEnemy, "Aqua"))
	elseif s.Flashable(72--[[Shield Bash]]) and a.Castable["Shield Bash"]() then
		s.Flash(72--[[Shield Bash]], SetColor(x.ActiveEnemy, "Aqua"))
	elseif s.Flashable(12809--[[Concussion Blow]]) and a.Castable["Concussion Blow"]() then
		s.Flash(12809--[[Concussion Blow]], SetColor(x.ActiveEnemy, "Aqua"))
	elseif s.Flashable(85388--[[Throwdown]]) and a.Castable["Throwdown"]() then
		s.Flash(85388--[[Throwdown]], SetColor(x.ActiveEnemy, "Aqua"))
	elseif s.Flashable(23920--[[Spell Reflection]]) and a.Castable["Spell Reflection"]() then
		s.Flash(23920--[[Spell Reflection]], "Aqua")
	elseif s.Flashable(60970--[[Heroic Fury]]) and a.Castable["Heroic Fury"]() then
		s.Flash(60970--[[Heroic Fury]], "Aqua")
	end
	
	if x.NoCC and not x.ActiveEnemy and s.Flashable(57755--[[Heroic Throw]]) and a.Castable["Heroic Throw"]() then
		s.Flash(57755--[[Heroic Throw]], "Pink")
	end
	
	if s.Flashable(3411--[[Intervene]]) and a.Castable["Intervene"]() then
		s.Flash(3411--[[Intervene]], SetColor(s.ActiveEnemy(s.UnitSelection().."target") and UnitIsUnit(s.UnitSelection().."targettarget", s.UnitSelection())))
	elseif x.NoCC and s.Flashable(100--[[Charge]]) and a.Castable["Charge"]() then
		s.Flash(100--[[Charge]], SetColor(x.ActiveEnemy))
	elseif x.NoCC and s.Flashable(20252--[[Intercept]]) and a.Castable["Intercept"]() then
		s.Flash(20252--[[Intercept]], SetColor(x.ActiveEnemy))
	elseif x.NoCC and s.Flashable(57755--[[Heroic Throw]]) and a.Castable["Heroic Throw"]() then
		s.Flash(57755--[[Heroic Throw]], SetColor(x.ActiveEnemy))
	else
		
		if s.Flashable(355--[[Taunt]]) and a.Castable["Taunt"]() then
			s.Flash(355--[[Taunt]], "Pink")
		end
		
		if x.ActiveEnemy and s.Flashable(1160--[[Demoralizing Shout]]) and a.Castable["Demoralizing Shout"]() then
			s.Flash(1160--[[Demoralizing Shout]], "Blue")
		end
		
		if x.ActiveEnemy and s.Flashable(2565--[[Shield Block]]) and a.Castable["Shield Block"]() then
			s.Flash(2565--[[Shield Block]], "Pink")
		end
		
		if x.ActiveEnemy then
			if s.Flashable(845--[[Cleave]]) and a.Castable["Cleave"]() then
				s.Flash(845--[[Cleave]], "Purple")
			elseif s.HasTalent(84614--[[Blood and Thunder]]) and s.Flashable(772--[[Rend]]) and a.Castable["Rend"]() then
				s.Flash(772--[[Rend]], "Purple")
			elseif s.Flashable(6343--[[Thunder Clap]]) and a.Castable["Thunder Clap"]() then
				s.Flash(6343--[[Thunder Clap]], "Purple")
			elseif s.Flashable(46968--[[Shockwave]]) and a.Castable["Shockwave"]() then
				s.Flash(46968--[[Shockwave]], "Purple")
			elseif s.Flashable(1680--[[Whirlwind]]) and a.Castable["Whirlwind"]() then
				s.Flash(1680--[[Whirlwind]], "Purple")
			elseif s.Flashable(12328--[[Sweeping Strikes]]) and a.Castable["Sweeping Strikes"]() then
				s.Flash(12328--[[Sweeping Strikes]], "Purple")
			elseif s.Flashable(46924--[[Bladestorm]]) and a.Castable["Bladestorm"]() then
				s.Flash(46924--[[Bladestorm]], "Purple")
			end
		end
		
		if x.NoCC and s.SpellCooldown(23922--[[Shield Slam]]) > s.SpellCooldown(78--[[Heroic Strike]]) and s.Flashable(78--[[Heroic Strike]]) and a.Castable["Heroic Strike"]() then
			s.Flash(78--[[Heroic Strike]], SetColor(x.ActiveEnemy, "Yellow"))
		elseif x.NoCC and s.Flashable(23922--[[Shield Slam]]) and s.HasTalent(86894--[[Heavy Repercussions]]) and ( s.CurrentSpell(2565--[[Shield Block]]) or s.SpellDelay(2565--[[Shield Block]]) or s.Buff(2565--[[Shield Block]], "player") ) and a.Castable["Shield Slam"]() then
			s.Flash(23922--[[Shield Slam]], SetColor(x.ActiveEnemy, "Yellow"))
		elseif x.NoCC and s.Flashable(78--[[Heroic Strike]]) and a.Castable["Heroic Strike"]() then
			s.Flash(78--[[Heroic Strike]], SetColor(x.ActiveEnemy, "Yellow"))
		elseif s.Flashable(1715--[[Hamstring]]) and x.ActiveEnemy and a.Castable["Hamstring"]() then
			s.Flash(1715--[[Hamstring]], "Yellow")
		elseif x.NoCC and s.HasTalent(46913--[[Bloodsurge]]) and s.Buff(46916--[[Bloodsurge]], "player") and s.Flashable(1464--[[Slam]]) and a.Castable["Slam"]() then
			s.Flash(1464--[[Slam]], SetColor(x.ActiveEnemy, "Yellow"))
		elseif x.NoCC and s.Flashable(34428--[[Victory Rush]]) and a.Castable["Victory Rush"]() then
			s.Flash(34428--[[Victory Rush]], SetColor(x.ActiveEnemy, "Yellow"))
		elseif x.NoCC and s.HasTalent(84583--[[Lambs to the Slaughter]]) and s.Flashable(12294--[[Mortal Strike]]) and a.Castable["Mortal Strike"]() then
			s.Flash(12294--[[Mortal Strike]], SetColor(x.ActiveEnemy))
		elseif x.NoCC and s.Flashable(7384--[[Overpower]]) and a.Castable["Overpower"]() then
			s.Flash(7384--[[Overpower]], SetColor(x.ActiveEnemy, "Yellow"))
		elseif x.NoCC and s.Flashable(5308--[[Execute]]) and a.Castable["Execute"]() then
			s.Flash(5308--[[Execute]], SetColor(x.ActiveEnemy, "Yellow"))
		elseif x.NoCC and ( s.HasTalent(56636--[[Taste for Blood]]) or s.HasTalent(29836--[[Blood Frenzy]]) ) and s.Flashable(772--[[Rend]]) and a.Castable["Rend"]() then
				s.Flash(772--[[Rend]], SetColor(x.ActiveEnemy, "Yellow"))
		elseif s.HasTalent(86894--[[Heavy Repercussions]]) and x.ActiveEnemy and s.Flashable(2565--[[Shield Block]]) and a.Castable["Shield Block"]() then
			s.Flash(2565--[[Shield Block]], "Yellow")
		elseif x.NoCC and s.Flashable(23922--[[Shield Slam]]) and a.Castable["Shield Slam"]() then
			s.Flash(23922--[[Shield Slam]], SetColor(x.ActiveEnemy))
		elseif x.NoCC and s.Flashable(6572--[[Revenge]]) and a.Castable["Revenge"]() then
			s.Flash(6572--[[Revenge]], SetColor(x.ActiveEnemy, "Yellow"))
		elseif x.NoCC and s.Flashable(23881--[[Bloodthirst]]) and a.Castable["Bloodthirst"]() then
			s.Flash(23881--[[Bloodthirst]], SetColor(x.ActiveEnemy))
		elseif x.NoCC and s.Flashable(12294--[[Mortal Strike]]) and a.Castable["Mortal Strike"]() then
			s.Flash(12294--[[Mortal Strike]], SetColor(x.ActiveEnemy))
		elseif x.NoCC and s.Flashable(88161--[[Strike]]) and a.Castable["Strike"]() then
			s.Flash(88161--[[Strike]], SetColor(x.ActiveEnemy))
		elseif x.NoCC and s.Flashable(85288--[[Raging Blow]]) and a.Castable["Raging Blow"]() then
			s.Flash(85288--[[Raging Blow]], SetColor(x.ActiveEnemy, "Yellow"))
		elseif x.ActiveEnemy and s.Flashable(85288--[[Raging Blow]]) and s.Flashable(18499--[[Berserker Rage]]) and a.Castable["Raging Blow"](1) and a.Castable["Berserker Rage"]() then
			s.Flash(18499--[[Berserker Rage]], "Yellow")
		elseif x.NoCC and s.Flashable(86346--[[Colossus Smash]]) and a.Castable["Colossus Smash"]() then
			s.Flash(86346--[[Colossus Smash]], SetColor(x.ActiveEnemy))
		else
			
			if x.ActiveEnemy and s.Flashable(676--[[Disarm]]) and a.Castable["Disarm"]() then
				if not s.Player() then
					s.Flash(676--[[Disarm]], "Pink")
				elseif s.Class(nil, MeleeClasses) then
					s.Flash(676--[[Disarm]], "Aqua")
				end
			end
			
			if x.ActiveEnemy and s.Flashable(6343--[[Thunder Clap]]) and a.Castable["Thunder Clap"](HasteDebuffs) then
				s.Flash(6343--[[Thunder Clap]], "Blue")
			end
			
			if x.ActiveEnemy and s.Flashable(64382--[[Shattering Throw]]) and a.Castable["Shattering Throw"]() then
				s.Flash(64382--[[Shattering Throw]], "Pink")
			end
			
			if x.NoCC and s.Flashable(772--[[Rend]]) and s.NotDieing() and a.Castable["Rend"]() then
				s.Flash(772--[[Rend]], SetColor(x.ActiveEnemy))
			elseif x.NoCC and s.Flashable(20243--[[Devastate]]) and a.Castable["Devastate"]() then
				s.Flash(20243--[[Devastate]], SetColor(x.ActiveEnemy))
			else
				
				if x.NoCC and s.Flashable(1464--[[Slam]]) and a.Castable["Slam"]() then
					s.Flash(1464--[[Slam]], SetColor(x.ActiveEnemy))
				end
				
				if x.ActiveEnemy then
					if a.Castable["Auto Attack"]() then
						s.Flash(6603--[[Auto Attack]])
					end
					if a.Castable["Attack"]() then
						s.Flash(88163--[[Attack]])
					end
					if s.Flashable(7386--[[Sunder Armor]]) and not s.Flashable(20243--[[Devastate]]) and a.Castable["Sunder Armor"]() then
						s.Flash(7386--[[Sunder Armor]], "Pink")
					end
				end
			end
		end
	end
	
end

