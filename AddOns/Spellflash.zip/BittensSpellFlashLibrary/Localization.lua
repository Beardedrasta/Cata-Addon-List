-- To update a translation please use the localization utility at:
-- http://wow.curseforge.com/addons/bitten-common/localization/

local AddonName, a = ...
local function DefaultFunction(_, key) return key end
a.Localize = setmetatable({}, {__index = DefaultFunction})
local L = a.Localize

-- Example:
L["English text goes here."] = "Translated text goes here."

if GetLocale() == "ptBR" then -- Brazilian Portuguese
-- L["Print Debugging Info"] = ""

elseif GetLocale() == "frFR" then -- French
-- L["Print Debugging Info"] = ""

elseif GetLocale() == "deDE" then -- German
-- L["Print Debugging Info"] = ""

elseif GetLocale() == "koKR" then -- Korean
-- L["Print Debugging Info"] = ""

elseif GetLocale() == "esMX" then -- Latin American Spanish
-- L["Print Debugging Info"] = ""

elseif GetLocale() == "ruRU" then -- Russian
-- L["Print Debugging Info"] = ""

elseif GetLocale() == "zhCN" then -- Simplified Chinese
-- L["Print Debugging Info"] = ""

elseif GetLocale() == "esES" then -- Spanish
-- L["Print Debugging Info"] = ""

elseif GetLocale() == "zhTW" then -- Traditional Chinese
-- L["Print Debugging Info"] = ""

end