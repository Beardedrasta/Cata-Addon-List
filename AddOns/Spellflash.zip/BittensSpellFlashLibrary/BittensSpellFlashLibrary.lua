BittensSpellFlashLibrary = {}
local s = SpellFlashAddon
local c = BittensSpellFlashLibrary

c.BLEED_DEBUFFS = {
	"Mangle", 
	"Trauma", 
	"Hemorrhage", 
	"Tendon Rip", 
	"Gore", 
	"Stampede"}
c.WEAKEN_DEBUFFS = {
	"Curse of Weakness",
	"Demoralizing Roar", 
	"Demoralizing Shout", 
	"Scarlet Fever", 
	"Vindication"}
c.SLOW_MELEE_DEBUFFS = {
	"Judgements of the Just", 
	"Infected Wounds", 
	"Frost Fever", 
	"Thunder Clap", 
	"Earth Shock", 
	"Dust Cloud", 
	"Hurricane", 
	"Tailspin"}
c.SPELL_DAMAGE_DEBUFFS = {
	"Curse of the Elements",
	"Jinx: Curse of the Elements",
	"Master Poisoner",
	"Ebon Plaguebringer",
	"Earth and Moon",
	"Fire Breath",
	"Lightning Breath"}
c.SPELL_CRIT_DEBUFFS = {
	"Shadow and Flame",
	"Critical Mass"}

function c.userFlagged(switch)
	return s.GetModuleConfig(c.addonName, switch)
end

function c.run(func, spec, offSwitch)
	if s.TalentMastery(spec) and not c.userFlagged(offSwitch) then
		func()
	end
end

function c.isFlashable(spell)
	id = spell.SpellID
	--print("  ", id)
	if not s.Flashable(id) then
		--print("  (not flashable)")
		return false
	end
	
	if spell.NoGCD and GetSpellCooldown(id) > 0 then
		--print("  (on cooldown)")
		return false
	end
	
	if spell.RequiresBuff and not c.hasBuff(spell.RequiresBuff) then
		--print("  (missing buff", spell.RequiresBuff, ")")
		return false
	end
	
	if spell.MeleeDistance and not s.MeleeDistance() then
		--print("  (not in melee distance)")
		return false
	end
	
	if spell.ConfigEnabled and not c.userFlagged(spell.ConfigEnabled) then
		--print("  (not enabled by user:", spell.ConfigEnabled, ")")
		return false
	end
	
	if spell.ExtraCheck and not spell.ExtraCheck() then
		--print("  (fails extra check)")
		return false
	end
	
	if spell.OverrideCheck then
		if not spell.OverrideCheck() then
			--print("  (fails override)")
			return false
		end
	else
		if not s.CheckIfSpellCastable(spell) then
			--print("  (not castable)")
			return false
		end
	end
	
	return true
end

local function flashSpell(spell, ...)
	if c.isFlashable(spell) then
		s.Flash(spell.SpellID, ...)
		return true
	else
		return false
	end
end

local function flashItem(item, ...)
	id = item.ItemID
	if not s.ItemFlashable(id) then
		return false
	end
	
	if GetItemCooldown(id) > 0 then
		return false
	end
	
	if item.ExtraCheck and not item.ExtraCheck() then
		return false
	end
	
	s.FlashItem(id, ...)
	return true
end

function c.flash(name, ...)
	spellOrItem = c.spells[name]
	if not spellOrItem then
		print("No spell defined: ", name)
	elseif spellOrItem.SpellID then
		return flashSpell(spellOrItem, ...)
	elseif spellOrItem.ItemID then
		return flashItem(spellOrItem, ...)
	else
		print("No id found found for ", name)
	end
	return false
end

function c.priorityFlash(color, ...)
	for i=1,select("#", ...) do
		name = select(i, ...)
		spellOrItem = c.spells[name]
		if not spellOrItem then
			print("No spell defined: ", name)
		elseif spellOrItem.Optional then
			c.flash(name, "yellow")
		elseif c.flash(name, color) then
			return name
		end
	end
	return nil
end

function c.flashAll(color, ...)
	flashing = false
	for i=1,select("#", ...) do
		if c.flash(select(i, ...), color) then
			flashing = true
		end
	end
	return flashing
end

function c.rotateCooldowns(uncontrolledBuffs, ...)
	for i=1,select("#", uncontrolledBuffs) do
		if s.Buff(select(i, uncontrolledBuffs), "player") then
			return
		end
	end
	for i=1,select("#", ...) do
		name = select(i, ...)
		if c.spells[name].Buff then
			name = c.spells[name].Buff
		end
		if s.Buff(name, "player") then
			return
		end
	end
	for i=1,select("#", ...) do
		if c.flash(select(i, ...), "yellow") then
			return
		end
	end
end

function c.getGcdUp()
	up = GetTime()
	cast = s.Casting(nil, "player")
	if cast then
		up = cast + up
	end
	start,duration,t = GetSpellCooldown(c.gcdSpell)
	if start > 0 and start + duration > up then
		return start + duration
	else
		return up
	end
end

function c.getBusyTime()
	gcd = s.SpellCooldown(c.gcdSpell)
	casting = s.Casting("player")
	if gcd then
		if casting then
			if gcd > casting then
				return gcd
			else
				return casting
			end
		else
			return gcd
		end
	elseif casting then
		return casting
	else
		return 0
	end
end

function c.getCooldown(spell)
	cd,t = s.SpellCooldown(spell)
	return cd - c.getBusyTime()
end

function c.getBuffDuration(name)
	return s.BuffDuration(name, "player") - c.getBusyTime()
end

function c.hasBuff(name, durationRequired, noncombatDurationRequired)
	if noncombatDurationRequired and not s.InCombat() then
		durationRequired = noncombatDurationRequired
	elseif not durationRequired then
		durationRequired = .2
	end
	return c.getBuffDuration(name) > durationRequired
end

function c.getMyDebuffDuration(name, unit)
	return s.MyDebuffDuration(name, unit) - c.getBusyTime()
end

function c.hasMyDebuff(name, durationRequired)
	if not durationRequired then
		durationRequired = 0
	end
	return c.getMyDebuffDuration(name) > durationRequired
end

function c.isOnCooldown(spell)
	return c.getCooldown(spell) > 0
end

function c.isSlowed(timeRemaining)
	return s.Debuff(c.SLOW_MELEE_DEBUFFS, nil, timeRemaining)
end

function c.isWeakened(timeRemaining)
	return s.Debuff(c.WEAKEN_DEBUFFS, nil, timeRemaining)
end
