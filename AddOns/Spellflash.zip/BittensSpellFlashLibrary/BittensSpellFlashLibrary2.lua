local MinBuild, MaxBuild, Build = 40000, 0, select(4, GetBuildInfo())
if Build < MinBuild or ( MaxBuild > 0 and Build > MaxBuild ) then return end
local s = SpellFlashAddon
local x = s.UpdatedVariables

BittensSpellFlashLibrary2 = {}
local c = BittensSpellFlashLibrary2
local AddonName
local a

local libraryAddonName, libraryTable = ...
BINDING_HEADER_BITTENS_SPELLFLASH = select(2, GetAddOnInfo(libraryAddonName))
BINDING_NAME_BITTENS_SPELLFLASH_DEBUGGING
    = libraryTable.Localize["Print Debugging Info"]

local HideHilighting = false
hooksecurefunc(
    "ActionButton_ShowOverlayGlow", 
    function(self)
        if HideHilighting and self.overlay then
            self.overlay:Hide()
            ActionButton_HideOverlayGlow(self)
        end
    end)
s.AddSettingsListener(
    function()
        HideHilighting = false
    end)

c.Debugging = false

c.SLOW_MELEE_DEBUFFS = {
    68055, -- Judgements of the Just 
    58180, -- Infected Wounds 
    59921, -- Frost Fever 
    6343, -- Thunder Clap 
    8042, -- Earth Shock 
    50285, -- Dust Cloud 
    16914, -- Hurricane 
    90314, --Tailspin
}

c.ARMOR_DEBUFFS = {
    7386, -- Sunder Armor
    8647, -- Expose Armor
    91565, -- Faerie Fire
    35387, -- Corrosive Spit
    50498, -- Tear Armor
}

c.PHYSICAL_DAMAGE_DEBUFFS = {
    702, -- Curse of Weakness
    99, -- Demoralizing Roar
    1160, -- Demoralizing Shout 
    81130, -- Scarlet Fever 
    26017, -- Vindication
}

c.BLEED_DEBUFFS = {
    33876, -- Mangle
    46857, -- Trauma
    16511, -- Hemorrhage
    50271, -- Tendon Rip
    35290, -- Gore
    57386, -- Stampede
}

c.FIVE_PERCENT_BUFFS = {
    1126, -- Mark of the Wild
    20217, -- Blessing of Kings
    90363, -- Embrace of the Shale Spider
}

c.STAMINA_BUFFS = {
    79105, -- Power Word: Fortitude
    90364, -- Qiraji Fortitude
    6307, -- Blood Pact
    469, -- Commanding Shout
}

c.SHADOW_RESISTANCE_BUFFS = {
    19891, -- Resistance Aura
    79107, -- Shadow Protection
}

c.INTELLECT_BUFFS = {
    1459, -- Arcane Brilliance
    61316, -- Dalaran Brilliance
    52109, -- Flametongue Totem
    54424, -- Fel Intelligence
}

c.MANA_BUFFS = {
    1459, -- Arcane Brilliance
    61316, -- Dalaran Brilliance
    54424, -- Fel Intelligence
}

c.ATTACK_POWER_BUFFS = {
    79102, -- Blessing of Might
    53138, -- Abomination's Might
    19506, -- Trueshot Aura
    30808, -- Unleashed Rage
}

c.MP5_BUFFS = {
    19740, -- Blessing of Might
    5675, -- Mana Spring Totem
    54424, -- Fel Intelligence
}

c.CRIT_DEBUFFS = {
    22959, -- Critical Mass
    17800, -- Shadow and Flame
}

c.BLOODLUST_BUFFS = {
    90355, -- Ancient Hysteria
    80353, -- Time Warp
    2825, -- Bloodlust
    32182, -- Heroism
}

function c.Init(addonName, addonTable)
    AddonName = addonName
    a = addonTable
end

local function getCurrentRotation(addonTable)
    for _, rotation in pairs(addonTable.Rotations) do
        if (rotation.CheckFirst == nil or rotation.CheckFirst())
            and rotation.Spec == s.TalentMastery()
            and (rotation.OffSwitch == nil
                or not addonTable.GetConfig(rotation.OffSwitch))
            and (rotation.Form == nil or s.Form(c.GetID(rotation.Form))) then
            
            return rotation
        end
    end
    return nil
end

function c.Flash(addonName, addonTable)
    local rotation = getCurrentRotation(addonTable)
    if rotation ~= nil then
        HideHilighting = true
        c.Init(addonName, addonTable)
        if rotation.Function then -- depricated, do not use, will be phased out.
            rotation.Function()
        else
            if rotation.FlashAlways then
                rotation.FlashAlways()
            end
            if s.InCombat() then
                if rotation.FlashInCombat then
                    rotation.FlashInCombat()
                end
            else
                if rotation.FlashOutOfCombat then
                    rotation.FlashOutOfCombat()
                end
            end
        end
    end
end

local spellTargets = {}
local startedSpells = {}
local frame = CreateFrame("frame")
--frame:RegisterEvent("UNIT_SPELLCAST_FAILED")
--frame:RegisterEvent("UNIT_SPELLCAST_FAILED_QUIET")
--frame:RegisterEvent("UNIT_SPELLCAST_INTERRUPTED")
frame:RegisterEvent("UNIT_SPELLCAST_SENT")
frame:RegisterEvent("UNIT_SPELLCAST_START")
--frame:RegisterEvent("UNIT_SPELLCAST_STOP")
--frame:RegisterEvent("UNIT_SPELLCAST_SUCCEEDED")
frame:SetScript("OnEvent", 
    function(self, event, unitID, spell, rank, target, lineID)
        if not UnitIsUnit(unitID, "player") then
            return
        end
        
        event = event:sub(16)
        if event == "SENT" then
            spellTargets[lineID] = target
            startedSpells[lineID] = nil
        elseif event == "START" then
            startedSpells[lineID] = true
        end
    end
)
function c.GetCurrentCastTarget()
    local _, _, _, _, _, _, _, castID = UnitCastingInfo("player")
    if castID then
        return spellTargets[castID]
    else
        return nil
    end
end

local function maybeCast(func, ...)
    if func then
        func(...)
    end
end
function c.RegisterForEvents(addonName, addonTable)
--    s.RegisterModuleEvent(
--        addonName,
--        "UNIT_SPELLCAST_SENT",
--        function(_, unitID, spell, rank, target, lineID)
--            local rotation = getCurrentRotation(addonTable)
--            if rotation ~= nil
--                and rotation.SpellcastSent ~= nil
--                and UnitIsUnit(unitID, "player") then
--                
--                c.Init(addonName, addonTable)
--                rotation.event.SpellcastSent(spell, target)
--            end
--        end)
    local function registerCastEvent(eventName, handlerName, requireStart)
        s.RegisterModuleEvent(
            addonName,
            eventName,
            function(event, unitID, spell, rank, lineID, spellID)
                if not UnitIsUnit(unitID, "player")
                    or (requireStart and not startedSpells[lineID]) then
                    
                    return
                end
                
                local rotation = getCurrentRotation(addonTable)
                if rotation ~= nil and rotation[handlerName] ~= nil then
                    rotation[handlerName](spellID, spellTargets[lineID])
                end
            end
        )
    end
    registerCastEvent("UNIT_SPELLCAST_START", "CastStarted")
    registerCastEvent("UNIT_SPELLCAST_INTERRUPTED", "CastFailed")
    registerCastEvent("UNIT_SPELLCAST_FAILED", "CastFailed", true)
    registerCastEvent("UNIT_SPELLCAST_FAILED_QUIET", "CastFailed", true)
    registerCastEvent("UNIT_SPELLCAST_SUCCEEDED", "CastSucceeded")
    s.RegisterModuleEvent(
        addonName,
        "COMBAT_LOG_EVENT_UNFILTERED",
        function(_, ...)
            local source = select(5, ...)
            if source == nil or not UnitIsUnit(source, "player") then
                return
            end
            
            local rotation = getCurrentRotation(addonTable)
            if rotation == nil then
                return
            end
            
            c.Init(addonName, addonTable)
            
            local event = select(2, ...)
            local target = select(9, ...)
            local spellID = select(12, ...)
            local spellSchool = select(13, ...)
            --print("log", event)
--            if event == "SPELL_CAST_START" then
--                
--                maybeCast(rotation.SpellcastStarted, 
--                    spellID, target, spellSchool)
--            elseif event == "SPELL_CAST_SUCCESS" then
--            
--                maybeCast(rotation.SpellcastSucceeded,
--                    spellID, target, spellSchool)
--            elseif event == "SPELL_CAST_FAILED" then
--                
--                local failType = select(15, ...)
--                maybeCast(rotation.SpellcastFailed,
--                    spellID, target, failType, spellSchool)
--            else
            if event == "SPELL_DAMAGE"
                or event == "SPELL_PERIODIC_DAMAGE" then
                
                local amount = select(15, ...)
                local damageSchool = select(17, ...)
                local critical = select(21, ...)
                maybeCast(rotation.SpellDamage,
                    spellID,
                    target,
                    amount,
                    critical,
                    spellSchool,
                    damageSchool)
            elseif event == "SPELL_AURA_APPLIED"
                or event == "SPELL_AURA_FREFRESH" then
                
                maybeCast(rotation.AuraApplied, spellID, target, spellSchool)
            elseif event == "SPELL_AURA_REMOVED" then
            
                maybeCast(rotation.AuraRemoved, spellID, target, spellSchool)
            end
        end)
end

-- This function is depricated.  It will be phased out.  Use c.Flash()
function c.Run(...)
    for i=1,select("#", ...) do
        local runInfo = select(i, ...)
        
        local func = runInfo[1]
        local spec = runInfo[2]
        local offSwitch = runInfo[3]
        local form = runInfo[4]
        
        if s.TalentMastery(spec) 
            and not a.GetConfig(offSwitch) 
            and (form == nil or s.Form(c.GetID(form))) then
            
            HideHilighting = true
            func()
            return
        end
    end
    HideHilighting = false
end

-- remove in favor of a.GetConfig() when possible
function c.Selected(switch)
    return s.GetModuleConfig(AddonName, switch)
end

function c.RotateCooldowns(uncontrolledBuffs, ...)
    for tmp,id in pairs(uncontrolledBuffs) do
        if s.Buff(id, "player") then
            return
        end
    end
    for i=1,select("#", ...) do
        local buff = select(i, ...)
        local spell = a.spells[buff]
        if spell and spell.Buff then
            buff = spell.Buff
        end
        if c.HasBuff(buff, spell.NoGCD, spell.EarlyRefresh) then
            return
        end
    end
    return a.Flash(...)
end

function c.HasBuff(name, noGCD, durationRequired)
    local duration = s.BuffDuration(c.GetID(name), "player")
    
    -- duration == 0 for permanent buffs, so check that here
    if duration == 0 then
        return s.Buff(c.GetID(name), "player")
    end

    if durationRequired == nil then
        durationRequired = 0
    end    
    return duration - c.GetBusyTime(noGCD) >= durationRequired
end

function c.GetBuffDuration(name, noGCD)
    return math.max(
        s.BuffDuration(c.GetID(name), "player") - c.GetBusyTime(noGCD), 0)
end

function c.GetBuffStack(name)
    if c.HasBuff(name) then
        return s.BuffStack(c.GetID(name), "player")
    else
        return 0
    end
end

function c.HasMyDebuff(name, noGCD, durationRequired)
    if not durationRequired then
        durationRequired = 0
    end
    return c.GetMyDebuffDuration(name, noGCD) > durationRequired
end

function c.GetMyDebuffDuration(name, noGCD)
    return math.max(s.MyDebuffDuration(c.GetID(name)) - c.GetBusyTime(noGCD), 0)
end

function c.GetDebuffDuration(name, noGCD)
    return math.max(0, s.DebuffDuration(c.GetID(name)) - c.GetBusyTime(noGCD))
end

function c.GetBusyTime(noGCD)
    local casting = s.GetCastingOrChanneling(nil, "player")
    if noGCD then
        return casting
    else
        local global, _ = s.GlobalCooldown()
        if global ~= nil and global > casting then
            return global
        else
            return casting
        end
    end
end

function c.GetCooldown(name)
    return math.max(0, s.SpellCooldown(c.GetID(name)) - c.GetBusyTime())
end

function c.GetIDs(...)
    local ids = {}
    for i=1,select("#", ...) do
        local id = c.GetID(select(i, ...))
        if id then
            table.insert(ids, id)
        end
    end
    return ids
end

function c.GetID(name)
    local spell = a.spells[name]
    if spell and spell.ID then
        return spell.ID
    else
        print("No spell defined (or no ID attribute):", name)
    end
end

function c.SelfBuffNeeded(name)
    if s.InCombat() then
        return not c.HasBuff(name)
    else
        return not c.HasBuff(name, false, 5 * 60)
    end
end

function c.RaidBuffNeeded(idTable)
    local duration = 0
    if not s.InCombat() then
        duration = 5 * 60
    end
    local flags = "raid|all|range"
    if idTable == c.INTELLECT_BUFFS then
        flags = flags .. "|mana"
    end
    return not s.Buff(idTable, flags, duration)
end

function c.Debug(tag, ...)
    if c.Debugging then
        return print("|cFF00FFFF["..tag.."]|r", ...)
    end
end

function c.IsCasting(name)
    return s.CurrentSpell(c.GetID(name))
end

function c.IsCastingOrInAir(name)
    return c.IsCasting(name) or s.SpellDelay(c.GetID(name))
end

function c.IsAuraPendingFor(name)
    return c.IsCastingOrInAir(name) or s.AuraDelay(c.GetID(name))
end

function c.IsTanking()
    local status = UnitThreatSituation("player", "target")
    return status == 2 or status == 3
end

function c.CheckFirstForTaunts(z)
    local primaryTarget = s.GetPrimaryThreatTarget()
    if not primaryTarget or UnitIsUnit(primaryTarget, "player") then
        return false
    end
    
    if UnitGroupRolesAssigned(primaryTarget) == "TANK" then
        z.FlashSize = s.FlashSizePercent() / 2
        z.FlashColor = "yellow"
    else
        z.FlashSize = nil
        z.FlashColor = "red"
    end
    return true
end

function c.IsInGroup()
    return GetNumPartyMembers() > 0 or GetNumRaidMembers() > 1
end

-- remove when possible.  compare spell ids from events instead.
function c.SpellsAreEqual(blizzardSpellName, codeSpellName)
    return blizzardSpellName == s.SpellName(c.GetID(codeSpellName), 1)
end

local function calculateDotRefresh(event, unitID, spell, rank, lineID, spellID)
    if not UnitIsUnit(unitID, "player") or not a.ManagedDots[spellID] then
        return
    end
    
    for name, unhasted in pairs(a.ManagedDots[spellID]) do
        local tick = unhasted / (1 + UnitSpellHaste("player") / 100)
        a.spells[name].EarlyRefresh = math.max(0, tick - .1)
        c.Debug("Library", name, "ticks every", tick)
    end
end

function c.ManageDotRefresh(name, unhastedTick, spellID)
    if not spellID then
        spellID = c.GetID(name)
    end
    if not a.ManagedDots then
        a.ManagedDots = {}
    end
    if not a.ManagedDots[spellID] then
        a.ManagedDots[spellID] = {}
    end
    a.ManagedDots[spellID][name] = unhastedTick
    s.RegisterModuleEvent(
        AddonName, "UNIT_SPELLCAST_SUCCEEDED", calculateDotRefresh)
end

function c.WearingSet(number, name)
    local count = 0
    for slot, piece in pairs(a.EquipmentSets[name]) do
        if s.Equipped(piece, slot) then
            count = count + 1
        end
    end
    return count >= number
end

function c.EstimateTravelTime(name)
    local spell = a.spells[name]
    local id = spell.ID
    local travel, lastSeen = s.LastSpellTravelTime(id)
    if travel == nil then
        travel = spell.TravelTimeEstimate
        if travel == nil then
            print(name, "does not define TravelTimeEstimate")
            travel = 1
        end
        lastSeen = 0
    end
    
    if spell.SameTravelTimeAs ~= nil then
        for _, name in pairs(spell.SameTravelTimeAs) do
            local t, l = s.LastSpellTravelTime(c.GetID(name))
            if t ~= nil and l < lastSeen then
                travel = t
                lastSeen = l
            end
        end
    end
    return travel
end

local function incrementIfLandingRel(
    count, startDelay, endDelay, castDelay, travelTime, toPrint)
    
    if castDelay == nil then
        return count
    end
    
    local landDelay = castDelay + travelTime
    if startDelay <= landDelay and landDelay <= endDelay then
        if toPrint then
            c.Debug("Balance", toPrint)
        end
        return count + 1
    else
        return count
    end
end

local function incrementIfLandingAbs(
    count, startDelay, endDelay, startTime, travelTime, toPrint)
    
    if startTime then
        return incrementIfLandingRel(
            count,
            startDelay,
            endDelay,
            startTime - GetTime(),
            travelTime,
            toPrint)
    else
        return count
    end
end

function c.CountLandings(name, startDelay, endDelay, countNextCast)
    local count = 0
    local id = c.GetID(name)
    local travel = c.EstimateTravelTime(name)
    
    -- in the air
    local timesForAllTargets = s.SpellTravelStartTime(id, "all")
    local foundCurrent = false
    if timesForAllTargets then
        for _, timesForOneTarget in pairs(timesForAllTargets) do
            for _, timesForOneLaunch in pairs(timesForOneTarget) do
                local estimated, actual = unpack(timesForOneLaunch)
                if actual == nil then
                    foundCurrent = true
                end
                count = incrementIfLandingAbs(
                    count, startDelay, endDelay, estimated, travel)
            end
        end
    end
    
    -- currently casting
    if c.IsCasting(name) and not foundCurrent then
        count = incrementIfLandingRel(
            count, startDelay, endDelay, s.CastTime(id), travel)
    end
    
    -- will have time to cast
    if countNextCast then
        count = incrementIfLandingRel(
            count,
            startDelay,
            endDelay,
            c.GetBusyTime() + s.CastTime(id),
            travel)
    end
    
    return count
end
