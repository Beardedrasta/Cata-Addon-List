local MinBuild, MaxBuild, Build = 40000, 0, select(4, GetBuildInfo())
if Build < MinBuild or ( MaxBuild > 0 and Build > MaxBuild ) then return end
local AddonName, a = ...
local AddonTitle = select(2, GetAddOnInfo(AddonName))
local PlainAddonTitle = AddonTitle:gsub("|c........", ""):gsub("|r", "")
local L = a.Localize
local s = SpellFlashAddon
local x = s.UpdatedVariables
local config = {}
config.event = {}

config.CheckButtonOptions = {
	LeftCheckButton1 = {
		DefaultChecked = true,
		ConfigKey = "solo_off",
		Label = L["Solo Mode when not Grouped"],
	},
	LeftCheckButton2 = {
		DefaultChecked = true,
		ConfigKey = "assassination_off",
		Label = L["Flash Assassination"],
	},
	LeftCheckButton3 = {
		DefaultChecked = true,
		ConfigKey = "combat_off",
		Label = L["Flash Combat"],
	},
	LeftCheckButton4 = {
		DefaultChecked = true,
		ConfigKey = "My_Config_Key",
		Label = L["My_Check_Button_Label"],
	},
	LeftCheckButton5 = {
		DefaultChecked = true,
		ConfigKey = "My_Config_Key",
		Label = L["My_Check_Button_Label"],
	},
	LeftCheckButton6 = {
		DefaultChecked = true,
		ConfigKey = "My_Config_Key",
		Label = L["My_Check_Button_Label"],
	},
	LeftCheckButton7 = {
		DefaultChecked = true,
		ConfigKey = "My_Config_Key",
		Label = L["My_Check_Button_Label"],
	},
	RightCheckButton1 = {
		DefaultChecked = true,
		ConfigKey = "My_Config_Key",
		Label = L["My_Check_Button_Label"],
	},
	RightCheckButton2 = {
		DefaultChecked = false,
		ConfigKey = "My_Config_Key",
		Label = L["My_Check_Button_Label"],
	},
	RightCheckButton3 = {
		DefaultChecked = true,
		ConfigKey = "My_Config_Key",
		Label = L["My_Check_Button_Label"],
	},
	RightCheckButton4 = {
		DefaultChecked = true,
		ConfigKey = "My_Config_Key",
		Label = L["My_Check_Button_Label"],
	},
	RightCheckButton5 = {
		DefaultChecked = true,
		ConfigKey = "My_Config_Key",
		Label = L["My_Check_Button_Label"],
	},
	RightCheckButton6 = {
		DefaultChecked = true,
		ConfigKey = "My_Config_Key",
		Label = L["My_Check_Button_Label"],
	},
	RightCheckButton7 = {
		DefaultChecked = true,
		ConfigKey = "My_Config_Key",
		Label = L["My_Check_Button_Label"],
	},
}

a.LoadConfigs(config)