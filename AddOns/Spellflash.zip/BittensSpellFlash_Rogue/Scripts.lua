local MinBuild, MaxBuild, Build = 40000, 0, select(4, GetBuildInfo())
if Build < MinBuild or ( MaxBuild > 0 and Build > MaxBuild ) then return end
local AddonName, a = ...
local AddonTitle = select(2, GetAddOnInfo(AddonName))
local PlainAddonTitle = AddonTitle:gsub("|c........", ""):gsub("|r", "")
local L = a.Localize
local s = SpellFlashAddon
local x = s.UpdatedVariables

local c = BittensSpellFlashLibrary2
a.Rotations = {}

s.Spam[AddonName] = function()
    c.Flash(AddonName, a)
end

a.Rotations.Assassination = {
    Spec = 1,
    OffSwitch = "assassination_off",
    Function = function()
        a.FlashAll("Deadly Poison", "Instant Poison")
        if not s.InCombat() then
            a.Flash("Recouperate")
            return
        end
        
        a.FlashAll("Vendetta", "Vanish")
        local snd = c.GetBuffDuration("Slice and Dice")
        if snd > .1 and snd < 3 then
            a.Flash("Envenom")
        else
            a.Flash(
                "Slice and Dice",
                "Rupture",
                "Smart Envenom",
                "Backstab",
                "Mutilate")
        end
    end
}

a.Rotations.Combat = {
    Spec = 2,
    OffSwitch = "combat_off",
    Function = function()
        a.FlashAll("Wound Poison", "Deadly Poison", "Instant Poison")
        if not s.InCombat() then
            a.Flash("Recouperate")
            return
        end
        
        c.RotateCooldowns({}, "Adrenaline Rush", "Killing Spree")
        a.Flash(
            "Slice and Dice",
            "Expose Armor",
            "Rupture unless SnD",
            "Eviscerate",
            "Revealing Strike",
            "Sinister Strike")
    end
}
