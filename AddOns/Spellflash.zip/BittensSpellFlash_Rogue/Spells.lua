local MinBuild, MaxBuild, Build = 40000, 0, select(4, GetBuildInfo())
if Build < MinBuild or ( MaxBuild > 0 and Build > MaxBuild ) then return end
local AddonName, a = ...
local AddonTitle = select(2, GetAddOnInfo(AddonName))
local PlainAddonTitle = AddonTitle:gsub("|c........", ""):gsub("|r", "")
local L = a.Localize
local s = SpellFlashAddon
local x = s.UpdatedVariables

local c = BittensSpellFlashLibrary2

local function inSoloMode()
    return (not s.InRaidOrParty()) and (not a.GetConfig("solo_off"))
end

------------------------------------------------------------------------ common
local poisons = { 
    L["Wound Poison"], 
    L["Instant Poison"],
    L["Deadly Poison"],
}

local function isMissingAPoison()
    local min
    if s.InCombat() then
        min = 0
    else
        min = 5 * 60
    end
    return not s.MainHandItemBuff(poisons, min)
        or not s.OffHandItemBuff(poisons, min)
end

local function getEnergyRegen()
    return select(2, GetPowerRegen())
end

a.spells["Wound Poison"] = {
    Type = "item",
    ID = 10918,
    FlashColor = "yellow",
    CheckFirst = isMissingAPoison,
}

a.spells["Instant Poison"] = {
    Type = "item",
    ID = 6947,
    FlashColor = "yellow",
    CheckFirst = isMissingAPoison,
}

a.spells["Deadly Poison"] = {
    Type = "item",
    ID = 2892,
    FlashColor = "yellow",
    CheckFirst = isMissingAPoison,
}

a.spells["Slice and Dice"] = {
    ID = 5171,
    Buff = 5171,
    BuffUnit = "player",
    NoRangeCheck = 1,
    CheckFirst = function()
        return not inSoloMode()
    end
}

a.spells["Recouperate"] = {
    ID = 73651,
    NoRangeCheck = 1,
    FlashColor = "yellow",
    CheckFirst = function()
        return s.HealthPercent("player") < 100
    end
}

----------------------------------------------------------------- assassination
local function inExecute()
    return s.HealthPercent() < 35
        and not c.IsTanking()
        and s.TalentRank(14158) == 2 -- Murderous Intent
end

local function doFinisher()
    local cp = GetComboPoints("player")
    return cp == 5 or (not inExecute() and cp == 4)
end

a.spells["Overkill"] = { ID = 58427 }

a.spells["Garrote"] = {
    ID = 703,
}

a.spells["Mutilate"] = {
    ID = 1329,
    CheckFirst = function()
        return GetComboPoints("player") < 4 and not inExecute()
    end
}

a.spells["Backstab"] = {
    ID = 53,
    CheckFirst = function()
        return GetComboPoints("player") < 5 and inExecute()
    end
}

a.spells["Envenom"] = {
    ID = 32645,
}

a.spells["Smart Envenom"] = {
    ID = 32645,
    CheckFirst = function()
        if not doFinisher() then
            return false
        end
        
        if inSoloMode() then
            return true
        end
        
        local rupture = a.spells["Rupture"]
        local refresh = s.MyDebuffDuration(rupture.ID)
        local regen = getEnergyRegen()
        local untilCap = s.MaxPower("player") - s.Power("player") - regen
        return refresh > untilCap / regen
            and (not c.HasBuff("Envenom")
                or untilCap <= regen * c.GetBusyTime())
    end
}

a.spells["Rupture"] = {
    ID = 1943,
    MyDebuff = 1943,
    EarlyRefresh = 2,
    Continue = 1,
    FlashColor = "yellow",
    CheckFirst = function()
        if inSoloMode() or not doFinisher() then
            return false
        end
        
        local regen = getEnergyRegen()
        local t = c.GetBusyTime()
        local e = s.Power("player") + t * regen
        
        -- sim casting rupture
        t = t + 1
        e = e - 25 + regen
        if GetComboPoints("player") == 5
            and s.TalentRank(14179) == 3 then -- Relentless Strikes
            
            e = e + 25
        end
        
        -- sim generating at least one combo point
        t = t + 1
        if inExecute() then
            e = e - 30 + regen
        else
            e = e - 55 + regen
        end
        
        -- ensure we can cast envenom before SnD wears off
        t = s.BuffDuration(c.GetID("Slice and Dice"), "player") - t
        e = e + t * regen
        return t > .5 and e >= 35
    end
}

a.spells["Vendetta"] = {
    ID = 79140,
    FlashColor = "yellow",
}

a.spells["Vanish"] = {
    ID = 1856,
    NoGCD = true,
    FlashColor = "yellow",
    CheckFirst = function()
        return not inSoloMode()
            and not c.HasBuff("Overkill", true)
            and not c.HasMyDebuff("Garrote", true)
            and GetComboPoints("player") < 5
    end
}

------------------------------------------------------------------------ combat

local function sndIsNext()
    -- Can we wait for SnD to wear off without capping?
    -- Only called at 4 or 5 combo points, so no need to consider double combo
    -- point generation.
    local SnD = a.spells["Slice and Dice"]
    local timeTillRefresh = s.BuffDuration(SnD.ID, "player")
    return not inSoloMode()
        and s.Power("player")
                 + getEnergyRegen() * (timeTillRefresh + 1)
                 - (5 - GetComboPoints("player")) * 39
            < s.MaxPower("player")
end

a.spells["Blade Flurry"] = { ID = 13877 }

a.spells["Adrenaline Rush"] = {
    ID = 13750,
    NoGCD = 1,
    FlashColor = "yellow",
    CheckFirst = function()
        return s.Power("player") < 20
    end
}

a.spells["Killing Spree"] = {
    ID = 51690,
    FlashColor = "yellow",
    NoRangeCheck = 1,
    CheckFirst = function()
        return s.Power("player") < 20
    end
}

a.spells["Expose Armor"] = {
    ID = 8647,
    Debuff = c.ARMOR_DEBUFFS,
    EarlyRefresh = 5,
    Continue = 1,
    FlashColor = "yellow",
    CheckFirst = function()
        return GetComboPoints("player") == 5
            and not sndIsNext()
            and not inSoloMode()
    end
}

a.spells["Rupture unless SnD"] = {
    ID = 1943,
    MyDebuff = 1943,
    EarlyRefresh = 2,
    RequireDebuff = c.BLEED_DEBUFFS,
    Continue = 1, 
    FlashColor = "yellow",
    CheckFirst = function()
        return GetComboPoints("player") == 5
            and not sndIsNext()
            and not s.Buff("Blade Flurry", "player")
            and not inSoloMode()
    end
}

a.spells["Eviscerate"] = {
    ID = 2098,
    CheckFirst = function()
        return GetComboPoints("player") == 5
            and (not sndIsNext() or inSoloMode())
    end
}

a.spells["Revealing Strike"] = {
    ID = 84617,
    MyDebuff = 84617,
    EarlyRefresh = 2,
    CheckFirst = function()
        return GetComboPoints("player") == 4 and not sndIsNext()
    end
}

-- improvement: wait before putting on that 5th combo point to get a better
-- estimate on sndIsNext()
a.spells["Sinister Strike"] = {
    ID = 1752,
    CheckFirst = function()
        local cp = GetComboPoints("player") 
        return cp < 4 or (cp == 4 and sndIsNext())
    end
}
