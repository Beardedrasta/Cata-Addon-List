local MinBuild, MaxBuild, Build = 40000, 0, select(4, GetBuildInfo())
if Build < MinBuild or ( MaxBuild > 0 and Build > MaxBuild ) then return end
local AddonName, a = ...
local AddonTitle = select(2, GetAddOnInfo(AddonName))
local PlainAddonTitle = AddonTitle:gsub("|c........", ""):gsub("|r", "")
local L = a.Localize
local s = SpellFlashAddon
local x = s.UpdatedVariables

local c = BittensSpellFlashLibrary2
c.Init(AddonName, a)
a.EquipmentSets = {}

------------------------------------------------------------------------ Common
a.spells["Clearcasting"] = { ID = 16870 }
a.spells["Eclipse (Lunar)"] = { ID = 48518 }
a.spells["Eclipse (Solar)"] = { ID = 48517 }
a.spells["Nature's Grace"] = { ID = 16886 }

a.spells["Mark of the Wild"] = {
    ID = 1126,
    FlashColor = "yellow",
    NoRangeCheck = 1,
    CheckFirst = function()
        return c.RaidBuffNeeded(c.FIVE_PERCENT_BUFFS)
    end
}

----------------------------------------------------------------------- Balance
a.spells["Sunfire"] = { ID = 93402 }

a.spells["Moonkin Form"] = {
    Type = "form",
    ID = 24858,
}

a.spells["Insect Swarm"] = {
    ID = 5570,
    MyDebuff = 5570,
    EarlyRefresh = 1,
}
c.ManageDotRefresh("Insect Swarm", 2)

local function moonfireCheckFirst(moonfireEarlyRefresh, sunfireEarlyRefresh)
    return c.GetMyDebuffDuration("Moonfire") <= moonfireEarlyRefresh
        and c.GetMyDebuffDuration("Sunfire") <= sunfireEarlyRefresh
        and (c.GetMyDebuffDuration("Insect Swarm")
                > 3 + a.spells["Insect Swarm"].EarlyRefresh
            or c.IsCastingOrInAir("Insect Swarm"))
end

a.spells["Moonfire"] = {
    ID = 8921,
    FlashID = { 8921, 93402 }, -- Moonfire/Sunfire
    EarlyRefresh = 1,
    CheckFirst = function(z)
        return moonfireCheckFirst(z.EarlyRefresh, 0)
    end
}
c.ManageDotRefresh("Moonfire", 2)

a.spells["Tricky Sunfire"] = {
    ID = 8921, -- for some reason, using moonfire's id works better
    FlashID = { 8921, 93402 }, -- Moonfire/Sunfire
    MyDebuff = 93402,
    EarlyRefresh = 1,
    CheckFirst = function(z)
        return moonfireCheckFirst(0, z.EarlyRefresh)
    end
}
c.ManageDotRefresh("Tricky Sunfire", 2, 93402)

a.spells["Starfire"] = {
    ID = 2912,
}

a.spells["Wrath"] = {
    ID = 5176,
}

a.spells["Force of Nature"] = {
    ID = 33831,
    NoRangeCheck = 1,
    Continue = 1,
    FlashColor = "yellow",
}

a.spells["Starfall"] = {
    ID = 48505,
    Continue = 1,
    FlashColor = "yellow",
}

a.spells["Starsurge"] = {
    ID = 78674,
    NotIfActive = 1,
}

------------------------------------------------------------------------- Feral
a.EquipmentSets.FeralT13 = {
    HeadSlot = { 78789, 77015, 78694 },
    ShoulderSlot = { 78838, 77017, 78743 },
    ChestSlot = { 78760, 77013, 78665 },
    HandsSlot = { 78779, 77014, 78684 },
    LegsSlot = { 78808, 77016, 78713 },
}

a.spells["Berserk"] = {
    ID = 50334,
    NoGCD = true,
    FlashColor = "yellow",
}

a.spells["Faerie Fire (Feral)"] = {
    ID = 16857,
}

a.spells["Faerie Fire (Feral) to 3"] = {
    ID = 16857,
    Debuff = c.ARMOR_DEBUFFS,
    Stack = 3,
    EarlyRefresh = 30,
}

-------------------------------------------------------------------------- Bear
a.spells["Bear Form"] = { ID = 5487 }

a.spells["Survival Instincts"] = {
    ID = 61336,
    NoGCD = true,
    FlashColor = "yellow",
}

a.spells["Barkskin"] = {
    ID = 22812,
    NoGCD = true,
    FlashColor = "yellow",
}

a.spells["Berserk for Mitigation"] = {
    ID = 50334,
    NoGCD = true,
    FlashColor = "yellow",
    CheckFirst = function()
        return c.HasBuff("Pulverize", false, 8)
            and c.HasMyDebuff("Lacerate", false, 9)
            and s.MyDebuffStack("Lacerate") == 3
    end
}

a.spells["Enrage"] = {
    ID = 5229,
    NoGCD = true,
    FlashColor = "yellow",
}

a.spells["Frenzied Regeneration"] = {
    ID = 22842,
    Unit = "player",
    NoGCD = true,
    FlashColor = "yellow",
    CheckFirst = function()
        return s.HealthPercent("player") < 90
    end
}

a.spells["Maul"] = {
    ID = 6807,
    NoGCD = true,
    FlashColor = "yellow",
}

a.spells["Demoralizing Roar"] = {
    ID = 99,
    Debuff = c.PHYSICAL_DAMAGE_DEBUFFS,
    EarlyRefresh = 3,
    Melee = 1,
}

a.spells["Thrash"] = {
    ID = 77758,
    Melee = 1, 
    NoRangeCheck = 1,
}

a.spells["Lacerate"] = {
    ID = 33745,
}

a.spells["Lacerate to 3"] = {
    ID = 33745,
    Stack = 3,
    Run = function(self)
        if s.AuraDelay(c.GetID("Pulverize")) then
            -- pulverize is about to consume lacerate, so don't bother checking
            -- the stack count
            c.Debug("Bear", "pulverize detected")
            self.MyDebuff = nil
        else
            self.MyDebuff = 33745
        end
    end
}

a.spells["Pulverize"] = {
    ID = 80313,
    Buff = 80313,
    BuffUnit = "player",
    EarlyRefresh = 1.5,
    RequireMyDebuff = a.spells["Lacerate"].ID,
    RequireStack = 3,
}

a.spells["Bear Mangle"] = {
    ID = 33878,
}

a.spells["Bear Mangle for Debuff"] = {
    ID = 33878,
    Debuff = c.SLOW_MELEE_DEBUFFS,
}

a.spells["Feral Charge(Bear Form)"] = {
    ID = 16979,
}

a.spells["Growl"] = {
    ID = 6795,
    NoGCD = true,
    CheckFirst = c.CheckFirstForTaunts,
}

a.spells["Challenging Roar"] = {
    ID = 5209,
    CheckFirst = c.CheckFirstForTaunts,
}

--------------------------------------------------------------------------- Cat
a.spells["Cat Form"] = { ID = 768 }
a.spells["Stampede"] = { ID = 81022 }

local function capWarning()
    local regen = select(2, GetPowerRegen())
    return s.Power("player") + regen * (1 + c.GetBusyTime()) > 100
end

a.spells["Survival Instincts under 30"] = {
    ID = 61336,
    NoGCD = true,
    FlashColor = "red",
    CheckFirst = function()
        return s.HealthPercent("player") < 30
    end
}

a.spells["Barkskin under 30"] = {
    ID = 22812,
    NoGCD = true,
    FlashColor = "red",
    CheckFirst = function()
        return s.HealthPercent("red") < 30
    end
}

a.spells["Feral Charge(Cat Form)"] = {
    ID = 49376,
    NoRangeCheck = 1,
    Continue = 1,
    FlashColor = "yellow",
    CheckFirst = function()
        return s.HasTalent(78892) -- Stampede
            and not c.HasBuff("Berserk")
    end
}

a.spells["Tiger's Fury"] = {
    ID = 5217,
    NoGCD = true,
    FlashColor = "yellow",
    CheckFirst = function()
        local bonus = 20 * s.TalentRank(48492) -- King of the Jungle
        return (bonus == 0 or s.Power("player") < 90 - bonus) 
            and GetComboPoints("player") < 5
            and not c.HasBuff("Stampede")
    end
}

a.spells["Kitty Berserk"] = {
    ID = 50334,
    NoGCD = true,
    FlashColor = "yellow",
    CheckFirst = function()
        return s.Power("player") >= 80
            and c.GetCooldown("Tiger's Fury") > 3
    end
}

a.spells["Optional Faerie Fire (Feral) to 3"] = {
    ID = 16857,
    Debuff = c.ARMOR_DEBUFFS,
    Stack = 3,
    EarlyRefresh = 30,
    Continue = 1,
    FlashColor = "yellow",
}

a.spells["Cat Mangle"] = {
    ID = 33876,
}

a.spells["Cat Mangle for Bleed Debuff"] = {
    ID = 33876,
    CheckFirst = function(z)
        local duration = s.DebuffDuration(c.BLEED_DEBUFFS)
        local rake = c.GetMyDebuffDuration("Rake")
        if math.abs(duration - rake) < 1 then
            return duration < 3
        else
            return duration < 2
        end
    end
}

a.spells["Rip"] = {
    ID = 1079,
    MyDebuff = 1079,
    EarlyRefresh = 1.9,
    CheckFirst = function()
        return GetComboPoints("player") == 5
    end
}

a.spells["Rake"] = {
     ID = 1822,
    MyDebuff = 1822,
    EarlyRefresh = 1.9,
}

a.spells["Savage Roar"] = {
    ID = 52610,
    NoRangeCheck = 1,
    CheckFirst = function()
        if c.GetBuffDuration("Savage Roar") > a.RipDuration + 3 then
            return false
        end
        
        local buildup = a.CatSimulator.TimeToFive(25, "Savage Roar")
        return buildup < a.RipDuration
            and (buildup + 1.5 > a.RipDuration
                or (GetComboPoints("player") == 5
                    and (not c.HasBuff("Savage Roar")
                        or capWarning()
                        or c.HasBuff("Berserk"))))
    end
}

local function ravageOverride(z)
    duration = c.GetBuffDuration("Stampede")
    points = GetComboPoints("player")
    return duration > 0
        and s.MeleeDistance() 
        and (duration < 3 or (points < 5 and s.Power("player") < 80))
        and not s.SpellDelay(z.FlashID)
end

a.spells["Ravage"] = {
    ID = 6785, 
    FlashID = {6785, 81170}, -- "Ravage!"
    Override = ravageOverride,
}

a.spells["Ravage!"] = {
    ID = 81170, 
    FlashID = {6785, 81170}, -- "Ravage"
    Override = ravageOverride,
}

a.spells["Ferocious Bite conservative"] = {
    ID = 22568,
    CheckFirst = function()
        if GetComboPoints("player") < 5 then
            return false
        end
        
        if c.GetBuffDuration("Savage Roar") < a.RipDuration + 3 then
            return false
        end
        
        return a.RipDuration > a.CatSimulator.TimeToFive(35, "FB conservative")
    end
}

a.spells["Ferocious Bite to save Rip"] = {
    ID = 22568,
    CheckFirst = function()
        if c.WearingSet(2, "FeralT13") then
            maxHealth = 60
        else
            maxHealth = 25
        end
        return a.RipDuration > .2 
            and a.RipDuration < 3
            and s.HealthPercent() < maxHealth
    end
}

a.spells["Ferocious Bite during execute"] = {
    ID = 22568,
    CheckFirst = function()
        if c.WearingSet(2, "FeralT13") then
            maxHealth = 60
        else
            maxHealth = 25
        end
        return a.RipDuration > .2 
            and GetComboPoints("player") == 5
            and s.HealthPercent() < maxHealth
    end
}

local function order(t1, t2)
    if t1 < t2 then
        return t1, t2
    else
        return t2, t1
    end
end

a.spells["Shred"] = {
    ID = 5221,
    CheckFirst = function()
        local cp = GetComboPoints("player")
        local firstRefresh, secondRefresh = order(
            c.GetMyDebuffDuration("Rake"),
            s.DebuffDuration(c.BLEED_DEBUFFS) - c.GetBusyTime())
        local finisherRefresh = c.GetBuffDuration("Savage Roar")
        if a.RipDuration < finisherRefresh + 6 then
            finisherRefresh = a.RipDuration
        end
        
        -- shred to avoid capping
        if capWarning() 
            and (finisherRefresh == 0 or finisherRefresh > 2.5)
            and (firstRefresh > 2.5 or cp < 4)
            and (secondRefresh > 3.5 or cp < 3) then
            
            return true
        end
        
        -- pool if we will have enough combo points without shred
        if not c.HasBuff("Berserk")
            and (cp == 5
                or (cp == 4 and firstRefresh < finisherRefresh)
                or (cp == 3 and secondRefresh < finisherRefresh)) then
                
            return false
        end
        
        -- shred unless it would not leave enough energy to refresh things
        a.CatSimulator.Init("shred")
        a.CatSimulator.PoolThenCast(40)
        a.CatSimulator.PoolThenCast(35)
        if a.CatSimulator.Time > firstRefresh + 1 then
            return false
        end
        a.CatSimulator.PoolThenCast(35)
        if a.CatSimulator.Time > secondRefresh + 1 then
            return false
        end
        return true
    end
}

-------------------------------------------------------------------------- Tree
a.spells["Power Torrent"] = { ID = 74241 }

a.spells["Innervate"] = {
    ID = 29166,
    Unit = "player",
    CheckFirst = function()
        return s.PowerPercent("player") < 75 and c.HasBuff("Power Torrent")
    end
}

a.spells["Swiftmend"] = {
    ID = 18562,
    Override = function()
        return c.GetCooldown("Swiftmend") == 0
    end
}

a.spells["Tree of Life"] = {
    ID = 33891,
}

a.spells["Regrowth"] = {
    ID = 8936,
    Unit = "player",
}
