local MinBuild, MaxBuild, Build = 40000, 0, select(4, GetBuildInfo())
if Build < MinBuild or ( MaxBuild > 0 and Build > MaxBuild ) then return end
local AddonName, a = ...
local AddonTitle = select(2, GetAddOnInfo(AddonName))
local PlainAddonTitle = AddonTitle:gsub("|c........", ""):gsub("|r", "")
local L = a.Localize
local s = SpellFlashAddon
local x = s.UpdatedVariables

local c = BittensSpellFlashLibrary2

a.CatSimulator = {}
local u = a.CatSimulator

u.Time = 0
u.ComboPoints = 0
u.Energy = 0

local berserk
local missChance
local crit
local regen
local furyCD
local clearcasting
local stampede
local idleTime

local function advance(elapse)
    u.Time = u.Time + elapse
    u.Energy = u.Energy + elapse * regen
    berserk = berserk - elapse
    furyCD = furyCD - elapse
end

-- may not actually pool all the way to target; this should be in a loop
local function poolTo(target)
    local elapse = (target - u.Energy) / regen
    if elapse > furyCD then
        c.Debug("sim", "Tiger's Fury")
        u.Energy = u.Energy + s.TalentRank(48492) * 20 -- King of the Jungle
        furyCD = 30
        stampede = a.GetConfig("feral_4pT13")
            and s.HasTalent(78892) -- Blood in the Water
    else
        c.Debug("sim", "wait for", elapse)
        advance(elapse)
        u.Energy = target -- to eliminate truncation errors
        idleTime = idleTime + elapse
    end
end

local function cast(cost)
    if stampede then
        cost = 0
        stampede = false
        c.Debug("sim", "stampede")
    elseif clearcasting then
        cost = 0
        clearcasting = false
        c.Debug("sim", "clearcast")
    elseif berserk > 0 then
        cost = cost / 2
    end
    
    if u.Energy < cost then
        return false
    end
    
    c.Debug("sim", "cp for", cost)
    u.ComboPoints
        = u.ComboPoints
            + (1 + crit * s.TalentRank(37116) / 2) -- Primal Fury
                * (1 - miss)
    u.Energy = u.Energy - cost * (1 - miss)
    advance(1)
    return true
end

function u.Init(extraTag)
    berserk = c.GetBuffDuration("Berserk")
    miss = math.max(0, .08 - GetCombatRating(CR_HIT_MELEE) / 12000)
    crit = math.max(0, GetCritChance() / 100 - .048)
    regen = select(2, GetPowerRegen())
    furyCD = c.GetCooldown("Tiger's Fury")
    clearcasting = c.HasBuff("Clearcasting")
    stampede = c.HasBuff("Stampede")
    idleTime = 0
    
    u.Time = 0
    u.ComboPoints = GetComboPoints("player")
    u.Energy = s.Power("player") + regen * c.GetBusyTime()
    
    c.Debug("sim", "-----------------------------------------------", extraTag)
    c.Debug("sim", "points=", u.ComboPoints)
    c.Debug("sim", "energy=", u.Energy)
    c.Debug("sim", "berserk=", u.Berserk)
    c.Debug("sim", "miss=", miss)
    c.Debug("sim", "crit=", crit)
    c.Debug("sim", "regen=", regen)
    c.Debug("sim", "furyCD=", furyCD)
    c.Debug("sim", "clearcasting=", clearcasting)
    c.Debug("sim", "stampede=", stampede)
end

function u.PoolThenCast(cost)
    while not cast(cost) do
        if berserk > 0 then
            poolTo(cost / 2)
        else
            poolTo(cost)
        end
    end
end

-- The time until you get 5 combo points, if you consume them right now with
-- a spell that uses "cost" energy
function u.TimeToFive(cost, extraTag)
    u.Init(extraTag)
    u.PoolThenCast(cost)
    u.ComboPoints = 0
    
    while u.ComboPoints < 5 do
        c.Debug("sim", u.Time, u.ComboPoints, u.Energy, berserk)
        u.PoolThenCast(40)
    end
    c.Debug("sim", u.Time, u.ComboPoints, u.Energy, berserk, "<- END")
    return u.Time
end
