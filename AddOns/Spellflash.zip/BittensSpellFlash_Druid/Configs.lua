local MinBuild, MaxBuild, Build = 40000, 0, select(4, GetBuildInfo())
if Build < MinBuild or ( MaxBuild > 0 and Build > MaxBuild ) then return end
local AddonName, a = ...
local AddonTitle = select(2, GetAddOnInfo(AddonName))
local PlainAddonTitle = AddonTitle:gsub("|c........", ""):gsub("|r", "")
local L = a.Localize
local s = SpellFlashAddon
local x = s.UpdatedVariables
local config = {}
config.event = {}

local c = BittensSpellFlashLibrary2

function config.event.COMBAT_LOG_EVENT_UNFILTERED(event, ...)
    local source = select(5, ...)
    if not source or not UnitIsUnit(source, "player") then
        return
    end
    
    event = select(2, ...)
    if event == "SPELL_ENERGIZE" then
        c.Init(AddonName, a)
        local spell = select(13, ...)
        local gain = select(15, ...)
        if math.abs(gain) > 20 and math.abs(gain) < 41 then
            c.Debug("Event", "Euphoria from", spell, "gives", gain)
        end
    elseif event == "SPELL_MISSED" then
        c.Init(AddonName, a)
        local id = select(12, ...)
        local spell = select(13, ...)
        if id == c.GetID("Wrath")
            or id == c.GetID("Starsurge")
            or id == c.GetID("Starfire") then
            
            c.Debug("Event", "Miss", spell)
        end
    end
end

config.CheckButtonOptions = {
	LeftCheckButton1 = {
		DefaultChecked = true,
		ConfigKey = "balance_off",
		Label = L["Flash Balance"],
	},
	LeftCheckButton2 = {
		DefaultChecked = true,
		ConfigKey = "bear_off",
		Label = L["Flash Bear"],
	},
	LeftCheckButton3 = {
		DefaultChecked = true,
		ConfigKey = "cat_off",
		Label = L["Flash Cat"],
	},
	LeftCheckButton4 = {
		DefaultChecked = true,
		ConfigKey = "resto_off",
		Label = L["Flash Resto"],
	},
	LeftCheckButton5 = {
		DefaultChecked = true,
		ConfigKey = "My_Config_Key",
		Label = L["My_Check_Button_Label"],
	},
	LeftCheckButton6 = {
		DefaultChecked = true,
		ConfigKey = "My_Config_Key",
		Label = L["My_Check_Button_Label"],
	},
	LeftCheckButton7 = {
		DefaultChecked = true,
		ConfigKey = "My_Config_Key",
		Label = L["My_Check_Button_Label"],
	},
	RightCheckButton1 = {
		DefaultChecked = true,
		ConfigKey = "My_Config_Key",
		Label = L["My_Check_Button_Label"],
	},
	RightCheckButton2 = {
		DefaultChecked = true,
		ConfigKey = "My_Config_Key",
		Label = L["My_Check_Button_Label"],
	},
	RightCheckButton3 = {
		DefaultChecked = true,
		ConfigKey = "My_Config_Key",
		Label = L["My_Check_Button_Label"],
	},
	RightCheckButton4 = {
		DefaultChecked = true,
		ConfigKey = "My_Config_Key",
		Label = L["My_Check_Button_Label"],
	},
	RightCheckButton5 = {
		DefaultChecked = true,
		ConfigKey = "My_Config_Key",
		Label = L["My_Check_Button_Label"],
	},
	RightCheckButton6 = {
		DefaultChecked = true,
		ConfigKey = "My_Config_Key",
		Label = L["My_Check_Button_Label"],
	},
	RightCheckButton7 = {
		DefaultChecked = true,
		ConfigKey = "My_Config_Key",
		Label = L["My_Check_Button_Label"],
	},
}

config.EditBoxOptions = {
	LeftEditBox1 = {
		DefaultValue = "",
		Numeric = false,
		MaxCharacters = 999,
		ConfigKey = "My_Config_Key",
		Label = L["My_Edit_Box_Label:"],
	},
	LeftEditBox2 = {
		DefaultValue = "",
		Numeric = false,
		MaxCharacters = 999,
		ConfigKey = "My_Config_Key",
		Label = L["My_Edit_Box_Label:"],
	},
	RightEditBox1 = {
		DefaultValue = "",
		Numeric = false,
		MaxCharacters = 999,
		ConfigKey = "My_Config_Key",
		Label = L["My_Edit_Box_Label:"],
	},
	RightEditBox2 = {
		DefaultValue = "",
		Numeric = false,
		MaxCharacters = 999,
		ConfigKey = "My_Config_Key",
		Label = L["My_Edit_Box_Label:"],
	},
}

a.LoadConfigs(config)