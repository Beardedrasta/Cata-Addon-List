local MinBuild, MaxBuild, Build = 40000, 0, select(4, GetBuildInfo())
if Build < MinBuild or ( MaxBuild > 0 and Build > MaxBuild ) then return end
local AddonName, a = ...
local AddonTitle = select(2, GetAddOnInfo(AddonName))
local PlainAddonTitle = AddonTitle:gsub("|c........", ""):gsub("|r", "")
local L = a.Localize
local s = SpellFlashAddon
local x = s.UpdatedVariables

local c = BittensSpellFlashLibrary2
a.Rotations = {}

s.Spam[AddonName] = function()
    c.Flash(AddonName, a)
end

----------------------------------------------------------------------- balance
local function estimateTravelTime(name)
    if name == "Starfire" then
        return s.LastSpellTravelTime(c.GetID("Starfire")) or .1
    end
    
    local travel1, time1 = s.LastSpellTravelTime(c.GetID("Wrath"))
    local travel2, time2 = s.LastSpellTravelTime(c.GetID("Starsurge"))
    if travel1 then
        if travel2 then
            if time1 < time2 then
                return travel2
            else
                return travel1
            end
        else
            return travel1
        end
    elseif travel2 then
        return travel2
    else
        return 1.3
    end
end

local function incrementIfLandingRel(
    count, startDelay, endDelay, castDelay, travelTime, toPrint)
    
    if castDelay == nil then
        return count
    end
    
    local landDelay = castDelay + travelTime
    if startDelay <= landDelay and landDelay <= endDelay then
        if toPrint then
            c.Debug("Balance", toPrint)
        end
        return count + 1
    else
        return count
    end
end

local function incrementIfLandingAbs(
    count, startDelay, endDelay, startTime, travelTime, toPrint)
    
    if startTime then
        return incrementIfLandingRel(
            count,
            startDelay,
            endDelay,
            startTime - GetTime(),
            travelTime,
            toPrint)
    else
        return count
    end
end

local function numberLanding(name, startDelay, endDelay, simNextCast)
    local count = 0
    local id = c.GetID(name)
    local travel = estimateTravelTime(name)
    
    -- in the air
    local timesForAllTargets = s.SpellTravelStartTime(id, "all")
    local foundCurrent = false
    if timesForAllTargets then
        for _, timesForOneTarget in pairs(timesForAllTargets) do
            for _, timesForOneLaunch in pairs(timesForOneTarget) do
                local estimated, actual = unpack(timesForOneLaunch)
                if actual == nil then
                    foundCurrent = true
                end
                count = incrementIfLandingAbs(
                    count, startDelay, endDelay, estimated, travel)
            end
        end
    end
    
    -- currently casting
    if c.IsCasting(name) and not foundCurrent then
        count = incrementIfLandingRel(
            count, startDelay, endDelay, s.CastTime(id), travel)
    end
    
    -- will have time to cast
    if simNextCast then
        count = incrementIfLandingRel(
            count,
            startDelay,
            endDelay,
            c.GetBusyTime() + s.CastTime(id),
            travel)
    end
    
    return count
end

local function calcPower(goingUp, startPower, startDelay, endDelay, simNextCast)
    if goingUp then
        return startPower
            + 20 * numberLanding("Starfire", startDelay, endDelay, simNextCast)
            + 15 * numberLanding("Starsurge", startDelay, endDelay)
    else
        return startPower
            - 14 * numberLanding("Wrath", startDelay, endDelay, simNextCast)
            - 15 * numberLanding("Starsurge", startDelay, endDelay)
    end
end

a.Rotations.Balance = {
    Spec = 1,
    OffSwitch = "balance_off",
    Function = function()
        a.FlashAll("Moonkin Form", "Mark of the Wild")
        if not s.InCombat() then
            return
        end
        
        -- calculate state for when the next cast will start
        local power = s.Power("player", SPELL_POWER_ECLIPSE)
        local goingUp = c.HasBuff("Eclipse (Lunar)")
             or (not c.HasBuff("Eclipse (Solar)") and power >= 0)
        local busyTime = c.GetBusyTime()
        power = calcPower(goingUp, power, -3, busyTime)
        local eclipse
        if goingUp then
            goingUp = power < 100
            eclipse = power < 0 or power >= 100
        else
            goingUp = power <= -100
            eclipse = power > 0 or power <= -100
        end
        local eclipseSoon
        local futurePower = calcPower(
            goingUp, power, busyTime, 3 + busyTime, true)
        if goingUp then
            eclipseSoon = not eclipse and futurePower >= 100
        else
            eclipseSoon = not eclipse and futurePower <= -100
        end
        
        --"Force of Nature"
        --"Starfall if Lunar"
        --"Lunar Moonfire with Glyph of Starfire, unless eclipse w/in 2 casts"
        --"Insect Swarm, unless eclipse w/in 2 seconds"
        --"Moonfire, unless eclipse w/in 2 seconds"
        --"Starsurge unless eclipse w/in 2 seconds"
        --"Starfire if Going Up"
        --"Wrath"
        
        -- flash
        a.Flash("Force of Nature")
        if eclipse and c.HasBuff("Eclipse (Lunar)") then
            a.Flash("Starfall")
        end
        if eclipseSoon then
            if c.GetMyDebuffDuration("Insect Swarm") < 3
                or (c.GetMyDebuffDuration("Moonfire") < 3
                    and c.GetMyDebuffDuration("Sunfire") < 3) then
                
                if a.Flash("Starsurge") then
                    return
                end
            end
        else
            if eclipse and not goingUp and s.HasTalent(93401) then -- Sunfire
                if a.Flash("Insect Swarm", "Tricky Sunfire", "Starsurge") then
                    return
                end
            else
                if a.Flash("Insect Swarm", "Moonfire", "Starsurge") then
                    return
                end
            end
        end
        if goingUp then
            if calcPower(
                goingUp, 
                power, 
                busyTime, 
                busyTime + s.CastTime(c.GetID("Wrath"))) >= 100 then
                
                a.Flash("Wrath")
            else
                a.Flash("Starfire")
            end
        else
            if calcPower(
                goingUp, 
                power, 
                busyTime, 
                busyTime + s.CastTime(c.GetID("Starfire"))) <= -100 then
                
                a.Flash("Starfire")
            else
                a.Flash("Wrath")
            end
        end
    end
}

------------------------------------------------------------------------- feral
a.Rotations.FeralCaster = {
    Spec = 2,
    CheckFirst = function()
        return (not s.Form())
            and (not a.GetConfig("bear_off") or not a.GetConfig("cat_off"))
    end,
    Function = function()
        a.Flash("Mark of the Wild")
    end
}

-------------------------------------------------------------------------- bear
local UncontrolledMitigationBuffs = {
    109861, -- Fury of the Beast LFR
    108011, -- Fury of the Beast
    109864, -- Fury of the Beast Heroic
    109774, -- Master Tactician LFR
    107986, -- Master Tactician
    109776, -- Master Tactician Heroic
}

a.Rotations.Bear = {
    Spec = 2,
    OffSwitch = "bear_off",
    Form = "Bear Form",
    Function = function()
        a.Flash("Mark of the Wild")
        if not s.InCombat() then
            return
        end
        
        -- Not on the GCD
        a.FlashAll("Enrage", "Growl", "Challenging Roar")
        if c.WearingSet(2, "FeralT13") then
            c.RotateCooldowns(
                UncontrolledMitigationBuffs, 
                "Berserk for Mitigation",
                "Barkskin", 
                "Survival Instincts", 
                "Frenzied Regeneration")
        else
            a.Flash("Berserk")
            c.RotateCooldowns(
                UncontrolledMitigationBuffs, 
                "Barkskin", 
                "Survival Instincts", 
                "Frenzied Regeneration")
        end
        local rage = s.PowerPercent("player")
        if rage > 70 then
            a.Flash("Maul")
        end
        
        -- Rotation
        a.Flash(
            "Bear Mangle for Debuff",
            "Demoralizing Roar",
            "Pulverize",
            "Bear Mangle",
            "Lacerate to 3",
            "Faerie Fire (Feral) to 3",
            "Thrash",
            "Faerie Fire (Feral)",
            "Lacerate")
    end
}

--------------------------------------------------------------------------- cat
local lastRipTime = 0
local lastRipDuration = 0
local pendingRipExtension = 0
local function updateRipDuration()
    if not s.HasGlyph(54815) then -- Glyph of Bloodletting
        a.RipDuration = c.GetMyDebuffDuration("Rip")
        return
    end
    
    local now = GetTime()
    local duration = s.MyDebuffDuration(c.GetID("Rip"))
    if now - lastRipTime > 1 then
        c.Debug("Glyph of Bloodletting", "New Application")
        pendingRipExtension = 6
    elseif duration - lastRipDuration > 4 then
        c.Debug(
            "Glyph of Bloodletting", 
            "Overwrite: ", duration - lastRipDuration)
        pendingRipExtension = 6
    elseif duration > lastRipDuration then
        pendingRipExtension = pendingRipExtension - 2
        c.Debug(
            "Glyph of Bloodletting",
            "change of ", duration - lastRipDuration,
            " -> ", pendingRipExtension)
    end
    lastRipTime = now
    lastRipDuration = duration
    
    duration = c.GetMyDebuffDuration("Rip")
    if duration > 0 then
        a.RipDuration = duration + pendingRipExtension
    else
        a.RipDuration = 0
    end
end

a.Rotations.Cat = {
    Spec = 2,
    OffSwitch = "cat_off",
    Form = "Cat Form",
    Function = function()
        a.Flash("Mark of the Wild")
        if not s.InCombat() then
            return
        end
        
        updateRipDuration()
        
        -- Not on the GCD
        a.FlashAll(
            "Survival Instincts under 30", 
            "Barkskin under 30",
            "Tiger's Fury",
            "Kitty Berserk")
        
        -- Rotation
        a.Flash(
            "Optional Faerie Fire (Feral) to 3",
            "Cat Mangle for Bleed Debuff",
            "Ferocious Bite to save Rip",
            "Rip",
            "Savage Roar",
            "Ferocious Bite during execute",
            "Ferocious Bite conservative",
            "Rake",
            "Ravage",
            "Ravage!",
            "Feral Charge(Cat Form)",
            "Shred")
    end
}

------------------------------------------------------------------------- resto
local lastNG = 0
a.Rotations.Restoration = {
    Spec = 3,
    OffSwitch = "resto_off",
    Function = function()
        a.Flash("Mark of the Wild")
        if not s.InCombat() then
            return
        end
        
        local ngcool = GetTime() - lastNG
        if ngcool > 45 and c.HasBuff("Nature's Grace", true) then
            lastNG = GetTime()
        elseif ngcool >= 60 then
            local regrowth = a.spells["Regrowth"]
            if c.HasBuff("Clearcasting", false, s.CastTime(regrowth.ID)) then
                regrowth.FlashColor = nil
                regrowth.FlashSize = nil
            else
                regrowth.FlashColor = "yellow"
                regrowth.FlashSize = s.FlashSizePercent() / 2
            end
            a.Flash("Regrowth")
        end
        
        a.FlashAll("Innervate", "Swiftmend")
    end
}
