-- To update a translation please use the localization utility at:
-- http://wow.curseforge.com/addons/bittens-spellflash-druid/localization/

local AddonName, a = ...
local function DefaultFunction(_, key) return key end
a.Localize = setmetatable({}, {__index = DefaultFunction})
local L = a.Localize

-- Example:
L["English text goes here."] = "Translated text goes here."

if GetLocale() == "ptBR" then -- Brazilian Portuguese
-- L["Flash Bear"] = ""
-- L["Flash Cat"] = ""
-- L["Flash Resto"] = ""
-- L["Wearing Feral 2pT13"] = ""

elseif GetLocale() == "frFR" then -- French
-- L["Flash Bear"] = ""
-- L["Flash Cat"] = ""
-- L["Flash Resto"] = ""
-- L["Wearing Feral 2pT13"] = ""

elseif GetLocale() == "deDE" then -- German
L["Flash Bear"] = "Aufblitzen in Bärengestalt" -- Needs review
L["Flash Cat"] = "Aufblitzen in Katzengestalt" -- Needs review
L["Flash Resto"] = "Aufblitzen bei Wiederherstellung" -- Needs review
L["Wearing Feral 2pT13"] = "Trage 2 Wilder Kampf T13 Teile" -- Needs review

elseif GetLocale() == "koKR" then -- Korean
-- L["Flash Bear"] = ""
-- L["Flash Cat"] = ""
-- L["Flash Resto"] = ""
-- L["Wearing Feral 2pT13"] = ""

elseif GetLocale() == "esMX" then -- Latin American Spanish
-- L["Flash Bear"] = ""
-- L["Flash Cat"] = ""
-- L["Flash Resto"] = ""
-- L["Wearing Feral 2pT13"] = ""

elseif GetLocale() == "ruRU" then -- Russian
-- L["Flash Bear"] = ""
-- L["Flash Cat"] = ""
-- L["Flash Resto"] = ""
-- L["Wearing Feral 2pT13"] = ""

elseif GetLocale() == "zhCN" then -- Simplified Chinese
-- L["Flash Bear"] = ""
-- L["Flash Cat"] = ""
-- L["Flash Resto"] = ""
-- L["Wearing Feral 2pT13"] = ""

elseif GetLocale() == "esES" then -- Spanish
-- L["Flash Bear"] = ""
-- L["Flash Cat"] = ""
-- L["Flash Resto"] = ""
-- L["Wearing Feral 2pT13"] = ""

elseif GetLocale() == "zhTW" then -- Traditional Chinese
-- L["Flash Bear"] = ""
-- L["Flash Cat"] = ""
-- L["Flash Resto"] = ""
-- L["Wearing Feral 2pT13"] = ""

end