local MinBuild, MaxBuild, Build = 40000, 0, select(4, GetBuildInfo())
if Build < MinBuild or ( MaxBuild > 0 and Build > MaxBuild ) then return end
local AddonName, a = ...
local AddonTitle = select(2, GetAddOnInfo(AddonName))
local PlainAddonTitle = AddonTitle:gsub("|c........", ""):gsub("|r", "")
local L = a.Localize
local s = SpellFlashAddon
local x = s.UpdatedVariables
local config = {}
config.event = {}


-- Only add this function if a spell has a buff or debuff name that is different than the name of the spell that is cast.
-- This is so travel time can be properly tracked for the spell.
-- Example other auras function:
--function config.OtherAurasFunction()
--	if s.HasTalent(17793--[[Shadow and Flame]]) then
--		s.SetOtherAuras(686--[[Shadow Bolt]], 17800--[[Shadow and Flame]])
--		s.SetOtherAuras(29722--[[Incinerate]], 17800--[[Shadow and Flame]])
--	end
--	if s.HasTalent(32385--[[Shadow Embrace]]) then
--		s.SetOtherAuras(686--[[Shadow Bolt]], 32385--[[Shadow Embrace]])
--		s.SetOtherAuras(48181--[[Haunt]], 32385--[[Shadow Embrace]])
--	end
--	if s.HasTalent(18179--[[Jinx]]) then
--		s.SetOtherAuras(1490--[[Curse of the Elements]], 85547--[[Jinx: Curse of the Elements]])
--	end
--end

function config.OtherAurasFunction()
	if s.HasTalent(17793--[[Shadow and Flame]]) then
		s.SetOtherAuras(686--[[Shadow Bolt]], 17800--[[Shadow and Flame]])
		s.SetOtherAuras(29722--[[Incinerate]], 17800--[[Shadow and Flame]])
	end
	if s.HasTalent(32385--[[Shadow Embrace]]) then
		s.SetOtherAuras(686--[[Shadow Bolt]], 32385--[[Shadow Embrace]])
		s.SetOtherAuras(48181--[[Haunt]], 32385--[[Shadow Embrace]])
	end
	if s.HasTalent(18179--[[Jinx]]) then
		s.SetOtherAuras(1490--[[Curse of the Elements]], 85547--[[Jinx: Curse of the Elements]])
	end
end


-- Event listings:
-- http://wowprogramming.com/docs/events
-- http://www.wowwiki.com/Events_(API)

-- Add as many event functions as needed.
-- Example event function:
--function config.event.EVENT_NAME_GOES_HERE(event, ...)
--	a.print(L["Something happened!"], event, ...)
--end

function config.event.COMBAT_LOG_EVENT_UNFILTERED(event, ...)
	local Event = select(2, ...)
	local sourceGUID = select(4, ...)
	local GUID = select(8, ...)
	local SpellName = select(13, ...)
	if Event == "SPELL_CAST_SUCCESS" and sourceGUID == UnitGUID("player") and SpellName == s.SpellName(86121--[[Soul Swap]], 1) then
		a.LastSoulSwap = GUID
	end
end


config.CheckButtonOptions = {
	LeftCheckButton1 = {
		DefaultChecked = true,
		ConfigKey = "My_Config_Key",
		Label = L["My_Check_Button_Label"],
	},
	LeftCheckButton2 = {
		DefaultChecked = true,
		ConfigKey = "My_Config_Key",
		Label = L["My_Check_Button_Label"],
	},
	LeftCheckButton3 = {
		DefaultChecked = true,
		ConfigKey = "My_Config_Key",
		Label = L["My_Check_Button_Label"],
	},
	LeftCheckButton4 = {
		DefaultChecked = true,
		ConfigKey = "My_Config_Key",
		Label = L["My_Check_Button_Label"],
	},
	LeftCheckButton5 = {
		DefaultChecked = true,
		ConfigKey = "My_Config_Key",
		Label = L["My_Check_Button_Label"],
	},
	LeftCheckButton6 = {
		DefaultChecked = true,
		ConfigKey = "My_Config_Key",
		Label = L["My_Check_Button_Label"],
	},
	LeftCheckButton7 = {
		DefaultChecked = true,
		ConfigKey = "My_Config_Key",
		Label = L["My_Check_Button_Label"],
	},
	RightCheckButton1 = {
		DefaultChecked = true,
		ConfigKey = "My_Config_Key",
		Label = L["My_Check_Button_Label"],
	},
	RightCheckButton2 = {
		DefaultChecked = true,
		ConfigKey = "My_Config_Key",
		Label = L["My_Check_Button_Label"],
	},
	RightCheckButton3 = {
		DefaultChecked = true,
		ConfigKey = "My_Config_Key",
		Label = L["My_Check_Button_Label"],
	},
	RightCheckButton4 = {
		DefaultChecked = true,
		ConfigKey = "My_Config_Key",
		Label = L["My_Check_Button_Label"],
	},
	RightCheckButton5 = {
		DefaultChecked = true,
		ConfigKey = "My_Config_Key",
		Label = L["My_Check_Button_Label"],
	},
	RightCheckButton6 = {
		DefaultChecked = true,
		ConfigKey = "My_Config_Key",
		Label = L["My_Check_Button_Label"],
	},
	RightCheckButton7 = {
		DefaultChecked = true,
		ConfigKey = "My_Config_Key",
		Label = L["My_Check_Button_Label"],
	},
}

config.EditBoxOptions = {
	LeftEditBox1 = {
		DefaultValue = "",
		Numeric = false,
		MaxCharacters = 999,
		ConfigKey = "My_Config_Key",
		Label = L["My_Edit_Box_Label:"],
	},
	LeftEditBox2 = {
		DefaultValue = "",
		Numeric = false,
		MaxCharacters = 999,
		ConfigKey = "My_Config_Key",
		Label = L["My_Edit_Box_Label:"],
	},
	RightEditBox1 = {
		DefaultValue = "",
		Numeric = false,
		MaxCharacters = 999,
		ConfigKey = "My_Config_Key",
		Label = L["My_Edit_Box_Label:"],
	},
	RightEditBox2 = {
		DefaultValue = "",
		Numeric = false,
		MaxCharacters = 999,
		ConfigKey = "My_Config_Key",
		Label = L["My_Edit_Box_Label:"],
	},
}


config.SlashCommands = {
	-- Add and remove as many slash commands as needed:
	"/put_slash_command_here",
	"/put_another_slash_command_here",
}

function config.SlashHandler(msg, editbox)
	local msg = msg:lower()
	-- Do something here
end


a.LoadConfigs(config)