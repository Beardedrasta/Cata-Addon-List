local MinBuild, MaxBuild, Build = 40000, 0, select(4, GetBuildInfo())
if Build < MinBuild or ( MaxBuild > 0 and Build > MaxBuild ) then return end
local AddonName, a = ...
local AddonTitle = select(2, GetAddOnInfo(AddonName))
local PlainAddonTitle = AddonTitle:gsub("|c........", ""):gsub("|r", "")
local L = a.Localize
local s = SpellFlashAddon
local x = s.UpdatedVariables

-- SpellFlash API:
-- http://wow.curseforge.com/addons/spellflash/pages/api/

-- Updated variable references:
-- http://wow.curseforge.com/addons/spellflash/pages/api/#w-local-x-spell-flash-addon-updated-variables
-- x.Enemy, x.ActiveEnemy, x.NoCC, x.InInstance, x.InstanceType, x.PetAlive, x.PetActiveEnemy, x.PetNoCC, x.Lag, x.DoubleLag, x.ThreatPercent, x.EnemyDetected, x.ShouldPermanentBuff, x.ShouldTemporaryBuff

-- Spell table references:
-- http://wow.curseforge.com/addons/spellflash/pages/api/#w-s-castable


a.spells["Soulstone"] = {
	Type = "item",
	ItemName = 5232--[[Soulstone]],
	Buff = 20707--[[Soulstone Resurrection]],
	EarlyRefresh = 20,
	NoRangeCheck = 1,
	NotIfActive = 1,
	--NotWhileMoving = 1,
	FlashColor = "Green",
	CheckFirst = function(z)
		if x.ShouldTemporaryBuff then
			z.CastTime = s.CastTime(20707--[[Soulstone Resurrection]])
			if x.InstanceType == "arena" then
				z.BuffUnit = "raid"
			elseif x.InstanceType ~= "pvp" and s.InRaidOrParty() and s.Healer("raid|afk|notself") then
				z.BuffUnit = "raid|healer|afk|notself"
			else
				z.BuffUnit = "player"
			end
			return true
		end
		return false
	end,
}

a.spells["Metamorphosis"] = {
	Type = "form",
	ID = 47241--[[Metamorphosis]],
	EnemyTargetNeeded = 1,
	CheckFirst = function(z)
		z.FlashColor = s.If(x.ActiveEnemy, "White", "Pink")
		return x.NoCC and x.ShouldTemporaryBuff
	end,
}

a.spells["Demon Leap"] = {
	ID = 54785--[[Demon Leap]],
	EnemyTargetNeeded = 1,
	CheckFirst = function(z)
		z.FlashColor = s.If(x.ActiveEnemy, "Purple", "Pink")
		return x.NoCC and not CheckInteractDistance(s.UnitSelection(), 3)
	end,
}

a.spells["Immolation Aura"] = {
	ID = 50589--[[Immolation Aura]],
	CheckFirst = function(z)
		z.FlashColor = s.If(x.ActiveEnemy, "Purple", "Pink")
		return x.NoCC
	end,
}

a.spells["Shadow Ward"] = {
	ID = 6229--[[Shadow Ward]],
	EnemyTargetNeeded = 1,
	FlashColor = "Green",
	CheckFirst = function(z)
		return x.ShouldTemporaryBuff
	end,
}

a.spells["Summon Imp"] = {
	ID = 688--[[Summon Imp]],
	NotIfActive = {
		688--[[Summon Imp]],
		712--[[Summon Succubus]],
		697--[[Summon Voidwalker]],
		691--[[Summon Felhunter]],
		30146--[[Summon Felguard]],
	},
	FlashColor = "Green",
	CheckFirst = function(z)
		--z.NotWhileMoving = not s.Buff(74434--[[Soulburn]], "player")
		return not x.PetAlive and x.ShouldPermanentBuff
	end,
}

a.spells["Summon Succubus"] = {
	ID = 712--[[Summon Succubus]],
	NotIfActive = {
		688--[[Summon Imp]],
		712--[[Summon Succubus]],
		697--[[Summon Voidwalker]],
		691--[[Summon Felhunter]],
		30146--[[Summon Felguard]],
	},
	FlashColor = "Green",
	CheckFirst = function(z)
		--z.NotWhileMoving = not s.Buff(74434--[[Soulburn]], "player")
		return not x.PetAlive and x.ShouldPermanentBuff
	end,
}

a.spells["Summon Voidwalker"] = {
	ID = 697--[[Summon Voidwalker]],
	NotIfActive = {
		688--[[Summon Imp]],
		712--[[Summon Succubus]],
		697--[[Summon Voidwalker]],
		691--[[Summon Felhunter]],
		30146--[[Summon Felguard]],
	},
	FlashColor = "Green",
	CheckFirst = function(z)
		--z.NotWhileMoving = not s.Buff(74434--[[Soulburn]], "player")
		return not x.PetAlive and x.ShouldPermanentBuff
	end,
}

a.spells["Summon Felhunter"] = {
	ID = 691--[[Summon Felhunter]],
	NotIfActive = {
		688--[[Summon Imp]],
		712--[[Summon Succubus]],
		697--[[Summon Voidwalker]],
		691--[[Summon Felhunter]],
		30146--[[Summon Felguard]],
	},
	FlashColor = "Green",
	CheckFirst = function(z)
		--z.NotWhileMoving = not s.Buff(74434--[[Soulburn]], "player")
		return not x.PetAlive and x.ShouldPermanentBuff
	end,
}

a.spells["Summon Felguard"] = {
	ID = 30146--[[Summon Felguard]],
	NotIfActive = {
		688--[[Summon Imp]],
		712--[[Summon Succubus]],
		697--[[Summon Voidwalker]],
		691--[[Summon Felhunter]],
		30146--[[Summon Felguard]],
	},
	FlashColor = "Green",
	CheckFirst = function(z)
		--z.NotWhileMoving = not s.Buff(74434--[[Soulburn]], "player")
		return not x.PetAlive and x.ShouldPermanentBuff
	end,
}

a.spells["Soul Link"] = {
	ID = 19028--[[Soul Link]],
	Buff = 19028--[[Soul Link]],
	BuffUnit = "pet",
	NoRangeCheck = 1,
	FlashColor = "Green",
	CheckFirst = function(z)
		return x.PetAlive and x.ShouldPermanentBuff
	end,
}

a.spells["Demonic Empowerment"] = {
	ID = 47193--[[Demonic Empowerment]],
	Debuff = 1098--[[Enslave Demon]],
	BuffUnit = "pet",
	CheckFirst = function(z)
		return s.NotDieing("pettarget")
	end,
}

a.spells["Demon Soul"] = {
	ID = 77801--[[Demon Soul]],
	Debuff = 1098--[[Enslave Demon]],
	BuffUnit = "pet",
	EnemyTargetNeeded = 1,
	CheckFirst = function(z)
		return x.ActiveEnemy and x.PetAlive and s.NotDieing()
	end,
}

a.spells["Summon Doomguard"] = {
	ID = 18540--[[Summon Doomguard]],
	RequireMyDebuff = {
		980--[[Bane of Agony]],
		603--[[Bane of Doom]],
		80240--[[Bane of Havoc]],
	},
	EnemyTargetNeeded = 1,
	FlashColor = "Purple",
	CheckFirst = function(z)
		return s.Player() or s.Boss()
	end,
}

a.spells["Summon Infernal"] = {
	ID = 1122--[[Summon Infernal]],
	RequireMyDebuff = {
		980--[[Bane of Agony]],
		603--[[Bane of Doom]],
		80240--[[Bane of Havoc]],
	},
	EnemyTargetNeeded = 1,
	NoRangeCheck = 1,
	NotWhileMoving = 1,
	FlashColor = "Purple",
	CheckFirst = function(z)
		return s.Player() or s.Boss()
	end,
}

a.spells["Bane of Agony"] = {
	ID = 980--[[Bane of Agony]],
	MyDebuff = {
		980--[[Bane of Agony]],
		603--[[Bane of Doom]],
		80240--[[Bane of Havoc]],
	},
	EnemyTargetNeeded = 1,
	NotIfActive = {
		980--[[Bane of Agony]],
		603--[[Bane of Doom]],
		80240--[[Bane of Havoc]],
	},
	CheckFirst = function(z)
		z.FlashColor = s.If(x.ActiveEnemy, "White", "Pink")
		if not s.MyDebuff(603--[[Bane of Doom]]) then
			z.EarlyRefresh = 1
		end
		return x.NoCC and ( not s.Buff(86121--[[Soul Swap]], "player") or s.HasGlyph(57270--[[Glyph of Soul Swap]]) )
	end,
}

a.spells["Bane of Doom"] = {
	ID = 603--[[Bane of Doom]],
	MyDebuff = {
		980--[[Bane of Agony]],
		603--[[Bane of Doom]],
		80240--[[Bane of Havoc]],
	},
	EnemyTargetNeeded = 1,
	NotIfActive = {
		980--[[Bane of Agony]],
		603--[[Bane of Doom]],
		80240--[[Bane of Havoc]],
	},
	CheckFirst = function(z)
		z.FlashColor = s.If(x.ActiveEnemy, "White", "Pink")
		return x.NoCC and ( not s.Buff(86121--[[Soul Swap]], "player") or s.HasGlyph(57270--[[Glyph of Soul Swap]]) ) and s.HealthPercent() > 25 and s.Boss()
	end,
}

a.spells["Bane of Havoc"] = {
	ID = 80240--[[Bane of Havoc]],
	MyDebuff = {
		980--[[Bane of Agony]],
		603--[[Bane of Doom]],
		80240--[[Bane of Havoc]],
	},
	EnemyTargetNeeded = 1,
	NotIfActive = {
		980--[[Bane of Agony]],
		603--[[Bane of Doom]],
		80240--[[Bane of Havoc]],
	},
	CheckFirst = function(z)
		z.FlashColor = s.If(x.ActiveEnemy, "White", "Pink")
		return x.NoCC
	end,
}

a.spells["Curse of the Elements"] = {
	ID = 1490--[[Curse of the Elements]],
	Debuff = {
		1490--[[Curse of the Elements]],
		85547--[[Jinx: Curse of the Elements]],
	},
	MyDebuff = {
		702--[[Curse of Weakness]],
		1714--[[Curse of Tongues]],
		18223--[[Curse of Exhaustion]],
	},
	EarlyRefresh = 5,
	EnemyTargetNeeded = 1,
	NotIfActive = {
		1490--[[Curse of the Elements]],
		85547--[[Jinx: Curse of the Elements]],
		1714--[[Curse of Tongues]],
		702--[[Curse of Weakness]],
		18223--[[Curse of Exhaustion]],
	},
	CheckFirst = function(z)
		z.FlashColor = s.If(x.ActiveEnemy, "White", "Pink")
		return x.NoCC
	end,
}

a.spells["Curse of Tongues"] = {
	ID = 1714--[[Curse of Tongues]],
	Debuff = 1714--[[Curse of Tongues]],
	MyDebuff = {
		85547--[[Jinx: Curse of the Elements]],
		1490--[[Curse of the Elements]],
		702--[[Curse of Weakness]],
		18223--[[Curse of Exhaustion]],
	},
	EarlyRefresh = 5,
	EnemyTargetNeeded = 1,
	NotIfActive = {
		1490--[[Curse of the Elements]],
		85547--[[Jinx: Curse of the Elements]],
		1714--[[Curse of Tongues]],
		702--[[Curse of Weakness]],
		18223--[[Curse of Exhaustion]],
	},
	CheckFirst = function(z)
		z.FlashColor = s.If(x.ActiveEnemy, "White", "Pink")
		return x.NoCC
	end,
}

a.spells["Curse of Weakness"] = {
	ID = 702--[[Curse of Weakness]],
	Debuff = {
		702--[[Curse of Weakness]],
		1160--[[Demoralizing Shout]],
		99--[[Demoralizing Roar]],
		24423--[[Demoralizing Screech]],
		26016--[[Vindication]],
	},
	MyDebuff = {
		85547--[[Jinx: Curse of the Elements]],
		1490--[[Curse of the Elements]],
		1714--[[Curse of Tongues]],
		18223--[[Curse of Exhaustion]],
	},
	EarlyRefresh = 5,
	EnemyTargetNeeded = 1,
	NotIfActive = {
		1490--[[Curse of the Elements]],
		85547--[[Jinx: Curse of the Elements]],
		1714--[[Curse of Tongues]],
		702--[[Curse of Weakness]],
		18223--[[Curse of Exhaustion]],
	},
	CheckFirst = function(z)
		z.FlashColor = s.If(x.ActiveEnemy, "White", "Pink")
		return x.NoCC
	end,
}

a.spells["Curse of Exhaustion"] = {
	ID = 18223--[[Curse of Exhaustion]],
	Debuff = 18223--[[Curse of Exhaustion]],
	MyDebuff = {
		85547--[[Jinx: Curse of the Elements]],
		1490--[[Curse of the Elements]],
		702--[[Curse of Weakness]],
		1714--[[Curse of Tongues]],
	},
	EarlyRefresh = 5,
	EnemyTargetNeeded = 1,
	NotIfActive = {
		1490--[[Curse of the Elements]],
		85547--[[Jinx: Curse of the Elements]],
		1714--[[Curse of Tongues]],
		702--[[Curse of Weakness]],
		18223--[[Curse of Exhaustion]],
	},
	CheckFirst = function(z)
		z.FlashColor = s.If(x.ActiveEnemy, "White", "Pink")
		return x.NoCC and s.Player()
	end,
}

a.spells["Immolate"] = {
	ID = 348--[[Immolate]],
	MyDebuff = {
		348--[[Immolate]],
		30108--[[Unstable Affliction]],
	},
	EarlyRefresh = 1,
	EnemyTargetNeeded = 1,
	NotWhileMoving = 1,
	NotIfActive = {
		348--[[Immolate]],
		30108--[[Unstable Affliction]],
	},
	CheckFirst = function(z)
		z.FlashColor = s.If(x.ActiveEnemy, "White", "Pink")
		if s.HasTalent(85103--[[Cremation]]) then
			local casting = s.Casting(71521--[[Hand of Gul'dan]], "player")
			if ( casting and s.MyDebuff(z.ID, nil, casting + x.DoubleLag) ) or ( s.SpellDelay(71521--[[Hand of Gul'dan]]) and s.MyDebuff(z.ID, nil, x.DoubleLag) ) then
				return false
			end
		end
		return x.NoCC and ( not s.Buff(86121--[[Soul Swap]], "player") or s.HasGlyph(57270--[[Glyph of Soul Swap]]) )
	end,
}

a.spells["Unstable Affliction"] = {
	ID = 30108--[[Unstable Affliction]],
	MyDebuff = {
		348--[[Immolate]],
		30108--[[Unstable Affliction]],
	},
	EarlyRefresh = 1,
	EnemyTargetNeeded = 1,
	NotWhileMoving = 1,
	NotIfActive = {
		348--[[Immolate]],
		30108--[[Unstable Affliction]],
	},
	CheckFirst = function(z)
		z.FlashColor = s.If(x.ActiveEnemy, "White", "Pink")
		return x.NoCC and ( not s.Buff(86121--[[Soul Swap]], "player") or s.HasGlyph(57270--[[Glyph of Soul Swap]]) )
	end,
}

a.spells["Corruption"] = {
	ID = 172--[[Corruption]],
	MyDebuff = {
		172--[[Corruption]],
		27243--[[Seed of Corruption]],
	},
	EnemyTargetNeeded = 1,
	NotIfActive = {
		172--[[Corruption]],
		27243--[[Seed of Corruption]],
	},
	CheckFirst = function(z)
		z.FlashColor = s.If(x.ActiveEnemy, "White", "Pink")
		if not s.MyDebuff(27243--[[Seed of Corruption]]) then
			z.EarlyRefresh = 1
		end
		return x.NoCC and not s.Buff(86121--[[Soul Swap]], "player") or s.HasGlyph(57270--[[Glyph of Soul Swap]])
	end,
}

a.spells["Seed of Corruption"] = {
	ID = 27243--[[Seed of Corruption]],
	MyDebuff = {
		172--[[Corruption]],
		27243--[[Seed of Corruption]],
	},
	EnemyTargetNeeded = 1,
	NotWhileMoving = 1,
	CheckFirst = function(z)
		z.FlashColor = s.If(x.ActiveEnemy, "White", "Pink")
		return x.NoCC and not s.Buff(86121--[[Soul Swap]], "player") or s.HasGlyph(57270--[[Glyph of Soul Swap]])
	end,
}

a.spells["Create Healthstone"] = {
	ID = 6201--[[Create Healthstone]],
	NotIfActive = 1,
	--NotWhileMoving = 1,
	FlashColor = "Green",
	CheckFirst = function(z)
		return x.ShouldTemporaryBuff and GetItemCount(5512--[[Healthstone]], true) == 0 and not s.CastingOrChanneling(29893--[[Ritual of Souls]], "player")
	end,
}

a.spells["Ritual of Souls"] = {
	ID = 29893--[[Ritual of Souls]],
	NoRangeCheck = 1,
	NotIfActive = 1,
	--NotWhileMoving = 1,
	FlashColor = "Green",
	CheckFirst = function(z)
		return x.ShouldTemporaryBuff and ( (s.InRaid() or 0) > 2 or (s.InParty() or 0) > 1 ) and GetItemCount(5512--[[Healthstone]], true) == 0
	end,
}

a.spells["Dark Intent"] = {
	ID = 80398--[[Dark Intent]],
	MyBuff = 80398--[[Dark Intent]],
	BuffUnit = "player",
	EarlyRefresh = 30,
	NoRangeCheck = 1,
	FlashColor = "Green",
	CheckFirst = function(z)
		return x.ShouldTemporaryBuff
	end,
}

a.spells["Death Coil"] = {
	ID = 6789--[[Death Coil]],
	EnemyTargetNeeded = 1,
	CheckFirst = function(z)
		z.FlashColor = s.If(x.ActiveEnemy, "White", "Pink")
		return x.NoCC
	end
}

a.spells["Demon Armor"] = {
	ID = 687--[[Demon Armor]],
	Buff = {
		687--[[Demon Armor]],
		28176--[[Fel Armor]],
	},
	BuffUnit = "player",
	FlashColor = "Green",
	CheckFirst = function(z)
		return x.ShouldPermanentBuff
	end,
}

a.spells["Fel Armor"] = {
	ID = 28176--[[Fel Armor]],
	Buff = {
		687--[[Demon Armor]],
		28176--[[Fel Armor]],
	},
	BuffUnit = "player",
	FlashColor = "Green",
	CheckFirst = function(z)
		return x.ShouldPermanentBuff
	end,
}

a.spells["Demonic Circle: Teleport"] = {
	ID = 48020--[[Demonic Circle: Teleport]],
}

a.spells["Demonic Circle: Summon"] = {
	ID = 48018--[[Demonic Circle: Summon]],
	NotWhileMoving = 1,
}

a.spells["Drain Life"] = {
	ID = 689--[[Drain Life]],
	EnemyTargetNeeded = 1,
	NotWhileMoving = 1,
	CheckFirst = function(z)
		z.FlashColor = s.If(x.ActiveEnemy, "White", "Pink")
		return x.NoCC and s.HealthPercent("player") <= 70 and ( not s.MeleeDistance("focus") or not s.EnemyTargetingYou("focus") ) and ( not s.MeleeDistance("enemy") or not s.EnemyTargetingYou("enemy") )
	end,
}

a.spells["Drain Mana"] = {
	ID = 5138--[[Drain Mana]],
	EnemyTargetNeeded = 1,
	TargetThatUsesManaNeeded = 1,
	NotWhileMoving = 1,
	CheckFirst = function(z)
		z.FlashColor = s.If(x.ActiveEnemy, "White", "Pink")
		return s.HasMana()
	end,
}

a.spells["Drain Soul - Finisher"] = {
	ID = 1120--[[Drain Soul]],
	EnemyTargetNeeded = 1,
	NotWhileMoving = 1,
	FlashColor = "Red",
	CheckFirst = function(z)
		return x.ActiveEnemy and s.HealthPercent() <= 25 and s.GivesXP() and ( s.PowerPercent("player", SPELL_POWER_SOUL_SHARDS) < 100 or s.HasGlyph(58337--[[Glyph of Drain Soul]]) )
	end,
}

a.spells["Drain Soul"] = {
	ID = 1120--[[Drain Soul]],
	EnemyTargetNeeded = 1,
	NotWhileMoving = 1,
	CheckFirst = function(z)
		z.FlashColor = s.If(x.ActiveEnemy, "White", "Pink")
		return x.NoCC and s.HealthPercent() <= 25
	end,
}

a.spells["Health Funnel"] = {
	ID = 755--[[Health Funnel]],
	NoRangeCheck = 1,
	NotIfActive = 1,
	--NotWhileMoving = 1,
	CheckFirst = function(z)
		z.FlashColor = s.If(s.InCombat(), "Yellow", "Green")
		return x.PetAlive and s.HealthPercent("pet") <= 90 and s.HealthPercent("player") >= 10 and not s.CastingOrChanneling(17767--[[Consume Shadows]], "pet") and ( not s.InCombat() or s.HealthPercent("pet") <= 70 )
	end,
}

a.spells["Incinerate - Molten Core"] = {
	ID = 29722--[[Incinerate]],
	EnemyTargetNeeded = 1,
	NotWhileMoving = 1,
	CheckFirst = function(z)
		z.FlashColor = s.If(x.ActiveEnemy, "Yellow", "Pink")
		return x.NoCC and s.HasTalent(47245--[[Molten Core]]) and s.Buff(47245--[[Molten Core]], "player") and ( not s.Casting(29722--[[Incinerate]], "player") or s.BuffStack(47245--[[Molten Core]], "player") > 1 )
	end,
}

a.spells["Incinerate - Shadow and Flame"] = {
	ID = 29722--[[Incinerate]],
	EnemyTargetNeeded = 1,
	NotWhileMoving = 1,
	CheckFirst = function(z)
		z.FlashColor = s.If(x.ActiveEnemy, "White", "Pink")
		return x.NoCC and s.TalentMastery(3--[[Destruction]]) and a.ShadowAndFlame(29722--[[Incinerate]])
	end,
}

a.spells["Incinerate"] = {
	ID = 29722--[[Incinerate]],
	EnemyTargetNeeded = 1,
	NotWhileMoving = 1,
	CheckFirst = function(z)
		z.FlashColor = s.If(x.ActiveEnemy, "White", "Pink")
		return x.NoCC and s.TalentMastery(3--[[Destruction]])
	end,
}

a.spells["Life Tap"] = {
	ID = 1454--[[Life Tap]],
	FlashColor = "Green",
	CheckFirst = function(z)
		if not x.ShouldPermanentBuff or s.PowerPercent("player") >= 75 then
			return false
		elseif x.EnemyDetected or not s.HasSpell(79268--[[Soul Harvest]]) or s.SpellCooldown(79268--[[Soul Harvest]]) > s.SpellCooldown(1454--[[Life Tap]]) then
			if ( s.InCombat() and ( s.EnemyTargetingYou("focus") or s.EnemyTargetingYou("enemy") ) )
			or not ( ( s.PowerPercent("player") >= 75 and s.HealthPercent("player") >= 98 ) or ( s.PowerPercent("player") < 75 and s.HealthPercent("player") >= 95 ) ) then
				return false
			end
		elseif s.HealthPercent("player") < 30 then
			return false
		end
		return true
	end,
}

a.spells["Searing Pain"] = {
	ID = 5676--[[Searing Pain]],
	EnemyTargetNeeded = 1,
	NotWhileMoving = 1,
	CheckFirst = function(z)
		z.FlashColor = s.If(x.ActiveEnemy, "White", "Pink")
		return x.NoCC
	end,
}

a.spells["Shadow Bolt - Shadow Trance"] = {
	ID = 686--[[Shadow Bolt]],
	RequireBuff = 17941--[[Shadow Trance]],
	RequireBuffUnit = "player",
	EnemyTargetNeeded = 1,
	CheckFirst = function(z)
		z.FlashColor = s.If(x.ActiveEnemy, "Yellow", "Pink")
		z.NotWhileMoving = not s.Buff(17941--[[Shadow Trance]], "player")
		return x.NoCC
	end,
}

a.spells["Shadow Bolt - Shadow Embrace"] = {
	ID = 686--[[Shadow Bolt]],
	EnemyTargetNeeded = 1,
	CheckFirst = function(z)
		z.FlashColor = s.If(x.ActiveEnemy, "White", "Pink")
		z.NotWhileMoving = not s.Buff(17941--[[Shadow Trance]], "player")
		return x.NoCC and a.ShadowEmbrace()
	end,
}

a.spells["Shadow Bolt - Shadow and Flame"] = {
	ID = 686--[[Shadow Bolt]],
	EnemyTargetNeeded = 1,
	CheckFirst = function(z)
		z.FlashColor = s.If(x.ActiveEnemy, "White", "Pink")
		z.NotWhileMoving = not s.Buff(17941--[[Shadow Trance]], "player")
		return x.NoCC and a.ShadowAndFlame(686--[[Shadow Bolt]])
	end,
}

a.spells["Shadow Bolt - Starter"] = {
	ID = 686--[[Shadow Bolt]],
	EnemyTargetNeeded = 1,
	NotIfActive = 1,
	FlashColor = "Pink",
	CheckFirst = function(z)
		z.NotWhileMoving = not s.Buff(17941--[[Shadow Trance]], "player")
		return a.IdleTarget(z.ID)
	end,
}

a.spells["Shadow Bolt"] = {
	ID = 686--[[Shadow Bolt]],
	EnemyTargetNeeded = 1,
	CheckFirst = function(z)
		z.FlashColor = s.If(x.ActiveEnemy, "White", "Pink")
		z.NotWhileMoving = not s.Buff(17941--[[Shadow Trance]], "player")
		return x.NoCC
	end,
}

a.spells["Shadowflame"] = {
	ID = 47897--[[Shadowflame]],
	EnemyTargetNeeded = 1,
	Continue = 1,
	CheckFirst = function(z)
		z.FlashColor = s.If(x.ActiveEnemy, "Purple", "Pink")
		return x.NoCC and ( not s.Buff(86121--[[Soul Swap]], "player") or s.HasGlyph(57270--[[Glyph of Soul Swap]]) ) and CheckInteractDistance(s.UnitSelection(), 3)
	end,
}

a.spells["Soul Fire - Starter"] = {
	ID = 6353--[[Soul Fire]],
	EnemyTargetNeeded = 1,
	NotIfActive = 1,
	FlashColor = "Pink",
	CheckFirst = function(z)
		z.NotWhileMoving = not s.Buff(74434--[[Soulburn]], "player")
		return a.IdleTarget(z.ID)
	end,
}

a.spells["Soul Fire - Soulburn"] = {
	ID = 6353--[[Soul Fire]],
	RequireBuff = 74434--[[Soulburn]],
	RequireBuffUnit = "player",
	EnemyTargetNeeded = 1,
	CheckFirst = function(z)
		z.FlashColor = s.If(x.ActiveEnemy, "Yellow", "Pink")
		return x.NoCC
	end,
}

a.spells["Soul Fire - Decimation"] = {
	ID = 6353--[[Soul Fire]],
	RequireBuff = 63156--[[Decimation]],
	RequireBuffUnit = "player",
	EnemyTargetNeeded = 1,
	CheckFirst = function(z)
		z.FlashColor = s.If(x.ActiveEnemy, "Yellow", "Pink")
		z.NotWhileMoving = not s.Buff(74434--[[Soulburn]], "player")
		return x.NoCC
	end,
}

a.spells["Soul Fire - Improved Soul Fire"] = {
	ID = 6353--[[Soul Fire]],
	Buff = 85383--[[Improved Soul Fire]],
	BuffUnit = "player",
	EarlyRefresh = 1,
	EnemyTargetNeeded = 1,
	CheckFirst = function(z)
		z.FlashColor = s.If(x.ActiveEnemy, "White", "Pink")
		z.NotWhileMoving = not s.Buff(74434--[[Soulburn]], "player")
		return x.NoCC and s.HasTalent(18119--[[Improved Soul Fire]]) and ( not s.TalentMastery(1) or s.HealthPercent() > 25 or s.Boss() )
	end,
}

a.spells["Soul Fire"] = {
	ID = 6353--[[Soul Fire]],
	EnemyTargetNeeded = 1,
	CheckFirst = function(z)
		z.FlashColor = s.If(x.ActiveEnemy, "White", "Pink")
		z.NotWhileMoving = not s.Buff(74434--[[Soulburn]], "player")
		return x.NoCC
	end,
}

a.spells["Soulburn"] = {
	ID = 74434--[[Soulburn]],
	CheckFirst = function(z)
		return not a.IdleTarget(6353--[[Soul Fire]]) and x.ActiveEnemy and a.Flashable("Soul Fire")
	end,
}

a.spells["Soul Harvest"] = {
	ID = 79268--[[Soul Harvest]],
	--NotWhileMoving = 1,
	FlashColor = "Green",
	CheckFirst = function(z)
		return x.ShouldPermanentBuff and ( s.HealthPercent("player") <= 80 or s.PowerPercent("player", SPELL_POWER_SOUL_SHARDS) < 100 )
	end,
}

a.spells["Soulshatter"] = {
	ID = 29858--[[Soulshatter]],
	EnemyTargetNeeded = 1,
	FlashColor = "Yellow",
	CheckFirst = function(z)
		return x.ThreatPercent >= 90 and not UnitPlayerControlled(s.UnitSelection()) and s.SpellInRange(686--[[Shadow Bolt]]) and ( s.InRaidOrParty() or ( s.SameTargetAsPet() and ( s.HasSpell(3716--[[Torment]]) or s.HasSpell(30213--[[Legion Strike]]) ) ) )
	end,
}

a.spells["Conflagrate"] = {
	ID = 17962--[[Conflagrate]],
	CheckFirst = function(z)
		z.EvenIfNotUsable = s.SpellOrAuraDelay(348--[[Immolate]]) or s.CurrentSpell(348--[[Immolate]]) or s.Casting(348--[[Immolate]], "player") or s.MyDebuff(348--[[Immolate]])
		z.FlashColor = s.If(x.ActiveEnemy, "White", "Pink")
		return x.NoCC and z.EvenIfNotUsable
	end,
}

a.spells["Unending Breath"] = {
	ID = 5697--[[Unending Breath]],
	Buff = {
		5697--[[Unending Breath]],
		73701--[[Sea Legs]],
	},
	BuffUnit = "player",
	EarlyRefresh = 10,
	NoRangeCheck = 1,
	FlashColor = "Green",
	CheckFirst = function(z)
		return GetMirrorTimerProgress("BREATH") > 0 or ( x.ShouldPermanentBuff and IsSwimming() and s.HasGlyph(58336--[[Glyph of Unending Breath]]) )
	end,
}

a.spells["Create Soulstone"] = {
	ID = 693--[[Create Soulstone]],
	NotIfActive = 1,
	--NotWhileMoving = 1,
	FlashColor = "Green",
	CheckFirst = function(z)
		return x.ShouldTemporaryBuff and GetItemCount(5232--[[Soulstone]], true) == 0
	end,
}

a.spells["Chaos Bolt"] = {
	ID = 50796--[[Chaos Bolt]],
	EnemyTargetNeeded = 1,
	NotWhileMoving = 1,
	CheckFirst = function(z)
		z.FlashColor = s.If(x.ActiveEnemy, "White", "Pink")
		return x.NoCC
	end,
}

a.spells["Haunt"] = {
	ID = 48181--[[Haunt]],
	EnemyTargetNeeded = 1,
	NotIfActive = 1,
	NotWhileMoving = 1,
	CheckFirst = function(z)
		z.FlashColor = s.If(x.ActiveEnemy, "White", "Pink")
		return x.NoCC
	end,
}

a.spells["Shadowburn"] = {
	ID = 17877--[[Shadowburn]],
	EnemyTargetNeeded = 1,
	CheckFirst = function(z)
		z.FlashColor = s.If(x.ActiveEnemy, "White", "Pink")
		return x.NoCC
	end,
}

a.spells["Fel Flame - Fel Spark"] = {
	ID = 77799--[[Fel Flame]],
	RequireBuff = 89937--[[Fel Spark]],
	RequireBuffUnit = "player",
	EnemyTargetNeeded = 1,
	CheckFirst = function(z)
		z.FlashColor = s.If(x.ActiveEnemy, "Yellow", "Pink")
		return x.NoCC
	end,
}

a.spells["Fel Flame"] = {
	ID = 77799--[[Fel Flame]],
	EnemyTargetNeeded = 1,
	CheckFirst = function(z)
		z.FlashColor = s.If(x.ActiveEnemy, "White", "Pink")
		return x.NoCC
	end,
}

a.spells["Shadowfury"] = {
	ID = 30283--[[Shadowfury]],
	EnemyTargetNeeded = 1,
	NoRangeCheck = 1,
	CheckFirst = function(z)
		z.FlashColor = s.If(x.ActiveEnemy, "White", "Pink")
		return x.NoCC
	end
}

a.spells["Hand of Gul'dan"] = {
	ID = 71521--[[Hand of Gul'dan]],
	EnemyTargetNeeded = 1,
	NotIfActive = 1,
	NotWhileMoving = 1,
	CheckFirst = function(z)
		z.FlashColor = s.If(x.ActiveEnemy, "White", "Pink")
		return x.NoCC and x.PetAlive and UnitExists("pettarget")
	end,
}

a.spells["Soul Swap"] = {
	ID = 86121--[[Soul Swap]],
	Buff = 86121--[[Soul Swap]],
	BuffUnit = "player",
	RequireMyDebuff = {
		980--[[Bane of Agony]],
		603--[[Bane of Doom]],
		348--[[Immolate]],
		30108--[[Unstable Affliction]],
		172--[[Corruption]],
		27243--[[Seed of Corruption]],
		47897--[[Shadowflame]],
	},
	EnemyTargetNeeded = 1,
	FlashID = {
		86121--[[Soul Swap]],
		86213--[[Soul Swap Exhale]],
	},
	CheckFirst = function(z)
		z.FlashColor = s.If(x.ActiveEnemy and s.HasGlyph(57270--[[Glyph of Soul Swap]]), "White", "Pink")
		return x.NoCC and s.HealthPercent() <= 25 and not s.Boss()
	end,
}

a.spells["Soul Swap Exhale"] = {
	ID = 86121--[[Soul Swap]],
	RequireBuff = 86121--[[Soul Swap]],
	RequireBuffUnit = "player",
	EvenIfNotUsable = 1,
	NoPowerCheck = 1,
	EnemyTargetNeeded = 1,
	FlashID = {
		86121--[[Soul Swap]],
		86213--[[Soul Swap Exhale]],
	},
	CheckFirst = function(z)
		z.FlashColor = s.If(x.ActiveEnemy, "White", "Pink")
		return x.NoCC and UnitGUID(s.UnitSelection()) ~= a.LastSoulSwap
	end,
}

a.spells["Banish"] = {
	ID = 710--[[Banish]],
	--NotWhileMoving = 1,
	EnemyTargetNeeded = 1,
	Run = function(z)
		if UnitExists("focus") and not s.Boss("focus") then
			z.Unit = "focus"
		else
			z.Unit = nil
		end
		z.FlashColor = s.If(s.ActiveEnemy(z.Unit, 1), "Yellow", "Pink")
	end,
	CheckLast = function(z)
		local seconds = s.CastTime(z.ID) + s.SpellCooldown(z.ID) + x.DoubleLag
		return not s.Boss(z.Unit) and not s.ImmunityDebuff(z.Unit, seconds) and not s.BreakOnDamageCC(z.Unit, seconds + 5)
	end,
}

a.spells["Axe Toss"] = {
	Type = "pet",
	ID = 89766--[[Axe Toss]],
	Interrupt = 1,
	FlashColor = "Aqua",
	CheckFirst = function(z)
		return x.PetAlive
	end,
}

a.spells["Suffering"] = {
	Type = "pet",
	ID = 17735--[[Suffering]],
	FlashColor = "Red",
	CheckFirst = function(z)
		return x.PetAlive and ( x.InstanceType == "party" or x.InstanceType == "raid" ) and s.Autocast(17735--[[Suffering]])
	end,
}

a.spells["Consume Shadows"] = {
	Type = "pet",
	ID = 17767--[[Consume Shadows]],
	FlashColor = "Green",
	CheckFirst = function(z)
		return x.PetAlive and not s.InCombat() and ( s.HealthPercent("pet") <= 99 or s.PowerPercent("pet") <= 99 )
	end,
}

a.spells["Felstorm"] = {
	Type = "pet",
	ID = 89751--[[Felstorm]],
	FlashColor = "Purple",
	CheckFirst = function(z)
		return x.PetAlive and x.PetActiveEnemy
	end,
}

a.spells["Whiplash"] = {
	Type = "pet",
	ID = 6360--[[Whiplash]],
	FlashColor = "Purple",
	CheckFirst = function(z)
		return x.PetAlive and x.PetActiveEnemy
	end,
}

a.spells["Sacrifice"] = {
	Type = "pet",
	ID = 7812--[[Sacrifice]],
	FlashColor = "Green",
	CheckFirst = function(z)
		return x.PetAlive and x.ActiveEnemy and ( s.EnemyTargetingYou() or s.Boss() or s.Boss("pettarget") ) and s.HealthPercent("pet") > 25
	end,
}

a.spells["Flee"] = {
	Type = "pet",
	ID = 89792--[[Flee]],
	FlashColor = "Aqua",
	CheckFirst = function(z)
		return x.PetAlive and s.NoDamageCC("pet")
	end,
}

a.spells["Spell Lock"] = {
	Type = "pet",
	ID = 19647--[[Spell Lock]],
	Interrupt = 1,
	FlashColor = "Aqua",
	CheckFirst = function(z)
		return x.PetAlive
	end,
}

a.spells["Devour Magic"] = {
	Type = "pet",
	ID = 19505--[[Devour Magic]],
	FlashColor = "Green",
	CheckFirst = function(z)
		return x.PetAlive and x.PetActiveEnemy and ( s.HealthPercent("pet") <= 95 or ( s.HealthPercent("player") <= 95 and s.HasGlyph(56249--[[Glyph of Felhunter]]) ) ) and s.Buff(nil, "pettarget")
	end,
}

a.spells["Attack"] = {
	Type = "pet",
	ID = "Attack",
	FlashColor = "Pink",
	CheckFirst = function(z)
		return x.PetAlive and x.ActiveEnemy and not x.PetActiveEnemy
	end,
}

a.spells["Follow"] = {
	Type = "pet",
	ID = "Follow",
	CheckFirst = function(z)
		return x.PetAlive and x.PetActiveEnemy and not UnitPlayerControlled("pettarget") and not UnitExists("pettargettarget") and s.HealthPercent("pettarget") <= 25
	end,
}

a.spells["Stay"] = {
	Type = "pet",
	ID = "Stay",
	CheckFirst = function(z)
		return x.PetAlive and not x.PetNoCC
	end,
}

