local MinBuild, MaxBuild, Build = 40000, 0, select(4, GetBuildInfo())
if Build < MinBuild or ( MaxBuild > 0 and Build > MaxBuild ) then return end
local AddonName, a = ...
local AddonTitle = select(2, GetAddOnInfo(AddonName))
local PlainAddonTitle = AddonTitle:gsub("|c........", ""):gsub("|r", "")
local L = a.Localize
local s = SpellFlashAddon
local x = s.UpdatedVariables


function a.ShadowEmbrace()
	if s.HasTalent(32385--[[Shadow Embrace]]) and ( s.CurrentSpell(48181--[[Haunt]]) or s.Casting(48181--[[Haunt]], "player") or math.max((s.SpellCooldown(686--[[Shadow Bolt]])), s.GetCasting(686--[[Shadow Bolt]], "player")) + s.CastTime(686--[[Shadow Bolt]]) < s.SpellCooldown(48181--[[Haunt]]) + s.CastTime(48181--[[Haunt]]) or not s.Flashable(48181--[[Haunt]]) ) then
		local cast = x.Lag + 2
		if not s.SpellOrAuraDelay(32385--[[Shadow Embrace]]) then
			cast = ( s.Casting(686--[[Shadow Bolt]], "player") or s.Casting(48181--[[Haunt]], "player") or (math.max((s.SpellCooldown(686--[[Shadow Bolt]])), s.GetCasting(nil, "player")) + s.CastTime(686--[[Shadow Bolt]])) ) + x.DoubleLag + 2
		end
		local stack = s.MyDebuffStack(32385--[[Shadow Embrace]], nil, cast)
		if s.AuraDelay(32385--[[Shadow Embrace]]) then
			stack = stack + 1
		end
		if s.CurrentSpell(686--[[Shadow Bolt]]) or s.Casting(686--[[Shadow Bolt]], "player") or s.CurrentSpell(48181--[[Haunt]]) or s.Casting(48181--[[Haunt]], "player") then
			stack = stack + 1
		end
		stack = stack + (s.SpellDelay(32385--[[Shadow Embrace]]) or 0)
		return stack < 3
	end
	return false
end

local ShadowAndFlameDebuffs = {
	17800--[[Shadow and Flame]],
	11095--[[Critical Mass]],
}
function a.ShadowAndFlame(SpellID)
	return s.TalentRank(17793--[[Shadow and Flame]]) > 1
	and not s.SpellOrAuraDelay(17800--[[Shadow and Flame]])
	and not s.CurrentSpell(686--[[Shadow Bolt]])
	and not s.Casting(686--[[Shadow Bolt]], "player")
	and not s.CurrentSpell(29722--[[Incinerate]])
	and not s.Casting(29722--[[Incinerate]], "player")
	and not s.Debuff(ShadowAndFlameDebuffs, nil, math.max((s.SpellCooldown(SpellID)), s.GetCasting(nil, "player")) + s.CastTime(SpellID) + x.DoubleLag + 2)
end

local ImmunityDebuffs = {
	710--[[Banish]],
	33786--[[Cyclone]],
}
function a.IdleTarget(SpellID)
	return not s.InCombat() and not s.SpellDelay(SpellID) and (
		not x.ActiveEnemy
		or
		(
			s.Player()
			and
			(
				(
					x.NoCC and not s.EnemyTargetingYou()
				)
				or
				(
					not x.NoCC and s.DebuffDuration(ImmunityDebuffs) <= s.CastTime(SpellID) + s.SpellCooldown(SpellID) + x.Lag
				)
			)
		)
	)
end
