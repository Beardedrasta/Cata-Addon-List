local MinBuild, MaxBuild, Build = 40000, 0, select(4, GetBuildInfo())
if Build < MinBuild or ( MaxBuild > 0 and Build > MaxBuild ) then return end
local AddonName, a = ...
local AddonTitle = select(2, GetAddOnInfo(AddonName))
local PlainAddonTitle = AddonTitle:gsub("|c........", ""):gsub("|r", "")
local L = a.Localize
local s = SpellFlashAddon
local x = s.UpdatedVariables

-- SpellFlash API:
-- http://wow.curseforge.com/addons/spellflash/pages/api/

-- Updated variable references:
-- http://wow.curseforge.com/addons/spellflash/pages/api/#w-local-x-spell-flash-addon-updated-variables
-- x.Enemy, x.ActiveEnemy, x.NoCC, x.InInstance, x.InstanceType, x.PetAlive, x.PetActiveEnemy, x.PetNoCC, x.Lag, x.DoubleLag, x.ThreatPercent, x.EnemyDetected, x.ShouldPermanentBuff, x.ShouldTemporaryBuff


-- Use this single spam function and remove the multiple spam table below, or just use the multiple spam table below and leave this function in place.
s.Spam[AddonName] = function()
	
	if x.PetAlive then
		
		if s.HasSpell(93375--[[Control Demon]]) then
		
			a.FlashAll("Axe Toss", "Suffering")
			
			a.Flash("Consume Shadows", "Health Funnel")
			
			if not a.Flash(
				"Felstorm",
				"Whiplash",
				"Sacrifice",
				"Flee",
			nil) then
				
				a.FlashAll("Spell Lock", "Devour Magic")
				
			end
			
			a.Flash("Attack", "Follow", "Stay")
			
		end
		
		a.Flash("Demon Soul")
		
	else
		
		a.FlashAll(
			"Summon Imp",
			"Summon Succubus",
			"Summon Voidwalker",
			"Summon Felhunter",
			"Summon Felguard",
		nil)
		
	end
	
	a.FlashAll(
		"Banish",
		"Soulshatter",
		"Soulstone",
		"Create Soulstone",
		"Shadow Ward",
		"Soul Link",
		"Fel Armor",
		"Demon Armor",
		"Unending Breath",
		"Dark Intent",
	nil)
	
	a.Flash("Ritual of Souls", "Create Healthstone")
	a.Flash("Life Tap", "Soul Harvest")
	
	if a.Flash("Soul Fire - Starter", "Shadow Bolt - Starter") then return end
	
	a.FlashAll(
		"Summon Doomguard",
		"Summon Infernal",
		"Curse of Exhaustion",
		"Corruption",
		"Drain Soul - Finisher",
		"Drain Life",
	nil)
	
	a.Flash("Bane of Doom", "Bane of Agony")
	a.Flash("Soul Swap", "Soul Swap Exhale")
	
	if not a.Flash("Curse of the Elements") then
		a.FlashAll("Curse of Weakness", "Curse of Tongues")
	end
	
	if not a.Flash("Metamorphosis") then
		a.FlashAll("Immolation Aura", "Demon Leap")
	end
	
	a.Flash(
		"Soul Fire - Soulburn",
		"Fel Flame - Fel Spark",
		"Shadow Bolt - Shadow Trance",
		"Conflagrate",
		"Shadowburn",
		"Chaos Bolt",
		"Haunt",
		"Unstable Affliction",
		"Immolate",
		"Hand of Gul'dan",
		"Shadowflame", -- Continue
		"Shadow Bolt - Shadow Embrace",
		"Incinerate - Molten Core",
		"Incinerate - Shadow and Flame",
		"Shadow Bolt - Shadow and Flame",
		"Soulburn",
		"Soul Fire - Decimation",
		"Soul Fire - Improved Soul Fire",
		"Drain Soul",
		"Incinerate",
		"Shadow Bolt",
		"Fel Flame",
	nil)
	
end

