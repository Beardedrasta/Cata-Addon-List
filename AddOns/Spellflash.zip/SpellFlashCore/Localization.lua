﻿-- To update a translation please use the localization utility at:
-- http://wow.curseforge.com/addons/spellflashcore/localization/

local AddonName, AddonTable = ...
local function DefaultFunction(_, key) return key end
AddonTable.Localize = setmetatable({}, {__index = DefaultFunction})
local L = AddonTable.Localize

-- Example:
L["English text goes here."] = "Translated text goes here."

if GetLocale() == "ptBR" then -- Brazilian Portuguese
--@localization(locale="ptBR", format="lua_additive_table")@
elseif GetLocale() == "frFR" then -- French
--@localization(locale="frFR", format="lua_additive_table")@
elseif GetLocale() == "deDE" then -- German
--@localization(locale="deDE", format="lua_additive_table")@
elseif GetLocale() == "koKR" then -- Korean
--@localization(locale="koKR", format="lua_additive_table")@
elseif GetLocale() == "esMX" then -- Latin American Spanish
--@localization(locale="esMX", format="lua_additive_table")@
elseif GetLocale() == "ruRU" then -- Russian
--@localization(locale="ruRU", format="lua_additive_table")@
elseif GetLocale() == "zhCN" then -- Simplified Chinese
--@localization(locale="zhCN", format="lua_additive_table")@
elseif GetLocale() == "esES" then -- Spanish
--@localization(locale="esES", format="lua_additive_table")@
elseif GetLocale() == "zhTW" then -- Traditional Chinese
--@localization(locale="zhTW", format="lua_additive_table")@
end