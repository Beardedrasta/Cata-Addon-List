local MinBuild, MaxBuild, Build = 40000, 0, select(4, GetBuildInfo())
if Build < MinBuild or ( MaxBuild > 0 and Build > MaxBuild ) then return end
local AddonName, a = ...
local AddonTitle = select(2, GetAddOnInfo(AddonName))
local PlainAddonTitle = AddonTitle:gsub("|c........", ""):gsub("|r", "")
local L = a.Localize
local s = SpellFlashAddon
local x = s.UpdatedVariables

local c = BittensSpellFlashLibrary2
c.Init(AddonName, a)

------------------------------------------------------------------------ common
local function needsInner()
    return not s.Buff(c.GetID("Inner Fire"), "player")
        and not s.Buff(c.GetID("Inner Will"), "player")
end

a.spells["Surge of Light"] = { ID = 88688 }

a.spells["Power Word: Fortitude"] = {
    ID = 21562,
    NoRangeCheck = 1,
    FlashColor = "yellow",
    CheckFirst = function()
        return c.RaidBuffNeeded(c.STAMINA_BUFFS)
    end
}

a.spells["Shadow Protection"] = {
    ID = 27683,
    NoRangeCheck = 1,
    FlashColor = "yellow",
    CheckFirst = function()
        return c.RaidBuffNeeded(c.SHADOW_RESISTANCE_BUFFS)
    end
}

a.spells["Free Flash Heal"] = {
    ID = 2061,
    NoRangeCheck = 1,
    FlashColor = "yellow",
    NoStopChannel = 1,
    CheckFirst = function()
        return c.HasBuff("Surge of Light")
    end
}

a.spells["Shadowfiend for Mana"] = {
    ID = 34433,
    FlashColor = "yellow",
    NoStopChannel = 1,
    CheckFirst = function()
        return s.PowerPercent("player") < 70
    end
}

a.spells["Inner Fire"] = {
    ID = 588,
    Buff = 588,
    BuffUnit = "player",
    FlashColor = "yellow",
}

a.spells["Inner Fire unless Inner Will"] = {
    ID = 588,
    FlashColor = "yellow",
    CheckFirst = needsInner,
}

a.spells["Inner Will"] = {
    ID = 73413,
    Buff = 73413,
    BuffUnit = "player",
    FlashColor = "yellow",
}

a.spells["Inner Will unless Inner Fire"] = {
    ID = 73413,
    FlashColor = "yellow",
    CheckFirst = needsInner,
}

-------------------------------------------------------------------- discipline
a.spells["Weakened Soul"] = { ID = 6788 }

a.spells["Pennance"] = {
    ID = 47540,
    FlashColor = "yellow",
}

a.spells["Inner Focus"] = {
    ID = 89485,
    FlashColor = "yellow",
    NoGCD = 1,
}

a.spells["Power Word: Shield"] = {
    ID = 17,
    MyBuff = 17,
    FlashColor = "yellow",
    NoStopChannel = 1,
    CheckFirst = function(z)
        if a.GetConfig("mouseover_bubble") then
            z.Unit = "mouseover"
        else
            z.Unit = nil
        end
        return not s.Debuff(
            c.GetID("Weakened Soul"), z.Unit, c.GetBusyTime())
    end
}

-------------------------------------------------------------------------- holy
a.spells["Serendipity 1"] = { ID = 63730 }
a.spells["Serendipity 2"] = { ID = 63733 }
a.spells["Chakra: Serenity"] = { ID = 81208 }
a.spells["Chakra: Sanctuary"] = { ID = 81206 }

local function getSerendipityStacks()
    local stacks = c.GetBuffStack("Serendipity 1")
    if stacks == 0 then
        return c.GetBuffStack("Serendipity 2")
    else
        return stacks
    end
end

local function inSerenity()
    return s.Buff(c.GetID("Chakra: Serenity"), "player")
end

local function inSanctuary()
    return s.Buff(c.GetID("Chakra: Sanctuary"), "player")
end

local function holyWordOverride(z)
    z.FlashID = { 
        c.GetID("Holy Word: Chastise"),
        c.GetID("Holy Word: Serenity"),
        c.GetID("Holy Word: Sanctuary"),
    }
    if inSerenity() then
        return c.GetCooldown("Holy Word: Serenity") == 0
    elseif inSanctuary() then
        return c.GetCooldown("Holy Word: Sanctuary") == 0
    else
        return false
    end
end

a.spells["Lightwell"] = {
    ID = 724,
    NoRangeCheck = 1,
    FlashColor = "yellow",
}

a.spells["Greater Heal under Serendipity"] = {
    ID = 2060,
    FlashColor = "yellow",
    NoRangeCheck = 1,
    CheckFirst = function(z)
        local stacks = getSerendipityStacks()
        if stacks == 1 then
            z.FlashSize = s.FlashSizePercent() / 2
        else
            z.FlashSize = nil
        end
        return stacks > 0
    end
}

a.spells["Prayer of Healing under Serendipity"] = {
    ID = 596,
    FlashColor = "yellow",
    NoRangeCheck = 1,
    CheckFirst = function(z)
        local stacks = getSerendipityStacks()
        if stacks == 1 then
            z.FlashSize = s.FlashSizePercent() / 2
        else
            z.FlashSize = nil
        end
        return stacks > 0
    end
}

a.spells["Chakra"] = {
    ID = 14751,
    Buff = chakras,
    BuffUnit = "player",
    FlashColor = "yellow",
    CheckFirst = function(z)
        return not inSerenity() and not inSanctuary()
    end
}

a.spells["Holy Word: Chastise"] = {
    ID = 88625,
    FlashColor = "yellow",
    Override = holyWordOverride,
}

a.spells["Holy Word: Serenity"] = {
    ID = 88684,
    FlashColor = "yellow",
    Override = holyWordOverride,
}

a.spells["Holy Word: Sanctuary"] = {
    ID = 88685,
--    NoRangeCheck = 1,
    FlashColor = "yellow",
    Override = holyWordOverride,
}

a.spells["Prayer of Mending"] = {
    ID = 33076,
    NoRangeCheck = 1,
    FlashColor = "yellow",
    CheckFirst = function()
        return not a.PrayerOfMendingTarget
            or s.MyBuffDuration(33076, a.PrayerOfMendingTarget) 
                < c.GetBusyTime()
            or s.MyBuffStack(33076, a.PrayerOfMendingTarget) < 5
    end
}

------------------------------------------------------------------------ shadow
a.spells["Shadow Orb"] = { ID = 77487 }
a.spells["Empowered Shadow"] = { ID = 95799 }
a.spells["Dark Evangelism"] = { ID = 87118 }

a.spells["Shadowform"] = {
    ID = 15473,
    NotIfActive = 1,
    FlashColor = "yellow",
}

a.spells["Vampiric Embrace"] = {
    ID = 15286,
    Buff = 15286,
    BuffUnit = "player",
    FlashColor = "yellow",
}

a.spells["Shadowfiend"] = {
    ID = 34433,
    Continue = 1,
    FlashColor = "yellow",
    NoStopChannel = 1,
}

a.spells["Shadow Word: Death"] = {
    ID = 32379,
    NoStopChannel = 1,
    CheckFirst = function(z)
        if s.HealthPercent() > 25 then
            z.FlashColor = "yellow"
            z.Continue = 1
            return s.PowerPercent("player") < 50
        else
            z.FlashColor = nil
            z.Continue = nil
            return true
        end
    end
}

a.spells["Vampiric Touch"] = {
    ID = 34914,
    MyDebuff = 34914,
    EarlyRefresh = 2,
    NotIfActive = 1,
    NoStopChannel = 1,
}
c.ManageDotRefresh("Vampiric Touch", 3)

a.spells["Devouring Plague"] = {
    ID = 2944,
    MyDebuff = 2944,
    EarlyRefresh = 2,
    NoStopChannel = 1,
}
c.ManageDotRefresh("Devouring Plague", 3)

a.spells["Shadow Word: Pain"] = {
    ID = 589,
    MyDebuff = 589,
    NoStopChannel = 1,
}

a.spells["Mind Blast"] = {
    ID = 8092,
    NotIfActive = 1,
    NoStopChannel = 1,
}

a.spells["Mind Blast at 3 Orbs"] = {
    ID = 8092,
    NotIfActive = 1,
    NoStopChannel = 1,
    CheckFirst = function()
        return c.GetBuffStack("Shadow Orb") == 3
    end
}

a.spells["Mind Blast for Empowered Shadow"] = {
    ID = 8092,
    NotIfActive = 1,
    CheckFirst = function()
        return c.HasBuff("Shadow Orb")
    end
}

a.spells["Mind Flay"] = {
    ID = 15407,
}

a.spells["Mind Flay for Dark Evangelism"] = {
    ID = 15407,
    CheckFirst = function()
        return c.BuffStack("Dark Evangelism") < 5
    end
}

a.spells["Mind Flay for Empowered Shadow"] = {
    ID = 15407,
    CheckFirst = function()
        return not c.HasBuff("Empowered Shadow")
            and not s.Casting(c.GetID("Mind Blast"), "player")
    end
}

a.spells["Dark Archangel"] = {
    ID = 87151,
    NoGCD = true,
    Continue = true,
    FlashColor = "yellow",
    CheckFirst = function()
        return c.GetBuffStack("Dark Evangelism") == 5
    end
}

a.spells["Dispursion"] = {
    ID = 47585,
    FlashColor = "yellow",
    CheckFirst = function()
        return s.PowerPercent("player") < 64
    end
}
