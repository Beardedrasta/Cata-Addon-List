local MinBuild, MaxBuild, Build = 40000, 0, select(4, GetBuildInfo())
if Build < MinBuild or ( MaxBuild > 0 and Build > MaxBuild ) then return end
local AddonName, a = ...
local AddonTitle = select(2, GetAddOnInfo(AddonName))
local PlainAddonTitle = AddonTitle:gsub("|c........", ""):gsub("|r", "")
local L = a.Localize
local s = SpellFlashAddon
local x = s.UpdatedVariables

local c = BittensSpellFlashLibrary2
a.Rotations = {}

s.Spam[AddonName] = function()
    c.Flash(AddonName, a)
end

a.Rotations.Discipline = {
    Spec = 1,
    OffSwitch = "disc_off",
    Function = function()
        a.FlashAll(
            "Power Word: Fortitude",
            "Shadow Protection",
            "Inner Fire unless Inner Will", 
            "Inner Will unless Inner Fire")
        if not s.InCombat() then
            return
        end
        
        a.FlashAll(
            "Prayer of Mending",
            "Free Flash Heal",
            "Shadowfiend for Mana",
            "Pennance",
            "Inner Focus",
            "Power Word: Shield")
    end
}

a.Rotations.Holy = {
    Spec = 2,
    OffSwitch = "holy_off",
    Function = function()
        a.FlashAll(
            "Power Word: Fortitude",
            "Shadow Protection",
            "Inner Fire unless Inner Will", 
            "Inner Will unless Inner Fire",
            "Chakra")
        if not s.InCombat() then
            return
        end
        
        a.FlashAll(
            "Prayer of Mending",
            "Free Flash Heal",
            "Shadowfiend for Mana",
            "Lightwell",
            "Greater Heal under Serendipity",
            "Prayer of Healing under Serendipity",
            "Holy Word: Chastise",
            "Holy Word: Serenity",
            "Holy Word: Sanctuary")
    end
}

a.Rotations.Shadow = {
    Spec = 3,
    OffSwitch = "shadow_off",
    Function = function()
        a.FlashAll(
            "Power Word: Fortitude",
            "Shadow Protection",
            "Shadowform", 
            "Inner Fire", 
            "Vampiric Embrace")
        if not s.InCombat() then
            a.Flash("Dispursion")
            return
        end
        
        a.Flash(
            "Shadow Word: Pain",
            "Mind Blast for Empowered Shadow",
            "Mind Flay for Empowered Shadow",
            "Mind Blast at 3 Orbs",
            "Dark Evangelism",
            "Vampiric Touch",
            "Devouring Plague",
            "Dark Archangel",
            "Mind Blast",
            "Shadow Word: Death",
            "Shadowfiend",
            "Mind Flay")
    end
}
