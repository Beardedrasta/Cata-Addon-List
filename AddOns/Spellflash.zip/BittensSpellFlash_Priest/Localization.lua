-- To update a translation please use the localization utility at:
-- http://wow.curseforge.com/addons/bittens-spellflash-priest/localization/

local AddonName, a = ...
local function DefaultFunction(_, key) return key end
a.Localize = setmetatable({}, {__index = DefaultFunction})
local L = a.Localize

-- Example:
L["English text goes here."] = "Translated text goes here."

if GetLocale() == "ptBR" then -- Brazilian Portuguese
-- L["Flash Discipline"] = ""
-- L["Flash Holy"] = ""
-- L["Flash Shadow"] = ""

elseif GetLocale() == "frFR" then -- French
-- L["Flash Discipline"] = ""
-- L["Flash Holy"] = ""
-- L["Flash Shadow"] = ""

elseif GetLocale() == "deDE" then -- German
L["Flash Discipline"] = "Aufblitzen bei Disziplin" -- Needs review
L["Flash Holy"] = "Aufblitzen bei Heilig" -- Needs review
L["Flash Shadow"] = "Aufblitzen bei Schatten" -- Needs review

elseif GetLocale() == "koKR" then -- Korean
-- L["Flash Discipline"] = ""
-- L["Flash Holy"] = ""
-- L["Flash Shadow"] = ""

elseif GetLocale() == "esMX" then -- Latin American Spanish
-- L["Flash Discipline"] = ""
-- L["Flash Holy"] = ""
-- L["Flash Shadow"] = ""

elseif GetLocale() == "ruRU" then -- Russian
-- L["Flash Discipline"] = ""
-- L["Flash Holy"] = ""
-- L["Flash Shadow"] = ""

elseif GetLocale() == "zhCN" then -- Simplified Chinese
-- L["Flash Discipline"] = ""
-- L["Flash Holy"] = ""
-- L["Flash Shadow"] = ""

elseif GetLocale() == "esES" then -- Spanish
-- L["Flash Discipline"] = ""
-- L["Flash Holy"] = ""
-- L["Flash Shadow"] = ""

elseif GetLocale() == "zhTW" then -- Traditional Chinese
-- L["Flash Discipline"] = ""
-- L["Flash Holy"] = ""
-- L["Flash Shadow"] = ""

end