local MinBuild, MaxBuild, Build = 40000, 0, select(4, GetBuildInfo())
if Build < MinBuild or ( MaxBuild > 0 and Build > MaxBuild ) then return end
local AddonName, a = ...
local AddonTitle = select(2, GetAddOnInfo(AddonName))
local PlainAddonTitle = AddonTitle:gsub("|c........", ""):gsub("|r", "")
local L = a.Localize
local s = SpellFlashAddon
local x = s.UpdatedVariables
local config = {}
config.event = {}

local c = BittensSpellFlashLibrary2

function config.event.COMBAT_LOG_EVENT_UNFILTERED(event, ...)
    event = select(2, ...)
    sourceGUID = select(4, ...)
    spellName = select(13, ...)
    if event ~= "SPELL_CAST_SUCCESS" or sourceGUID ~= UnitGUID("player") then
        return
    end
    
    c.Init(AddonName, a)
    if spellName == s.SpellName(c.GetID("Earth Shield"), 1) then
        a.EarthShieldTarget = select(9, ...)
    end
end

config.CheckButtonOptions = {
    LeftCheckButton1 = {
        DefaultChecked = true,
        ConfigKey = "elemental_off",
        Label = L["Flash Elemental"],
    },
    LeftCheckButton2 = {
        DefaultChecked = true,
        ConfigKey = "enhance_off",
        Label = L["Flash Enhancement"],
    },
    LeftCheckButton3 = {
        DefaultChecked = true,
        ConfigKey = "resto_off",
        Label = L["Flash Restoration"],
    },
    LeftCheckButton4 = {
        DefaultChecked = true,
        ConfigKey = "My_Config_Key",
        Label = L["My_Check_Button_Label"],
    },
    LeftCheckButton5 = {
        DefaultChecked = true,
        ConfigKey = "My_Config_Key",
        Label = L["My_Check_Button_Label"],
    },
    LeftCheckButton6 = {
        DefaultChecked = true,
        ConfigKey = "My_Config_Key",
        Label = L["My_Check_Button_Label"],
    },
    LeftCheckButton7 = {
        DefaultChecked = true,
        ConfigKey = "My_Config_Key",
        Label = L["My_Check_Button_Label"],
    },
    RightCheckButton1 = {
        DefaultChecked = true,
        ConfigKey = "My_Config_Key",
        Label = L["My_Check_Button_Label"],
    },
    RightCheckButton2 = {
        DefaultChecked = false,
        ConfigKey = "My_Config_Key",
        Label = L["My_Check_Button_Label"],
    },
    RightCheckButton3 = {
        DefaultChecked = true,
        ConfigKey = "My_Config_Key",
        Label = L["My_Check_Button_Label"],
    },
    RightCheckButton4 = {
        DefaultChecked = true,
        ConfigKey = "My_Config_Key",
        Label = L["My_Check_Button_Label"],
    },
    RightCheckButton5 = {
        DefaultChecked = true,
        ConfigKey = "My_Config_Key",
        Label = L["My_Check_Button_Label"],
    },
    RightCheckButton6 = {
        DefaultChecked = true,
        ConfigKey = "My_Config_Key",
        Label = L["My_Check_Button_Label"],
    },
    RightCheckButton7 = {
        DefaultChecked = true,
        ConfigKey = "My_Config_Key",
        Label = L["My_Check_Button_Label"],
    },
}

a.LoadConfigs(config)