local MinBuild, MaxBuild, Build = 40000, 0, select(4, GetBuildInfo())
if Build < MinBuild or ( MaxBuild > 0 and Build > MaxBuild ) then return end
local AddonName, a = ...
local AddonTitle = select(2, GetAddOnInfo(AddonName))
local PlainAddonTitle = AddonTitle:gsub("|c........", ""):gsub("|r", "")
local L = a.Localize
local s = SpellFlashAddon
local x = s.UpdatedVariables

local c = BittensSpellFlashLibrary2
a.Rotations = {}

s.Spam[AddonName] = function()
    c.Flash(AddonName, a)
end

a.Rotations.Elemental = {
    Spec = 1,
    OffSwitch = "elemental_off",
    Function = function()
        a.FlashAll("Lightning Shield", "Flametongue Weapon")
        if not s.InCombat() then
            a.Flash("Thunderstorm")
            return
        end
        
        a.FlashAll("Elemental Mastery", "Wind Shear")
        a.Flash(
            "Fire Elemental Totem",
            "Searing Totem",
            "Lava Burst",
            "Flame Shock",
            "Fulmination",
            "Lightning Bolt")
    end
}

a.Rotations.Enhancement = {
    Spec = 2,
    OffSwitch = "enhance_off",
    Function = function()
        a.FlashAll(
            "Lightning Shield", "Windfury Weapon", "Flametongue Weapon Offhand")
        if not s.InCombat() then
            return
        end
        
        a.FlashAll("Wind Shear")
        a.Flash(
            "Searing Totem",
            "Stormstrike",
            "Lava Lash",
            "Lightning Bolt at 5 Maelstrom",
            "Flame Shock under Unleash Flame",
            "Unleash Elements",
            "Earth Shock",
            "Feral Spirit",
            "Searing Totem Early",
            "Lightning Bolt at 4 Maelstrom")
    end
}

a.Rotations.Restoration = {
    Spec = 3,
    OffSwitch = "resto_off",
    Function = function()
        a.FlashAll("Water Shield", "Earthliving Weapon", "Earth Shield")
        if not s.InCombat() then
            return
        end
        
        a.FlashAll("Wind Shear")
    end
}
