local MinBuild, MaxBuild, Build = 40000, 0, select(4, GetBuildInfo())
if Build < MinBuild or ( MaxBuild > 0 and Build > MaxBuild ) then return end
local AddonName, a = ...
local AddonTitle = select(2, GetAddOnInfo(AddonName))
local PlainAddonTitle = AddonTitle:gsub("|c........", ""):gsub("|r", "")
local L = a.Localize
local s = SpellFlashAddon
local x = s.UpdatedVariables

local c = BittensSpellFlashLibrary2

local function ShouldFlashShield(id, noncombatStacks)
    local duration = s.BuffDuration(id, "player")
    if s.InCombat() then
        return duration == 0
    else
        return duration < 5 * 60 or s.BuffStack(id, "player") < noncombatStacks
    end
end

local function ShouldFlashImbue(buffTooltipName, offhand)
    local min
    if s.InCombat() then
        min = 0
    else
        min = 5 * 60
    end
    if offhand then
        return not s.OffHandItemBuff(L[buffTooltipName], min)
    else
        return not s.MainHandItemBuff(L[buffTooltipName], min)
    end
end

local function getFireTotemDuration()
    local haveTotem, name, startTime, duration, icon = GetTotemInfo(1)
    duration = startTime + duration - GetTime() - c.GetBusyTime()
    return math.max(0, duration)
end

a.spells["Wind Shear"] = {
    ID = 57994,
    Interrupt = 1,
    FlashColor = "aqua",
}

--------------------------------------------------------------------- elemental
a.spells["Elemental Mastery"] = {
    ID = 16166,
    NoGCD = true,
    FlashColor = "yellow",
}

a.spells["Thunderstorm"] = {
    ID = 51490,
    FlashColor = "yellow",
    CheckFirst = function()
        return s.PowerPercent("player") < 100
    end
}

a.spells["Totems"] = {
    ID = 66842,
}

a.spells["Lightning Shield"] = {
    ID = 324,
    FlashColor = "yellow",
    Override = function()
        return ShouldFlashShield(324, 3)
    end
}

a.spells["Flame Shock"] = {
    ID = 8050,
    MyDebuff = "Flame Shock",
    EarlyRefresh = 2.5,
}

a.spells["Lava Burst"] = {
    ID = 51505,
    NotIfActive = true,
    CheckFirst = function()
        return c.GetMyDebuffDuration("Flame Shock") > s.CastTime(51505)
    end
}

a.spells["Fulmination"] = {
    ID = 8042,
    CheckFirst = function()
        local remaining = c.GetMyDebuffDuration("Flame Shock")
        local stacks = s.BuffStack(c.GetID("Lightning Shield"), "player")
        return remaining > 5 and ((remaining < 7 and stacks > 6) or stacks > 7)
    end
}

a.spells["Chain Lightning"] = {
    ID = 421,
}

a.spells["Lightning Bolt"] = {
    ID = 403,
}

a.spells["Flametongue Weapon"] = {
    ID = 8024,
    FlashColor = "yellow",
    Override = function()
        return ShouldFlashImbue("Flametongue")
    end
}

a.spells["Unleash for Lava Burst"] = {
    ID = 73680,
    CheckFirst = function()
        local burstCD = c.getCooldown("Lava Burst")
        local burstCast = s.CastTime("Lava Burst")
        local shockCD = c.getCooldown("Flame Shock")
        local shockRemaining = c.getMyDebuffDuration("Flame Shock")
        return not s.Casting("Lava Burst", "player")
            and burstCD < 2.5
            and burstCD > 1
            and shockCD < burstCD + burstCast 
            and shockRemaining > burstCD + burstCast
            and shockRemaining < burstCD + burstCast + a.spells["Flame Shock"].EarlyRefresh
    end
}

a.spells["Searing Totem"] = {
    ID = 3599,
    CheckFirst = function()
        return getFireTotemDuration() == 0
    end
}

a.spells["Fire Elemental Totem"] = {
    ID = 2894,
    Continue = true,
    FlashColor = "yellow",
    CheckFirst = function()
        return getFireTotemDuration() == 0
    end
}

----------------------------------------------------------------------- enhance
a.spells["Unleash Flame"] = { ID = 73683 }
a.spells["Maelstrom Weapon"] = { ID = 53817 }

a.spells["Windfury Weapon"] = {
    ID = 8232,
    FlashColor = "yellow",
    Override = function()
        return ShouldFlashImbue("Windfury")
    end
}

a.spells["Flametongue Weapon Offhand"] = {
    ID = 8024,
    FlashColor = "yellow",
    Override = function()
        return ShouldFlashImbue("Flametongue", true)
    end
}

a.spells["Stormstrike"] = {
    ID = 17364,
}

a.spells["Lava Lash"] = {
    ID = 60103,
}

a.spells["Lightning Bolt at 4 Maelstrom"] = {
    ID = 403,
    NotIfActive = 1,
    CheckFirst = function()
        return c.GetBuffStack("Maelstrom Weapon") == 4
    end
}

a.spells["Lightning Bolt at 5 Maelstrom"] = {
    ID = 403,
    CheckFirst = function()
        return c.GetBuffStack("Maelstrom Weapon") == 5
    end
}

a.spells["Flame Shock under Unleash Flame"] = {
    ID = 8050,
    CheckFirst = function()
        return c.HasBuff("Unleash Flame")
    end
}

a.spells["Unleash Elements"] = {
    ID = 73680,
}

a.spells["Earth Shock"] = {
    ID = 8042,
}

a.spells["Feral Spirit"] = {
    ID = 51533,
    Continue = 1,
    FlashColor = "yellow",
    NoRangeCheck = 1,
}

a.spells["Searing Totem Early"] = {
    ID = 3599,
    CheckFirst = function()
        return getFireTotemDuration() < 10
    end
}

------------------------------------------------------------------------- resto
a.spells["Earthliving Weapon"] = {
    ID = 51730,
    FlashColor = "yellow",
    Override = function()
        return ShouldFlashImbue("Earthliving")
    end
}

a.spells["Water Shield"] = {
    ID = 52127,
    FlashColor = "yellow",
    Override = function()
        return ShouldFlashShield(52127, 3)
    end
}

a.spells["Earth Shield"] = {
    ID = 974,
    FlashColor = "yellow",
    Override = function()
        if GetNumPartyMembers() < 1 and GetNumRaidMembers() < 2 then
            return false
        end
        
        if not a.EarthShieldTarget then
            return true
        end
        
        if s.InCombat() then
            return not s.MyBuff(974, a.EarthShieldTarget)
        else
            return s.MyBuffDuration(974, a.EarthShieldTarget) < 5 * 60
                or s.MyBuffStack(974, a.EarthShieldTarget) < 9
        end
    end
}
