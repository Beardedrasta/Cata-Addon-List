local MinBuild, MaxBuild, Build = 40000, 0, select(4, GetBuildInfo())
if Build < MinBuild or ( MaxBuild > 0 and Build > MaxBuild ) then return end
local AddonName, a = ...
local AddonTitle = select(2, GetAddOnInfo(AddonName))
local PlainAddonTitle = AddonTitle:gsub("|c........", ""):gsub("|r", "")
local L = a.Localize
local s = SpellFlashAddon
local x = s.UpdatedVariables


-- SpellFlash API: http://wow.curseforge.com/addons/spellflash/pages/api/
-- x.Enemy, x.ActiveEnemy, x.NoCC, x.InInstance, x.InstanceType, x.PetAlive, x.PetActiveEnemy, x.PetNoCC, x.Lag, x.DoubleLag, x.ThreatPercent, x.EnemyDetected, x.ShouldPermanentBuff, x.ShouldTemporaryBuff

--[[
	White - Default
	Yellow - Limited Time or No Global Cooldown
	Purple - AOE or Positional Damage
	Blue - AOE Debuff
	Orange - Finishing Move
	Aqua - Spell Interrupt, Reflect or Dispel
	Green - Self Buff or Turn Autocast On
	Red - Emergency Mitigation Cooldowns or Turn Autocast Off
	Pink - Optional
]]

-- Example spell table:
a.spells["English_Spell_Name"] = {
	Type = "spell",   --this indicates what kind of spell this is
	ID = GlobalSpellID--[[English_Spell_Name]],   --this is for defining the correct name of the spell
	DebuffSlotNeeded = 1,   --use this if you want to make sure that a debuff slot is free on the target so that you do not replace other debuffs
	Debuff = GlobalSpellID--[[English_Spell_Name]],   --place debuff ID or table of IDs here if the spell has a debuff that may only be on a target once in total from everyone and has a cooldown shorter than the debuff duration
	MyDebuff = GlobalSpellID--[[English_Spell_Name]],   --place debuff ID or table of IDs here if the spell has a debuff that may be on the target multiple times by many people and has a cooldown shorter than the debuff duration
	Buff = GlobalSpellID--[[English_Spell_Name]],   --place buff ID or table of IDs here if the spell has a buff that may only be on yourself once in total from everyone and has a cooldown shorter than the buff duration
	MyBuff = GlobalSpellID--[[English_Spell_Name]],   --place buff ID or table of IDs here if the spell has a buff that may be on the target multiple times by many people and has a cooldown shorter than the buff duration
	BuffUnit = "player",   --you will need to use this if the buff or debuff is not applied to your target
	Stack = 2,   --use this if the buff or debuff requires more than one application
	EarlyRefresh = 5,   --use this to indicate the buff or debuff early for a desired number of seconds
	RequireDebuff = GlobalSpellID--[[English_Spell_Name]],   --place buff ID or table of IDs here if a debuff needs to be on the target first
	RequireMyDebuff = GlobalSpellID--[[English_Spell_Name]],   --place buff ID or table of IDs here if your debuff needs to be on the target first
	RequireBuff = GlobalSpellID--[[English_Spell_Name]],   --place buff ID or table of IDs here if a buff needs to be on the target first
	RequireMyBuff = GlobalSpellID--[[English_Spell_Name]],   --place buff ID or table of IDs here if your buff needs to be on the target first
	RequireBuffUnit = "player",   --you will need to use this if the buff or debuff is not applied to your target
	RequireStack = 2,   --use this if the buff or debuff requires more than one application
	RequireMoreBuffTime = 5,   --use this to require more time be on the buff or debuff
	CastTime = 0,   --use this only if you want to replace the spell cast time used for early indication of a buff or debuff
	NoGCD = 1,   --use this to not use global cool down time to indicate the spell earlier
	EnemyTargetNeeded = 1,   --use this if the spell should have an enemy targeted
	Melee = 1,   --use this to check if you are within melee distance if the spell does not have built in distance checking
	TargetThatUsesManaNeeded = 1,   --use this if the spell is only useful on a target that uses mana such as mana draining spells
	NoRangeCheck = 1,   --use this to disable range detection if the spell has a limited range but the detection in this function is not working correctly for the particular spell
	NotIfActive = 1,   --use this if the spell may be toggled on such as auto attack or on next swing spells, or to disable when casting or channeling, or if the spell has a cooldown
	NotWhileMoving = 1,   --use this if the spell is not able to be cast while moving
	NoPowerCheck = 1,   --use this to disable the power checking in this function
	EvenIfNotUsable = 1,   --use this to disable the usability checking in this function and may be used if currently in the process of completing a prerequisite that will make the spell usable
	Unit = "target",   --this should not be used unless the spell is not to be cast on the target
	Interrupt = 1,   --use this if the target should be casting or channeling an interruptible ability
	CheckFirst = function(z) return true end,   --use this to check conditions or modify settings first before everything else has been checked
	CheckLast = function(z) return true end,   --use this to check conditions last after everything else has been checked
	Override = function(z) return true end,   --use this to use this function for condition checking and nothing else
	FlashColor = "White",   --use this to change the flash color if you want it to flash something other than white
	FlashSize = s.FlashSizePercent() * 2,   --use this to change the flash size
	FlashBrightness = 100,   --use this to change the flash brightness
	FlashBlink = 1,   --use this to have the button blink
	FlashNoMacros = 1,   --use this to not flash macros
	FlashID = GlobalSpellID--[[English_Spell_Name]],   --use this to add a spell ID or a table of spell IDs that will replace the spell that is flashed
	Continue = 1,   --this will make it so that even if this spell flashes in a list of spells it will continue checking the rest of the spells so that they may also be able to flash
}

-- Example form table:
a.spells["English_Spell_Name"] = {
	Type = "form",   --this indicates what kind of spell this is
	ID = GlobalSpellID--[[English_Spell_Name]],   --this is for defining the correct name of the spell
	DebuffSlotNeeded = 1,   --use this if you want to make sure that a debuff slot is free on the target so that you do not replace other debuffs
	Debuff = GlobalSpellID--[[English_Spell_Name]],   --place debuff ID or table of IDs here if the spell has a debuff that may only be on a target once in total from everyone and has a cooldown shorter than the debuff duration
	MyDebuff = GlobalSpellID--[[English_Spell_Name]],   --place debuff ID or table of IDs here if the spell has a debuff that may be on the target multiple times by many people and has a cooldown shorter than the debuff duration
	Buff = GlobalSpellID--[[English_Spell_Name]],   --place buff ID or table of IDs here if the spell has a buff that may only be on yourself once in total from everyone and has a cooldown shorter than the buff duration
	MyBuff = GlobalSpellID--[[English_Spell_Name]],   --place buff ID or table of IDs here if the spell has a buff that may be on the target multiple times by many people and has a cooldown shorter than the buff duration
	BuffUnit = "player",   --you will need to use this if the buff or debuff is not applied to your target
	Stack = 2,   --use this if the buff or debuff requires more than one application
	EarlyRefresh = 5,   --use this to indicate the buff or debuff early for a desired number of seconds
	RequireDebuff = GlobalSpellID--[[English_Spell_Name]],   --place buff ID or table of IDs here if a debuff needs to be on the target first
	RequireMyDebuff = GlobalSpellID--[[English_Spell_Name]],   --place buff ID or table of IDs here if your debuff needs to be on the target first
	RequireBuff = GlobalSpellID--[[English_Spell_Name]],   --place buff ID or table of IDs here if a buff needs to be on the target first
	RequireMyBuff = GlobalSpellID--[[English_Spell_Name]],   --place buff ID or table of IDs here if your buff needs to be on the target first
	RequireBuffUnit = "player",   --you will need to use this if the buff or debuff is not applied to your target
	RequireStack = 2,   --use this if the buff or debuff requires more than one application
	RequireMoreBuffTime = 5,   --use this to require more time be on the buff or debuff
	CastTime = 0,   --use this only if you want to replace the spell cast time used for early indication of a buff or debuff
	NoGCD = 1,   --use this to not use global cool down time to indicate the spell earlier
	EnemyTargetNeeded = 1,   --use this if the spell should have an enemy targeted
	Melee = 1,   --use this to check if you are within melee distance if the spell does not have built in distance checking
	TargetThatUsesManaNeeded = 1,   --use this if the spell is only useful on a target that uses mana such as mana draining spells
	NoRangeCheck = 1,   --use this to disable range detection if the spell has a limited range but the detection in this function is not working correctly for the particular spell
	NotIfActive = 1,   --use this if the spell may be toggled on such as auto attack or on next swing spells, or to disable when casting or channeling, or if the spell has a cooldown
	NotWhileMoving = 1,   --use this if the spell is not able to be cast while moving
	NoPowerCheck = 1,   --use this to disable the power checking in this function
	EvenIfNotUsable = 1,   --use this to disable the usability checking in this function and may be used if currently in the process of completing a prerequisite that will make the spell usable
	Unit = "target",   --this should not be used unless the spell is not to be cast on the target
	Interrupt = 1,   --use this if the target should be casting or channeling an interruptible ability
	CheckFirst = function(z) return true end,   --use this to check conditions or modify settings first before everything else has been checked
	CheckLast = function(z) return true end,   --use this to check conditions last after everything else has been checked
	Override = function(z) return true end,   --use this to use this function for condition checking and nothing else
	FlashColor = "White",   --use this to change the flash color if you want it to flash something other than white
	FlashSize = s.FlashSizePercent() * 2,   --use this to change the flash size
	FlashBrightness = 100,   --use this to change the flash brightness
	FlashBlink = 1,   --use this to have the button blink
	FlashNoMacros = 1,   --use this to not flash macros
	FlashID = GlobalSpellID--[[English_Spell_Name]],   --use this to add a spell ID or a table of spell IDs that will replace the spell that is flashed
	Continue = 1,   --this will make it so that even if this spell flashes in a list of spells it will continue checking the rest of the spells so that they may also be able to flash
}

-- Example item table:
a.spells["English_Item_Name"] = {
	Type = "item",   --this indicates what kind of spell this is
	ID = ItemID--[[English_Item_Name]],   --this is for defining the correct name of the item
	DebuffSlotNeeded = 1,   --use this if you want to make sure that a debuff slot is free on the target so that you do not replace other debuffs
	Debuff = GlobalSpellID--[[English_Spell_Name]],   --place debuff ID or table of IDs here if the item has a debuff that may only be on a target once in total from everyone and has a cooldown shorter than the debuff duration
	MyDebuff = GlobalSpellID--[[English_Spell_Name]],   --place debuff ID or table of IDs here if the item has a debuff that may be on the target multiple times by many people and has a cooldown shorter than the debuff duration
	Buff = GlobalSpellID--[[English_Spell_Name]],   --place buff ID or table of IDs here if the item has a buff that may only be on yourself once in total from everyone and has a cooldown shorter than the buff duration
	MyBuff = GlobalSpellID--[[English_Spell_Name]],   --place buff ID or table of IDs here if the item has a buff that may be on the target multiple times by many people and has a cooldown shorter than the buff duration
	BuffUnit = "player",   --you will need to use this if the buff or debuff is not applied to your target
	Stack = 2,   --use this if the buff or debuff requires more than one application
	EarlyRefresh = 5,   --use this to indicate the buff or debuff early for a desired number of seconds
	RequireDebuff = GlobalSpellID--[[English_Spell_Name]],   --place buff ID or table of IDs here if a debuff needs to be on the target first
	RequireMyDebuff = GlobalSpellID--[[English_Spell_Name]],   --place buff ID or table of IDs here if your debuff needs to be on the target first
	RequireBuff = GlobalSpellID--[[English_Spell_Name]],   --place buff ID or table of IDs here if a buff needs to be on the target first
	RequireMyBuff = GlobalSpellID--[[English_Spell_Name]],   --place buff ID or table of IDs here if your buff needs to be on the target first
	RequireBuffUnit = "player",   --you will need to use this if the buff or debuff is not applied to your target
	RequireStack = 2,   --use this if the buff or debuff requires more than one application
	RequireMoreBuffTime = 5,   --use this to require more time be on the buff or debuff
	CastTime = 0,   --use this if the item has a cast time for indication of a buff or debuff early
	NoGCD = 1,   --use this to not use global cool down time to indicate the item earlier
	EnemyTargetNeeded = 1,   --use this if the item should have an enemy targeted
	Melee = 1,   --use this to check if you are within melee distance if the spell does not have built in distance checking
	TargetThatUsesManaNeeded = 1,   --use this if the item is only useful on a target that uses mana such as mana draining items
	NoRangeCheck = 1,   --use this to disable range detection if the item has a limited range but the detection in this function is not working correctly for the particular item
	NoEquipCheck = 1,   --use this to disable equippable detection if the item can be equipped but does not need to be
	NotIfActive = 1,   --use this if the item may be toggled on such as auto attack or on next swing spells, or to disable when casting or channeling, or if the item has a cooldown
	NotWhileMoving = 1,   --use this if the item is not able to be used while moving
	NoPowerCheck = 1,   --use this to disable the power checking in this function
	EvenIfNotUsable = 1,   --use this to disable the usability checking in this function and may be used if currently in the process of completing a prerequisite that will make the item usable
	Unit = "target",   --this should not be used unless the item is not to be cast on the target
	Interrupt = 1,   --use this if the target should be casting or channeling an interruptible ability
	CheckFirst = function(z) return true end,   --use this to check conditions or modify settings first before everything else has been checked
	CheckLast = function(z) return true end,   --use this to check conditions last after everything else has been checked
	Override = function(z) return true end,   --use this to use this function for condition checking and nothing else
	FlashColor = "White",   --use this to change the flash color if you want it to flash something other than white
	FlashSize = s.FlashSizePercent() * 2,   --use this to change the flash size
	FlashBrightness = 100,   --use this to change the flash brightness
	FlashBlink = 1,   --use this to have the button blink
	FlashNoMacros = 1,   --use this to not flash macros
	FlashID = GlobalSpellID--[[English_Spell_Name]],   --use this to add a spell ID or a table of spell IDs that will replace the spell that is flashed
	Continue = 1,   --this will make it so that even if this spell flashes in a list of spells it will continue checking the rest of the spells so that they may also be able to flash
}

-- Example vehicle table:
a.spells["English_Spell_Name"] = {
	Type = "vehicle",   --this indicates what kind of spell this is
	ID = GlobalSpellID--[[English_Spell_Name]],   --this is for defining the correct name of the spell
	DebuffSlotNeeded = 1,   --use this if you want to make sure that a debuff slot is free on the target so that you do not replace other debuffs
	Debuff = GlobalSpellID--[[English_Spell_Name]],   --place debuff ID or table of IDs here if the spell has a debuff that may only be on a target once in total from everyone and has a cooldown shorter than the debuff duration
	MyDebuff = GlobalSpellID--[[English_Spell_Name]],   --place debuff ID or table of IDs here if the spell has a debuff that may be on the target multiple times by many people and has a cooldown shorter than the debuff duration
	Buff = GlobalSpellID--[[English_Spell_Name]],   --place buff ID or table of IDs here if the spell has a buff that may only be on yourself once in total from everyone and has a cooldown shorter than the buff duration
	MyBuff = GlobalSpellID--[[English_Spell_Name]],   --place buff ID or table of IDs here if the spell has a buff that may be on the target multiple times by many people and has a cooldown shorter than the buff duration
	BuffUnit = "vehicle",   --you will need to use this if the buff or debuff is not applied to your target
	Stack = 2,   --use this if the buff or debuff requires more than one application
	EarlyRefresh = 5,   --use this to indicate the buff or debuff early for a desired number of seconds
	RequireDebuff = GlobalSpellID--[[English_Spell_Name]],   --place buff ID or table of IDs here if a debuff needs to be on the target first
	RequireMyDebuff = GlobalSpellID--[[English_Spell_Name]],   --place buff ID or table of IDs here if your debuff needs to be on the target first
	RequireBuff = GlobalSpellID--[[English_Spell_Name]],   --place buff ID or table of IDs here if a buff needs to be on the target first
	RequireMyBuff = GlobalSpellID--[[English_Spell_Name]],   --place buff ID or table of IDs here if your buff needs to be on the target first
	RequireBuffUnit = "player",   --you will need to use this if the buff or debuff is not applied to your target
	RequireStack = 2,   --use this if the buff or debuff requires more than one application
	RequireMoreBuffTime = 5,   --use this to require more time be on the buff or debuff
	CastTime = 0,   --use this if the spell has a cast time for indication of a buff or debuff early
	NoGCD = 1,   --use this to not use global cool down time to indicate the spell earlier
	EnemyTargetNeeded = 1,   --use this if the spell should have an enemy targeted
	TargetThatUsesManaNeeded = 1,   --use this if the spell is only useful on a target that uses mana such as mana draining spells
	NoRangeCheck = 1,   --use this to disable range detection if the spell has a limited range but the detection in this function is not working correctly for the particular spell
	NotIfActive = 1,   --use this if the spell may be toggled on such as auto attack or on next swing spells, or to disable when casting or channeling, or if the spell has a cooldown
	NotWhileMoving = 1,   --use this if the spell is not able to be cast while moving
	NoPowerCheck = 1,   --use this to disable the power checking in this function
	EvenIfNotUsable = 1,   --use this to disable the usability checking in this function and may be used if currently in the process of completing a prerequisite that will make the spell usable
	GlobalVehicleCooldownSpell = GlobalSpellID--[[English_Spell_Name]],   -- use this if spell has more than a global cooldown
	Unit = "target",   --this should not be used unless the spell is not to be cast on the target
	Interrupt = 1,   --use this if the target should be casting or channeling an interruptible ability
	CheckFirst = function(z) return true end,   --use this to check conditions or modify settings first before everything else has been checked
	CheckLast = function(z) return true end,   --use this to check conditions last after everything else has been checked
	Override = function(z) return true end,   --use this to use this function for condition checking and nothing else
	FlashColor = "White",   --use this to change the flash color if you want it to flash something other than white
	FlashSize = s.FlashSizePercent() * 2,   --use this to change the flash size
	FlashBrightness = 100,   --use this to change the flash brightness
	FlashBlink = 1,   --use this to have the button blink
	FlashID = GlobalSpellID--[[English_Spell_Name]],   --use this to add a spell ID or a table of spell IDs that will replace the spell that is flashed
	Continue = 1,   --this will make it so that even if this spell flashes in a list of spells it will continue checking the rest of the spells so that they may also be able to flash
}

-- Example pet table:
a.spells["English_Spell_Name"] = {
	Type = "pet",   --this indicates what kind of spell this is
	ID = GlobalSpellID--[[English_Spell_Name]],   --this is for defining the correct name of the spell
	PetFrameNeeded = 1,   --use this is the pet frame needs to be shown to cast this spell
	PetHealthNotNeeded = 1,   --use this if the pet does not need to have health to cast this spell
	GlobalPetCooldownSpell = GlobalSpellID--[[English_Spell_Name]],   -- use this if spell has more than a global cooldown
	DebuffSlotNeeded = 1,   --use this if you want to make sure that a debuff slot is free on the target so that you do not replace other debuffs
	Debuff = GlobalSpellID--[[English_Spell_Name]],   --place debuff ID or table of IDs here if the spell has a debuff that may only be on a target once in total from everyone and has a cooldown shorter than the debuff duration
	MyDebuff = GlobalSpellID--[[English_Spell_Name]],   --place debuff ID or table of IDs here if the spell has a debuff that may be on the target multiple times by many people and has a cooldown shorter than the debuff duration
	Buff = GlobalSpellID--[[English_Spell_Name]],   --place buff ID or table of IDs here if the spell has a buff that may only be on yourself once in total from everyone and has a cooldown shorter than the buff duration
	MyBuff = GlobalSpellID--[[English_Spell_Name]],   --place buff ID or table of IDs here if the spell has a buff that may be on the target multiple times by many people and has a cooldown shorter than the buff duration
	BuffUnit = "player",   --you will need to use this if the buff or debuff is not applied to your target
	Stack = 2,   --use this if the buff or debuff requires more than one application
	EarlyRefresh = 5,   --use this to indicate the buff or debuff early for a desired number of seconds
	RequireDebuff = GlobalSpellID--[[English_Spell_Name]],   --place buff ID or table of IDs here if a debuff needs to be on the target first
	RequireMyDebuff = GlobalSpellID--[[English_Spell_Name]],   --place buff ID or table of IDs here if your debuff needs to be on the target first
	RequireBuff = GlobalSpellID--[[English_Spell_Name]],   --place buff ID or table of IDs here if a buff needs to be on the target first
	RequireMyBuff = GlobalSpellID--[[English_Spell_Name]],   --place buff ID or table of IDs here if your buff needs to be on the target first
	RequireBuffUnit = "player",   --you will need to use this if the buff or debuff is not applied to your target
	RequireStack = 2,   --use this if the buff or debuff requires more than one application
	RequireMoreBuffTime = 5,   --use this to require more time be on the buff or debuff
	NoGCD = 1,   --use this to not use global cool down time to indicate the spell earlier
	EvenIfNotUsable = 1,   --use this to disable the usability checking in this function and may be used if currently in the process of completing a prerequisite that will make the spell usable
	Unit = "pettarget",   --this should not be used unless the spell is not to be cast on the pet's target
	CheckFirst = function(z) return true end,   --use this to check conditions or modify settings first before everything else has been checked
	CheckLast = function(z) return true end,   --use this to check conditions last after everything else has been checked
	Override = function(z) return true end,   --use this to use this function for condition checking and nothing else
	FlashColor = "White",   --use this to change the flash color if you want it to flash something other than white
	FlashSize = s.FlashSizePercent() * 2,   --use this to change the flash size
	FlashBrightness = 100,   --use this to change the flash brightness
	FlashBlink = 1,   --use this to have the button blink
	FlashID = GlobalSpellID--[[English_Spell_Name]],   --use this to add a spell ID or a table of spell IDs that will replace the spell that is flashed
	Continue = 1,   --this will make it so that even if this spell flashes in a list of spells it will continue checking the rest of the spells so that they may also be able to flash
}



a.spells["Auto Attack"] = {
	Type = "spell",
	ID = 6603--[[Auto Attack]],
	EnemyTargetNeeded = 1,
	Melee = 1,
	NotIfActive = 1,
	CheckFirst = function(z)
		z.FlashColor = s.If(x.ActiveEnemy, "White", "Pink")
		return x.NoCC
	end,
}

a.spells["Shoot"] = {
	Type = "spell",
	ID = 3018--[[Shoot]],
	EnemyTargetNeeded = 1,
	NotIfActive = 1,
	CheckFirst = function(z)
		z.FlashColor = s.If(x.ActiveEnemy, "White", "Pink")
		return x.NoCC and not s.Shooting()
	end,
}



a.spells["Every Man for Himself"] = {
	Type = "spell",
	ID = 59752,
	FlashColor = "Aqua",
	CheckFirst = function(self)
		return s.CrowedControlled("player") or s.MovementImpaired("player")
	end,
}

a.spells["Will of the Forsaken"] = {
	Type = "spell",
	ID = 7744,
	FlashColor = "Aqua",
	CheckFirst = function(self)
		return s.CrowedControlled("player")
	end,
}

a.spells["Stoneform"] = {
	Type = "spell",
	ID = 20594,
	FlashColor = "Aqua",
	CheckFirst = function(self)
		return s.Diseased("player") or s.Poisoned("player")
	end,
}

a.spells["Arcane Torrent"] = {
	Type = "spell",
	ID = 28730,
	EnemyTargetNeeded = 1,
	Interrupt = 1,
	FlashColor = "Aqua",
	CheckFirst = function(self)
		return s.MeleeDistance()
	end,
}

a.spells["Berserking"] = {
	Type = "spell",
	ID = 26297,
	EnemyTargetNeeded = 1,
	FlashColor = "Green",
	CheckFirst = function(self)
		return x.ActiveEnemy and s.InCombat() and ( s.HealthPercent() > 25 or UnitIsPlayer(s.UnitSelection()) or s.Boss() )
	end,
}

a.spells["Blood Fury"] = {
	Type = "spell",
	ID = 20572,
	EnemyTargetNeeded = 1,
	FlashColor = "Green",
	CheckFirst = function(self)
		return x.ActiveEnemy and s.InCombat() and ( s.HealthPercent() > 25 or UnitIsPlayer(s.UnitSelection()) or s.Boss() )
	end,
}

a.spells["Escape Artist"] = {
	Type = "spell",
	ID = 20589,
	FlashColor = "Aqua",
	CheckFirst = function(self)
		return s.MovementImpaired("player")
	end,
}

a.spells["War Stomp"] = {
	Type = "spell",
	ID = 20549,
	EnemyTargetNeeded = 1,
	Interrupt = 1,
	FlashColor = "Aqua",
	CheckFirst = function(self)
		return s.MeleeDistance()
	end,
}

a.spells["Rocket Barrage"] = {
	Type = "spell",
	ID = 69041,
	EnemyTargetNeeded = 1,
	CheckFirst = function(self)
		self.FlashColor = s.If(x.ActiveEnemy, "White", "Pink")
		return s.HealthPercent() > 25 or UnitIsPlayer(s.UnitSelection()) or s.Boss()
	end,
}

