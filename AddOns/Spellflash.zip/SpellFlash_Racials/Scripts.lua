local MinBuild, MaxBuild, Build = 40000, 0, select(4, GetBuildInfo())
if Build < MinBuild or ( MaxBuild > 0 and Build > MaxBuild ) then return end
local AddonName, a = ...
local AddonTitle = select(2, GetAddOnInfo(AddonName))
local PlainAddonTitle = AddonTitle:gsub("|c........", ""):gsub("|r", "")
local L = a.Localize
local s = SpellFlashAddon
local x = SpellFlashAddon.UpdatedVariables

-- SpellFlash API: http://wow.curseforge.com/addons/spellflash/pages/api/
-- x.Enemy, x.ActiveEnemy, x.NoCC, x.InInstance, x.InstanceType, x.PetAlive, x.PetActiveEnemy, x.PetNoCC, x.Lag, x.DoubleLag, x.ThreatPercent, x.EnemyDetected, x.ShouldPermanentBuff, x.ShouldTemporaryBuff


function a.HUMAN()
	a.Flash("Every Man for Himself")
end

function a.UNDEAD()
	a.Flash("Will of the Forsaken")
end

function a.DWARF()
	a.Flash("Stoneform")
end

function a.BLOODELF()
	a.Flash("Arcane Torrent")
end

function a.TROLL()
	a.Flash("Berserking")
end

function a.ORC()
	a.Flash("Blood Fury")
end

function a.GNOME()
	a.Flash("Escape Artist")
end

function a.TAUREN()
	a.Flash("War Stomp")
end

function a.GOBLIN()
	a.Flash("Rocket Barrage")
end

local RACE = s.Race("player")

-- Use this single spam function and remove the multiple spam table below, or just use the multiple spam table below and leave this function in place.
s.Spam[AddonName] = function() if a.GetConfig("spell_flashing_off") then return end a.RunSpamTable()
	
	if a[RACE] then
		a[RACE]()
	end
	
end

