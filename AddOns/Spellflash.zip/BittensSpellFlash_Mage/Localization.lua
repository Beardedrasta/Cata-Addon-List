﻿-- To update a translation please use the localization utility at:
-- http://wow.curseforge.com/addons/bittens-spellflash-mage/localization/

local AddonName, a = ...
local function DefaultFunction(_, key) return key end
a.Localize = setmetatable({}, {__index = DefaultFunction})
local L = a.Localize

-- Example:
L["English text goes here."] = "Translated text goes here."

if GetLocale() == "ptBR" then -- Brazilian Portuguese
-- L["Evocate at % mana:"] = ""
-- L["Flash Arcane"] = ""
-- L["Flash Frost"] = ""
-- L["Length of burn phase:"] = ""
-- L["Use Arcane Missiles below % mana:"] = ""

elseif GetLocale() == "frFR" then -- French
-- L["Evocate at % mana:"] = ""
-- L["Flash Arcane"] = ""
-- L["Flash Frost"] = ""
-- L["Length of burn phase:"] = ""
-- L["Use Arcane Missiles below % mana:"] = ""

elseif GetLocale() == "deDE" then -- German
L["Evocate at % mana:"] = "Hervorrufung bei % Mana" -- Needs review
L["Flash Arcane"] = "Aufblitzen bei Arkan" -- Needs review
L["Flash Frost"] = "Aufblitzen bei Frost" -- Needs review
L["Length of burn phase:"] = "Dauer der Burnphase" -- Needs review
L["Use Arcane Missiles below % mana:"] = "Benutze Arkane Geschosse unter % Mana" -- Needs review

elseif GetLocale() == "koKR" then -- Korean
-- L["Evocate at % mana:"] = ""
-- L["Flash Arcane"] = ""
-- L["Flash Frost"] = ""
-- L["Length of burn phase:"] = ""
-- L["Use Arcane Missiles below % mana:"] = ""

elseif GetLocale() == "esMX" then -- Latin American Spanish
-- L["Evocate at % mana:"] = ""
-- L["Flash Arcane"] = ""
-- L["Flash Frost"] = ""
-- L["Length of burn phase:"] = ""
-- L["Use Arcane Missiles below % mana:"] = ""

elseif GetLocale() == "ruRU" then -- Russian
-- L["Evocate at % mana:"] = ""
-- L["Flash Arcane"] = ""
-- L["Flash Frost"] = ""
-- L["Length of burn phase:"] = ""
-- L["Use Arcane Missiles below % mana:"] = ""

elseif GetLocale() == "zhCN" then -- Simplified Chinese
-- L["Evocate at % mana:"] = ""
-- L["Flash Arcane"] = ""
-- L["Flash Frost"] = ""
-- L["Length of burn phase:"] = ""
-- L["Use Arcane Missiles below % mana:"] = ""

elseif GetLocale() == "esES" then -- Spanish
-- L["Evocate at % mana:"] = ""
-- L["Flash Arcane"] = ""
-- L["Flash Frost"] = ""
-- L["Length of burn phase:"] = ""
-- L["Use Arcane Missiles below % mana:"] = ""

elseif GetLocale() == "zhTW" then -- Traditional Chinese
-- L["Evocate at % mana:"] = ""
-- L["Flash Arcane"] = ""
-- L["Flash Frost"] = ""
-- L["Length of burn phase:"] = ""
-- L["Use Arcane Missiles below % mana:"] = ""

end