local MinBuild, MaxBuild, Build = 40000, 0, select(4, GetBuildInfo())
if Build < MinBuild or ( MaxBuild > 0 and Build > MaxBuild ) then return end
local AddonName, a = ...
local AddonTitle = select(2, GetAddOnInfo(AddonName))
local PlainAddonTitle = AddonTitle:gsub("|c........", ""):gsub("|r", "")
local L = a.Localize
local s = SpellFlashAddon
local x = s.UpdatedVariables
local config = {}
config.event = {}

local c = BittensSpellFlashLibrary2

function config.OtherAurasFunction()
    -- This is called before Spells.lua loads, so sadly we have to hard code
    -- the spell ids.
    s.SetOtherAuras(2948--[[Scorch]], 22959--[[Critical Mass]])
end

a.Phase = "neutral"
a.UnstackedMaxMana = 1000000000
function config.event.PLAYER_REGEN_ENABLED(event)
    -- why on earth is this the event for leaving combat,
    -- and not "PLAYER_LEAVE_COMBAT"??
    a.Phase = "neutral"
    a.UnstackedMaxMana = 1000000000
end

local blizzFingerCount = -1
a.FingerCount = blizzFingerCount
a.StolenTimeRemaining = 10
function config.event.COMBAT_LOG_EVENT_UNFILTERED(event, ...)
    source = select(5, ...)
    if source == nil or not UnitIsUnit(source, "player") then
        return
    end
    
    c.Init(AddonName, a)
    event = select(2, ...)
    local id = select(12, ...)
    
    -- Frost
    if (event == "SPELL_CAST_SUCCESS" or event == "SPELL_CAST_START")
        and (id == c.GetID("Ice Lance")
            or id == c.GetID("Frostfire Bolt")
            or id == c.GetID("Deep Freeze")) then
        
        a.FingerCount = math.max(0, a.FingerCount - 1)
        c.Debug("Event", "Pretend FoF is now at", a.FingerCount)
    end
    
    -- 4pT13 stuff
    if id == c.GetID("Stolen Time") then
        if (event == "SPELL_AURA_APPLIED" or event == "SPELL_AURA_APPLIED_DOSE")
            and a.StolenTimeRemaining > 0
            and not s.Buff(c.GetID("Arcane Power"), "player")
            and not s.MyDebuff(c.GetID("Combustion"))
            and not s.Buff(c.GetID("Icy Veins"), "player") then
                
            a.StolenTimeRemaining = a.StolenTimeRemaining - 1
            c.Debug("Event", "Stolen Time Bump", a.StolenTimeRemaining)
        elseif event == "SPELL_AURA_REMOVED" then
            a.StolenTimeRemaining = 10
            c.Debug("Event", "Stolen Time Reset", 10)
        end
    elseif not c.WearingSet(4, "T13") then
        a.StolenTimeRemaining = 0
    end
end

function config.event.UNIT_AURA(event, unit)
    if not UnitIsUnit(unit, "player") then
        return
    end
    
    c.Init(AddonName, a)
    
    -- Frost
    local stack = c.GetBuffStack("Fingers of Frost")
    if a.FingerCount < 0 then
        a.FingerCount = stack
        c.Debug("Event", "FoF initializing to", stack)
    elseif stack > blizzFingerCount then
        if a.FingerCount == blizzFingerCount - 1 then
            a.FingerCount = stack - 1
        else
            a.FingerCount = stack
        end
        c.Debug("Event",
            "Gained FoF. Stack =", stack, "Pretend =", a.FingerCount)
    elseif stack < blizzFingerCount then
        a.FingerCount = stack
        c.Debug("Event", "Lost FoF. Stack =", stack)
    end
    blizzFingerCount = stack
end

config.CheckButtonOptions = {
    LeftCheckButton1 = {
        DefaultChecked = true,
        ConfigKey = "arcane_off",
        Label = L["Flash Arcane"],
    },
    LeftCheckButton2 = {
        DefaultChecked = true,
        ConfigKey = "fire_off",
        Label = L["Flash Fire"],
    },
    LeftCheckButton3 = {
        DefaultChecked = true,
        ConfigKey = "frost_off",
        Label = L["Flash Frost"],
    },
    LeftCheckButton4 = {
        DefaultChecked = true,
        ConfigKey = "My_Config_Key",
        Label = L["My_Check_Button_Label"],
    },
    LeftCheckButton5 = {
        DefaultChecked = true,
        ConfigKey = "My_Config_Key",
        Label = L["My_Check_Button_Label"],
    },
    LeftCheckButton6 = {
        DefaultChecked = true,
        ConfigKey = "My_Config_Key",
        Label = L["My_Check_Button_Label"],
    },
    LeftCheckButton7 = {
        DefaultChecked = true,
        ConfigKey = "My_Config_Key",
        Label = L["My_Check_Button_Label"],
    },
    RightCheckButton1 = {
        DefaultChecked = true,
        ConfigKey = "My_Config_Key",
        Label = L["My_Check_Button_Label"],
    },
    RightCheckButton2 = {
        DefaultChecked = true,
        ConfigKey = "hide_BCM",
        Label = L["Show Combustion Monitor"],
    },
    RightCheckButton3 = {
        DefaultChecked = true,
        ConfigKey = "My_Config_Key",
        Label = L["My_Check_Button_Label"],
    },
    RightCheckButton4 = {
        DefaultChecked = true,
        ConfigKey = "My_Config_Key",
        Label = L["My_Check_Button_Label"],
    },
    RightCheckButton5 = {
        DefaultChecked = true,
        ConfigKey = "My_Config_Key",
        Label = L["My_Check_Button_Label"],
    },
    RightCheckButton6 = {
        DefaultChecked = true,
        ConfigKey = "My_Config_Key",
        Label = L["My_Check_Button_Label"],
    },
    RightCheckButton7 = {
        DefaultChecked = true,
        ConfigKey = "My_Config_Key",
        Label = L["My_Check_Button_Label"],
    },
}

config.EditBoxOptions = {
	LeftEditBox1 = {
		DefaultValue = "45",
		Numeric = true,
		MaxCharacters = 3,
		ConfigKey = "burn_length",
		Label = L["Length of burn phase:"],
	},
	LeftEditBox2 = {
		DefaultValue = "28",
		Numeric = true,
		MaxCharacters = 2,
		ConfigKey = "evocate_percent",
		Label = L["Evocate at % mana:"],
	},
	RightEditBox1 = {
		DefaultValue = "92",
		Numeric = true,
		MaxCharacters = 2,
		ConfigKey = "missiles_percent",
		Label = L["Use Arcane Missiles below % mana:"],
	},
	RightEditBox2 = {
		DefaultValue = "150000",
		Numeric = true,
		MaxCharacters = 7,
		ConfigKey = "combust_at",
		Label = L["Minumum Combustion total damage:"],
	},
}

a.LoadConfigs(config)
