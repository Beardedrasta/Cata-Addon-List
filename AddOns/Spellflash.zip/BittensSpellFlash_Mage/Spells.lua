local MinBuild, MaxBuild, Build = 40000, 0, select(4, GetBuildInfo())
if Build < MinBuild or ( MaxBuild > 0 and Build > MaxBuild ) then return end
local AddonName, a = ...
local AddonTitle = select(2, GetAddOnInfo(AddonName))
local PlainAddonTitle = AddonTitle:gsub("|c........", ""):gsub("|r", "")
local L = a.Localize
local s = SpellFlashAddon
local x = s.UpdatedVariables

local c = BittensSpellFlashLibrary2
c.Init(AddonName, a)

------------------------------------------------------------------------ Common
a.spells["Combat Mind LFR"] = { ID = 109793 }
a.spells["Combat Mind"] = { ID = 107970 }
a.spells["Combat Mind Heroic"] = { ID = 109795 }
a.spells["Stolen Time"] = { ID = 105785 }

a.spells["Evocation"] = {
    ID = 12051,
}

a.spells["Flame Orb"] = {
    ID = 82731,
    NoRangeCheck = 1,
    Contintue = 1,
    FlashColor = "yellow",
}

a.spells["Conjure Mana Gem"] = {
    ID = 759,
    FlashColor = "yellow",
    CheckFirst = function()
        local count = GetItemCount("Mana Gem", false, true)
        if s.InCombat() then
            return count == 0
        else
            return count < 3
        end
    end    
}

a.spells["Mana Gem"] = {
    Type = "item",
    ID = 36799,
    FlashColor = "yellow",
}

a.spells["Molten Armor"] = {
    ID = 30482,
    FlashColor = "yellow",
    CheckFirst = function()
        return c.SelfBuffNeeded("Molten Armor")
    end
}

a.spells["Mirror Image"] = {
    ID = 55342,
    Continue = 1,
    FlashColor = "yellow",
    NoGCD = true,
    CheckFirst = function()
        local ap = c.HasBuff("Arcane Power", true)
        if s.HasGlyph(56381) then -- Glyph of Arcane Power
            return ap
        else
            return not ap
        end
    end
}

a.spells["Arcane Brilliance"] = {
    ID = 1459,
    NoRangeCheck = 1,
    FlashColor = "yellow",
    CheckFirst = function()
        return c.RaidBuffNeeded(c.INTELLECT_BUFFS)
    end
}

a.spells["Dalaran Brilliance"] = {
    ID = 61316,
    NoRangeCheck = 1,
    FlashColor = "yellow",
    CheckFirst = function()
        return c.RaidBuffNeeded(c.INTELLECT_BUFFS)
    end
}

a.spells["Counterspell"] = {
    ID = 2139,
    Interrupt = 1,
    FlashColor = "aqua",
}

------------------------------------------------------------------------ Arcane
a.spells["Arcane Power"] = {
    ID = 12042,
    NonGCD = true,
    FlashColor = "yellow",
    CheckFirst = function()
        return a.StolenTimeRemaining == 0
    end
}

a.spells["Arcane Blast"] = {
    ID = 30451,
}

a.spells["Arcane Missiles"] = {
    ID = 5143,
}

a.spells["Arcane Barrage"] = {
    ID = 44425,
}

a.spells["Presence of Mind"] = {
    ID = 12043,
    FlashColor = "yellow",
    NoGCD = true,
}

a.spells["Mage Armor"] = {
    ID = 6117,
    FlashColor = "yellow",
    CheckFirst = function()
        return c.SelfBuffNeeded("Mage Armor")
    end
}

-------------------------------------------------------------------------- Fire
a.spells["Hot Streak"] = { ID = 48108 }
a.spells["Fire Blast"] = { ID = 2136 }
a.spells["Frostfire Bolt"] = { ID = 44614 }
a.spells["Ignite"] = { ID = 12654 }
a.spells["Combustion DoT"] = { ID = 83853 }

a.spells["Living Bomb"] = {
    ID = 44457,
    CheckFirst = function()
        return not c.HasMyDebuff("Living Bomb")
            and not c.IsCasting("Living Bomb")
    end
}

a.spells["Pyroblast"] = {
    ID = 11366,
    FlashID = { 11366, 92315 }, -- Pyroblast!
    TravelTimeEstimate = 1.3,
    SameTravelTimeAs = { "Pyroblast!", "Fireball" },
    Override = function()
        return c.HasBuff("Hot Streak")
            and not c.IsCasting("Pyroblast")
            and not c.IsCasting("Pyroblast!")
    end
}

a.spells["Pyroblast!"] = {
    ID = 92315,
    FlashID = { 11366, 92315 }, -- Pyroblast
    TravelTimeEstimate = 1.3,
    SameTravelTimeAs = { "Pyroblast", "Fireball" },
    Override = function()
        return c.HasBuff("Hot Streak")
            and not c.IsCasting("Pyroblast")
            and not c.IsCasting("Pyroblast!")
    end
}

a.spells["Fireball"] = {
    ID = 133,
    NotWhileMoving = 1,
    TravelTimeEstimate = 1.3,
    SameTravelTimeAs = { "Pyroblast", "Pyroblast!" },
    CheckFirst = function()
        local mana = s.Power("player")
        local curSpell = s.Casting(nil, "player")
        if curSpell ~= nil then
            mana = mana - s.SpellCost(curSpell)
        end
        return mana > 5000
    end
}

a.spells["Scorch"] = {
    ID = 2948,
    TravelTimeEstimate = .1,
    SameTravelTimeAs = { "Living Bomb" },
    CheckFirst = function()
        return s.HasTalent(86914) -- Firestarter
    end 
}

a.spells["Scorch to Apply Critical Mass"] = {
    ID = 2948,
    Debuff = c.CRIT_DEBUFFS,
    CheckFirst = function()
        return s.HasTalent(86914) -- Firestarter
            and not c.IsAuraPendingFor("Scorch")
            and not c.IsAuraPendingFor("Pyroblast")
            and not c.IsAuraPendingFor("Pyroblast!")
    end 
}

a.spells["Scorch to Refresh Critical Mass"] = {
    ID = 2948,
    Debuff = c.CRIT_DEBUFFS,
    EarlyRefresh = 5,
    CheckFirst = function()
        return s.HasTalent(86914) -- Firestarter
            and not c.IsAuraPendingFor("Scorch")
            and not c.IsAuraPendingFor("Pyroblast")
            and not c.IsAuraPendingFor("Pyroblast!")
    end 
}

a.spells["Combustion"] = {
    ID = 11129,
    CheckFirst = function(z)
        if a.StolenTimeRemaining > 0 then
            return false
        end
        
        local threshhold = a.GetConfig("combust_at")
        if a.PredictCombustionDamage(false, false) >= threshhold then
            if a.PredictCombustionDamage(true, false) >= threshhold then
                z.FlashColor = "yellow"
            else
                z.FlashColor = "red"
            end
            return true
        end
    end
}

------------------------------------------------------------------------- Frost
a.spells["Brain Freeze"] = { ID = 57761 }
a.spells["Fingers of Frost"] = { ID = 44544 }

a.EquipmentSets = {}
a.EquipmentSets.T13 = {
    HeadSlot = { 78796, 76213, 78701 },
    ShoulderSlot = { 78843, 76216, 78748 },
    ChestSlot = { 78824, 76215, 78729 },
    HandsSlot = { 78766, 76212, 78671 },
    LegsSlot = { 78815, 76214, 78720 },
}

a.spells["Frostbolt"] = {
    ID = 116,
}

a.spells["Deep Freeze"] = {
    ID = 44572,
}

a.spells["Instant Frozen Frostfire Bolt"] = {
    ID = 44614,
    CheckFirst = function()
        return c.HasBuff("Brain Freeze")
            and a.FingerCount > 0
    end
}

a.spells["Ice Lance"] = {
    ID = 30455,
}

a.spells["Frozen Ice Lance"] = {
    ID = 30455,
    CheckFirst = function()
        return a.FingerCount > 0
    end
}

a.spells["Frostfire Orb"] = {
    ID = 82731, -- flame orb
    FlashID = { 82731, 92283 }, 
    NoRangeCheck = 1,
}

a.spells["Icy Veins"] = {
    ID = 12472,
    Buff = 12472,
    BuffUnit = "player",
    NoGCD = 1,
    FlashColor = "yellow",
    CheckFirst = function()
        return a.StolenTimeRemaining == 0
    end
}

a.spells["Cold Snap"] = {
    ID = 11958,
    NoGCD = 1,
    FlashColor = "yellow",
    CheckFirst = function()
        return c.GetCooldown("Icy Veins") > 10
            and c.GetCooldown("Deep Freeze") > 10
            and c.GetCooldown("Frostfire Orb") > 10
    end
}

a.spells["Summon Water Elemental"] = {
    ID = 31687,
    FlashColor = "yellow",
    CheckFirst = function()
        return not x.PetAlive
    end
}

a.spells["Freeze"] = {
    ID = 33395,
    Continue = 1,
    FlashColor = "yellow",
    NoRangeCheck = 1,
    CheckFirst = function()
        local dfcd = c.GetCooldown("Deep Freeze")
        return (dfcd == 0 or dfcd > 25)
            and a.FingerCount == 0
    end
}

a.spells["Freeze on Pet Bar"] = {
    Type = "pet",
    ID = 33395,
    Continue = 1,
    FlashColor = "yellow",
    NoRangeCheck = 1,
    CheckFirst = function()
        local dfcd = c.GetCooldown("Deep Freeze")
        return (dfcd == 0 or dfcd > 25)
            and a.FingerCount == 0
    end
}
