local MinBuild, MaxBuild, Build = 40000, 0, select(4, GetBuildInfo())
if Build < MinBuild or ( MaxBuild > 0 and Build > MaxBuild ) then return end
local AddonName, a = ...
local AddonTitle = select(2, GetAddOnInfo(AddonName))
local PlainAddonTitle = AddonTitle:gsub("|c........", ""):gsub("|r", "")
local L = a.Localize
local s = SpellFlashAddon
local x = s.UpdatedVariables

local c = BittensSpellFlashLibrary2
a.Rotations = {}

s.Spam[AddonName] = function()
    a.UpdateBCMVisibility()
    c.Flash(AddonName, a)
end

------------------------------------------------------------------------ Arcane
local function setBlastColor(color)
    a.spells["Arcane Blast"].FlashColor = color
end

local function flashBlast(color)
    setBlastColor(color)
    a.Flash("Arcane Blast")
end

local function flashNeutralAround(percent, manaRatio, warningRatio)
    if warningRatio and manaRatio >= warningRatio then
        setBlastColor("red")
    else
        setBlastColor(nil)
    end
    if manaRatio > percent / 100 then
        a.FlashAll("Arcane Blast", "Conjure Mana Gem")
    else
        a.Flash("Arcane Missiles", "Arcane Blast")
    end
end

a.Rotations.Arcane = {
    Spec = 1,
    OffSwitch = "arcane_off",
    Function = function()
        a.FlashAll("Mage Armor", "Arcane Brilliance", "Dalaran Brilliance")
        if not s.InCombat() then
            a.Flash("Conjure Mana Gem")
            return
        end
        
        ----------------------------------------------------- mana calculations
        local mana = s.Power("player")
        local casting = s.CastingOrChannelingName(nil, "player")
        if casting ~= nil then
            mana = mana - s.SpellCost(casting)
        end
        
        local stackedMana = 
            78 * 15 * s.BuffStack(c.GetID("Combat Mind LFR"), "player")
                + 88 * 15 * s.BuffStack(c.GetID("Combat Mind"), "player")
                + 99 * 15 * s.BuffStack(c.GetID("Combat Mind Heroic"), "player")
        if s.Buff(c.FIVE_PERCENT_BUFFS, "player") then
            stackedMana = stackedMana * 1.05
        end
        local maxMana = s.MaxPower("player") - stackedMana
        if maxMana < a.UnstackedMaxMana then
            a.UnstackedMaxMana = maxMana
        end
        maxMana = a.UnstackedMaxMana + stackedMana
        local manaRatio = mana / maxMana
        
        ----------------------------------------------------- phase transitions
        local abStack = s.DebuffStack(c.GetID("Arcane Blast"), "player")
        if abStack < 4 and casting == s.SpellName(c.GetID("Arcane Blast")) then
            abStack = abStack + 1
        end
        
        if a.Phase == "neutral"
            and c.GetCooldown("Evocation") < a.GetConfig("burn_length") then
            
            a.Phase = "burn transition"
        end
        
        if a.Phase == "burn transition" and c.HasBuff("Arcane Power") then
            a.Phase = "burn"
        end
        
        if a.Phase == "burn"
            and manaRatio < a.GetConfig("evocate_percent") / 100 then
            
            a.Phase = "neutral transition"
        end
        
        if casting == s.SpellName(c.GetID("Evocation")) then
            a.Phase = "neutral"
        end
        
        -------------------------------------------------------------- flashing
        a.FlashAll("Presence of Mind", "Mirror Image", "Counterspell")
        if a.Phase ~= "burn" or not c.HasBuff("Arcane Power") then
            a.Flash("Flame Orb")
        end
        
        if a.Phase == "neutral" then
            flashNeutralAround(a.GetConfig("missiles_percent"), manaRatio, 1)
            local apCool = 120
            if c.WearingSet(4, "T13") then
                apCool = apCool - (10 - a.StolenTimeRemaining) * 7
            end
            apCool = apCool * (1 - .125 * s.TalentRank(44379)) -- Arcane Flows
            if c.GetCooldown("Evocation") - a.GetConfig("burn_length") 
                > apCool then
            
                a.Flash("Arcane Power")
            end
            
        elseif a.Phase == "burn transition" then
            flashBlast("yellow")
            flashNeutralAround(a.GetConfig("missiles_percent"), manaRatio, 1)
            if abStack == 4 and maxMana - mana >= 12404 then -- mana gem
                if a.Flash("Arcane Power") then
                    a.Flash("Mana Gem")
                end
            end
            
        elseif a.Phase == "burn" then
            flashBlast()
            
        elseif a.Phase == "neutral transition" then
            if not a.Flash("Evocation") then
                flashNeutralAround(
                    a.GetConfig("evocate_percent")
                        - (100 - a.GetConfig("missiles_percent")),
                    manaRatio)
            end
        end
    end
}

-------------------------------------------------------------------------- Fire
local function dangerOfHotStreakOverwrite()
    local startDelay = c.GetCooldown("Pyroblast!")
    local endDelay = startDelay + s.CastTime(c.GetID("Fireball"))
    return c.HasBuff("Hot Streak")
        and (c.CountLandings("Fireball", startDelay, endDelay) > 0
            or c.CountLandings("Pyroblast!", startDelay, endDelay) > 0
            or c.CountLandings("Scorch", startDelay, endDelay) > 0
            or c.CountLandings("Pyroblast", startDelay, endDelay) > 0)
end

a.Rotations.Fire = {
    Spec = 2,
    OffSwitch = "fire_off",
    Function = function()
        a.FlashAll("Molten Armor", "Arcane Brilliance", "Dalaran Brilliance")
        if not s.InCombat() then
            a.Flash("Conjure Mana Gem")
            return
        end
        
        a.FlashAll("Combustion", "Counterspell")
        if s.Power("player") < 10000 then
            a.Flash("Mana Gem")
        end
        if dangerOfHotStreakOverwrite() then
            a.FlashAll("Pyroblast", "Pyroblast!")
        else
            a.Flash(
                "Scorch to Apply Critical Mass",
                "Living Bomb",
                "Flame Orb",
                "Mirror Image",
                "Pyroblast",
                "Pyroblast!",
                "Scorch to Refresh Critical Mass",
                "Fireball",
                "Scorch")
        end
    end
}

------------------------------------------------------------------------- Frost
a.Rotations.Frost = {
    Spec = 3,
    OffSwitch = "frost_off",
    Function = function()
        a.FlashAll(
            "Molten Armor", 
            "Summon Water Elemental", 
            "Arcane Brilliance", 
            "Dalaran Brilliance")
        if not s.InCombat() then
            a.Flash("Conjure Mana Gem")
            return
        end
        
        a.FlashAll("Mirror Image", "Icy Veins", "Cold Snap", "Counterspell")
        if s.Power("player") < 10000 then
            a.Flash("Mana Gem")
        end
        a.Flash(
            "Frostfire Orb",
            "Deep Freeze",
            "Freeze",
            "Freeze on Pet Bar",
            "Instant Frozen Frostfire Bolt",
            "Frozen Ice Lance",
            "Frostbolt",
            "Evocation")
    end
}
