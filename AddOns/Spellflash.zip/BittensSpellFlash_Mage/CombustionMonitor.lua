local MinBuild, MaxBuild, Build = 40000, 0, select(4, GetBuildInfo())
if Build < MinBuild or ( MaxBuild > 0 and Build > MaxBuild ) then return end
local AddonName, a = ...
local AddonTitle = select(2, GetAddOnInfo(AddonName))
local PlainAddonTitle = AddonTitle:gsub("|c........", ""):gsub("|r", "")
local L = a.Localize
local s = SpellFlashAddon
local x = s.UpdatedVariables

local c = BittensSpellFlashLibrary2

------------------------------------------------------------------ Calculations
local igniteTick = 0
local igniteIsDirty = false

local function countDebuff(name, delay)
    local duration = 0
    if delay then
        duration = c.GetBusyTime(true)
    end
    return s.MyDebuffDuration(c.GetID(name)) > duration
end

-- additive:        mastery, critical mass, molten fury
-- multiplicitive:  fire power, 
function a.PredictCombustionDamage(delay, debug)
    local perTick = 0
    local spellPower = GetSpellBonusDamage(4)
    local mastery = .028 * GetMastery()
    local firePower = .01 * s.TalentRank(54734) -- Fire Power
    if debug then
        c.Debug("Combustion", "Spell Power:", spellPower)
        c.Debug("Combustion", "Mastery:", mastery)
        c.Debug("Combustion", "Fire Power:", firePower)
    end
    if countDebuff("Living Bomb", delay) then
        local criticalMass = .05 * s.TalentRank(12873) -- Critical Mass
        --local glyph = 0
        --if s.HasGlyph(89926) then -- Glyph of Living Bomb
        --    glyph = .03
        --end
        -- Ok - so this is the correct calculation for Living Bomb, but it's not
        -- what Combustion uses ...
        --local tick = (232 + (0.258 * spellPower))
        --    * (1 + mastery + criticalMass + glyph)
        --    * (1 + firePower)
        --    * 1.25 -- Fire Specialization
        local tick = (232 + (0.258 * spellPower))
            * (1 + mastery)
            * (1 + criticalMass)
        --    * (1 + glyph)
            * (1 + firePower)
            * 1.25 -- Fire Specialization
        perTick = perTick + tick / 3
        if debug then
            c.Debug("Combustion", "Critical Mass:", criticalMass)
        --    c.Debug("Combustion", "Glyph of Living Bomb", glyph)
            c.Debug("Combustion", "Living Bomb Tick:", tick)
        end
    end
    if countDebuff("Pyroblast!", delay)
        or countDebuff("Pyroblast", delay) then
        
        local tick = (164 + (0.18 * spellPower))
            * (1 + mastery)
            * (1 + firePower)
            * 1.25 -- Fire Specialization
        perTick = perTick + tick / 3
        if debug then
            c.Debug("Combustion", "Pyroblast Tick:", tick)
        end
    end
    if countDebuff("Ignite", delay) then
        perTick = perTick + igniteTick / 2
        if debug then
            c.Debug("Combustion", "Ignite Tick:", igniteTick)
            c.Debug("Combustion", "Ignite is Dirty:", igniteIsDirty)
        end
    end
    
    local numTicks = floor(.5 + 10 * (1 + UnitSpellHaste("player") / 100))
    local crit = (GetSpellCritChance(4) - 1.8) / 100
    local total = perTick * numTicks * (1.055 * crit + 1)
    
    if debug then
        c.Debug("Combustion", "Num Ticks:", numTicks)
        c.Debug("Combustion", "Current Crit:", crit)
        c.Debug("Combustion", "Estimate Per Tick:", perTick)
        c.Debug("Combustion", "Total Estimate:", total)
    end
    return total, perTick, numTicks, crit
end

-------------------------------------------------------------------- The Window
local window = CreateFrame("Frame", nil, UIParent)
window:SetFrameStrata("HIGH")
window:SetSize(90, 45)
window:EnableMouse(true)
window:SetMovable(true)
window:RegisterForDrag("LeftButton")
window:CreateTitleRegion():SetAllPoints(true)

local function createLine(anchor)
    local line = window:CreateFontString()
    line:SetPoint(anchor)
    line:SetSize(window:GetWidth(), window:GetHeight() / 3)
    line:SetJustifyH("LEFT")
    line:SetFont("Fonts\\FRIZQT__.TTF", 10) 
    line:SetTextColor(1, 1, 1)
    return line
end

local line1 = createLine("TOP")
local line2 = createLine("CENTER")
local line3 = createLine("BOTTOM")

local function saveWindowPosition()
    local settings = CombustionMonitorSettings
    if settings == nil then
        settings = {}
        CombustionMonitorSettings = settings
    end
    settings.WindowPoints = {}
    for i = 1, window:GetNumPoints() do
        local point, relativeTo, relativePoint, xoffset, yoffset
            = window:GetPoint(i)
        settings.WindowPoints[i] = {
            point = point,
            relativePoint = relativePoint,
            xoffset = xoffset,
            yoffset = yoffset }
    end
end

local function positionWindow()
    local settings = CombustionMonitorSettings
    if settings == nil then
        window:SetPoint("CENTER")
    else
        for _, point in pairs(settings.WindowPoints) do
            window:SetPoint(
                point.point,
                nil,
                point.relativePoint,
                point.xoffset,
                point.yoffset)
        end
    end
end

function a.UpdateBCMVisibility()
    local hide = s.TalentMastery() ~= 2
        or a.GetConfig("fire_off")
        or a.GetConfig("hide_BCM")
    local isShowing = window:IsShown()
    if hide and isShowing then
        window:Hide()
    elseif (not hide) and (not isShowing) then
        window:Show()
    end
end
s.AddSettingsListener(a.UpdateBCMVisibility)

SLASH_BITTENS_COMBUSTION_MONITOR1 = "/bcm"
function SlashCmdList.BITTENS_COMBUSTION_MONITOR(args)
    if string.find(args, "reset") then
        CombustionMonitorSettings = nil
        positionWindow()
    end
end

local function getDisplayText(damage, perTick)
    local text = floor(damage / 1000) .. "K"
    if igniteIsDirty then
        text = text .. "*"
    end
    text = text .. " (" .. floor(perTick / 1000 + .5) .. "K"
    if igniteIsDirty then
        text = text .. "*"
    end
    return text .. ")"
end

local function updateWindow()
    if not window:IsShown() then
        return
    end
    
    local damage, perTick, numTicks, crit
        = a.PredictCombustionDamage(false, false)
    local text = floor(crit * 1000 + .5) / 10 .. "%   x" .. numTicks
    if c.WearingSet(4, "T13") then
        text = text .. "   " .. a.StolenTimeRemaining
    end
    line1:SetText(text)
    line2:SetText(getDisplayText(damage, perTick))
    line3:SetText(getDisplayText(a.PredictCombustionDamage(true, false)))
end

updateWindow()

------------------------------------------------------------------------ Events
local logHandlers = {}

function logHandlers.SPELL_PERIODIC_DAMAGE(spellID, ...)
    local tick = select(15, ...)
    if spellID == c.GetID("Ignite") then
        if select(21, ...) then
            tick = tick / 2.055
        end
        igniteTick = tick
        igniteIsDirty = false
        updateWindow()
        c.Debug("Combustion", "Ignite is ticking for", igniteTick)
    elseif spellID == c.GetID("Combustion DoT") then
        c.Debug("Combustion", "Acutal Combustion tick:", tick)
    end
end

-- TODO: move this to Ignite applied or refreshed
function logHandlers.SPELL_DAMAGE(spellID, ...)
    if igniteTick > 0
        and not igniteIsDirty
        and select(21, ...) -- is crit
        and select(17, ...) == 4 -- is fire damage
        and spellID ~= c.GetID("Living Bomb") then
        
        igniteIsDirty = true
        updateWindow()
        c.Debug("Combustion", "Ignite is dirty")
    end
end

function logHandlers.SPELL_CAST_SUCCESS(spellID, ...)
    if spellID == c.GetID("Combustion") then
        a.PredictCombustionDamage(false, true)
    end
end

function logHandlers.SPELL_AURA_APPLIED(spellID, ...)
    updateWindow()
end

function logHandlers.SPELL_AURA_REMOVED(spellID, ...)
    if select(12, ...) == c.GetID("Ignite") then
        igniteTick = 0
        c.Debug("Combustion", "Ignite fell off")
    end
    updateWindow()
end

local eventHandlers = {}

function eventHandlers.ADDON_LOADED(addonName)
    if addonName == AddonName then
        positionWindow()
    end
end

function eventHandlers.PLAYER_LOGOUT()
    saveWindowPosition()
end

function eventHandlers.UNIT_SPELLCAST_START()
    updateWindow()
end

function eventHandlers.UNIT_SPELLCAST_STOP()
    updateWindow()
end

function eventHandlers.UNIT_SPELLCAST_SUCCEEDED()
    updateWindow()
end

function eventHandlers.COMBAT_LOG_EVENT_UNFILTERED(...)
    source = select(5, ...)
    if source == nil or not UnitIsUnit(source, "player") then
        return
    end
    
    event = select(2, ...)
    if logHandlers[event] then
        logHandlers[event](select(12, ...), ...)
    end
end

for event, _ in pairs(eventHandlers) do
    window:RegisterEvent(event)
end
window:SetScript("OnEvent", function(self, event, ...)
    eventHandlers[event](...)
end)


--LAST_BUTTON = nil
--COMBUSTION_BUTTON = nil
--hooksecurefunc("ActionButton_Update", function(button)
--    local type, id, subType, spellID = GetActionInfo(button.action)
--    if spellID == 11129 then
--        print("update")
--        COMBUSTION_BUTTON = button
--        createFrameFor(button)
--        LOADED_BUTTON = button
--    end
--    LAST_BUTTON = button
--end)