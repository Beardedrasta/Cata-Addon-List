local MinBuild, MaxBuild, Build = 40000, 0, select(4, GetBuildInfo())
if Build < MinBuild or ( MaxBuild > 0 and Build > MaxBuild ) then return end
local AddonName, a = ...
local AddonTitle = select(2, GetAddOnInfo(AddonName))
local PlainAddonTitle = AddonTitle:gsub("|c........", ""):gsub("|r", "")
local L = a.Localize
local s = SpellFlashAddon
local x = s.UpdatedVariables

local c = BittensSpellFlashLibrary2

a.EquipmentSets = {}

function a.hasThreeHolyPower()
    return a.HolyPower == 3
end

------------------------------------------------------------------------ common
a.spells["Seal of Justice"] = { ID = 20164 }

a.spells["Avenging Wrath"] = {
    ID = 31884,
    NoGCD = 1,
    FlashColor = "yellow",
}

a.spells["Word of Glory"] = {
    ID = 85673,
}

a.spells["Word of Glory at 90"] = {
    ID = 85673,
    Unit = "player",
    CheckFirst = function()
        return a.hasThreeHolyPower() 
            and s.HealthPercent("player") < 90
    end
}

a.spells["Crusader Strike"] = {
    ID = 35395,
}

a.spells["Crusader Strike for Holy Power"] = {
    ID = 35395,
    CheckFirst = function()
        return not a.hasThreeHolyPower()
    end
}

a.spells["Seal of Truth"] = {
    ID = 31801,
    FlashColor = "yellow",
    CheckFirst = function()
        return c.SelfBuffNeeded("Seal of Truth")
    end
}

a.spells["Seal of Insight"] = {
    ID = 20165,
    FlashColor = "yellow",
    CheckFirst = function()
        return c.SelfBuffNeeded("Seal of Insight")
    end
}

a.spells["Hammer of Wrath"] = {
    ID = 24275,
}

a.spells["Judgement"] = {
    ID = 20271,
}

a.spells["Judgement for Buff"] = {
    ID = 20271,
    FlashColor = "yellow",
    NoRangeCheck = 1,
    CheckFirst = function()
        return not c.HasBuff("Judgements of the Pure")
    end
}

a.spells["Consecration over 50"] = {
    ID = 26573,
    CheckFirst = function()
        return s.PowerPercent("player") > 50
    end
}

a.spells["Holy Wrath"] = {
    ID = 2812,
}

a.spells["Divine Plea"] = {
    ID = 54428,
}

a.spells["Auras"] = {
    Type = "form",
    ID = 32223,
    FlashColor = "yellow",
    FlashID = { 32223, 19891, 19746, 7294, 465 },
    Override = function()
        return not s.Form()
    end
}

a.spells["Blessing of Kings"] = {
    ID = 20217,
    FlashColor = "yellow",
    NoRangeCheck = 1,
}

a.spells["Blessing of Might"] = {
    ID = 19740,
    FlashColor = "yellow",
    NoRangeCheck = 1,
}

a.spells["Rebuke"] = {
    ID = 96231,
    Interrupt = 1,
    FlashColor = "aqua",
}

-------------------------------------------------------------------------- holy
a.spells["Infusion of Light"] = { ID = 54149 }
a.spells["Daybreak"] = { ID = 88819 }
a.spells["Judgements of the Pure"] = { ID = 53657 }

a.spells["Word of Glory at 3"] = {
    ID = 85673,
    FlashColor = "yellow",
    NoRangeCheck = 1,
    CheckFirst = function()
        return a.hasThreeHolyPower() 
    end
}

a.spells["Light of Dawn"] = {
    ID = 85222,
    NoRangeCheck = 1,
    FlashColor = "yellow",
}

a.spells["Light of Dawn at 3"] = {
    ID = 85222,
    NoRangeCheck = 1,
    FlashColor = "yellow",
    CheckFirst = function()
        return a.hasThreeHolyPower() 
    end
}

a.spells["Holy Shock"] = {
    ID = 20473,
    NoRangeCheck = 1,
    FlashColor = "yellow",
}

a.spells["Holy Shock under 3 with Daybreak"] = {
    ID = 20473,
    NoRangeCheck = 1,
    FlashColor = "yellow",
    CheckFirst = function()
        return a.HolyPower < 3 and c.HasBuff("Daybreak")
    end
}

a.spells["Holy Shock under 3"] = {
    ID = 20473,
    NoRangeCheck = 1,
    FlashColor = "yellow",
    CheckFirst = function()
        return not a.hasThreeHolyPower() 
    end
}

a.spells["Divine Light"] = {
    ID = 82326,
    NoRangeCheck = 1,
    FlashColor = "yellow",
}

--a.spells["Fast Divine Light"] = {
--    ID = 82326,
--    FlashColor = "yellow",
--    Override = function()
--        return c.HasBuff("Infusion of Light")
--    end
--}

a.spells["Flash of Light"] = {
    ID = 19750,
    FlashColor = "yellow",
}

a.spells["Holy Radiance"] = {
    ID = 82327,
    NoRangeCheck = 1,
    FlashColor = "yellow",
}

--a.spells["Fast Holy Radiance"] = {
--    ID = 82327,
--    NoRangeCheck = 1,
--    FlashColor = "yellow",
--    Override = function()
--        return c.HasBuff("Infusion of Light")
--    end
--}

a.spells["Beacon of Light"] = {
    ID = 53563,
    FlashColor = "yellow",
    Override = function()
        if not c.IsInGroup() then
            return false
        end
        
        if not a.BeaconTarget then
            return true
        end
        
        if s.InCombat() then
            return not s.MyBuff(53563, a.BeaconTarget)
        else
            return s.MyBuffDuration(53563, a.BeaconTarget) < 2 * 60
        end
    end
}

-------------------------------------------------------------------- protection
a.spells["Grand Crusader"] = { ID = 98057 }
a.spells["Elusive"] = { ID = 107951 }

a.EquipmentSets.ProtT13 = {
    HeadSlot = { 78790, 77005, 78695 },
    ShoulderSlot = { 78840, 77007, 78745 },
    ChestSlot = { 78827, 77003, 78732 },
    HandsSlot = { 78772, 77004, 78677 },
    LegsSlot = { 78810, 77006, 78715 },
}

a.spells["Shield of the Righteous unless WoG"] = {
    ID = 53600,
    CheckFirst = function()
        return a.hasThreeHolyPower() and c.GetCooldown("Word of Glory") > 12
    end
}

a.spells["Avenger's Shield"] = {
    ID = 31935,
}

a.spells["Avenger's Shield for Holy Power"] = {
    ID = 31935,
    CheckFirst = function()
        return c.HasBuff("Grand Crusader")
    end
}

a.spells["Ardent Defender"] = {
    ID = 31850,
    NoGCD = true,
    FlashColor = "yellow",
}

a.spells["Holy Shield"] = {
    ID = 20925,
    NoGCD = true,
    FlashColor = "yellow",
}

a.spells["Divine Protection"] = {
    ID = 498,
    NoGCD = true,
    FlashColor = "yellow",
}

a.spells["Fire of the Deep"] = {
    Type = "item",
    ID = 77117,
    Buff = "Elusive",
    FlashColor = "yellow",
}

a.spells["Guardian of Ancient Kings"] = {
    ID = 86150,
    NoGCD = true,
    FlashColor = "yellow",
}

a.spells["Judgements of the Just"] = {
    ID = 20271,
    Debuff = c.SLOW_MELEE_DEBUFFS,
    EarlyRefresh = 3,
}

a.spells["Delayed Judgement"] = {
    ID = 20271,
    CheckFirst = function()
        return c.WearingSet(2, "ProtT13")
    end
}

a.spells["Vindication"] = {
    ID = 35395,
    Debuff = c.PHYSICAL_DAMAGE_DEBUFFS,
    EarlyRefresh = 3,
}

a.spells["Righteous Fury"] = {
    ID = 25780,
    Buff = 25780,
    BuffUnit = "player",
    FlashColor = "yellow",
}

a.spells["Holy Wrath to Stun"] = {
    ID = 2812,
    CheckFirst = function()
        local level = UnitLevel("target")
        if level == -1 or level > UnitLevel("player") then
            return false
        end
        
        local ct = UnitCreatureType("target")
        return UnitLevel("target") <= UnitLevel("player")
            and (ct == L["Demon"]
                or ct == L["Dragonkin"]
                or ct == L["Elemental"]
                or ct == L["Undead"])
    end
}

a.spells["Hand of Reckoning"] = {
    ID = 62124,
    NoGCD = true,
    CheckFirst = c.CheckFirstForTaunts,
}

a.spells["Righteous Defense"] = {
    ID = 31789,
    NoGCD = true,
    CheckFirst = c.CheckFirstForTaunts,
}

------------------------------------------------------------------- retribution
a.spells["The Art of War"] = { ID = 59578 }
a.spells["Seal of Righteousness"] = { ID = 20154 }

a.spells["Free Exorsism"] = {
    ID = 879,
    CheckFirst = function()
        return c.HasBuff("The Art of War")
    end
}

a.spells["Free Exorsism against Undead"] = {
    ID = 879,
    CheckFirst = function()
        return c.HasBuff("The Art of War")
            and UnitCreatureType("target") == L["Undead"]
    end
}

a.spells["Templar's Verdict"] = {
    ID = 85256,
    CheckFirst = function()
        return a.hasThreeHolyPower()
    end
}

a.spells["Zealotry"] = {
    ID = 85696,
    NonGCD = true,
    FlashColor = "yellow",
}

a.spells["Inquisition"] = {
    ID = 84963,
    Buff = "Inquisition",
    BuffUnit = "player",
    EarlyRefresh = 3,
    CheckFirst = function()
        return a.hasThreeHolyPower()
    end
}
