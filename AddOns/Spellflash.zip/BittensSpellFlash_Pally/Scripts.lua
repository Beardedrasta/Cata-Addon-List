local AddonName, a = ...
local L = a.Localize
local s = SpellFlashAddon
local c = BittensSpellFlashLibrary2

a.Rotations = {}
c.RegisterForEvents(AddonName, a)
s.Spam[AddonName] = function()
    a.HolyPower = s.Power("player", SPELL_POWER_HOLY_POWER)
    c.Flash(AddonName, a)
end

local function flashRaidBuffs()
    local duration = 0
    if not s.InCombat() then
        duration = 5 * 60
    end
    
    -- if I have my own kings, make sure everyone else does too
    if s.MyBuff(c.GetID("Blessing of Kings"), "player") then
        if not s.Buff(c.FIVE_PERCENT_BUFFS, "raid|all|range", duration) then
            a.Flash("Blessing of Kings")
        end
        return
    end
    
    -- if I have my own might, make sure everyone else does too
    if s.MyBuff(c.GetID("Blessing of Might"), "player") then
        if not s.Buff(c.ATTACK_POWER_BUFFS, "raid|all|range", duration)
            or not s.Buff(c.MP5_BUFFS, "raid|all|range", duration) then
            
            a.Flash("Blessing of Might")
        end
        return
    end
    
    -- check the raid for both kings and might
    if not s.Buff(c.FIVE_PERCENT_BUFFS, "raid|all|range", duration) then
        a.Flash("Blessing of Kings")
    end
    if not s.Buff(c.ATTACK_POWER_BUFFS, "raid|all|range", duration)
        or not s.Buff(c.MP5_BUFFS, "raid|all|range", duration) then

        a.Flash("Blessing of Might")
    end
end

local function flashSeal(name, ...)
    for i = 1, select("#", ...) do
        if not c.SelfBuffNeeded(select(i, ...)) then
            return
        end
    end
    a.Flash(name)
end

local consumingInfusion = false
a.Rotations.Holy = {
    Spec = 1,
    OffSwitch = "holy_off",
    
    FlashAlways = function()
	    a.FlashAll("Seal of Insight", "Beacon of Light", "Auras")
	    flashRaidBuffs()
	end,
	
	FlashInCombat = function()
	    if c.IsCasting("Holy Radiance")
	        or (c.IsCasting("Divine Light") 
	            and s.MyBuff(
	                c.GetID("Beacon of Light"), 
	                c.GetCurrentCastTarget(),
	                s.GetCasting())) then
	        
	        a.HolyPower = math.min(a.HolyPower + 1, 3)
	    end
	    
	    a.FlashAll(
	        "Judgement for Buff",
	        "Word of Glory at 3",
	        "Light of Dawn at 3",
	        "Holy Shock under 3 with Daybreak",
	        "Rebuke")
	    if c.HasBuff("Infusion of Light") and not consumingInfusion then
	        a.FlashAll("Divine Light", "Holy Radiance", "Flash of Light")
	    end
	end,
    
    CastStarted = function(spellID, target)
        if (spellID == c.GetID("Divine Light")
                or spellID == c.GetID("Holy Radiance"))
            and c.HasBuff("Infusion of Light") then
            
            consumingInfusion = true
            c.Debug("Event", "Consuming Infusion of Light")
        end
    end,
    
    CastFailed = function(spellID, target)
        if consumingInfusion
            and (spellID == c.GetID("Divine Light")
                or spellID == c.GetID("Holy Radiance")) then
            
            consumingInfusion = false
            c.Debug("Event", "Resuming Infusion of Light (failure)")
        end
    end,
    
    CastSucceeded = function(spellID, target)
        if consumingInfusion
            and (spellID == c.GetID("Divine Light")
                or spellID == c.GetID("Holy Radiance")) then
            
            consumingInfusion = false
            c.Debug("Event", "Resuming Infusion of Light (success)")
        end
    end,
    
    AuraApplied = function(spellID, target)
        if spellID == c.GetID("Beacon of Light") then
            a.BeaconTarget = target
            c.Debug("Event", "Beacon target:", target)
        end
    end,
}

a.Rotations.Protection = {
    Spec = 2,
    OffSwitch = "prot_off",
	
	FlashInCombat = function()
	    a.FlashAll(
	       "Avenging Wrath", "Hand of Reckoning", "Righteous Defense", "Rebuke")
	    
	    if a.Flash("Holy Wrath to Stun") then
	        return
	    end
	    
	    -- TODO: add "if not stunned"
	    c.RotateCooldowns(
	        { "Windwalk", "Veil of Lies" }, 
	        "Holy Shield", 
	        "Divine Protection", 
	        "Fire of the Deep", 
	        "Guardian of Ancient Kings", 
	        "Ardent Defender")
	    
	    if a.Flash("Word of Glory at 90") then
	        return
	    end
	    
	    if a.hasThreeHolyPower()
	        and s.HealthPercent("player") < 90 
	        and c.GetCooldown("Word of Glory") < 1 then
	            
	        return
	    end
	    
	    if a.Flash(
	        "Vindication", 
	        "Judgements of the Just",
	        "Delayed Judgement",
	        "Shield of the Righteous unless WoG",
	        "Crusader Strike", 
	        "Avenger's Shield for Holy Power") then
	        
	        return
	    end
	    
	    if c.GetCooldown("Crusader Strike") < .5 then
	        return
	    end
	    
	    a.Flash(
	        "Hammer of Wrath",
	        "Avenger's Shield",
	        "Consecration over 50",
	        "Judgement",
	        "Holy Wrath")
	end,
    
    FlashAlways = function()
	    a.FlashAll("Righteous Fury", "Auras")
	    flashSeal("Seal of Insight", "Seal of Truth", "Seal of Justice")
	    flashRaidBuffs()
	end,
}

a.Rotations.Retribution = {
    Spec = 3,
    OffSwitch = "ret_off",
	
	FlashInCombat = function()
	    a.FlashAll("Zealotry", "Avenging Wrath", "Rebuke")
	    a.Flash(
	        "Inquisition",
	        "Crusader Strike for Holy Power",
	        "Free Exorsism against Undead",
	        "Hammer of Wrath",
	        "Free Exorsism",
	        "Templar's Verdict",
	        "Crusader Strike",
	        "Judgement",
	        "Holy Wrath",
	        "Consecration over 50",
	        "Divine Plea")
	end,
    
    FlashAlways = function()
	    a.FlashAll("Seal of Truth", "Auras")
        flashSeal("Seal of Truth", "Seal of Justice", "Seal of Righteousness")
	    flashRaidBuffs()
	end,
}
