if not Skinner:isAddonEnabled("MonkeyQuest") then return end

function Skinner:MonkeyQuest()

	self:applySkin(MonkeyQuestFrame)

end
