if not Skinner:isAddonEnabled("DamageMeters") then return end

function Skinner:DamageMeters()

	self:applySkin(DamageMetersFrame_TitleButton)
	self:applySkin(DamageMetersFrame)

end
