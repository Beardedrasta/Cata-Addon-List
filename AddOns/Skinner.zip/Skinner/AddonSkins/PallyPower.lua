if not Skinner:isAddonEnabled("PallyPower") then return end

function Skinner:PallyPower()

-->-- Other buttons
	self:applySkin(PallyPowerAutoBtn)
	self:applySkin(PallyPowerRFBtn)
	self:applySkin(PallyPowerAuraBtn)
	
end
