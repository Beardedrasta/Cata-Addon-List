Hi,

  I have moved some Addon skins into the Obsolete Skins folder as I believe they are no longer used.

  If you still use one of them then please post to the Skinner topic specifying which skin you are using and I will move it back.

  Jncl

  The Skinner topic URL is : http://forums.wowace.com/showthread.php?t=2923
