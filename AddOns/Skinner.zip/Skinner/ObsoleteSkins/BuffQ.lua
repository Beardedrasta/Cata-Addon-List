
function Skinner:BuffQ()

	self:applySkin(BQMainFrame)
	self:applySkin(BQListFrame)

end
