
function Skinner:BigTrouble()

	self:applySkin(BigTroubleFrame)

end
