--[[
Name: LibRover-1.0
Revision: $Rev: 1 $
Author(s): sinus (sinus@sinpi.net)
Description: A library calculating travel paths from point A to point B.
Dependencies: None
License: MIT
]]

-- BabbleZone or somesuch heavily suggested. This library uses English map names.

-- #######################
--	T H I S   I S   A   S T U B   ! ! !
-- #######################

local MAJOR_VERSION = "LibRover-1.0"
local MINOR_VERSION = tonumber(("$Revision: 1 $"):match("%d+"))

local name,addon = ...
-- #AUTODOC_NAMESPACE prototype

local GAME_LOCALE = GetLocale()

local Astrolabe = DongleStub("Astrolabe-ZGV")
local LibTaxi = LibStub("LibTaxi-1.0")

do
	local LIB_MAJOR, LIB_MINOR = "LibRover-1.0", 1

	local Lib = LibStub:NewLibrary(LIB_MAJOR, LIB_MINOR)

	if Lib then

		-- let's get famous
		addon.LibRover = Lib
		_G['LibRover'] = Lib

		local yield = coroutine.yield
		local resume = coroutine.resume

		-- Localization stub:
		local L = {}
		setmetatable(L,{__index=function(self,k) return rawget(self,k) or k end})

		Lib.is_stub=true

		Lib.data = Lib.data or addon.LibRoverData     addon.LibRoverData = nil

		Lib.opennodes = { }
		Lib.closednodes = { }

		Lib.banned_nodes = {}

		Lib.nodes = {all={},taxi={},id={},mageteleport={}}
		local allnodes = Lib.nodes.all

		
		Lib.knowntaxis = {}  -- managed by LibTaxi


		-- intercrossable zone pairs
		Lib.intercross = {}

		Lib.do_updating = true

		Lib.cfg = { use_cot = true, use_mage_teleport = 1, avoid_highlevel_zones=1, strip_arrivals=1 }

		--[[
		local TYPE_BORDER = 1
		local TYPE_TAXI = 3
		local TYPE_START = 4
		local TYPE_END = 5

		local WAY_GROUND = 1
		local WAY_SHIP = 2
		local WAY_TAXI = 3
		local WAY_FLY = 4
		local WAY_PORTAL = 5
		local WAY_ZEPPELIN = 6
		--]]

		local function getdist(node1,node2)
			local dist,xd,yd = Astrolabe:ComputeDistance(node1.m,node1.f,node1.x,node1.y,node2.m,node2.f,node2.x,node2.y)
			if dist==0 and node1.c~=node2.c or (node1.c==node2.c and node1.c==-1 and node1.m~=node2.m) then dist=nil end
			return dist or 99999999,xd,yd
		end
		Lib.GetDist=getdist

		local function map_breaks_stuff()
			return WorldMapFrame:IsShown() and (GetPlayerMapPosition("player")==0)
		end

		local function playerpos()
			local m,f=ZGV.CurrentMapID,ZGV.CurrentMapFloor -- WHY OH WHY do I have to do it like that ;_;
			local lam,laf,lax,lay = unpack(Astrolabe.LastPlayerPosition)
			local x,y = Astrolabe:TranslateWorldMapPosition( lam, laf, lax, lay, m, f )
			if not x or x<0 or y<0 or x>1 or y>1 then x,y=nil,nil end
			return m,f,x,y
		end
		Lib.playerpos=playerpos

		local function myassert(test,msg,...)
			if not test then
				ERRORS=ERRORS or {}  -- global!
				tinsert(ERRORS,{...})
				error(msg)
			end
		end



		-- IMPORTANT OBSERVATION.
		-- Nodes are (almost) ALWAYS separated by "walk"/"fly"

		local function MapName(id)
			if type(id)=="table" then id=id.m end
			return GetMapNameByID(tonumber(id) or 0) or (id==0 and "Azeroth") or (id==13 and "Kalimdor") or (id==14 and "Eastern Kingdoms") or (id==466 and "Outland") or (id==485 and "Northrend") or "(map "..tostring(id).."?)"
		end

		local node_proto = {}

		-- Run as node:GetText().
		-- Additional params allow for contextualization - give a node its predecessor and successor, and get proper "ship from..." display.
		function node_proto.GetText(node,prevnode,nextnode,dir)
			local prevstep,nextstep
			if prevnode and prevnode.node then prevstep,prevnode = prevnode,prevnode.node end
			if nextnode and nextnode.node then nextstep,nextnode = nextnode,nextnode.node end

			function FromTo(strfrom,strto)
				if prevnode and prevnode==node.border then return strfrom else return strto end
			end

			if node.extra_title then return L[node.extra_title] end

			if Lib.debug_verbose_nodes then
				return ("[%d] %s %d,%d (%s)"):format(node.num,GetMapNameByID(node.m or 0) or "world",node.x*100,node.y*100,node.type)

			elseif node.type=="border" then
				--if fromnode and fromnode.n[node] and fromnode.n[node].border then
					--local border = fromnode.n[node].border
					--return ("%s border"):format(GetMapNameByID(fromnode:GetText()) or dstmap)
				--else
					--return ("%s/%s border"):format(GetMapNameByID(node.border[1]) or node.border[1],GetMapNameByID(node.border[2]) or node.border[2])
				--end
				return ("%s/%s border"):format(MapName(node),MapName(node.border or node.ms and next(node.ms)))
			elseif node.type=="taxi" then
				return ("%s flight point"):format(node.name)
			elseif node.type=="ship" then
				local destportname = node.border.port and ("%s, %s"):format(node.border.port,MapName(node.border)) or node.border.name or MapName(node.border)
				return FromTo("Ship from %s","Ship to %s"):format(destportname)
			elseif node.type=="zeppelin" then
				local destportname = node.border.port and ("%s, %s"):format(node.border.port,MapName(node.border)) or node.border.name or MapName(node.border)
				return FromTo("Zeppelin from %s","Zeppelin to %s"):format(destportname)
			elseif node.type=="tram" then
				--local dest=node.border.port or (nextnode.m~=node.m and nextnode) or (prevnode.m~=node.m and prevnode)
				local destportname = node.border.port and ("%s, %s"):format(node.border.port,MapName(node.border)) or node.border.name or MapName(node.border)
				return FromTo("Tram from %s","Tram to %s"):format(destportname)
			elseif node.type=="portal" then
				if node.border and node.m==node.border.m then
					return ("Portal")
				elseif node.border and node.border~="multi" then -- should have one! though portals tend to have common destination points, account for that too.
					local destportname = node.border.port and ("%s, %s"):format(node.border.port,MapName(node.border)) or node.border.name or MapName(node.border)
					return FromTo("Portal from %s","Portal to %s"):format(destportname)
				elseif prevnode then
					local destportname = prevnode.port or prevnode.name or MapName(prevnode)
					return FromTo("Portal from %s","Portal to %s"):format(destportname)
				else
					return "Portal destination"
				end
				--if not srcmap then
					--return ("%s/%s portal"):format(GetMapNameByID(node.n[fromnode]border[1]),GetMapNameByID(node.border[2]))
				--else
				--	local dstmap = node.border[1]==srcmap and dstmap or srcmap
				--	return ("Portal %s %s"):format(dir=="src" and "to" or "from",GetMapNameByID(dstmap))
				--end
			else
				return ("%s %d,%d"):format(MapName(node),node.x*100,node.y*100)
			end
		end

		function node_proto.tostring(node,withneighs)
			local ret = ("[%d] \"%s\" = %s %.1f,%.1f"):format(node.num, node:GetText(), MapName(node),node.x*100,node.y*100, neighs)
			if node.region then
				ret = ret .. (" (REG:%s)"):format(node.region)
			end
			if node.score then
				ret = ret .. (" (t=%.1f, h=%.1f)"):format(node.score or -1,node.heur or -1)
			end
			if withneighs then
				local neighs = ""
				for n,link in pairs(node.n) do neighs=neighs.." ".. n:tostring().." <"..(link.mode or "?")..">\n" end
				ret = ret .. "\nLinks:\n"..neighs
			end
			return ret
		end

		function node_proto.GetAngleTo(node1,node2)
			local dist,xd,yd = getdist(node1,node2)
			if not xd then return end
			local dir = atan2(xd, -yd)
			return dir%360
		end

		local node_meta = {__index=node_proto}

		local TWOPI=math.pi*2

		local link_walk_intercross = {mode="walk", interx=1}

		-- ONE WAY. Run twice to do two-way.
		-- Checks if n1 sees n2, and - if yes - adds it to neighbours.
		-- node.m = map id
		-- node.ms[mapid] = "does node see nodes in mapid as visible" (crossable borders)
		-- node.c = cont id
		local function DoNodeLinkage(n1,n2)
			if n1.c==n2.c then

				-- taxis see each other across the continent, assuming they're the same 'operator' (important for Vashj'ir seahorses!)
				if n1.type=="taxi" and n2.type=="taxi" and n1.taxioperator==n2.taxioperator then
					n1.n[n2]={mode="taxi"}
					return
				end

				-- do ground connections
				if (n1.m==n2.m  -- same map
					--or (n1.ms and n1.ms[n2.m])  -- same "surrogate" map, one way or another
					or (n2.ms and n2.ms[n1.m])
					or Lib.intercross:CanCross(n1.m,n2.m)
					)
				and not (n1.region~=n2.region)
				--and not n2.noallzone -- they see us using "see all zone"
				and (not n2.noallzone or (n1==Lib.startnode)) -- startnode allowed to connect even in noallzone, we'll just run a penalty for beelines later
				and (not n2.noallzone or (n1==Lib.endnode)) -- startnode allowed to connect even in noallzone, we'll just run a penalty for beelines later
				and not (n2.m==41 and (n1.y-0.8)*(n2.y-0.8)<0) -- Darnassus! Unwalkable to Rut'Theran! TEMPORARY...
				--and not (n2.m==17 and (n1.x-0.837)*(n2.x-0.837)<0) -- Badlands: Fuselight-by-the-sea
				--and not (n1.is_remote~=n2.is_remote)
				then
					n1.n[n2]={mode="walk"}
					
					--DEBUG
					if n1.debug then
						Lib:Debug(n1:tostring().."  --WALK--  "..n2:tostring())
						Lib:Debug("n2.noallzone: "..tostring(n2.noallzone).."  startnode? "..tostring(n1==Lib.startnode))
					end
				end

			end
			--[[
			for t,to in pairs(n1.taxi) do
				if (#to==2 and to[1]==n2.l[1] and to[2]==n2.l[2]) -- they see us using "see all zone"
				or ((type(to)==number or type(to)==string) and n2.id==to) -- direct link to us
				then
					n1.n[i]=WAY_TAXI
				end
			end
			--]]
		end

		local function AddNode(node)
			--if not self.nodes[node.l[1]] then self.nodes[node.l[1]]={} end
			table.insert(allnodes,node)
			if (node.type) then
				if not Lib.nodes[node.type] then Lib.nodes[node.type]={} --[[setmetatable(Lib.nodes[node.type],{__mode="v"}) --]] end
				table.insert(Lib.nodes[node.type],node)
			end

			setmetatable(node,node_meta)

			-- sanitize continent, coordinates, floor
			node.c = node.c or Lib.ContinentsByID[node.m]
			if node.x>1 then node.x,node.y=node.x/100,node.y/100 end
			node.f = ZGV:SanitizeMapFloor(node.m,node.f)

			local ni = #allnodes
			node.num=ni

			-- set node.region, if applicable. BEFORE neighbours, ffs.
			Lib.NodeRegions:Assign(node)
			if node.m==341 then node.nofly=1 end  --ironforge, experimental nofly


			-- sanitize metadata
			node.dist=tonumber(node.dist)

			node.n={}  -- prepare neighbours
			--setmetatable(node.n,{__mode="k"})
			-- connect to other nodes in the zone, by automatic linkage (taxi, ground)
			for i,v in pairs(allnodes) do
				if v~=node then
					-- endnode only gets linked TO.
					if node~=Lib.endnode then DoNodeLinkage(node,v) end
					-- startnode and inns don't get linked TO, only FROM.
					if node~=Lib.startnode and node.type~="inn" then DoNodeLinkage(v,node) end
				end
			end

			--[[
			-- now done differently through the intelligent Lib.intercross
			for pi,pair in ipairs(Lib.intercross) do
				if node.m==pair[1] or node.m==pair[2] then
					for ni2,node2 in ipairs(Lib.nodes.all) do
						if (node~=node2) and ((node2.m==pair[1]) or (node2.m==pair[2])) then
							node.n[node2]=link_walk_intercross
							node2.n[node]=link_walk_intercross
						end
					end
				end
			end
			--]]

			if node.id then Lib.nodes.id[node.id]=node end

			return node
		end

		local function MakeNode(text)
			if not text then return end
			local dat={}
			local function grab_dat(s)
				s=s:gsub("%%GT%%","<")
				local k,v = s:match("(.-):(.+)")
				dat[k]=v
				return ""
			end
			text=text:gsub("%s*<(.-)>",grab_dat)

			text=text:match("^%s*(.-)%s*$") or text  --trim
			local rest,id = text:match("^(.-)%s*@(%S+)$")  -- "Map 12,34 @id"
			if id and rest=="" then return nil,nil,nil,id end  -- just id!
			text=rest~="" and rest or text
			local m,x,y = text:match("^(.-)[%s,]+([0-9%.]+),([0-9%.]+)$")
			m=m or text  -- could be just the zone, after all.
			m = Lib.data.MapIDsByName[m]
			if type(m)=="table" then m=m[1] end
			assert(m,"Bad map in MakeNode('"..text.."')")

			return m,x and tonumber(x)/100,y and tonumber(y)/100,id,dat
		end

		--[[
		local function ParseFullNode(text)
			local text2,faction,ntype = text:match("^(.-) %((.):(.-)%)$")
			text=text2 or text
			local mxy1,dir,mxy2 = text:match("^(.-)%s+([xto]+)%s+(.-)$")
			local m1,x1,y1 = ParseMapXY(mxy1)
			local m2,x2,y2
			if mxy2 then m2,x2,y2 = ParseMapXY(mxy2) end

			if ntype=="_" then ntype=nil end
			return m1,x1,y1,m2,x2,y2,dir=="x",faction,ntype
		end
		--]]

		--[[-- REGIONS --]]--
		-- All this jazz allows us to Lib.NodeRegions:Assign(node) and the node gets .region set to the name of a matching region. All automagically.
			Lib.NodeRegions = { }

			function Lib.NodeRegions:Assign(node)
				for ri,region in ipairs(self) do if region:Contains(node) then node.region=region.name  node.regionobj=region  end end
			end

			local function Region__Contains(region,node)
				--print(getdist(region.centernode,node))
				return region.centernode.m==node.m and getdist(region.centernode,node)<region.radius
			end

			local region_proto = {Contains=Region__Contains}
			local region_mt = {__index=region_proto}
			local function AddRegion(data)
				local region = data
				setmetatable(region,region_mt)
				local m1,x1,y1,id1,dat1 = MakeNode(region.center)   region.center=nil
				region.centernode = x1 and {m=m1,x=x1,y=y1,id=id1,type=ntype} or Lib.nodes.id[id1]
				tinsert(Lib.NodeRegions,region)
			end

		local LAST_NODE  -- to use with @+ pseudo-id in data

		local function __SmartAddNode(text,deftype)
			local extra

			deftype=deftype or "misc"

			-- by default, nodes are "misc" and connect as "walk".

			-- Extract the (A:TYPE) faction+type marker. Ugly, but there it is.
			local text1,faction,ntype,text2 = text:match("^(.-)%((.):(.-)%)(.-)$")
			text=text1 and text1..text2 or text
			-- faction check
			local enemyfac = UnitFactionGroup("player")=="Alliance" and "H" or "A"
			if faction==enemyfac then return end
			-- type default: border
			if ntype=="_" then ntype=nil end
			ntype=ntype and ntype:lower() or deftype

			-- Powerhorse: extract all {data:blablabla} tags.
			local extra={mode="walk"}
			while text:find("{") do
				local text1,key,val,text2 = text:match("^(.-){(.-):(.-)}(.-)$")
				if key then
					extra[key]=val
					text=text1..text2
				end
			end

			if extra.cond then
				local err
				extra.cond_fun,err = loadstring("return "..extra.cond)
				if err then error(err.." in parsing '"..extra.cond.."'") end
			end

			text=text:gsub("\\>","%%GT%%")

			-- Powerhorse #2: parse "zone 12,34 to zone 55,66"
			local mxy1,dir,mxy2 = text:match("^(.-)%s+%-([xto]+)%-%s+(.-)$")
			if not mxy1 then mxy1 = text end -- OMG one node!?
			local m1,x1,y1,id1,dat1 = MakeNode(mxy1)
			local m2,x2,y2,id2,dat2 = MakeNode(mxy2)
			local twoway = dir=="x"

			local n1 = x1 and {m=m1,x=x1,y=y1,id=id1,type=ntype} or (id1=="+" and LAST_NODE) or Lib.nodes.id[id1]
			local n2 = x2 and {m=m2,x=x2,y=y2,id=id2,type=ntype} or Lib.nodes.id[id2]

			LAST_NODE = n2 or n1
			
			if dat1 then for k,v in pairs(dat1) do n1[k]=v end end
			if x1 then AddNode(n1) end --new!
			-- we surely have the first node, right?
			if n2 then
				if dat2 then for k,v in pairs(dat2) do n2[k]=v end end
				if x2 then
					AddNode(n2)
				end
				-- we have a proper second node! link to it
				n1.n[n2]=extra
				extra.hardwired=1
			end

			if twoway then
				if n2 then
					-- normal return trip, same type
					n2.n[n1]=n1.n[n2]
				elseif m2 then
					-- "Zone 12,34 x Zone"? Write a dual-map node. We only have one node here with a multiple personality.
					if not n1.ms then n1.ms={} end
					n1.ms[m2]=extra
				end
			else
				--if n2 then n2.onlydst=n1 end
			end

			-- define some more details about the nodes' linkage.
			if n1 and (n2 or n1.ms) then
				extra.mode=ntype or extra.mode or "walk"  -- this is link metadata. Assign a mode of travel.

				-- If the node is closely bound with another (quite likely, since they're usually added in pairs), store the (hint to the) linkage separately.
				-- This way a node that's later known to have 5 neighbours, can quickly tell one of the neighbours as the SPECIAL neighbour.
				-- But, if the node ALREADY has a special neighbour... then delete this; it's a multi-special whore node.

				if not extra.dontsetborder then -- allow for some linkages that are NOT special
					n1.border = n1.border and "multi" or n2
					if n2 then  n2.border = n2.border and "multi" or n1  end
				end

			else
				-- single node!!
				for k,v in pairs(extra) do n1[k]=v end
			end

			if n1.spell then
				tinsert(Lib.nodes.mageteleport,n1)
			end

			--assert(n1,"No coords in SmartAddNode(\""..text.."\")")
			--[[
			if n2 then
				Lib:Debug(("New smart node: %s %.1f,%.1f  %s  %s %.1f,%.1f"):format(GetMapNameByID(m1),x1,y1, twoway and "x" or "to", GetMapNameByID(m2),x2,y2))
			else
				Lib:Debug(("New smart node: %s %.1f,%.1f  %s  %s"):format(GetMapNameByID(m1),x1,y1, twoway and "x" or "to", GetMapNameByID(m2)))
			end
			--]]

			return n1,n2
		end

		function Lib.intercross:CanCross(id1,id2)
			return (self[id1] and self[id1][id2]) or (self[id2] and self[id2][id1])
		end

		local enemyfac = UnitFactionGroup("player")=="Alliance" and "H" or "A"

		--[[================ INITIALIZE NODES ===============]]--

		local function InitializeTaxis()
			for c,cont in pairs(LibTaxi.taxipoints) do
				for z,zone in pairs(cont) do
					z=Lib.data.MapIDsByName[z] or z
					if type(z)=="table" then z=z[1] end
					for n,node in ipairs(zone) do
						if node.faction~=enemyfac then
							node.m = z
							node.c = c
							node.type = "taxi"
							-- other fields are already there, how convenient!
							AddNode(node)
						end
					end
				end
			end
			-- DON'T clear taxis. They're good for lookups by other addons.
			-- Though we could clean up the enemy faction...
		end

		Lib.ContinentsByID = {[13]=1,[14]=2,[466]=3,[485]=4}  -- main continents, somehow they're unnamed, the bastards.
		Lib.MapFloorCountCache = {}
		Lib.MapLevels = {}
		setmetatable(Lib.MapLevels,{__index=function() return 0 end})

		function Lib:DoStartup()

			for id=1,1000 do
				if GetMapNameByID(id) then
					SetMapByID(id)
					Lib.ContinentsByID[id]=GetCurrentMapContinent()
					Lib.MapLevels[id]=GetCurrentMapLevelRange() --minimum.
					Lib.MapFloorCountCache[id]=GetNumDungeonMapLevels() or 0
				end
			end

			-- add map IDs to taxis
			InitializeTaxis()
			-- if available, try to glean known taxi routes. Otherwise assume they're not known.
			if LibTaxi then  LibTaxi:Startup(Lib.knowntaxis)  end
		end

		--[[====]]--



		-- uhhh, WHY!???
		local function GetPlayerPos()
			local m,f,x,y = Astrolabe:GetCurrentPlayerPosition()
			if m==13 or m==14 or m==0 or m==689 or m==-1 or m==485 or m==466 then
				-- bad pos, better get the last
				m,f,x,y=unpack(Astrolabe.LastPlayerPosition)
			end
			return m,f,x,y
		end


			-- LEGACY, OBSOLETE, only used by the |fly lines

			function Lib:GetNearestTaxi()
				if not Astrolabe then return end
				local mindist=999999
				local minnode
				local m,f,x,y = playerpos()
				if not x then return end
				for n,node in ipairs(Lib.nodes.taxi) do
					if node.m and node.x and node.y then
						local dist = Astrolabe:ComputeDistance(m,f,x,y,node.m,node.f,node.x,node.y)
						if dist and dist<mindist then mindist,minnode=dist,node end
					end
				end
				return minnode,mindist
			end

			function Lib:GetNearestTaxiInZone()
				--pmap = GetCurrentMapAreaID()
				if not Astrolabe then return end
				local mindist=999999
				local minnode
				local m,f,x,y = playerpos()
				if not x then return end
				for n,node in ipairs(Lib.nodes.taxi) do
					if node.m and node.x and node.y and node.m == m then
						local dist = Astrolabe:ComputeDistance(m,f,x,y,node.m,node.f,node.x,node.y)
						if dist and dist<mindist then mindist,minnode=dist,node end
					end
				end
				return minnode,mindist
			end

		--- Drop our special start/end nodes from the map
		function Lib:ClearPath()
			return --DEV
		end

		local success_endnode

		local lam,laf,lax,lay, lbm,lbf,lbx,lby
		local fromme=false

		--]=]

		local function dictsize(dict)
			local i=0
			for _,__ in pairs(dict) do i=i+1 end
			return i
		end

		-- one-step A*
		
		local closingnode,minscore,current,found
		local cost,heur,time
		local cl,nl,el
		local neigh,neighlink

		local lastupdate=0

		Lib.calculation_step_limit = 9999

		--[[
		Notes on speeds: [yd/sec]
		run: 7
		mount: 7*1.6=11.2
		fmount: 7*2.2=14
		fly: 7*2.5=17.5
		ffly: 7*4.1=28.7

		taxi storm-iron: 3:36=216
		--]]

		local function assertfmt(test,msg,...)
			if not test then error(msg:format(...)) end
		end

		local WALKSPEED=7

		local bestcost

		--local flylink={mode="fly"}  -- DO NOT USE, breaks cachins.
		local hearthlink = {mode="hearth",cost=3*60}

		Lib.DO_HEUR = false

		Lib.debug_nodes = {}

		local colors={['portal']="|cffff8800",['taxi']="|cff88ff00"}

		local function is_exo_or_belf(map) -- dual purpose: 
			return map==464 or map==476 or map==471  -- exo & co.
				or map==463 or map==462 or map==480  -- smoon & co.
		end

		local function is_vash(map)
			return map==613 or map==610 or map==614 or map==615
		end

		function Lib:StepForever()
			local still,ret = true,nil
			while still do
				still,ret = self:StepPath()
			end
			if ret then
				self:ReportPath(ret)
			else
				self:ReportFail()
			end
			self:Cleanup()
		end

		local dists_to_portals = {}
		Lib.dists_to_portals = dists_to_portals

		function Lib:StepPath()
			return --DEV
		end

		function Lib:Cleanup()
			--self.force_next=nil
		end

		local n
		function Lib:ReportPath(endnode)
			return --DEV
		end

		function Lib:ReportFail()
			self.calculating = nil
			Lib:Debug("No route found.")
			self.PathFoundHandler("failure")
		end


		--[[
		function Lib:____RebuildNodes()
			wipe(self.masternodes)

			self:ImportTaxis(self.basenodes_taxis_N)
			if UnitFactionGroup("player")~="Alliance" then
				self:ImportTaxis(self.basenodes_taxis_A)
			else
				self:ImportTaxis(self.basenodes_taxis_H)
			end

			self:ImportBorders()
		end
		--]]

		--local maxpersec = 20000  -- nodes processed
		local hardmaxfirst = 3000 -- don't get greedy
		local hardmaxidle = 1000 -- don't get greedy
		local hardmax = 1000
		local hardmin = 50 -- don't get greedy
		local perframethrot = 0

		-- off the top of my head. elapsed>0.05 (20fps) = setting slow speed. elapsed<0.02 (50fps) = setting full speed.

		local waitphase=0

		Lib.update_interval = 2

		local interval_min=1/12
		local interval_max=1/50

		function Lib:OnUpdate(elapsed)
			return --DEV
		end

		function Lib:UpdateNow()
			lastupdate=999
			lax=-999
			self.calculating=false -- yes, false; need to restart, so stop calculating, start updating, wait for FindLastPath call.
			self.updating=true
			self.is_first_run=1
			--self.updatepaused=nil
		end
    
		function Lib:FindPath(am,af,ax,ay,bm,bf,bx,by, handler, extradata)
			ZGV:Debug("LibRover: sorry, pathing is DEV-only.")
			return --DEV
		end

		function Lib:FindLastPath()
			return --DEV
		end

		function Lib:Abort()
			return --DEV
		end

		Lib.maxspeedinzone={}
		
		function Lib.HasAchievement(id)
			return select(4,GetAchievementInfo(id))
		end
		local HasAchievement=Lib.HasAchievement

		function Lib:CheckMaxSpeeds()
			return --DEV
		end

		local function warn(message)
			local _, ret = pcall(error, message, 3)
			geterrorhandler()(ret)
		end
		

		local function onEvent(this, event, arg1)
			if event=="ADDON_LOADED" and not Lib.loaded then
				Lib.loaded=true
				
				Lib:DoStartup()
			end
		end

		Lib.frame = LibRoverFrame or CreateFrame("Frame", "LibRoverFrame")
		Lib.frame:RegisterEvent("ADDON_LOADED")
		Lib.frame:SetScript("OnEvent", onEvent)
		Lib.frame:SetScript("OnUpdate", function(frame,elapsed) Lib:OnUpdate(elapsed) end)

		function Lib:ShowAllNodes(nodetype)
			nodetype=nodetype or "all"
			for ni,n in ipairs(Lib.nodes[nodetype]) do
				ZGV.Pointer:SetWaypoint(n.m,n.f,n.x,n.y,{title=n:tostring(true)})
			end
		end

		function PlayerCompletedQuest(id)
			local completedquests = GetQuestsCompleted() or QueryQuestsCompleted()
			if not completedquests then return end
			return completedquests[id]
		end

		function Lib:GoSlow()
			maxpersec = 1
		end

		function Lib:Debug(...)
			local str = ...
			ZGV:Debug("|cff762fca9LibRover> ".. str, select(2,...) )
		end

	end

end

--[[
local MapZoneCache={}
local cached
local function GetMapZoneNumbers(zonename)
	if zonename==self.BZL["Plaguelands: The Scarlet Enclave"] then return 5,1 end
	cached = MapZoneCache[zonename]
	if cached then return unpack(cached) end
	for cont in pairs{GetMapContinents()} do
		for zone,name in pairs{GetMapZones(cont)} do
			if name==zonename then
				MapZoneCache[zonename]={cont,zone}
				return cont,zone
			end
		end
	end
	return 0
end
--]]