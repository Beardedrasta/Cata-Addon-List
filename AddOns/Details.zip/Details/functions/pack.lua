

local _detalhes = 		_G._detalhes
