
SkadaCharDB = {
	["sets"] = {
		{
			["starttime"] = 1689857870,
			["mana"] = 3598,
			["enemies"] = {
				{
					["damagespells"] = {
						[21390] = {
							["school"] = 64,
							["total"] = 977,
							["targets"] = {
								["Beardedrasta"] = {
									["total"] = 652,
									["amount"] = 523,
								},
								["Myrony"] = {
									["total"] = 325,
									["amount"] = 325,
								},
							},
							["amount"] = 848,
						},
						[6603] = {
							["school"] = 1,
							["total"] = 1451,
							["targets"] = {
								["Myrony"] = {
									["total"] = 1451,
									["amount"] = 1451,
								},
							},
							["amount"] = 1451,
						},
						[16100] = {
							["school"] = 1,
							["total"] = 193,
							["targets"] = {
								["Myrony"] = {
									["total"] = 193,
									["amount"] = 193,
								},
							},
							["amount"] = 193,
						},
					},
					["damagetaken"] = 30535,
					["id"] = "0xF1302FCC00000067",
					["class"] = "BOSS",
					["damagetakenspells"] = {
						[16827] = {
							["school"] = 1,
							["total"] = 866,
							["sources"] = {
								["Macius"] = {
									["total"] = 866,
									["amount"] = 866,
								},
							},
							["amount"] = 866,
						},
						[1120] = {
							["school"] = 32,
							["total"] = 264,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 264,
									["amount"] = 264,
								},
							},
							["amount"] = 264,
						},
						[1978] = {
							["school"] = 8,
							["total"] = 787,
							["sources"] = {
								["Macius"] = {
									["total"] = 787,
									["amount"] = 787,
								},
							},
							["amount"] = 787,
						},
						[88625] = {
							["school"] = 2,
							["total"] = 183,
							["sources"] = {
								["Nianhong"] = {
									["total"] = 183,
									["amount"] = 183,
								},
							},
							["amount"] = 183,
						},
						[85256] = {
							["school"] = 1,
							["total"] = 1866,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 1866,
									["amount"] = 1866,
								},
							},
							["amount"] = 1866,
						},
						[25742] = {
							["school"] = 2,
							["total"] = 649,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 351,
									["amount"] = 351,
								},
								["Myrony"] = {
									["total"] = 298,
									["amount"] = 298,
								},
							},
							["amount"] = 649,
						},
						[35395] = {
							["school"] = 1,
							["total"] = 3589,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 2413,
									["amount"] = 2413,
								},
								["Myrony"] = {
									["total"] = 1176,
									["amount"] = 1176,
								},
							},
							["amount"] = 3589,
						},
						[589] = {
							["school"] = 32,
							["total"] = 315,
							["sources"] = {
								["Nianhong"] = {
									["total"] = 315,
									["amount"] = 315,
								},
							},
							["amount"] = 315,
						},
						[56641] = {
							["sources"] = {
								["Macius"] = {
									["total"] = 2071,
									["overkill"] = 35,
									["amount"] = 2071,
								},
							},
							["amount"] = 2071,
							["school"] = 1,
							["total"] = 2071,
							["overkill"] = 35,
						},
						[53595] = {
							["school"] = 1,
							["total"] = 69,
							["sources"] = {
								["Myrony"] = {
									["total"] = 69,
									["amount"] = 69,
								},
							},
							["amount"] = 69,
						},
						[6603] = {
							["school"] = 1,
							["total"] = 6231,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 937,
									["amount"] = 937,
								},
								["Macius"] = {
									["total"] = 1034,
									["amount"] = 1034,
								},
								["Fragrance"] = {
									["total"] = 2522,
									["amount"] = 2522,
								},
								["Myrony"] = {
									["total"] = 1738,
									["amount"] = 1738,
								},
							},
							["amount"] = 6231,
						},
						[879] = {
							["school"] = 2,
							["total"] = 2086,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 2086,
									["amount"] = 2086,
								},
							},
							["amount"] = 2086,
						},
						[3044] = {
							["school"] = 64,
							["total"] = 55,
							["sources"] = {
								["Macius"] = {
									["total"] = 55,
									["amount"] = 55,
								},
							},
							["amount"] = 55,
						},
						[2643] = {
							["school"] = 1,
							["total"] = 258,
							["sources"] = {
								["Macius"] = {
									["total"] = 258,
									["amount"] = 258,
								},
							},
							["amount"] = 258,
						},
						[980] = {
							["school"] = 32,
							["total"] = 383,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 383,
									["amount"] = 383,
								},
							},
							["amount"] = 383,
						},
						[686] = {
							["school"] = 32,
							["total"] = 643,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 643,
									["amount"] = 643,
								},
							},
							["amount"] = 643,
						},
						[88263] = {
							["school"] = 2,
							["total"] = 580,
							["sources"] = {
								["Myrony"] = {
									["total"] = 580,
									["amount"] = 580,
								},
							},
							["amount"] = 580,
						},
						[172] = {
							["school"] = 32,
							["total"] = 571,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 571,
									["amount"] = 571,
								},
							},
							["amount"] = 571,
						},
						[8092] = {
							["school"] = 32,
							["total"] = 324,
							["sources"] = {
								["Nianhong"] = {
									["total"] = 324,
									["amount"] = 324,
								},
							},
							["amount"] = 324,
						},
						[96172] = {
							["school"] = 2,
							["total"] = 8,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 8,
									["amount"] = 8,
								},
							},
							["amount"] = 8,
						},
						[2812] = {
							["school"] = 2,
							["total"] = 297,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 142,
									["amount"] = 142,
								},
								["Myrony"] = {
									["total"] = 155,
									["amount"] = 155,
								},
							},
							["amount"] = 297,
						},
						[81297] = {
							["school"] = 2,
							["total"] = 264,
							["sources"] = {
								["Myrony"] = {
									["total"] = 264,
									["amount"] = 264,
								},
							},
							["amount"] = 264,
						},
						[31935] = {
							["school"] = 2,
							["total"] = 338,
							["sources"] = {
								["Myrony"] = {
									["total"] = 338,
									["amount"] = 338,
								},
							},
							["amount"] = 338,
						},
						[14914] = {
							["school"] = 2,
							["total"] = 349,
							["sources"] = {
								["Nianhong"] = {
									["total"] = 349,
									["amount"] = 349,
								},
							},
							["amount"] = 349,
						},
						[20187] = {
							["school"] = 2,
							["total"] = 1211,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 384,
									["amount"] = 384,
								},
								["Myrony"] = {
									["total"] = 827,
									["amount"] = 827,
								},
							},
							["amount"] = 1211,
						},
						[53301] = {
							["school"] = 4,
							["total"] = 2181,
							["sources"] = {
								["Macius"] = {
									["total"] = 2181,
									["amount"] = 2181,
								},
							},
							["amount"] = 2181,
						},
						[30108] = {
							["school"] = 32,
							["total"] = 588,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 588,
									["amount"] = 588,
								},
							},
							["amount"] = 588,
						},
						[7294] = {
							["school"] = 2,
							["total"] = 104,
							["sources"] = {
								["Myrony"] = {
									["total"] = 104,
									["amount"] = 104,
								},
							},
							["amount"] = 104,
						},
						[83077] = {
							["school"] = 8,
							["total"] = 215,
							["sources"] = {
								["Macius"] = {
									["total"] = 215,
									["amount"] = 215,
								},
							},
							["amount"] = 215,
						},
						[54049] = {
							["school"] = 32,
							["total"] = 913,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 913,
									["amount"] = 913,
								},
							},
							["amount"] = 913,
						},
						[75] = {
							["school"] = 1,
							["total"] = 2277,
							["sources"] = {
								["Macius"] = {
									["total"] = 2277,
									["amount"] = 2277,
								},
							},
							["amount"] = 2277,
						},
					},
					["totaldamage"] = 2621,
					["name"] = "Lord Vyletongue",
					["totaldamagetaken"] = 30535,
					["flag"] = 2632,
					["damage"] = 2492,
				}, -- [1]
				{
					["damagespells"] = {
						[6603] = {
							["school"] = 1,
							["total"] = 801,
							["targets"] = {
								["Fragrance"] = {
									["total"] = 184,
									["amount"] = 184,
								},
								["Myrony"] = {
									["total"] = 617,
									["amount"] = 617,
								},
							},
							["amount"] = 801,
						},
						[9080] = {
							["school"] = 1,
							["total"] = 73,
							["targets"] = {
								["Fragrance"] = {
									["total"] = 42,
									["amount"] = 42,
								},
								["Myrony"] = {
									["total"] = 31,
									["amount"] = 31,
								},
							},
							["amount"] = 73,
						},
					},
					["damagetaken"] = 9269,
					["id"] = "0xF1302E1000000068",
					["class"] = "MONSTER",
					["damagetakenspells"] = {
						[16827] = {
							["school"] = 1,
							["total"] = 173,
							["sources"] = {
								["Macius"] = {
									["total"] = 173,
									["amount"] = 173,
								},
							},
							["amount"] = 173,
						},
						[25742] = {
							["school"] = 2,
							["total"] = 247,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 162,
									["amount"] = 162,
								},
								["Myrony"] = {
									["total"] = 85,
									["amount"] = 85,
								},
							},
							["amount"] = 247,
						},
						[35395] = {
							["school"] = 1,
							["total"] = 1941,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 1593,
									["amount"] = 1593,
								},
								["Myrony"] = {
									["total"] = 348,
									["amount"] = 348,
								},
							},
							["amount"] = 1941,
						},
						[53595] = {
							["school"] = 1,
							["total"] = 39,
							["sources"] = {
								["Myrony"] = {
									["total"] = 39,
									["amount"] = 39,
								},
							},
							["amount"] = 39,
						},
						[6603] = {
							["school"] = 1,
							["total"] = 1324,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 187,
									["amount"] = 187,
								},
								["Macius"] = {
									["total"] = 114,
									["amount"] = 114,
								},
								["Fragrance"] = {
									["total"] = 786,
									["amount"] = 786,
								},
								["Myrony"] = {
									["total"] = 237,
									["amount"] = 237,
								},
							},
							["amount"] = 1324,
						},
						[2643] = {
							["school"] = 1,
							["total"] = 368,
							["sources"] = {
								["Macius"] = {
									["total"] = 368,
									["amount"] = 368,
								},
							},
							["amount"] = 368,
						},
						[980] = {
							["school"] = 32,
							["total"] = 297,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 297,
									["amount"] = 297,
								},
							},
							["amount"] = 297,
						},
						[85256] = {
							["school"] = 1,
							["total"] = 623,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 623,
									["amount"] = 623,
								},
							},
							["amount"] = 623,
						},
						[96172] = {
							["school"] = 2,
							["total"] = 5,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 5,
									["amount"] = 5,
								},
							},
							["amount"] = 5,
						},
						[2812] = {
							["sources"] = {
								["Fragrance"] = {
									["total"] = 497,
									["overkill"] = 127,
									["amount"] = 497,
								},
								["Myrony"] = {
									["total"] = 155,
									["amount"] = 155,
								},
							},
							["amount"] = 652,
							["school"] = 2,
							["total"] = 652,
							["overkill"] = 127,
						},
						[88263] = {
							["school"] = 2,
							["total"] = 304,
							["sources"] = {
								["Myrony"] = {
									["total"] = 304,
									["amount"] = 304,
								},
							},
							["amount"] = 304,
						},
						[31935] = {
							["school"] = 2,
							["total"] = 358,
							["sources"] = {
								["Myrony"] = {
									["total"] = 358,
									["amount"] = 358,
								},
							},
							["amount"] = 358,
						},
						[81297] = {
							["school"] = 2,
							["total"] = 324,
							["sources"] = {
								["Myrony"] = {
									["total"] = 324,
									["amount"] = 324,
								},
							},
							["amount"] = 324,
						},
						[20187] = {
							["school"] = 2,
							["total"] = 1080,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 256,
									["amount"] = 256,
								},
								["Myrony"] = {
									["total"] = 824,
									["amount"] = 824,
								},
							},
							["amount"] = 1080,
						},
						[172] = {
							["school"] = 32,
							["total"] = 483,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 483,
									["amount"] = 483,
								},
							},
							["amount"] = 483,
						},
						[30108] = {
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 489,
									["overkill"] = 50,
									["amount"] = 489,
								},
							},
							["amount"] = 489,
							["school"] = 32,
							["total"] = 489,
							["overkill"] = 50,
						},
						[56641] = {
							["school"] = 1,
							["total"] = 79,
							["sources"] = {
								["Macius"] = {
									["total"] = 79,
									["amount"] = 79,
								},
							},
							["amount"] = 79,
						},
						[7294] = {
							["school"] = 2,
							["total"] = 65,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 13,
									["amount"] = 13,
								},
								["Myrony"] = {
									["total"] = 52,
									["amount"] = 52,
								},
							},
							["amount"] = 65,
						},
						[54049] = {
							["school"] = 32,
							["total"] = 278,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 278,
									["amount"] = 278,
								},
							},
							["amount"] = 278,
						},
						[75] = {
							["school"] = 1,
							["total"] = 140,
							["sources"] = {
								["Macius"] = {
									["total"] = 140,
									["amount"] = 140,
								},
							},
							["amount"] = 140,
						},
					},
					["totaldamage"] = 874,
					["name"] = "Putridus Shadowstalker",
					["totaldamagetaken"] = 9269,
					["flag"] = 2632,
					["damage"] = 874,
				}, -- [2]
			},
			["dispel"] = 2,
			["totaldamage"] = 39804,
			["time"] = 55,
			["ccdone"] = 7,
			["totaldamagetaken"] = 3495,
			["etotaldamage"] = 3495,
			["damage"] = 39804,
			["players"] = {
				{
					["ccdonespells"] = {
						[2812] = {
							["count"] = 3,
							["targets"] = {
								["Putridus Shadowstalker"] = 2,
								["Lord Vyletongue"] = 1,
							},
						},
					},
					["last"] = 11055.959,
					["flag"] = 1298,
					["class"] = "PALADIN",
					["auras"] = {
						[2812] = {
							["type"] = "DEBUFF",
							["count"] = 3,
							["school"] = 2,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["uptime"] = 3,
									["count"] = 2,
								},
								["Lord Vyletongue"] = {
									["uptime"] = 1,
									["count"] = 1,
								},
							},
							["uptime"] = 4,
						},
						[59578] = {
							["type"] = "BUFF",
							["count"] = 2,
							["school"] = 1,
							["uptime"] = 3,
						},
						[94686] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 1,
							["uptime"] = 15,
						},
						[89906] = {
							["type"] = "BUFF",
							["count"] = 2,
							["school"] = 2,
							["refresh"] = 3,
							["uptime"] = 39,
						},
						[139] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 2,
							["uptime"] = 12,
						},
						[93435] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 1,
							["refresh"] = 1,
							["uptime"] = 55,
						},
					},
					["time"] = 52.41,
					["totaldamagetaken"] = 226,
					["damage"] = 13707,
					["damagespells"] = {
						["Exorcism"] = {
							["total"] = 2086,
							["criticalamount"] = 2086,
							["id"] = 879,
							["targets"] = {
								["Lord Vyletongue"] = {
									["total"] = 2086,
									["amount"] = 2086,
								},
							},
							["casts"] = 2,
							["critical"] = 2,
							["amount"] = 2086,
							["school"] = 2,
							["criticalmin"] = 1032,
							["criticalmax"] = 1054,
							["count"] = 2,
						},
						["Melee"] = {
							["DODGE"] = 2,
							["total"] = 3308,
							["hitmin"] = 201,
							["criticalamount"] = 2026,
							["id"] = 6603,
							["amount"] = 3308,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 786,
									["amount"] = 786,
								},
								["Lord Vyletongue"] = {
									["total"] = 2522,
									["amount"] = 2522,
								},
							},
							["criticalmin"] = 368,
							["critical"] = 5,
							["criticalmax"] = 446,
							["count"] = 14,
							["hit"] = 6,
							["school"] = 1,
							["hitmax"] = 224,
							["MISS"] = 1,
							["hitamount"] = 1282,
						},
						["Retribution Aura"] = {
							["total"] = 13,
							["hitmin"] = 13,
							["id"] = 7294,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 13,
									["amount"] = 13,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 2,
							["hitmax"] = 13,
							["amount"] = 13,
							["hitamount"] = 13,
						},
						["Holy Wrath"] = {
							["criticalmin"] = 213,
							["total"] = 639,
							["hitmin"] = 142,
							["criticalamount"] = 213,
							["id"] = 2812,
							["criticalmax"] = 213,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 497,
									["overkill"] = 127,
									["amount"] = 497,
								},
								["Lord Vyletongue"] = {
									["total"] = 142,
									["amount"] = 142,
								},
							},
							["overkill"] = 127,
							["critical"] = 1,
							["casts"] = 2,
							["count"] = 4,
							["hit"] = 3,
							["school"] = 2,
							["hitmax"] = 142,
							["amount"] = 639,
							["hitamount"] = 426,
						},
						["Templar's Verdict"] = {
							["DODGE"] = 2,
							["total"] = 2489,
							["hitmin"] = 591,
							["id"] = 85256,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 623,
									["amount"] = 623,
								},
								["Lord Vyletongue"] = {
									["total"] = 1866,
									["amount"] = 1866,
								},
							},
							["casts"] = 6,
							["count"] = 6,
							["hit"] = 4,
							["school"] = 1,
							["hitmax"] = 657,
							["amount"] = 2489,
							["hitamount"] = 2489,
						},
						["Seal of Righteousness"] = {
							["total"] = 513,
							["hitmin"] = 27,
							["criticalamount"] = 54,
							["id"] = 25742,
							["criticalmin"] = 54,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 162,
									["amount"] = 162,
								},
								["Lord Vyletongue"] = {
									["total"] = 351,
									["amount"] = 351,
								},
							},
							["criticalmax"] = 54,
							["critical"] = 1,
							["casts"] = 1,
							["count"] = 18,
							["hit"] = 17,
							["school"] = 2,
							["hitmax"] = 27,
							["amount"] = 513,
							["hitamount"] = 459,
						},
						["Hand of Light"] = {
							["total"] = 13,
							["hitmin"] = 1,
							["id"] = 96172,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 5,
									["amount"] = 5,
								},
								["Lord Vyletongue"] = {
									["total"] = 8,
									["amount"] = 8,
								},
							},
							["casts"] = 1,
							["count"] = 13,
							["hit"] = 13,
							["school"] = 2,
							["hitmax"] = 1,
							["amount"] = 13,
							["hitamount"] = 13,
						},
						["Crusader Strike"] = {
							["total"] = 4006,
							["hitmin"] = 306,
							["criticalamount"] = 2090,
							["id"] = 35395,
							["criticalmin"] = 630,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 1593,
									["amount"] = 1593,
								},
								["Lord Vyletongue"] = {
									["total"] = 2413,
									["amount"] = 2413,
								},
							},
							["criticalmax"] = 738,
							["critical"] = 3,
							["casts"] = 9,
							["count"] = 9,
							["hit"] = 6,
							["school"] = 1,
							["hitmax"] = 341,
							["amount"] = 4006,
							["hitamount"] = 1916,
						},
						["Judgement of Righteousness"] = {
							["total"] = 640,
							["hitmin"] = 128,
							["id"] = 20187,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 256,
									["amount"] = 256,
								},
								["Lord Vyletongue"] = {
									["total"] = 384,
									["amount"] = 384,
								},
							},
							["casts"] = 5,
							["count"] = 5,
							["hit"] = 5,
							["school"] = 2,
							["hitmax"] = 128,
							["amount"] = 640,
							["hitamount"] = 640,
						},
					},
					["damagetaken"] = 226,
					["id"] = "0x0000000000048007",
					["damagetakenspells"] = {
						["Melee"] = {
							["total"] = 184,
							["hitmin"] = 184,
							["id"] = 6603,
							["amount"] = 184,
							["sources"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 184,
									["amount"] = 184,
								},
							},
							["count"] = 2,
							["hit"] = 1,
							["school"] = 1,
							["hitmax"] = 184,
							["MISS"] = 1,
							["hitamount"] = 184,
						},
						["Hamstring"] = {
							["total"] = 42,
							["hitmin"] = 42,
							["id"] = 9080,
							["sources"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 42,
									["amount"] = 42,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 1,
							["hitmax"] = 42,
							["amount"] = 42,
							["hitamount"] = 42,
						},
					},
					["overkill"] = 127,
					["manaspells"] = {
						[89906] = 984,
					},
					["ccdone"] = 3,
					["totaldamage"] = 13707,
					["name"] = "Fragrance",
					["mana"] = 984,
					["role"] = "DAMAGER",
				}, -- [1]
				{
					["damagespells"] = {
						["Explosive Shot (DoT)"] = {
							["total"] = 2181,
							["hitmin"] = 180,
							["id"] = 53301,
							["targets"] = {
								["Lord Vyletongue"] = {
									["total"] = 2181,
									["amount"] = 2181,
								},
							},
							["casts"] = 4,
							["count"] = 12,
							["hit"] = 12,
							["school"] = 4,
							["hitmax"] = 184,
							["amount"] = 2181,
							["hitamount"] = 2181,
						},
						["Serpent Sting (DoT)"] = {
							["total"] = 787,
							["hitmin"] = 75,
							["criticalamount"] = 112,
							["id"] = 1978,
							["criticalmin"] = 112,
							["targets"] = {
								["Lord Vyletongue"] = {
									["total"] = 787,
									["amount"] = 787,
								},
							},
							["criticalmax"] = 112,
							["critical"] = 1,
							["casts"] = 2,
							["count"] = 10,
							["hit"] = 9,
							["school"] = 8,
							["hitmax"] = 75,
							["amount"] = 787,
							["hitamount"] = 675,
						},
						["Claw (Cat)"] = {
							["DODGE"] = 2,
							["hitmin"] = 86,
							["criticalmin"] = 172,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 173,
									["amount"] = 173,
								},
								["Lord Vyletongue"] = {
									["total"] = 866,
									["amount"] = 866,
								},
							},
							["amount"] = 1039,
							["MISS"] = 1,
							["total"] = 1039,
							["criticalamount"] = 516,
							["id"] = 16827,
							["criticalmax"] = 172,
							["casts"] = 12,
							["hitmax"] = 88,
							["hit"] = 6,
							["school"] = 1,
							["critical"] = 3,
							["count"] = 12,
							["hitamount"] = 523,
						},
						["Arcane Shot"] = {
							["total"] = 55,
							["hitmin"] = 55,
							["id"] = 3044,
							["targets"] = {
								["Lord Vyletongue"] = {
									["total"] = 55,
									["amount"] = 55,
								},
							},
							["hitmax"] = 55,
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 64,
							["resisted"] = 128,
							["amount"] = 55,
							["hitamount"] = 55,
						},
						["Steady Shot"] = {
							["hitmin"] = 79,
							["criticalmin"] = 224,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 79,
									["amount"] = 79,
								},
								["Lord Vyletongue"] = {
									["total"] = 2071,
									["overkill"] = 35,
									["amount"] = 2071,
								},
							},
							["amount"] = 2150,
							["total"] = 2150,
							["criticalamount"] = 224,
							["id"] = 56641,
							["criticalmax"] = 224,
							["overkill"] = 35,
							["critical"] = 1,
							["casts"] = 18,
							["hitmax"] = 140,
							["hit"] = 16,
							["school"] = 1,
							["blocked"] = 33,
							["count"] = 17,
							["hitamount"] = 1926,
						},
						["Improved Serpent Sting"] = {
							["total"] = 215,
							["hitmin"] = 103,
							["id"] = 83077,
							["targets"] = {
								["Lord Vyletongue"] = {
									["total"] = 215,
									["amount"] = 215,
								},
							},
							["casts"] = 2,
							["count"] = 2,
							["hit"] = 2,
							["school"] = 8,
							["hitmax"] = 112,
							["amount"] = 215,
							["hitamount"] = 215,
						},
						["Auto Shot"] = {
							["total"] = 2417,
							["hitmin"] = 119,
							["id"] = 75,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 140,
									["amount"] = 140,
								},
								["Lord Vyletongue"] = {
									["total"] = 2277,
									["amount"] = 2277,
								},
							},
							["amount"] = 2417,
							["casts"] = 1,
							["count"] = 18,
							["hit"] = 17,
							["school"] = 1,
							["hitmax"] = 163,
							["MISS"] = 1,
							["hitamount"] = 2417,
						},
						["Melee (Cat)"] = {
							["DODGE"] = 1,
							["hitmin"] = 37,
							["criticalmin"] = 120,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 114,
									["amount"] = 114,
								},
								["Lord Vyletongue"] = {
									["total"] = 1034,
									["amount"] = 1034,
								},
							},
							["glancing"] = 3,
							["amount"] = 1148,
							["MISS"] = 1,
							["total"] = 1148,
							["criticalamount"] = 250,
							["id"] = 6603,
							["blocked"] = 32,
							["criticalmax"] = 130,
							["hitmax"] = 63,
							["hit"] = 14,
							["school"] = 1,
							["critical"] = 2,
							["count"] = 21,
							["hitamount"] = 759,
						},
						["Multi-Shot"] = {
							["total"] = 626,
							["hitmin"] = 105,
							["id"] = 2643,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 368,
									["amount"] = 368,
								},
								["Lord Vyletongue"] = {
									["total"] = 258,
									["amount"] = 258,
								},
							},
							["amount"] = 626,
							["casts"] = 3,
							["count"] = 6,
							["hit"] = 5,
							["school"] = 1,
							["hitmax"] = 136,
							["MISS"] = 1,
							["hitamount"] = 626,
						},
					},
					["last"] = 11056.542,
					["time"] = 52.12999999999999,
					["overkill"] = 35,
					["flag"] = 4370,
					["class"] = "HUNTER",
					["id"] = "0x00000000000477A3",
					["auras"] = {
						[1978] = {
							["type"] = "DEBUFF",
							["count"] = 2,
							["school"] = 8,
							["targets"] = {
								["Lord Vyletongue"] = {
									["uptime"] = 30,
									["count"] = 2,
								},
							},
							["uptime"] = 30,
						},
						[1130] = {
							["type"] = "DEBUFF",
							["count"] = 1,
							["school"] = 64,
							["targets"] = {
								["Lord Vyletongue"] = {
									["uptime"] = 34,
									["count"] = 1,
								},
							},
							["uptime"] = 34,
						},
						[53301] = {
							["type"] = "DEBUFF",
							["count"] = 4,
							["school"] = 4,
							["targets"] = {
								["Lord Vyletongue"] = {
									["uptime"] = 8,
									["count"] = 4,
								},
							},
							["uptime"] = 8,
						},
					},
					["energyspells"] = {
						[91954] = 153,
						[34720] = 20,
					},
					["role"] = "DAMAGER",
					["name"] = "Macius",
					["totaldamage"] = 10618,
					["energy"] = 173,
					["damage"] = 10618,
				}, -- [2]
				{
					["ccdonespells"] = {
						[2812] = {
							["count"] = 2,
							["targets"] = {
								["Putridus Shadowstalker"] = 1,
								["Lord Vyletongue"] = 1,
							},
						},
						[31935] = {
							["count"] = 2,
							["targets"] = {
								["Putridus Shadowstalker"] = 1,
								["Lord Vyletongue"] = 1,
							},
						},
					},
					["last"] = 11056.062,
					["flag"] = 1298,
					["class"] = "PALADIN",
					["auras"] = {
						[2812] = {
							["type"] = "DEBUFF",
							["count"] = 2,
							["school"] = 2,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["uptime"] = 2,
									["count"] = 1,
								},
								["Lord Vyletongue"] = {
									["uptime"] = 3,
									["count"] = 1,
								},
							},
							["uptime"] = 3,
						},
						[26573] = {
							["type"] = "DEBUFF",
							["count"] = 4,
							["school"] = 2,
							["targets"] = {
								["Myrony"] = {
									["uptime"] = 10,
									["count"] = 1,
								},
								["Putridus Shadowstalker"] = {
									["uptime"] = 40,
									["count"] = 2,
								},
								["Lord Vyletongue"] = {
									["uptime"] = 10,
									["count"] = 1,
								},
							},
							["uptime"] = 40,
						},
						[31930] = {
							["type"] = "BUFF",
							["count"] = 3,
							["school"] = 2,
							["refresh"] = 2,
							["uptime"] = 39,
						},
						[31935] = {
							["type"] = "DEBUFF",
							["count"] = 2,
							["school"] = 2,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["uptime"] = 3,
									["count"] = 1,
								},
								["Lord Vyletongue"] = {
									["uptime"] = 3,
									["count"] = 1,
								},
							},
							["uptime"] = 6,
						},
						[139] = {
							["type"] = "BUFF",
							["count"] = 3,
							["school"] = 2,
							["uptime"] = 35,
						},
						[68055] = {
							["type"] = "DEBUFF",
							["count"] = 3,
							["school"] = 2,
							["refresh"] = 2,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["uptime"] = 23,
									["count"] = 2,
								},
								["Lord Vyletongue"] = {
									["count"] = 1,
									["refresh"] = 2,
									["uptime"] = 25,
								},
							},
							["uptime"] = 47,
						},
						[31790] = {
							["type"] = "DEBUFF",
							["count"] = 1,
							["school"] = 1,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["uptime"] = 3,
									["count"] = 1,
								},
							},
							["uptime"] = 3,
						},
					},
					["role"] = "TANK",
					["time"] = 50.90999999999998,
					["totaldamagetaken"] = 2617,
					["damage"] = 8275,
					["damagespells"] = {
						["Melee"] = {
							["DODGE"] = 3,
							["hitmin"] = 72,
							["criticalmin"] = 232,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 237,
									["amount"] = 237,
								},
								["Lord Vyletongue"] = {
									["total"] = 1738,
									["amount"] = 1738,
								},
							},
							["amount"] = 1975,
							["MISS"] = 3,
							["total"] = 1975,
							["criticalamount"] = 490,
							["id"] = 6603,
							["blocked"] = 30,
							["criticalmax"] = 258,
							["hitmax"] = 133,
							["hit"] = 13,
							["school"] = 1,
							["critical"] = 2,
							["count"] = 21,
							["hitamount"] = 1485,
						},
						["Hammer of the Righteous (Physical)"] = {
							["total"] = 108,
							["hitmin"] = 32,
							["id"] = 53595,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 39,
									["amount"] = 39,
								},
								["Lord Vyletongue"] = {
									["total"] = 69,
									["amount"] = 69,
								},
							},
							["amount"] = 108,
							["casts"] = 1,
							["count"] = 4,
							["hit"] = 3,
							["school"] = 1,
							["hitmax"] = 39,
							["MISS"] = 1,
							["hitamount"] = 108,
						},
						["Retribution Aura"] = {
							["total"] = 156,
							["hitmin"] = 13,
							["id"] = 7294,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 52,
									["amount"] = 52,
								},
								["Lord Vyletongue"] = {
									["total"] = 104,
									["amount"] = 104,
								},
							},
							["casts"] = 1,
							["count"] = 12,
							["hit"] = 12,
							["school"] = 2,
							["hitmax"] = 13,
							["amount"] = 156,
							["hitamount"] = 156,
						},
						["Avenger's Shield"] = {
							["total"] = 696,
							["hitmin"] = 338,
							["id"] = 31935,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 358,
									["amount"] = 358,
								},
								["Lord Vyletongue"] = {
									["total"] = 338,
									["amount"] = 338,
								},
							},
							["casts"] = 2,
							["count"] = 2,
							["hit"] = 2,
							["school"] = 2,
							["hitmax"] = 358,
							["amount"] = 696,
							["hitamount"] = 696,
						},
						["Hammer of the Righteous"] = {
							["total"] = 884,
							["hitmin"] = 151,
							["criticalamount"] = 255,
							["id"] = 88263,
							["criticalmin"] = 255,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 304,
									["amount"] = 304,
								},
								["Lord Vyletongue"] = {
									["total"] = 580,
									["amount"] = 580,
								},
							},
							["criticalmax"] = 255,
							["critical"] = 1,
							["casts"] = 6,
							["count"] = 5,
							["hit"] = 4,
							["school"] = 2,
							["hitmax"] = 168,
							["amount"] = 884,
							["hitamount"] = 629,
						},
						["Holy Wrath"] = {
							["total"] = 310,
							["hitmin"] = 155,
							["id"] = 2812,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 155,
									["amount"] = 155,
								},
								["Lord Vyletongue"] = {
									["total"] = 155,
									["amount"] = 155,
								},
							},
							["casts"] = 1,
							["count"] = 2,
							["hit"] = 2,
							["school"] = 2,
							["hitmax"] = 155,
							["amount"] = 310,
							["hitamount"] = 310,
						},
						["Consecration"] = {
							["total"] = 588,
							["hitmin"] = 28,
							["id"] = 81297,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 324,
									["amount"] = 324,
								},
								["Lord Vyletongue"] = {
									["total"] = 264,
									["amount"] = 264,
								},
							},
							["casts"] = 1,
							["count"] = 20,
							["hit"] = 20,
							["school"] = 2,
							["hitmax"] = 30,
							["amount"] = 588,
							["hitamount"] = 588,
						},
						["Crusader Strike"] = {
							["total"] = 1524,
							["hitmin"] = 282,
							["id"] = 35395,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 348,
									["amount"] = 348,
								},
								["Lord Vyletongue"] = {
									["total"] = 1176,
									["amount"] = 1176,
								},
							},
							["casts"] = 5,
							["count"] = 5,
							["hit"] = 5,
							["school"] = 1,
							["hitmax"] = 348,
							["amount"] = 1524,
							["hitamount"] = 1524,
						},
						["Seal of Righteousness"] = {
							["total"] = 383,
							["hitmin"] = 19,
							["id"] = 25742,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 85,
									["amount"] = 85,
								},
								["Lord Vyletongue"] = {
									["total"] = 298,
									["amount"] = 298,
								},
							},
							["casts"] = 1,
							["count"] = 18,
							["hit"] = 18,
							["school"] = 2,
							["hitmax"] = 22,
							["amount"] = 383,
							["hitamount"] = 383,
						},
						["Judgement of Righteousness"] = {
							["total"] = 1651,
							["hitmin"] = 258,
							["criticalamount"] = 566,
							["id"] = 20187,
							["criticalmin"] = 566,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 824,
									["amount"] = 824,
								},
								["Lord Vyletongue"] = {
									["total"] = 827,
									["amount"] = 827,
								},
							},
							["criticalmax"] = 566,
							["critical"] = 1,
							["casts"] = 5,
							["count"] = 5,
							["hit"] = 4,
							["school"] = 2,
							["hitmax"] = 279,
							["amount"] = 1651,
							["hitamount"] = 1085,
						},
					},
					["damagetaken"] = 2617,
					["id"] = "0x00000000000447DB",
					["healspells"] = {
						[85673] = {
							["overheal"] = 116,
							["count"] = 1,
							["amount"] = 724,
							["school"] = 2,
							["max"] = 724,
							["targets"] = {
								["Myrony"] = {
									["overheal"] = 116,
									["amount"] = 724,
								},
							},
							["min"] = 724,
						},
					},
					["damagetakenspells"] = {
						["Shoot"] = {
							["total"] = 193,
							["hitmin"] = 49,
							["id"] = 16100,
							["amount"] = 193,
							["blocked"] = 20,
							["sources"] = {
								["Lord Vyletongue"] = {
									["total"] = 193,
									["amount"] = 193,
								},
							},
							["casts"] = 1,
							["count"] = 4,
							["hit"] = 3,
							["school"] = 1,
							["hitmax"] = 76,
							["MISS"] = 1,
							["hitamount"] = 193,
						},
						["Melee"] = {
							["DODGE"] = 2,
							["total"] = 2068,
							["hitmin"] = 144,
							["id"] = 6603,
							["amount"] = 2068,
							["PARRY"] = 10,
							["sources"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 617,
									["amount"] = 617,
								},
								["Lord Vyletongue"] = {
									["total"] = 1451,
									["amount"] = 1451,
								},
							},
							["count"] = 26,
							["hit"] = 12,
							["school"] = 1,
							["hitmax"] = 204,
							["MISS"] = 2,
							["hitamount"] = 2068,
						},
						["Multi-Shot"] = {
							["total"] = 325,
							["hitmin"] = 325,
							["id"] = 21390,
							["sources"] = {
								["Lord Vyletongue"] = {
									["total"] = 325,
									["amount"] = 325,
								},
							},
							["hitmax"] = 325,
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 64,
							["resisted"] = 81,
							["amount"] = 325,
							["hitamount"] = 325,
						},
						["Hamstring"] = {
							["DODGE"] = 1,
							["total"] = 31,
							["hitmin"] = 31,
							["id"] = 9080,
							["hitmax"] = 31,
							["casts"] = 2,
							["count"] = 2,
							["amount"] = 31,
							["school"] = 1,
							["sources"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 31,
									["amount"] = 31,
								},
							},
							["hit"] = 1,
							["hitamount"] = 31,
						},
					},
					["overheal"] = 116,
					["heal"] = 724,
					["name"] = "Myrony",
					["ccdone"] = 4,
					["manaspells"] = {
						[31930] = 1170,
						[84627] = 598,
					},
					["mana"] = 1768,
					["totaldamage"] = 8275,
				}, -- [3]
				{
					["last"] = 11056.201,
					["flag"] = 1297,
					["class"] = "WARLOCK",
					["auras"] = {
						[172] = {
							["type"] = "DEBUFF",
							["count"] = 4,
							["school"] = 32,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["uptime"] = 22,
									["count"] = 2,
								},
								["Lord Vyletongue"] = {
									["uptime"] = 35,
									["count"] = 2,
								},
							},
							["uptime"] = 48,
						},
						[64368] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 32,
							["refresh"] = 1,
							["uptime"] = 15,
						},
						[1120] = {
							["type"] = "DEBUFF",
							["count"] = 1,
							["school"] = 32,
							["targets"] = {
								["Lord Vyletongue"] = {
									["uptime"] = 6,
									["count"] = 1,
								},
							},
							["uptime"] = 6,
						},
						[139] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 2,
							["uptime"] = 12,
						},
						[980] = {
							["type"] = "DEBUFF",
							["count"] = 4,
							["school"] = 32,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["uptime"] = 23,
									["count"] = 2,
								},
								["Lord Vyletongue"] = {
									["uptime"] = 32,
									["count"] = 2,
								},
							},
							["uptime"] = 44,
						},
						[30108] = {
							["type"] = "DEBUFF",
							["count"] = 5,
							["school"] = 32,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["uptime"] = 19,
									["count"] = 2,
								},
								["Lord Vyletongue"] = {
									["uptime"] = 37,
									["count"] = 3,
								},
							},
							["uptime"] = 46,
						},
					},
					["time"] = 49.27999999999999,
					["totaldamagetaken"] = 652,
					["damage"] = 6033,
					["overheal"] = 66,
					["manaspells"] = {
						[31818] = 846,
					},
					["damagetaken"] = 523,
					["id"] = "0x000000000004825C",
					["spec"] = 265,
					["healspells"] = {
						[63106] = {
							["overheal"] = 66,
							["max"] = 33,
							["count"] = 15,
							["amount"] = 429,
							["school"] = 32,
							["min"] = 33,
							["targets"] = {
								["Beardedrasta"] = {
									["overheal"] = 66,
									["amount"] = 429,
								},
							},
						},
					},
					["overkill"] = 50,
					["damagetakenspells"] = {
						["Multi-Shot"] = {
							["total"] = 652,
							["hitmin"] = 259,
							["id"] = 21390,
							["sources"] = {
								["Lord Vyletongue"] = {
									["total"] = 652,
									["amount"] = 523,
								},
							},
							["hitmax"] = 264,
							["casts"] = 1,
							["count"] = 2,
							["hit"] = 2,
							["school"] = 64,
							["resisted"] = 220,
							["amount"] = 523,
							["hitamount"] = 523,
						},
					},
					["heal"] = 429,
					["name"] = "Beardedrasta",
					["mana"] = 846,
					["damagespells"] = {
						["Bane of Agony (DoT)"] = {
							["total"] = 680,
							["hitmin"] = 12,
							["criticalamount"] = 140,
							["id"] = 980,
							["criticalmin"] = 23,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 297,
									["amount"] = 297,
								},
								["Lord Vyletongue"] = {
									["total"] = 383,
									["amount"] = 383,
								},
							},
							["criticalmax"] = 47,
							["critical"] = 4,
							["casts"] = 3,
							["count"] = 30,
							["hit"] = 26,
							["school"] = 32,
							["hitmax"] = 36,
							["amount"] = 680,
							["hitamount"] = 540,
						},
						["Melee (Haapdhon)"] = {
							["DODGE"] = 3,
							["hitmin"] = 59,
							["criticalmin"] = 136,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 187,
									["amount"] = 187,
								},
								["Lord Vyletongue"] = {
									["total"] = 937,
									["amount"] = 937,
								},
							},
							["glancing"] = 2,
							["amount"] = 1124,
							["MISS"] = 3,
							["total"] = 1124,
							["criticalamount"] = 274,
							["id"] = 6603,
							["criticalmax"] = 138,
							["hitmax"] = 69,
							["hit"] = 12,
							["school"] = 1,
							["critical"] = 2,
							["count"] = 22,
							["hitamount"] = 764,
						},
						["Drain Soul (DoT)"] = {
							["total"] = 264,
							["hitmin"] = 128,
							["id"] = 1120,
							["targets"] = {
								["Lord Vyletongue"] = {
									["total"] = 264,
									["amount"] = 264,
								},
							},
							["count"] = 2,
							["hit"] = 2,
							["school"] = 32,
							["hitmax"] = 136,
							["amount"] = 264,
							["hitamount"] = 264,
						},
						["Shadow Bite (Haapdhon)"] = {
							["criticalmin"] = 308,
							["total"] = 1191,
							["hitmin"] = 127,
							["criticalamount"] = 308,
							["id"] = 54049,
							["criticalmax"] = 308,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 278,
									["amount"] = 278,
								},
								["Lord Vyletongue"] = {
									["total"] = 913,
									["amount"] = 913,
								},
							},
							["critical"] = 1,
							["amount"] = 1191,
							["casts"] = 9,
							["count"] = 9,
							["hit"] = 6,
							["school"] = 32,
							["hitmax"] = 176,
							["MISS"] = 2,
							["hitamount"] = 883,
						},
						["Corruption (DoT)"] = {
							["total"] = 1054,
							["hitmin"] = 44,
							["criticalamount"] = 174,
							["id"] = 172,
							["criticalmin"] = 87,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 483,
									["amount"] = 483,
								},
								["Lord Vyletongue"] = {
									["total"] = 571,
									["amount"] = 571,
								},
							},
							["criticalmax"] = 87,
							["critical"] = 2,
							["casts"] = 4,
							["count"] = 22,
							["hit"] = 20,
							["school"] = 32,
							["hitmax"] = 44,
							["amount"] = 1054,
							["hitamount"] = 880,
						},
						["Unstable Affliction (DoT)"] = {
							["criticalmin"] = 97,
							["total"] = 1077,
							["hitmin"] = 49,
							["criticalamount"] = 97,
							["id"] = 30108,
							["criticalmax"] = 97,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 489,
									["overkill"] = 50,
									["amount"] = 489,
								},
								["Lord Vyletongue"] = {
									["total"] = 588,
									["amount"] = 588,
								},
							},
							["overkill"] = 50,
							["critical"] = 1,
							["casts"] = 5,
							["count"] = 21,
							["hit"] = 20,
							["school"] = 32,
							["hitmax"] = 49,
							["amount"] = 1077,
							["hitamount"] = 980,
						},
						["Shadow Bolt"] = {
							["total"] = 643,
							["hitmin"] = 159,
							["id"] = 686,
							["targets"] = {
								["Lord Vyletongue"] = {
									["total"] = 643,
									["amount"] = 643,
								},
							},
							["amount"] = 643,
							["casts"] = 5,
							["count"] = 6,
							["hit"] = 4,
							["school"] = 32,
							["hitmax"] = 162,
							["MISS"] = 2,
							["hitamount"] = 643,
						},
					},
					["totaldamage"] = 6033,
					["role"] = "DAMAGER",
				}, -- [4]
				{
					["last"] = 11054.826,
					["flag"] = 1298,
					["class"] = "PRIEST",
					["auras"] = {
						[589] = {
							["type"] = "DEBUFF",
							["count"] = 2,
							["school"] = 32,
							["targets"] = {
								["Lord Vyletongue"] = {
									["uptime"] = 23,
									["count"] = 2,
								},
							},
							["uptime"] = 23,
						},
						[14914] = {
							["type"] = "DEBUFF",
							["count"] = 1,
							["school"] = 2,
							["targets"] = {
								["Lord Vyletongue"] = {
									["uptime"] = 7,
									["count"] = 1,
								},
							},
							["uptime"] = 7,
						},
					},
					["dispel"] = 2,
					["role"] = "HEALER",
					["time"] = 44.26000000000001,
					["totaldamagetaken"] = 0,
					["damage"] = 1171,
					["overheal"] = 965,
					["damagetaken"] = 0,
					["id"] = "0x00000000000467C0",
					["healspells"] = {
						[63544] = {
							["overheal"] = 0,
							["criticalamount"] = 140,
							["max"] = 140,
							["targets"] = {
								["Beardedrasta"] = {
									["overheal"] = 0,
									["amount"] = 58,
								},
								["Fragrance"] = {
									["overheal"] = 0,
									["amount"] = 52,
								},
								["Myrony"] = {
									["overheal"] = 0,
									["amount"] = 280,
								},
							},
							["min"] = 52,
							["criticalmax"] = 140,
							["critical"] = 1,
							["amount"] = 390,
							["school"] = 2,
							["criticalmin"] = 140,
							["count"] = 5,
						},
						[139] = {
							["overheal"] = 965,
							["max"] = 175,
							["targets"] = {
								["Beardedrasta"] = {
									["overheal"] = 34,
									["amount"] = 546,
								},
								["Fragrance"] = {
									["overheal"] = 354,
									["amount"] = 174,
								},
								["Myrony"] = {
									["overheal"] = 577,
									["amount"] = 1348,
								},
							},
							["min"] = 42,
							["casts"] = 5,
							["count"] = 19,
							["amount"] = 2068,
							["school"] = 2,
							["ishot"] = true,
						},
					},
					["heal"] = 2458,
					["name"] = "Nianhong",
					["damagespells"] = {
						["Mind Blast"] = {
							["total"] = 324,
							["hitmin"] = 324,
							["id"] = 8092,
							["targets"] = {
								["Lord Vyletongue"] = {
									["total"] = 324,
									["amount"] = 324,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 32,
							["hitmax"] = 324,
							["amount"] = 324,
							["hitamount"] = 324,
						},
						["Holy Fire"] = {
							["total"] = 282,
							["hitmin"] = 282,
							["id"] = 14914,
							["targets"] = {
								["Lord Vyletongue"] = {
									["total"] = 282,
									["amount"] = 282,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 2,
							["hitmax"] = 282,
							["amount"] = 282,
							["hitamount"] = 282,
						},
						["Holy Fire (DoT)"] = {
							["total"] = 67,
							["hitmin"] = 9,
							["criticalamount"] = 13,
							["id"] = 14914,
							["targets"] = {
								["Lord Vyletongue"] = {
									["total"] = 67,
									["amount"] = 67,
								},
							},
							["hitmax"] = 9,
							["count"] = 7,
							["criticalmax"] = 13,
							["critical"] = 1,
							["amount"] = 67,
							["school"] = 2,
							["hit"] = 6,
							["criticalmin"] = 13,
							["hitamount"] = 54,
						},
						["Shadow Word: Pain (DoT)"] = {
							["total"] = 315,
							["hitmin"] = 42,
							["criticalamount"] = 63,
							["id"] = 589,
							["criticalmin"] = 63,
							["targets"] = {
								["Lord Vyletongue"] = {
									["total"] = 315,
									["amount"] = 315,
								},
							},
							["criticalmax"] = 63,
							["critical"] = 1,
							["casts"] = 2,
							["count"] = 7,
							["hit"] = 6,
							["school"] = 32,
							["hitmax"] = 42,
							["amount"] = 315,
							["hitamount"] = 252,
						},
						["Holy Word: Chastise"] = {
							["total"] = 183,
							["hitmin"] = 183,
							["id"] = 88625,
							["targets"] = {
								["Lord Vyletongue"] = {
									["total"] = 183,
									["amount"] = 183,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 2,
							["hitmax"] = 183,
							["amount"] = 183,
							["hitamount"] = 183,
						},
					},
					["totaldamage"] = 1171,
					["dispelspells"] = {
						[528] = {
							["spells"] = {
								[21062] = 2,
							},
							["count"] = 2,
							["targets"] = {
								["Fragrance"] = 1,
								["Myrony"] = 1,
							},
						},
					},
				}, -- [5]
			},
			["type"] = "party",
			["damagetaken"] = 3366,
			["overheal"] = 1147,
			["gotboss"] = 12236,
			["energy"] = 173,
			["overkill"] = 212,
			["edamagetaken"] = 39804,
			["heal"] = 3611,
			["name"] = "Lord Vyletongue",
			["mobname"] = "Lord Vyletongue",
			["etotaldamagetaken"] = 39804,
			["edamage"] = 3366,
			["last_action"] = 1689857925,
			["endtime"] = 1689857925,
		}, -- [1]
		{
			["starttime"] = 1689857829,
			["mana"] = 2278,
			["enemies"] = {
				{
					["damagespells"] = {
						[6603] = {
							["school"] = 1,
							["total"] = 141,
							["targets"] = {
								["Myrony"] = {
									["total"] = 141,
									["amount"] = 141,
								},
							},
							["amount"] = 141,
						},
						[21331] = {
							["school"] = 8,
							["total"] = 46,
							["targets"] = {
								["Fragrance"] = {
									["total"] = 22,
									["amount"] = 22,
								},
								["Beardedrasta"] = {
									["total"] = 24,
									["amount"] = 20,
								},
							},
							["amount"] = 42,
						},
					},
					["damagetaken"] = 1579,
					["flag"] = 68168,
					["class"] = "MONSTER",
					["damagetakenspells"] = {
						[6603] = {
							["school"] = 1,
							["total"] = 228,
							["sources"] = {
								["Macius"] = {
									["total"] = 101,
									["amount"] = 101,
								},
								["Beardedrasta"] = {
									["total"] = 127,
									["amount"] = 127,
								},
							},
							["amount"] = 228,
						},
						[7294] = {
							["school"] = 2,
							["total"] = 13,
							["sources"] = {
								["Myrony"] = {
									["total"] = 13,
									["amount"] = 13,
								},
							},
							["amount"] = 13,
						},
						[16827] = {
							["school"] = 1,
							["total"] = 174,
							["sources"] = {
								["Macius"] = {
									["total"] = 174,
									["amount"] = 174,
								},
							},
							["amount"] = 174,
						},
						[35395] = {
							["school"] = 1,
							["total"] = 311,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 311,
									["amount"] = 311,
								},
							},
							["amount"] = 311,
						},
						[75] = {
							["sources"] = {
								["Macius"] = {
									["total"] = 261,
									["overkill"] = 101,
									["amount"] = 261,
								},
							},
							["amount"] = 261,
							["school"] = 1,
							["total"] = 261,
							["overkill"] = 101,
						},
						[25742] = {
							["school"] = 2,
							["total"] = 27,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 27,
									["amount"] = 27,
								},
							},
							["amount"] = 27,
						},
						[96172] = {
							["school"] = 2,
							["total"] = 1,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 1,
									["amount"] = 1,
								},
							},
							["amount"] = 1,
						},
						[20187] = {
							["school"] = 2,
							["total"] = 128,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 128,
									["amount"] = 128,
								},
							},
							["amount"] = 128,
						},
						[53301] = {
							["school"] = 4,
							["total"] = 324,
							["sources"] = {
								["Macius"] = {
									["total"] = 324,
									["amount"] = 324,
								},
							},
							["amount"] = 324,
						},
						[56641] = {
							["school"] = 1,
							["total"] = 112,
							["sources"] = {
								["Macius"] = {
									["total"] = 112,
									["amount"] = 112,
								},
							},
							["amount"] = 112,
						},
					},
					["name"] = "Deeprot Tangler",
					["totaldamage"] = 187,
					["totaldamagetaken"] = 1579,
					["id"] = "0xF130335600000034",
					["damage"] = 183,
				}, -- [1]
				{
					["damagespells"] = {
						[6603] = {
							["school"] = 1,
							["total"] = 521,
							["targets"] = {
								["Myrony"] = {
									["total"] = 521,
									["amount"] = 335,
								},
							},
							["amount"] = 335,
						},
					},
					["damagetaken"] = 992,
					["flag"] = 2632,
					["class"] = "MONSTER",
					["damagetakenspells"] = {
						[2812] = {
							["school"] = 2,
							["total"] = 56,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 56,
									["amount"] = 56,
								},
							},
							["amount"] = 56,
						},
						[31935] = {
							["school"] = 2,
							["total"] = 333,
							["sources"] = {
								["Myrony"] = {
									["total"] = 333,
									["amount"] = 333,
								},
							},
							["amount"] = 333,
						},
						[53385] = {
							["sources"] = {
								["Fragrance"] = {
									["total"] = 194,
									["overkill"] = 159,
									["amount"] = 194,
								},
							},
							["amount"] = 194,
							["school"] = 1,
							["total"] = 194,
							["overkill"] = 159,
						},
						[25742] = {
							["school"] = 2,
							["total"] = 21,
							["sources"] = {
								["Myrony"] = {
									["total"] = 21,
									["amount"] = 21,
								},
							},
							["amount"] = 21,
						},
						[96172] = {
							["school"] = 2,
							["total"] = 1,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 1,
									["amount"] = 1,
								},
							},
							["amount"] = 1,
						},
						[88263] = {
							["school"] = 2,
							["total"] = 153,
							["sources"] = {
								["Myrony"] = {
									["total"] = 153,
									["amount"] = 153,
								},
							},
							["amount"] = 153,
						},
						[7294] = {
							["school"] = 2,
							["total"] = 26,
							["sources"] = {
								["Myrony"] = {
									["total"] = 26,
									["amount"] = 26,
								},
							},
							["amount"] = 26,
						},
						[81297] = {
							["school"] = 2,
							["total"] = 208,
							["sources"] = {
								["Myrony"] = {
									["total"] = 208,
									["amount"] = 208,
								},
							},
							["amount"] = 208,
						},
					},
					["name"] = "Corruptor",
					["totaldamage"] = 521,
					["totaldamagetaken"] = 992,
					["id"] = "0xF1302FB900000037",
					["damage"] = 335,
				}, -- [2]
				{
					["damagespells"] = {
						[15657] = {
							["school"] = 1,
							["total"] = 244,
							["targets"] = {
								["Myrony"] = {
									["total"] = 244,
									["amount"] = 244,
								},
							},
							["amount"] = 244,
						},
						[13298] = {
							["school"] = 8,
							["total"] = 39,
							["targets"] = {
								["Myrony"] = {
									["total"] = 39,
									["amount"] = 7,
								},
							},
							["amount"] = 7,
						},
						[6603] = {
							["school"] = 1,
							["total"] = 605,
							["targets"] = {
								["Myrony"] = {
									["total"] = 605,
									["amount"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["damagetaken"] = 9590,
					["flag"] = 2632,
					["class"] = "MONSTER",
					["damagetakenspells"] = {
						[16827] = {
							["school"] = 1,
							["total"] = 396,
							["sources"] = {
								["Macius"] = {
									["total"] = 396,
									["amount"] = 396,
								},
							},
							["amount"] = 396,
						},
						[25742] = {
							["school"] = 2,
							["total"] = 137,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 27,
									["amount"] = 27,
								},
								["Myrony"] = {
									["total"] = 110,
									["amount"] = 110,
								},
							},
							["amount"] = 137,
						},
						[35395] = {
							["school"] = 1,
							["total"] = 349,
							["sources"] = {
								["Myrony"] = {
									["total"] = 349,
									["amount"] = 349,
								},
							},
							["amount"] = 349,
						},
						[53595] = {
							["school"] = 1,
							["total"] = 37,
							["sources"] = {
								["Myrony"] = {
									["total"] = 37,
									["amount"] = 37,
								},
							},
							["amount"] = 37,
						},
						[6603] = {
							["school"] = 1,
							["total"] = 1545,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 237,
									["amount"] = 237,
								},
								["Macius"] = {
									["total"] = 364,
									["amount"] = 364,
								},
								["Fragrance"] = {
									["total"] = 436,
									["amount"] = 436,
								},
								["Myrony"] = {
									["total"] = 508,
									["amount"] = 508,
								},
							},
							["amount"] = 1545,
						},
						[2643] = {
							["school"] = 1,
							["total"] = 641,
							["sources"] = {
								["Macius"] = {
									["total"] = 641,
									["amount"] = 641,
								},
							},
							["amount"] = 641,
						},
						[980] = {
							["school"] = 32,
							["total"] = 47,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 47,
									["amount"] = 47,
								},
							},
							["amount"] = 47,
						},
						[53385] = {
							["sources"] = {
								["Fragrance"] = {
									["total"] = 1135,
									["overkill"] = 214,
									["amount"] = 1135,
								},
							},
							["amount"] = 1135,
							["school"] = 1,
							["total"] = 1135,
							["overkill"] = 214,
						},
						[85256] = {
							["school"] = 1,
							["total"] = 623,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 623,
									["amount"] = 623,
								},
							},
							["amount"] = 623,
						},
						[96172] = {
							["school"] = 2,
							["total"] = 6,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 6,
									["amount"] = 6,
								},
							},
							["amount"] = 6,
						},
						[2812] = {
							["school"] = 2,
							["total"] = 215,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 112,
									["amount"] = 112,
								},
								["Myrony"] = {
									["total"] = 103,
									["amount"] = 103,
								},
							},
							["amount"] = 215,
						},
						[30108] = {
							["school"] = 32,
							["total"] = 196,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 196,
									["amount"] = 196,
								},
							},
							["amount"] = 196,
						},
						[31935] = {
							["school"] = 2,
							["total"] = 692,
							["sources"] = {
								["Myrony"] = {
									["total"] = 692,
									["amount"] = 692,
								},
							},
							["amount"] = 692,
						},
						[879] = {
							["sources"] = {
								["Fragrance"] = {
									["total"] = 1063,
									["overkill"] = 72,
									["amount"] = 1063,
								},
							},
							["amount"] = 1063,
							["school"] = 2,
							["total"] = 1063,
							["overkill"] = 72,
						},
						[20187] = {
							["school"] = 2,
							["total"] = 296,
							["sources"] = {
								["Myrony"] = {
									["total"] = 296,
									["amount"] = 296,
								},
							},
							["amount"] = 296,
						},
						[56641] = {
							["school"] = 1,
							["total"] = 461,
							["sources"] = {
								["Macius"] = {
									["total"] = 461,
									["amount"] = 461,
								},
							},
							["amount"] = 461,
						},
						[75] = {
							["school"] = 1,
							["total"] = 505,
							["sources"] = {
								["Macius"] = {
									["total"] = 505,
									["amount"] = 505,
								},
							},
							["amount"] = 505,
						},
						[81297] = {
							["school"] = 2,
							["total"] = 492,
							["sources"] = {
								["Myrony"] = {
									["total"] = 492,
									["amount"] = 492,
								},
							},
							["amount"] = 492,
						},
						[88263] = {
							["school"] = 2,
							["total"] = 320,
							["sources"] = {
								["Myrony"] = {
									["total"] = 320,
									["amount"] = 320,
								},
							},
							["amount"] = 320,
						},
						[54049] = {
							["school"] = 32,
							["total"] = 126,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 126,
									["amount"] = 126,
								},
							},
							["amount"] = 126,
						},
						[172] = {
							["school"] = 32,
							["total"] = 308,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 308,
									["amount"] = 308,
								},
							},
							["amount"] = 308,
						},
					},
					["name"] = "Putridus Trickster",
					["totaldamage"] = 888,
					["totaldamagetaken"] = 9590,
					["id"] = "0xF1302E0F00000035",
					["damage"] = 251,
				}, -- [3]
				{
					["id"] = "0xF1302FB800000040",
					["name"] = "Poison Sprite",
					["totaldamagetaken"] = 3467,
					["flag"] = 2632,
					["class"] = "MONSTER",
					["damagetaken"] = 3467,
					["damagetakenspells"] = {
						[81297] = {
							["school"] = 2,
							["total"] = 225,
							["sources"] = {
								["Myrony"] = {
									["total"] = 225,
									["amount"] = 225,
								},
							},
							["amount"] = 225,
						},
						[31935] = {
							["school"] = 2,
							["total"] = 355,
							["sources"] = {
								["Myrony"] = {
									["total"] = 355,
									["amount"] = 355,
								},
							},
							["amount"] = 355,
						},
						[6603] = {
							["school"] = 1,
							["total"] = 295,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 194,
									["amount"] = 194,
								},
								["Myrony"] = {
									["total"] = 101,
									["amount"] = 101,
								},
							},
							["amount"] = 295,
						},
						[2643] = {
							["school"] = 1,
							["total"] = 659,
							["sources"] = {
								["Macius"] = {
									["total"] = 659,
									["amount"] = 659,
								},
							},
							["amount"] = 659,
						},
						[35395] = {
							["sources"] = {
								["Fragrance"] = {
									["total"] = 768,
									["overkill"] = 755,
									["amount"] = 768,
								},
							},
							["amount"] = 768,
							["school"] = 1,
							["total"] = 768,
							["overkill"] = 755,
						},
						[25742] = {
							["school"] = 2,
							["total"] = 48,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 27,
									["amount"] = 27,
								},
								["Myrony"] = {
									["total"] = 21,
									["amount"] = 21,
								},
							},
							["amount"] = 48,
						},
						[96172] = {
							["school"] = 2,
							["total"] = 6,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 6,
									["amount"] = 6,
								},
							},
							["amount"] = 6,
						},
						[2812] = {
							["school"] = 2,
							["total"] = 112,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 112,
									["amount"] = 112,
								},
							},
							["amount"] = 112,
						},
						[53385] = {
							["sources"] = {
								["Fragrance"] = {
									["total"] = 999,
									["overkill"] = 213,
									["amount"] = 999,
								},
							},
							["amount"] = 999,
							["school"] = 1,
							["total"] = 999,
							["overkill"] = 213,
						},
					},
				}, -- [4]
				{
					["damagespells"] = {
						[6603] = {
							["school"] = 1,
							["total"] = 921,
							["targets"] = {
								["Fragrance"] = {
									["total"] = 623,
									["amount"] = 623,
								},
								["Myrony"] = {
									["total"] = 298,
									["amount"] = 146,
								},
							},
							["amount"] = 769,
						},
					},
					["damagetaken"] = 9171,
					["flag"] = 2632,
					["class"] = "MONSTER",
					["damagetakenspells"] = {
						[16827] = {
							["school"] = 1,
							["total"] = 77,
							["sources"] = {
								["Macius"] = {
									["total"] = 77,
									["amount"] = 77,
								},
							},
							["amount"] = 77,
						},
						[25742] = {
							["school"] = 2,
							["total"] = 230,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 81,
									["amount"] = 81,
								},
								["Myrony"] = {
									["total"] = 149,
									["amount"] = 149,
								},
							},
							["amount"] = 230,
						},
						[35395] = {
							["school"] = 1,
							["total"] = 650,
							["sources"] = {
								["Myrony"] = {
									["total"] = 650,
									["amount"] = 650,
								},
							},
							["amount"] = 650,
						},
						[53595] = {
							["school"] = 1,
							["total"] = 35,
							["sources"] = {
								["Myrony"] = {
									["total"] = 35,
									["amount"] = 35,
								},
							},
							["amount"] = 35,
						},
						[6603] = {
							["school"] = 1,
							["total"] = 1871,
							["sources"] = {
								["Macius"] = {
									["total"] = 207,
									["amount"] = 207,
								},
								["Beardedrasta"] = {
									["total"] = 319,
									["amount"] = 319,
								},
								["Fragrance"] = {
									["total"] = 562,
									["amount"] = 562,
								},
								["Myrony"] = {
									["total"] = 783,
									["amount"] = 783,
								},
							},
							["amount"] = 1871,
						},
						[3044] = {
							["sources"] = {
								["Macius"] = {
									["total"] = 298,
									["overkill"] = 41,
									["amount"] = 298,
								},
							},
							["amount"] = 298,
							["school"] = 64,
							["total"] = 298,
							["overkill"] = 41,
						},
						[2643] = {
							["school"] = 1,
							["total"] = 453,
							["sources"] = {
								["Macius"] = {
									["total"] = 453,
									["amount"] = 453,
								},
							},
							["amount"] = 453,
						},
						[980] = {
							["school"] = 32,
							["total"] = 155,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 155,
									["amount"] = 155,
								},
							},
							["amount"] = 155,
						},
						[53385] = {
							["school"] = 1,
							["total"] = 809,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 809,
									["amount"] = 809,
								},
							},
							["amount"] = 809,
						},
						[172] = {
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 308,
									["overkill"] = 38,
									["amount"] = 308,
								},
							},
							["amount"] = 308,
							["school"] = 32,
							["total"] = 308,
							["overkill"] = 38,
						},
						[96172] = {
							["school"] = 2,
							["total"] = 4,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 4,
									["amount"] = 4,
								},
							},
							["amount"] = 4,
						},
						[2812] = {
							["school"] = 2,
							["total"] = 541,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 284,
									["amount"] = 284,
								},
								["Myrony"] = {
									["total"] = 257,
									["amount"] = 257,
								},
							},
							["amount"] = 541,
						},
						[5019] = {
							["school"] = 1,
							["total"] = 49,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 49,
									["amount"] = 49,
								},
							},
							["amount"] = 49,
						},
						[31935] = {
							["school"] = 2,
							["total"] = 741,
							["sources"] = {
								["Myrony"] = {
									["total"] = 741,
									["amount"] = 741,
								},
							},
							["amount"] = 741,
						},
						[88263] = {
							["school"] = 2,
							["total"] = 309,
							["sources"] = {
								["Myrony"] = {
									["total"] = 309,
									["amount"] = 309,
								},
							},
							["amount"] = 309,
						},
						[20187] = {
							["school"] = 2,
							["total"] = 944,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 384,
									["amount"] = 384,
								},
								["Myrony"] = {
									["total"] = 560,
									["amount"] = 560,
								},
							},
							["amount"] = 944,
						},
						[56641] = {
							["school"] = 1,
							["total"] = 283,
							["sources"] = {
								["Macius"] = {
									["total"] = 283,
									["amount"] = 283,
								},
							},
							["amount"] = 283,
						},
						[30108] = {
							["school"] = 32,
							["total"] = 342,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 342,
									["amount"] = 342,
								},
							},
							["amount"] = 342,
						},
						[81297] = {
							["school"] = 2,
							["total"] = 30,
							["sources"] = {
								["Myrony"] = {
									["total"] = 30,
									["amount"] = 30,
								},
							},
							["amount"] = 30,
						},
						[7294] = {
							["school"] = 2,
							["total"] = 52,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 39,
									["amount"] = 39,
								},
								["Myrony"] = {
									["total"] = 13,
									["amount"] = 13,
								},
							},
							["amount"] = 52,
						},
						[54049] = {
							["school"] = 32,
							["total"] = 567,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 567,
									["amount"] = 567,
								},
							},
							["amount"] = 567,
						},
						[75] = {
							["school"] = 1,
							["total"] = 423,
							["sources"] = {
								["Macius"] = {
									["total"] = 423,
									["amount"] = 423,
								},
							},
							["amount"] = 423,
						},
					},
					["name"] = "Putridus Shadowstalker",
					["totaldamage"] = 921,
					["totaldamagetaken"] = 9171,
					["id"] = "0xF1302E1000000033",
					["damage"] = 769,
				}, -- [5]
			},
			["dispel"] = 1,
			["totaldamage"] = 24799,
			["time"] = 35,
			["absorb"] = 975,
			["totaldamagetaken"] = 2517,
			["etotaldamagetaken"] = 24799,
			["damage"] = 24799,
			["players"] = {
				{
					["damagespells"] = {
						["Explosive Shot (DoT)"] = {
							["total"] = 324,
							["hitmin"] = 162,
							["id"] = 53301,
							["targets"] = {
								["Deeprot Tangler"] = {
									["total"] = 324,
									["amount"] = 324,
								},
							},
							["count"] = 2,
							["hit"] = 2,
							["school"] = 4,
							["hitmax"] = 162,
							["amount"] = 324,
							["hitamount"] = 324,
						},
						["Claw (Cat)"] = {
							["total"] = 647,
							["hitmin"] = 76,
							["id"] = 16827,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 77,
									["amount"] = 77,
								},
								["Putridus Trickster"] = {
									["total"] = 396,
									["amount"] = 396,
								},
								["Deeprot Tangler"] = {
									["total"] = 174,
									["amount"] = 174,
								},
							},
							["casts"] = 8,
							["count"] = 8,
							["hit"] = 8,
							["school"] = 1,
							["hitmax"] = 88,
							["amount"] = 647,
							["hitamount"] = 647,
						},
						["Multi-Shot"] = {
							["total"] = 1753,
							["hitmin"] = 81,
							["id"] = 2643,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 453,
									["amount"] = 453,
								},
								["Poison Sprite"] = {
									["total"] = 659,
									["amount"] = 659,
								},
								["Putridus Trickster"] = {
									["total"] = 641,
									["amount"] = 641,
								},
								["Corruptor"] = {
									["total"] = 0,
									["amount"] = 0,
								},
							},
							["amount"] = 1753,
							["casts"] = 4,
							["count"] = 18,
							["hit"] = 17,
							["school"] = 1,
							["hitmax"] = 132,
							["MISS"] = 1,
							["hitamount"] = 1753,
						},
						["Auto Shot"] = {
							["total"] = 1189,
							["hitmin"] = 93,
							["id"] = 75,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 423,
									["amount"] = 423,
								},
								["Putridus Trickster"] = {
									["total"] = 505,
									["amount"] = 505,
								},
								["Deeprot Tangler"] = {
									["total"] = 261,
									["overkill"] = 101,
									["amount"] = 261,
								},
							},
							["overkill"] = 101,
							["casts"] = 1,
							["count"] = 10,
							["hit"] = 10,
							["school"] = 1,
							["hitmax"] = 138,
							["amount"] = 1189,
							["hitamount"] = 1189,
						},
						["Steady Shot"] = {
							["total"] = 856,
							["hitmin"] = 87,
							["criticalamount"] = 176,
							["id"] = 56641,
							["criticalmin"] = 176,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 283,
									["amount"] = 283,
								},
								["Putridus Trickster"] = {
									["total"] = 461,
									["amount"] = 461,
								},
								["Deeprot Tangler"] = {
									["total"] = 112,
									["amount"] = 112,
								},
							},
							["criticalmax"] = 176,
							["critical"] = 1,
							["casts"] = 11,
							["count"] = 8,
							["hit"] = 7,
							["school"] = 1,
							["hitmax"] = 112,
							["amount"] = 856,
							["hitamount"] = 680,
						},
						["Melee (Cat)"] = {
							["DODGE"] = 1,
							["hitmin"] = 47,
							["criticalmin"] = 104,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 207,
									["amount"] = 207,
								},
								["Putridus Trickster"] = {
									["total"] = 364,
									["amount"] = 364,
								},
								["Deeprot Tangler"] = {
									["total"] = 101,
									["amount"] = 101,
								},
							},
							["glancing"] = 4,
							["amount"] = 672,
							["MISS"] = 1,
							["total"] = 672,
							["criticalamount"] = 104,
							["id"] = 6603,
							["criticalmax"] = 104,
							["count"] = 14,
							["hit"] = 7,
							["school"] = 1,
							["hitmax"] = 63,
							["critical"] = 1,
							["hitamount"] = 374,
						},
						["Arcane Shot"] = {
							["total"] = 298,
							["hitmin"] = 149,
							["id"] = 3044,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 298,
									["overkill"] = 41,
									["amount"] = 298,
								},
							},
							["overkill"] = 41,
							["casts"] = 2,
							["count"] = 2,
							["hit"] = 2,
							["school"] = 64,
							["hitmax"] = 149,
							["amount"] = 298,
							["hitamount"] = 298,
						},
					},
					["last"] = 10995.009,
					["flag"] = 1298,
					["id"] = "0x00000000000477A3",
					["class"] = "HUNTER",
					["time"] = 34.32,
					["overkill"] = 142,
					["energyspells"] = {
						[91954] = 72,
					},
					["name"] = "Macius",
					["role"] = "DAMAGER",
					["totaldamage"] = 5739,
					["energy"] = 72,
					["damage"] = 5739,
				}, -- [1]
				{
					["ccdonespells"] = {
						[31935] = {
							["count"] = 6,
							["targets"] = {
								["Putridus Shadowstalker"] = 2,
								["Poison Sprite"] = 1,
								["Putridus Trickster"] = 2,
								["Corruptor"] = 1,
							},
						},
						[2812] = {
							["count"] = 3,
							["targets"] = {
								["Putridus Trickster"] = 1,
								["Putridus Shadowstalker"] = 2,
							},
						},
					},
					["last"] = 10992.566,
					["flag"] = 1298,
					["class"] = "PALADIN",
					["auras"] = {
						[62124] = {
							["type"] = "DEBUFF",
							["count"] = 1,
							["school"] = 2,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["uptime"] = 3,
									["count"] = 1,
								},
							},
							["uptime"] = 3,
						},
						[31935] = {
							["type"] = "DEBUFF",
							["count"] = 6,
							["school"] = 2,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["uptime"] = 3,
									["count"] = 2,
								},
								["Poison Sprite"] = {
									["uptime"] = 3,
									["count"] = 1,
								},
								["Putridus Trickster"] = {
									["uptime"] = 6,
									["count"] = 2,
								},
								["Corruptor"] = {
									["uptime"] = 3,
									["count"] = 1,
								},
							},
							["uptime"] = 6,
						},
						[2812] = {
							["type"] = "DEBUFF",
							["count"] = 3,
							["school"] = 2,
							["targets"] = {
								["Putridus Trickster"] = {
									["uptime"] = 2,
									["count"] = 1,
								},
								["Putridus Shadowstalker"] = {
									["uptime"] = 3,
									["count"] = 2,
								},
							},
							["uptime"] = 3,
						},
						[68055] = {
							["type"] = "DEBUFF",
							["count"] = 2,
							["school"] = 2,
							["refresh"] = 1,
							["targets"] = {
								["Putridus Trickster"] = {
									["uptime"] = 19,
									["count"] = 1,
								},
								["Putridus Shadowstalker"] = {
									["count"] = 1,
									["refresh"] = 1,
									["uptime"] = 11,
								},
							},
							["uptime"] = 20,
						},
						[31790] = {
							["type"] = "DEBUFF",
							["count"] = 1,
							["school"] = 1,
							["targets"] = {
								["Poison Sprite"] = {
									["uptime"] = 3,
									["count"] = 1,
								},
							},
							["uptime"] = 3,
						},
						[17] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 2,
							["uptime"] = 15,
						},
						[26573] = {
							["type"] = "DEBUFF",
							["count"] = 4,
							["school"] = 2,
							["targets"] = {
								["Deeprot Tangler"] = {
									["uptime"] = 30,
									["count"] = 1,
								},
								["Putridus Trickster"] = {
									["uptime"] = 30,
									["count"] = 1,
								},
								["Corruptor"] = {
									["uptime"] = 30,
									["count"] = 1,
								},
								["Myrony"] = {
									["uptime"] = 10,
									["count"] = 1,
								},
							},
							["uptime"] = 30,
						},
						[31930] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 2,
							["refresh"] = 2,
							["uptime"] = 26,
						},
					},
					["role"] = "TANK",
					["time"] = 31.63,
					["totaldamagetaken"] = 1848,
					["damage"] = 7890,
					["damagespells"] = {
						["Seal of Righteousness"] = {
							["total"] = 301,
							["hitmin"] = 21,
							["criticalamount"] = 44,
							["id"] = 25742,
							["criticalmin"] = 44,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 149,
									["amount"] = 149,
								},
								["Poison Sprite"] = {
									["total"] = 21,
									["amount"] = 21,
								},
								["Putridus Trickster"] = {
									["total"] = 110,
									["amount"] = 110,
								},
								["Corruptor"] = {
									["total"] = 21,
									["amount"] = 21,
								},
							},
							["criticalmax"] = 44,
							["critical"] = 1,
							["casts"] = 1,
							["count"] = 13,
							["hit"] = 12,
							["school"] = 2,
							["hitmax"] = 22,
							["amount"] = 301,
							["hitamount"] = 257,
						},
						["Hammer of the Righteous (Physical)"] = {
							["total"] = 72,
							["hitmin"] = 35,
							["id"] = 53595,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 37,
									["amount"] = 37,
								},
								["Putridus Shadowstalker"] = {
									["total"] = 35,
									["amount"] = 35,
								},
							},
							["casts"] = 1,
							["count"] = 2,
							["hit"] = 2,
							["school"] = 1,
							["hitmax"] = 37,
							["amount"] = 72,
							["hitamount"] = 72,
						},
						["Retribution Aura"] = {
							["total"] = 52,
							["hitmin"] = 13,
							["id"] = 7294,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 13,
									["amount"] = 13,
								},
								["Corruptor"] = {
									["total"] = 26,
									["amount"] = 26,
								},
								["Deeprot Tangler"] = {
									["total"] = 13,
									["amount"] = 13,
								},
							},
							["casts"] = 1,
							["count"] = 4,
							["hit"] = 4,
							["school"] = 2,
							["hitmax"] = 13,
							["amount"] = 52,
							["hitamount"] = 52,
						},
						["Holy Wrath"] = {
							["total"] = 360,
							["hitmin"] = 103,
							["criticalamount"] = 154,
							["id"] = 2812,
							["criticalmin"] = 154,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 103,
									["amount"] = 103,
								},
								["Putridus Shadowstalker"] = {
									["total"] = 257,
									["amount"] = 257,
								},
							},
							["criticalmax"] = 154,
							["critical"] = 1,
							["casts"] = 1,
							["count"] = 3,
							["hit"] = 2,
							["school"] = 2,
							["hitmax"] = 103,
							["amount"] = 360,
							["hitamount"] = 206,
						},
						["Hammer of the Righteous"] = {
							["total"] = 782,
							["hitmin"] = 141,
							["id"] = 88263,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 309,
									["amount"] = 309,
								},
								["Corruptor"] = {
									["total"] = 153,
									["amount"] = 153,
								},
								["Putridus Trickster"] = {
									["total"] = 320,
									["amount"] = 320,
								},
							},
							["casts"] = 3,
							["count"] = 5,
							["hit"] = 5,
							["school"] = 2,
							["hitmax"] = 168,
							["amount"] = 782,
							["hitamount"] = 782,
						},
						["Melee"] = {
							["DODGE"] = 2,
							["total"] = 1392,
							["hitmin"] = 85,
							["id"] = 6603,
							["targets"] = {
								["Poison Sprite"] = {
									["total"] = 101,
									["amount"] = 101,
								},
								["Putridus Shadowstalker"] = {
									["total"] = 783,
									["amount"] = 783,
								},
								["Putridus Trickster"] = {
									["total"] = 508,
									["amount"] = 508,
								},
							},
							["blocked"] = 74,
							["count"] = 14,
							["hit"] = 12,
							["school"] = 1,
							["hitmax"] = 136,
							["amount"] = 1392,
							["hitamount"] = 1392,
						},
						["Consecration"] = {
							["total"] = 955,
							["hitmin"] = 28,
							["criticalamount"] = 87,
							["id"] = 81297,
							["criticalmin"] = 42,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 30,
									["amount"] = 30,
								},
								["Poison Sprite"] = {
									["total"] = 225,
									["amount"] = 225,
								},
								["Putridus Trickster"] = {
									["total"] = 492,
									["amount"] = 492,
								},
								["Corruptor"] = {
									["total"] = 208,
									["amount"] = 208,
								},
							},
							["criticalmax"] = 45,
							["critical"] = 2,
							["casts"] = 1,
							["count"] = 31,
							["hit"] = 29,
							["school"] = 2,
							["hitmax"] = 30,
							["amount"] = 955,
							["hitamount"] = 868,
						},
						["Avenger's Shield"] = {
							["total"] = 2121,
							["hitmin"] = 333,
							["id"] = 31935,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 741,
									["amount"] = 741,
								},
								["Poison Sprite"] = {
									["total"] = 355,
									["amount"] = 355,
								},
								["Putridus Trickster"] = {
									["total"] = 692,
									["amount"] = 692,
								},
								["Corruptor"] = {
									["total"] = 333,
									["amount"] = 333,
								},
							},
							["casts"] = 2,
							["count"] = 6,
							["hit"] = 6,
							["school"] = 2,
							["hitmax"] = 375,
							["amount"] = 2121,
							["hitamount"] = 2121,
						},
						["Crusader Strike"] = {
							["DODGE"] = 1,
							["total"] = 999,
							["hitmin"] = 293,
							["id"] = 35395,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 349,
									["amount"] = 349,
								},
								["Putridus Shadowstalker"] = {
									["total"] = 650,
									["amount"] = 650,
								},
							},
							["casts"] = 4,
							["count"] = 4,
							["hit"] = 3,
							["school"] = 1,
							["hitmax"] = 357,
							["amount"] = 999,
							["hitamount"] = 999,
						},
						["Judgement of Righteousness"] = {
							["total"] = 856,
							["hitmin"] = 275,
							["id"] = 20187,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 296,
									["amount"] = 296,
								},
								["Putridus Shadowstalker"] = {
									["total"] = 560,
									["amount"] = 560,
								},
							},
							["casts"] = 3,
							["count"] = 3,
							["hit"] = 3,
							["school"] = 2,
							["hitmax"] = 296,
							["amount"] = 856,
							["hitamount"] = 856,
						},
					},
					["damagetaken"] = 873,
					["id"] = "0x00000000000447DB",
					["damagetakenspells"] = {
						["Poison (DoT)"] = {
							["total"] = 39,
							["hitmin"] = 7,
							["id"] = 13298,
							["amount"] = 7,
							["hitmax"] = 7,
							["sources"] = {
								["Putridus Trickster"] = {
									["total"] = 39,
									["amount"] = 7,
								},
							},
							["count"] = 5,
							["ABSORB"] = 4,
							["school"] = 8,
							["resisted"] = 3,
							["hit"] = 1,
							["hitamount"] = 7,
						},
						["Melee"] = {
							["total"] = 1565,
							["hitmin"] = 141,
							["id"] = 6603,
							["amount"] = 622,
							["ABSORB"] = 6,
							["PARRY"] = 11,
							["sources"] = {
								["Poison Sprite"] = {
									["total"] = 0,
									["amount"] = 0,
								},
								["Deeprot Tangler"] = {
									["total"] = 141,
									["amount"] = 141,
								},
								["Putridus Shadowstalker"] = {
									["total"] = 298,
									["amount"] = 146,
								},
								["Putridus Trickster"] = {
									["total"] = 605,
									["amount"] = 0,
								},
								["Corruptor"] = {
									["total"] = 521,
									["amount"] = 335,
								},
							},
							["count"] = 25,
							["hit"] = 4,
							["school"] = 1,
							["hitmax"] = 172,
							["MISS"] = 4,
							["hitamount"] = 622,
						},
						["Backstab"] = {
							["total"] = 244,
							["hitmin"] = 244,
							["id"] = 15657,
							["sources"] = {
								["Putridus Trickster"] = {
									["total"] = 244,
									["amount"] = 244,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 1,
							["hitmax"] = 244,
							["amount"] = 244,
							["hitamount"] = 244,
						},
					},
					["name"] = "Myrony",
					["ccdone"] = 9,
					["mana"] = 1558,
					["manaspells"] = {
						[31930] = 960,
						[84627] = 598,
					},
					["totaldamage"] = 7890,
				}, -- [2]
				{
					["last"] = 10993.864,
					["flag"] = 4369,
					["class"] = "WARLOCK",
					["auras"] = {
						[980] = {
							["type"] = "DEBUFF",
							["count"] = 4,
							["school"] = 32,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["uptime"] = 15,
									["count"] = 2,
								},
								["Putridus Trickster"] = {
									["uptime"] = 7,
									["count"] = 1,
								},
								["Deeprot Tangler"] = {
									["uptime"] = 2,
									["count"] = 1,
								},
							},
							["uptime"] = 24,
						},
						[30108] = {
							["type"] = "DEBUFF",
							["count"] = 3,
							["school"] = 32,
							["targets"] = {
								["Putridus Trickster"] = {
									["uptime"] = 13,
									["count"] = 1,
								},
								["Putridus Shadowstalker"] = {
									["uptime"] = 15,
									["count"] = 2,
								},
							},
							["uptime"] = 18,
						},
						[172] = {
							["type"] = "DEBUFF",
							["count"] = 5,
							["school"] = 32,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["uptime"] = 17,
									["count"] = 2,
								},
								["Putridus Trickster"] = {
									["uptime"] = 21,
									["count"] = 2,
								},
							},
							["uptime"] = 28,
						},
					},
					["time"] = 27.07,
					["totaldamagetaken"] = 24,
					["damage"] = 2781,
					["damagespells"] = {
						["Bane of Agony (DoT)"] = {
							["total"] = 202,
							["hitmin"] = 12,
							["criticalamount"] = 46,
							["id"] = 980,
							["casts"] = 3,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 47,
									["amount"] = 47,
								},
								["Putridus Shadowstalker"] = {
									["total"] = 155,
									["amount"] = 155,
								},
							},
							["criticalmin"] = 23,
							["critical"] = 2,
							["criticalmax"] = 23,
							["count"] = 12,
							["hit"] = 10,
							["school"] = 32,
							["hitmax"] = 24,
							["amount"] = 202,
							["hitamount"] = 156,
						},
						["Corruption (DoT)"] = {
							["total"] = 616,
							["hitmin"] = 44,
							["id"] = 172,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 308,
									["amount"] = 308,
								},
								["Putridus Shadowstalker"] = {
									["total"] = 308,
									["overkill"] = 38,
									["amount"] = 308,
								},
							},
							["overkill"] = 38,
							["casts"] = 4,
							["count"] = 14,
							["hit"] = 14,
							["school"] = 32,
							["hitmax"] = 44,
							["amount"] = 616,
							["hitamount"] = 616,
						},
						["Shoot"] = {
							["total"] = 49,
							["hitmin"] = 49,
							["id"] = 5019,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 49,
									["amount"] = 49,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 1,
							["hitmax"] = 49,
							["amount"] = 49,
							["hitamount"] = 49,
						},
						["Melee (Haapdhon)"] = {
							["DODGE"] = 4,
							["total"] = 683,
							["hitmin"] = 60,
							["criticalamount"] = 248,
							["id"] = 6603,
							["critical"] = 2,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 319,
									["amount"] = 319,
								},
								["Putridus Trickster"] = {
									["total"] = 237,
									["amount"] = 237,
								},
								["Deeprot Tangler"] = {
									["total"] = 127,
									["amount"] = 127,
								},
							},
							["criticalmin"] = 122,
							["glancing"] = 1,
							["criticalmax"] = 126,
							["count"] = 13,
							["hit"] = 6,
							["school"] = 1,
							["hitmax"] = 67,
							["amount"] = 683,
							["hitamount"] = 386,
						},
						["Unstable Affliction (DoT)"] = {
							["total"] = 538,
							["hitmin"] = 49,
							["criticalamount"] = 97,
							["id"] = 30108,
							["criticalmin"] = 97,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 196,
									["amount"] = 196,
								},
								["Putridus Shadowstalker"] = {
									["total"] = 342,
									["amount"] = 342,
								},
							},
							["criticalmax"] = 97,
							["critical"] = 1,
							["casts"] = 2,
							["count"] = 10,
							["hit"] = 9,
							["school"] = 32,
							["hitmax"] = 49,
							["amount"] = 538,
							["hitamount"] = 441,
						},
						["Shadow Bite (Haapdhon)"] = {
							["total"] = 693,
							["hitmin"] = 126,
							["criticalamount"] = 260,
							["id"] = 54049,
							["criticalmin"] = 260,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 126,
									["amount"] = 126,
								},
								["Putridus Shadowstalker"] = {
									["total"] = 567,
									["amount"] = 567,
								},
							},
							["criticalmax"] = 260,
							["critical"] = 1,
							["casts"] = 4,
							["count"] = 4,
							["hit"] = 3,
							["school"] = 32,
							["hitmax"] = 154,
							["amount"] = 693,
							["hitamount"] = 433,
						},
					},
					["damagetaken"] = 20,
					["id"] = "0x000000000004825C",
					["spec"] = 265,
					["healspells"] = {
						[63106] = {
							["overheal"] = 254,
							["count"] = 8,
							["amount"] = 10,
							["school"] = 32,
							["max"] = 10,
							["targets"] = {
								["Beardedrasta"] = {
									["overheal"] = 254,
									["amount"] = 10,
								},
							},
							["min"] = 10,
						},
					},
					["damagetakenspells"] = {
						["Entangling Roots (DoT)"] = {
							["total"] = 24,
							["hitmin"] = 10,
							["id"] = 21331,
							["sources"] = {
								["Deeprot Tangler"] = {
									["total"] = 24,
									["amount"] = 20,
								},
							},
							["count"] = 2,
							["hit"] = 2,
							["school"] = 8,
							["hitmax"] = 10,
							["amount"] = 20,
							["hitamount"] = 20,
						},
					},
					["heal"] = 10,
					["name"] = "Beardedrasta",
					["overkill"] = 38,
					["overheal"] = 254,
					["totaldamage"] = 2781,
					["role"] = "DAMAGER",
				}, -- [3]
				{
					["ccdonespells"] = {
						[2812] = {
							["count"] = 6,
							["targets"] = {
								["Putridus Shadowstalker"] = 1,
								["Poison Sprite"] = 2,
								["Corruptor"] = 1,
								["Putridus Trickster"] = 2,
							},
						},
					},
					["last"] = 10994.275,
					["flag"] = 1298,
					["class"] = "PALADIN",
					["auras"] = {
						[2812] = {
							["type"] = "DEBUFF",
							["count"] = 6,
							["school"] = 2,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["uptime"] = 2,
									["count"] = 1,
								},
								["Poison Sprite"] = {
									["uptime"] = 3,
									["count"] = 2,
								},
								["Corruptor"] = {
									["uptime"] = 1,
									["count"] = 1,
								},
								["Putridus Trickster"] = {
									["uptime"] = 3,
									["count"] = 2,
								},
							},
							["uptime"] = 5,
						},
						[59578] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 1,
							["uptime"] = 1,
						},
						[94686] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 1,
							["refresh"] = 5,
							["uptime"] = 22,
						},
						[89906] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 2,
							["refresh"] = 2,
							["uptime"] = 19,
						},
						[139] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 2,
							["uptime"] = 12,
						},
					},
					["totaldamage"] = 8389,
					["time"] = 29.18,
					["totaldamagetaken"] = 645,
					["damage"] = 8389,
					["damagespells"] = {
						["Exorcism"] = {
							["total"] = 1063,
							["criticalamount"] = 1063,
							["id"] = 879,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 1063,
									["overkill"] = 72,
									["amount"] = 1063,
								},
							},
							["overkill"] = 72,
							["casts"] = 1,
							["count"] = 1,
							["amount"] = 1063,
							["school"] = 2,
							["criticalmin"] = 1063,
							["criticalmax"] = 1063,
							["critical"] = 1,
						},
						["Melee"] = {
							["DODGE"] = 1,
							["total"] = 1192,
							["hitmin"] = 181,
							["id"] = 6603,
							["targets"] = {
								["Poison Sprite"] = {
									["total"] = 194,
									["amount"] = 194,
								},
								["Putridus Shadowstalker"] = {
									["total"] = 562,
									["amount"] = 562,
								},
								["Putridus Trickster"] = {
									["total"] = 436,
									["amount"] = 436,
								},
							},
							["count"] = 7,
							["hit"] = 6,
							["school"] = 1,
							["hitmax"] = 223,
							["amount"] = 1192,
							["hitamount"] = 1192,
						},
						["Retribution Aura"] = {
							["total"] = 39,
							["hitmin"] = 13,
							["id"] = 7294,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 39,
									["amount"] = 39,
								},
							},
							["casts"] = 1,
							["count"] = 3,
							["hit"] = 3,
							["school"] = 2,
							["hitmax"] = 13,
							["amount"] = 39,
							["hitamount"] = 39,
						},
						["Divine Storm"] = {
							["DODGE"] = 2,
							["hitmin"] = 133,
							["criticalmin"] = 378,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 809,
									["amount"] = 809,
								},
								["Poison Sprite"] = {
									["total"] = 999,
									["overkill"] = 213,
									["amount"] = 999,
								},
								["Putridus Trickster"] = {
									["total"] = 1135,
									["overkill"] = 214,
									["amount"] = 1135,
								},
								["Corruptor"] = {
									["total"] = 194,
									["overkill"] = 159,
									["amount"] = 194,
								},
							},
							["amount"] = 3137,
							["total"] = 3137,
							["criticalamount"] = 378,
							["id"] = 53385,
							["criticalmax"] = 378,
							["overkill"] = 586,
							["critical"] = 1,
							["casts"] = 4,
							["hitmax"] = 218,
							["hit"] = 14,
							["school"] = 1,
							["blocked"] = 56,
							["count"] = 17,
							["hitamount"] = 2759,
						},
						["Holy Wrath"] = {
							["total"] = 564,
							["hitmin"] = 56,
							["id"] = 2812,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 284,
									["amount"] = 284,
								},
								["Poison Sprite"] = {
									["total"] = 112,
									["amount"] = 112,
								},
								["Corruptor"] = {
									["total"] = 56,
									["amount"] = 56,
								},
								["Putridus Trickster"] = {
									["total"] = 112,
									["amount"] = 112,
								},
							},
							["casts"] = 2,
							["count"] = 6,
							["hit"] = 6,
							["school"] = 2,
							["hitmax"] = 284,
							["amount"] = 564,
							["hitamount"] = 564,
						},
						["Seal of Righteousness"] = {
							["total"] = 162,
							["hitmin"] = 27,
							["id"] = 25742,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 81,
									["amount"] = 81,
								},
								["Poison Sprite"] = {
									["total"] = 27,
									["amount"] = 27,
								},
								["Putridus Trickster"] = {
									["total"] = 27,
									["amount"] = 27,
								},
								["Deeprot Tangler"] = {
									["total"] = 27,
									["amount"] = 27,
								},
							},
							["casts"] = 1,
							["count"] = 6,
							["hit"] = 6,
							["school"] = 2,
							["hitmax"] = 27,
							["amount"] = 162,
							["hitamount"] = 162,
						},
						["Templar's Verdict"] = {
							["total"] = 623,
							["hitmin"] = 623,
							["id"] = 85256,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 623,
									["amount"] = 623,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 1,
							["hitmax"] = 623,
							["amount"] = 623,
							["hitamount"] = 623,
						},
						["Crusader Strike"] = {
							["criticalmin"] = 768,
							["total"] = 1079,
							["hitmin"] = 311,
							["criticalamount"] = 768,
							["id"] = 35395,
							["criticalmax"] = 768,
							["targets"] = {
								["Deeprot Tangler"] = {
									["total"] = 311,
									["amount"] = 311,
								},
								["Poison Sprite"] = {
									["total"] = 768,
									["overkill"] = 755,
									["amount"] = 768,
								},
							},
							["overkill"] = 755,
							["critical"] = 1,
							["casts"] = 2,
							["count"] = 2,
							["hit"] = 1,
							["school"] = 1,
							["hitmax"] = 311,
							["amount"] = 1079,
							["hitamount"] = 311,
						},
						["Hand of Light"] = {
							["total"] = 18,
							["hitmin"] = 1,
							["id"] = 96172,
							["targets"] = {
								["Poison Sprite"] = {
									["total"] = 6,
									["amount"] = 6,
								},
								["Deeprot Tangler"] = {
									["total"] = 1,
									["amount"] = 1,
								},
								["Putridus Shadowstalker"] = {
									["total"] = 4,
									["amount"] = 4,
								},
								["Putridus Trickster"] = {
									["total"] = 6,
									["amount"] = 6,
								},
								["Corruptor"] = {
									["total"] = 1,
									["amount"] = 1,
								},
							},
							["casts"] = 1,
							["count"] = 18,
							["hit"] = 18,
							["school"] = 2,
							["hitmax"] = 1,
							["amount"] = 18,
							["hitamount"] = 18,
						},
						["Judgement of Righteousness"] = {
							["total"] = 512,
							["hitmin"] = 128,
							["id"] = 20187,
							["targets"] = {
								["Deeprot Tangler"] = {
									["total"] = 128,
									["amount"] = 128,
								},
								["Putridus Shadowstalker"] = {
									["total"] = 384,
									["amount"] = 384,
								},
							},
							["casts"] = 4,
							["count"] = 4,
							["hit"] = 4,
							["school"] = 2,
							["hitmax"] = 128,
							["amount"] = 512,
							["hitamount"] = 512,
						},
					},
					["overkill"] = 1413,
					["damagetaken"] = 645,
					["id"] = "0x0000000000048007",
					["healspells"] = {
						[54172] = {
							["overheal"] = 1059,
							["max"] = 23,
							["targets"] = {
								["Beardedrasta"] = {
									["overheal"] = 89,
									["amount"] = 0,
								},
								["Consecration"] = {
									["overheal"] = 24,
									["amount"] = 0,
								},
								["Cat"] = {
									["overheal"] = 136,
									["amount"] = 0,
								},
								["Myrony"] = {
									["overheal"] = 245,
									["amount"] = 7,
								},
								["Haapdhon"] = {
									["overheal"] = 182,
									["amount"] = 0,
								},
								["Nianhong"] = {
									["overheal"] = 169,
									["amount"] = 0,
								},
								["Fragrance"] = {
									["overheal"] = 46,
									["amount"] = 23,
								},
								["Macius"] = {
									["overheal"] = 168,
									["amount"] = 0,
								},
							},
							["min"] = 7,
							["casts"] = 45,
							["count"] = 45,
							["amount"] = 30,
							["school"] = 2,
							["ishot"] = true,
						},
					},
					["damagetakenspells"] = {
						["Melee"] = {
							["total"] = 623,
							["hitmin"] = 183,
							["id"] = 6603,
							["sources"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 623,
									["amount"] = 623,
								},
							},
							["count"] = 3,
							["hit"] = 3,
							["school"] = 1,
							["hitmax"] = 224,
							["amount"] = 623,
							["hitamount"] = 623,
						},
						["Entangling Roots (DoT)"] = {
							["total"] = 22,
							["hitmin"] = 11,
							["id"] = 21331,
							["hitmax"] = 11,
							["sources"] = {
								["Deeprot Tangler"] = {
									["total"] = 22,
									["amount"] = 22,
								},
							},
							["count"] = 2,
							["hit"] = 2,
							["school"] = 8,
							["resisted"] = 2,
							["amount"] = 22,
							["hitamount"] = 22,
						},
					},
					["overheal"] = 1059,
					["heal"] = 30,
					["name"] = "Fragrance",
					["ccdone"] = 6,
					["mana"] = 720,
					["role"] = "DAMAGER",
					["manaspells"] = {
						[89906] = 720,
					},
				}, -- [4]
				{
					["last"] = 10992.781,
					["flag"] = 1298,
					["class"] = "PRIEST",
					["auras"] = {
						[6788] = {
							["type"] = "DEBUFF",
							["count"] = 1,
							["school"] = 2,
							["targets"] = {
								["Myrony"] = {
									["uptime"] = 15,
									["count"] = 1,
								},
							},
							["uptime"] = 15,
						},
					},
					["absorbspells"] = {
						[17] = {
							["min"] = 7,
							["casts"] = 1,
							["count"] = 10,
							["amount"] = 975,
							["school"] = 2,
							["targets"] = {
								["Myrony"] = 975,
							},
							["max"] = 186,
						},
					},
					["role"] = "HEALER",
					["time"] = 29.86,
					["overheal"] = 351,
					["absorb"] = 975,
					["id"] = "0x00000000000467C0",
					["healspells"] = {
						[63544] = {
							["overheal"] = 0,
							["count"] = 1,
							["amount"] = 52,
							["school"] = 2,
							["max"] = 52,
							["targets"] = {
								["Fragrance"] = {
									["overheal"] = 0,
									["amount"] = 52,
								},
							},
							["min"] = 52,
						},
						[56160] = {
							["overheal"] = 0,
							["count"] = 1,
							["amount"] = 248,
							["school"] = 2,
							["max"] = 248,
							["targets"] = {
								["Myrony"] = {
									["overheal"] = 0,
									["amount"] = 248,
								},
							},
							["min"] = 248,
						},
						[139] = {
							["overheal"] = 351,
							["max"] = 175,
							["targets"] = {
								["Fragrance"] = {
									["overheal"] = 111,
									["amount"] = 549,
								},
								["Myrony"] = {
									["overheal"] = 240,
									["amount"] = 460,
								},
							},
							["min"] = 21,
							["casts"] = 2,
							["count"] = 9,
							["amount"] = 1009,
							["school"] = 2,
							["ishot"] = true,
						},
					},
					["heal"] = 1309,
					["name"] = "Nianhong",
					["dispel"] = 1,
					["dispelspells"] = {
						[528] = {
							["spells"] = {
								[21062] = 1,
							},
							["count"] = 1,
							["targets"] = {
								["Fragrance"] = 1,
							},
						},
					},
				}, -- [5]
				{
					["last"] = 10973.421,
					["name"] = "Haapdhon",
					["flag"] = 4369,
					["class"] = "PET",
					["id"] = "0xF143011D00000006",
					["time"] = 0,
				}, -- [6]
				{
					["last"] = 10973.421,
					["name"] = "Cat",
					["flag"] = 4370,
					["class"] = "PET",
					["id"] = "0xF142F90400000007",
					["time"] = 0,
				}, -- [7]
				{
					["last"] = 10973.436,
					["name"] = "Consecration",
					["flag"] = 4370,
					["class"] = "PET",
					["id"] = "0xF130A9EB000001F3",
					["time"] = 0,
				}, -- [8]
			},
			["type"] = "party",
			["damagetaken"] = 1538,
			["ccdone"] = 15,
			["etotaldamage"] = 2517,
			["overheal"] = 1664,
			["overkill"] = 1593,
			["edamagetaken"] = 24799,
			["heal"] = 1349,
			["name"] = "Deeprot Tangler (2)",
			["mobname"] = "Deeprot Tangler",
			["energy"] = 72,
			["edamage"] = 1538,
			["last_action"] = 1689857864,
			["endtime"] = 1689857864,
		}, -- [2]
		{
			["mana"] = 378,
			["enemies"] = {
				{
					["damagespells"] = {
						[6603] = {
							["school"] = 1,
							["total"] = 747,
							["targets"] = {
								["Myrony"] = {
									["total"] = 747,
									["amount"] = 747,
								},
							},
							["amount"] = 747,
						},
					},
					["damagetaken"] = 7194,
					["flag"] = 2632,
					["class"] = "MONSTER",
					["damagetakenspells"] = {
						[16827] = {
							["school"] = 1,
							["total"] = 528,
							["sources"] = {
								["Macius"] = {
									["total"] = 528,
									["amount"] = 528,
								},
							},
							["amount"] = 528,
						},
						[25742] = {
							["sources"] = {
								["Fragrance"] = {
									["total"] = 81,
									["amount"] = 81,
								},
								["Myrony"] = {
									["total"] = 110,
									["overkill"] = 16,
									["amount"] = 110,
								},
							},
							["amount"] = 191,
							["school"] = 2,
							["total"] = 191,
							["overkill"] = 16,
						},
						[35395] = {
							["school"] = 1,
							["total"] = 638,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 309,
									["amount"] = 309,
								},
								["Myrony"] = {
									["total"] = 329,
									["amount"] = 329,
								},
							},
							["amount"] = 638,
						},
						[6603] = {
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 294,
									["overkill"] = 35,
									["amount"] = 294,
								},
								["Macius"] = {
									["total"] = 533,
									["amount"] = 533,
								},
								["Fragrance"] = {
									["total"] = 446,
									["amount"] = 446,
								},
								["Myrony"] = {
									["total"] = 617,
									["overkill"] = 220,
									["amount"] = 617,
								},
							},
							["amount"] = 1890,
							["school"] = 1,
							["total"] = 1890,
							["overkill"] = 255,
						},
						[3044] = {
							["school"] = 64,
							["total"] = 364,
							["sources"] = {
								["Macius"] = {
									["total"] = 364,
									["amount"] = 364,
								},
							},
							["amount"] = 364,
						},
						[2643] = {
							["school"] = 1,
							["total"] = 112,
							["sources"] = {
								["Macius"] = {
									["total"] = 112,
									["amount"] = 112,
								},
							},
							["amount"] = 112,
						},
						[42223] = {
							["school"] = 4,
							["total"] = 340,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 340,
									["amount"] = 340,
								},
							},
							["amount"] = 340,
						},
						[686] = {
							["school"] = 32,
							["total"] = 165,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 165,
									["amount"] = 165,
								},
							},
							["amount"] = 165,
						},
						[53385] = {
							["school"] = 1,
							["total"] = 381,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 381,
									["amount"] = 381,
								},
							},
							["amount"] = 381,
						},
						[56641] = {
							["school"] = 1,
							["total"] = 457,
							["sources"] = {
								["Macius"] = {
									["total"] = 457,
									["amount"] = 457,
								},
							},
							["amount"] = 457,
						},
						[96172] = {
							["school"] = 2,
							["total"] = 3,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 3,
									["amount"] = 3,
								},
							},
							["amount"] = 3,
						},
						[2812] = {
							["school"] = 2,
							["total"] = 117,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 117,
									["amount"] = 117,
								},
							},
							["amount"] = 117,
						},
						[31935] = {
							["school"] = 2,
							["total"] = 729,
							["sources"] = {
								["Myrony"] = {
									["total"] = 729,
									["amount"] = 729,
								},
							},
							["amount"] = 729,
						},
						[20187] = {
							["school"] = 2,
							["total"] = 287,
							["sources"] = {
								["Myrony"] = {
									["total"] = 287,
									["amount"] = 287,
								},
							},
							["amount"] = 287,
						},
						[75] = {
							["school"] = 1,
							["total"] = 405,
							["sources"] = {
								["Macius"] = {
									["total"] = 405,
									["amount"] = 405,
								},
							},
							["amount"] = 405,
						},
						[81297] = {
							["school"] = 2,
							["total"] = 375,
							["sources"] = {
								["Myrony"] = {
									["total"] = 375,
									["amount"] = 375,
								},
							},
							["amount"] = 375,
						},
						[54049] = {
							["school"] = 32,
							["total"] = 160,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 160,
									["amount"] = 160,
								},
							},
							["amount"] = 160,
						},
						[7294] = {
							["school"] = 2,
							["total"] = 52,
							["sources"] = {
								["Myrony"] = {
									["total"] = 52,
									["amount"] = 52,
								},
							},
							["amount"] = 52,
						},
					},
					["name"] = "Putridus Trickster",
					["totaldamage"] = 747,
					["totaldamagetaken"] = 7194,
					["id"] = "0xF1302E0F0000003D",
					["damage"] = 747,
				}, -- [1]
				{
					["damagespells"] = {
						[21068] = {
							["school"] = 32,
							["total"] = 15,
							["targets"] = {
								["Fragrance"] = {
									["total"] = 15,
									["amount"] = 15,
								},
							},
							["amount"] = 15,
						},
					},
					["damagetaken"] = 840,
					["flag"] = 2632,
					["class"] = "MONSTER",
					["damagetakenspells"] = {
						[2812] = {
							["school"] = 2,
							["total"] = 94,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 94,
									["amount"] = 94,
								},
							},
							["amount"] = 94,
						},
						[53385] = {
							["sources"] = {
								["Fragrance"] = {
									["total"] = 197,
									["overkill"] = 171,
									["amount"] = 197,
								},
							},
							["amount"] = 197,
							["school"] = 1,
							["total"] = 197,
							["overkill"] = 171,
						},
						[96172] = {
							["school"] = 2,
							["total"] = 1,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 1,
									["amount"] = 1,
								},
							},
							["amount"] = 1,
						},
						[81297] = {
							["school"] = 2,
							["total"] = 150,
							["sources"] = {
								["Myrony"] = {
									["total"] = 150,
									["amount"] = 150,
								},
							},
							["amount"] = 150,
						},
						[2643] = {
							["school"] = 1,
							["total"] = 228,
							["sources"] = {
								["Macius"] = {
									["total"] = 228,
									["amount"] = 228,
								},
							},
							["amount"] = 228,
						},
						[42223] = {
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 170,
									["overkill"] = 63,
									["amount"] = 170,
								},
							},
							["amount"] = 170,
							["school"] = 4,
							["total"] = 170,
							["overkill"] = 63,
						},
					},
					["name"] = "Corruptor",
					["totaldamage"] = 15,
					["totaldamagetaken"] = 840,
					["id"] = "0xF1302FB90000003A",
					["damage"] = 15,
				}, -- [2]
				{
					["id"] = "0xF1302FB800000038",
					["name"] = "Poison Sprite",
					["totaldamagetaken"] = 321,
					["flag"] = 2632,
					["class"] = "MONSTER",
					["damagetaken"] = 321,
					["damagetakenspells"] = {
						[81297] = {
							["school"] = 2,
							["total"] = 60,
							["sources"] = {
								["Myrony"] = {
									["total"] = 60,
									["amount"] = 60,
								},
							},
							["amount"] = 60,
						},
						[2643] = {
							["school"] = 1,
							["total"] = 129,
							["sources"] = {
								["Macius"] = {
									["total"] = 129,
									["amount"] = 129,
								},
							},
							["amount"] = 129,
						},
						[42223] = {
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 85,
									["overkill"] = 50,
									["amount"] = 85,
								},
							},
							["amount"] = 85,
							["school"] = 4,
							["total"] = 85,
							["overkill"] = 50,
						},
						[2812] = {
							["school"] = 2,
							["total"] = 47,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 47,
									["amount"] = 47,
								},
							},
							["amount"] = 47,
						},
					},
				}, -- [3]
			},
			["ccdone"] = 7,
			["totaldamage"] = 8355,
			["time"] = 10,
			["totaldamagetaken"] = 762,
			["etotaldamagetaken"] = 8355,
			["damage"] = 8355,
			["players"] = {
				{
					["ccdonespells"] = {
						[2812] = {
							["count"] = 5,
							["targets"] = {
								["Poison Sprite"] = 1,
								["Putridus Trickster"] = 2,
								["Corruptor"] = 2,
							},
						},
					},
					["last"] = 10945.075,
					["flag"] = 1298,
					["class"] = "PALADIN",
					["auras"] = {
						[94686] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 1,
							["uptime"] = 7,
						},
						[139] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 2,
							["uptime"] = 5,
						},
						[2812] = {
							["type"] = "DEBUFF",
							["count"] = 5,
							["school"] = 2,
							["targets"] = {
								["Poison Sprite"] = {
									["uptime"] = 2,
									["count"] = 1,
								},
								["Putridus Trickster"] = {
									["uptime"] = 3,
									["count"] = 2,
								},
								["Corruptor"] = {
									["uptime"] = 3,
									["count"] = 2,
								},
							},
							["uptime"] = 3,
						},
					},
					["time"] = 9.32,
					["totaldamagetaken"] = 15,
					["damage"] = 1676,
					["damagespells"] = {
						["Crusader Strike"] = {
							["total"] = 309,
							["hitmin"] = 309,
							["id"] = 35395,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 309,
									["amount"] = 309,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 1,
							["hitmax"] = 309,
							["amount"] = 309,
							["hitamount"] = 309,
						},
						["Seal of Righteousness"] = {
							["total"] = 81,
							["hitmin"] = 27,
							["id"] = 25742,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 81,
									["amount"] = 81,
								},
							},
							["casts"] = 1,
							["count"] = 3,
							["hit"] = 3,
							["school"] = 2,
							["hitmax"] = 27,
							["amount"] = 81,
							["hitamount"] = 81,
						},
						["Divine Storm"] = {
							["total"] = 578,
							["hitmin"] = 183,
							["id"] = 53385,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 381,
									["amount"] = 381,
								},
								["Corruptor"] = {
									["total"] = 197,
									["overkill"] = 171,
									["amount"] = 197,
								},
							},
							["overkill"] = 171,
							["casts"] = 1,
							["count"] = 3,
							["hit"] = 3,
							["school"] = 1,
							["hitmax"] = 198,
							["amount"] = 578,
							["hitamount"] = 578,
						},
						["Melee"] = {
							["total"] = 446,
							["hitmin"] = 221,
							["id"] = 6603,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 446,
									["amount"] = 446,
								},
							},
							["count"] = 2,
							["hit"] = 2,
							["school"] = 1,
							["hitmax"] = 225,
							["amount"] = 446,
							["hitamount"] = 446,
						},
						["Hand of Light"] = {
							["total"] = 4,
							["hitmin"] = 1,
							["id"] = 96172,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 3,
									["amount"] = 3,
								},
								["Corruptor"] = {
									["total"] = 1,
									["amount"] = 1,
								},
							},
							["casts"] = 1,
							["count"] = 4,
							["hit"] = 4,
							["school"] = 2,
							["hitmax"] = 1,
							["amount"] = 4,
							["hitamount"] = 4,
						},
						["Holy Wrath"] = {
							["total"] = 258,
							["hitmin"] = 47,
							["criticalamount"] = 70,
							["id"] = 2812,
							["criticalmin"] = 70,
							["targets"] = {
								["Poison Sprite"] = {
									["total"] = 47,
									["amount"] = 47,
								},
								["Corruptor"] = {
									["total"] = 94,
									["amount"] = 94,
								},
								["Putridus Trickster"] = {
									["total"] = 117,
									["amount"] = 117,
								},
							},
							["criticalmax"] = 70,
							["critical"] = 1,
							["casts"] = 1,
							["count"] = 5,
							["hit"] = 4,
							["school"] = 2,
							["hitmax"] = 47,
							["amount"] = 258,
							["hitamount"] = 188,
						},
					},
					["damagetaken"] = 15,
					["id"] = "0x0000000000048007",
					["healspells"] = {
						[54172] = {
							["overheal"] = 169,
							["max"] = 25,
							["targets"] = {
								["Consecration"] = {
									["overheal"] = 23,
									["amount"] = 0,
								},
								["Nianhong"] = {
									["overheal"] = 24,
									["amount"] = 0,
								},
								["Myrony"] = {
									["overheal"] = 0,
									["amount"] = 25,
								},
								["Haapdhon"] = {
									["overheal"] = 44,
									["amount"] = 0,
								},
								["Beardedrasta"] = {
									["overheal"] = 56,
									["amount"] = 0,
								},
								["Fragrance"] = {
									["overheal"] = 0,
									["amount"] = 22,
								},
								["Macius"] = {
									["overheal"] = 22,
									["amount"] = 0,
								},
							},
							["min"] = 22,
							["casts"] = 9,
							["count"] = 9,
							["amount"] = 47,
							["school"] = 2,
							["ishot"] = true,
						},
					},
					["damagetakenspells"] = {
						["Corruption (DoT)"] = {
							["total"] = 15,
							["hitmin"] = 3,
							["id"] = 21068,
							["hitmax"] = 4,
							["sources"] = {
								["Corruptor"] = {
									["total"] = 15,
									["amount"] = 15,
								},
							},
							["count"] = 4,
							["hit"] = 4,
							["school"] = 32,
							["resisted"] = 5,
							["amount"] = 15,
							["hitamount"] = 15,
						},
					},
					["heal"] = 47,
					["name"] = "Fragrance",
					["ccdone"] = 5,
					["overkill"] = 171,
					["overheal"] = 169,
					["role"] = "DAMAGER",
					["totaldamage"] = 1676,
				}, -- [1]
				{
					["damagespells"] = {
						["Steady Shot"] = {
							["total"] = 457,
							["hitmin"] = 107,
							["id"] = 56641,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 457,
									["amount"] = 457,
								},
							},
							["casts"] = 4,
							["count"] = 4,
							["hit"] = 4,
							["school"] = 1,
							["hitmax"] = 124,
							["amount"] = 457,
							["hitamount"] = 457,
						},
						["Multi-Shot"] = {
							["total"] = 469,
							["hitmin"] = 105,
							["id"] = 2643,
							["targets"] = {
								["Poison Sprite"] = {
									["total"] = 129,
									["amount"] = 129,
								},
								["Corruptor"] = {
									["total"] = 228,
									["amount"] = 228,
								},
								["Putridus Trickster"] = {
									["total"] = 112,
									["amount"] = 112,
								},
							},
							["amount"] = 469,
							["casts"] = 1,
							["count"] = 5,
							["hit"] = 4,
							["school"] = 1,
							["hitmax"] = 129,
							["MISS"] = 1,
							["hitamount"] = 469,
						},
						["Claw (Cat)"] = {
							["total"] = 528,
							["hitmin"] = 88,
							["criticalamount"] = 352,
							["id"] = 16827,
							["hitmax"] = 88,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 528,
									["amount"] = 528,
								},
							},
							["count"] = 4,
							["hit"] = 2,
							["casts"] = 4,
							["critical"] = 2,
							["amount"] = 528,
							["school"] = 1,
							["criticalmin"] = 176,
							["criticalmax"] = 176,
							["hitamount"] = 176,
						},
						["Auto Shot"] = {
							["total"] = 405,
							["hitmin"] = 119,
							["id"] = 75,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 405,
									["amount"] = 405,
								},
							},
							["casts"] = 1,
							["count"] = 3,
							["hit"] = 3,
							["school"] = 1,
							["hitmax"] = 143,
							["amount"] = 405,
							["hitamount"] = 405,
						},
						["Melee (Cat)"] = {
							["total"] = 533,
							["hitmin"] = 52,
							["criticalamount"] = 360,
							["id"] = 6603,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 533,
									["amount"] = 533,
								},
							},
							["hitmax"] = 64,
							["count"] = 6,
							["criticalmax"] = 126,
							["critical"] = 3,
							["amount"] = 533,
							["school"] = 1,
							["hit"] = 3,
							["criticalmin"] = 116,
							["hitamount"] = 173,
						},
						["Arcane Shot"] = {
							["total"] = 364,
							["hitmin"] = 176,
							["id"] = 3044,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 364,
									["amount"] = 364,
								},
							},
							["casts"] = 2,
							["count"] = 2,
							["hit"] = 2,
							["school"] = 64,
							["hitmax"] = 188,
							["amount"] = 364,
							["hitamount"] = 364,
						},
					},
					["last"] = 10945.157,
					["id"] = "0x00000000000477A3",
					["flag"] = 4370,
					["class"] = "HUNTER",
					["totaldamage"] = 2756,
					["time"] = 9.299999999999999,
					["energyspells"] = {
						[91954] = 36,
					},
					["role"] = "DAMAGER",
					["name"] = "Macius",
					["energy"] = 36,
					["damage"] = 2756,
				}, -- [2]
				{
					["ccdonespells"] = {
						[31935] = {
							["count"] = 2,
							["targets"] = {
								["Putridus Trickster"] = 2,
							},
						},
					},
					["last"] = 10945.579,
					["flag"] = 1298,
					["class"] = "PALADIN",
					["auras"] = {
						[68055] = {
							["type"] = "DEBUFF",
							["count"] = 1,
							["school"] = 2,
							["targets"] = {
								["Putridus Trickster"] = {
									["uptime"] = 8,
									["count"] = 1,
								},
							},
							["uptime"] = 8,
						},
						[31935] = {
							["type"] = "DEBUFF",
							["count"] = 2,
							["school"] = 2,
							["targets"] = {
								["Putridus Trickster"] = {
									["uptime"] = 3,
									["count"] = 2,
								},
							},
							["uptime"] = 3,
						},
						[31930] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 2,
							["uptime"] = 8,
						},
						[139] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 2,
							["uptime"] = 1,
						},
					},
					["totaldamage"] = 2709,
					["time"] = 9.68,
					["totaldamagetaken"] = 747,
					["damage"] = 2709,
					["damagespells"] = {
						["Crusader Strike"] = {
							["total"] = 329,
							["hitmin"] = 329,
							["id"] = 35395,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 329,
									["amount"] = 329,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 1,
							["hitmax"] = 329,
							["amount"] = 329,
							["hitamount"] = 329,
						},
						["Seal of Righteousness"] = {
							["total"] = 110,
							["hitmin"] = 22,
							["id"] = 25742,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 110,
									["overkill"] = 16,
									["amount"] = 110,
								},
							},
							["overkill"] = 16,
							["casts"] = 1,
							["count"] = 5,
							["hit"] = 5,
							["school"] = 2,
							["hitmax"] = 22,
							["amount"] = 110,
							["hitamount"] = 110,
						},
						["Melee"] = {
							["criticalmin"] = 220,
							["total"] = 617,
							["hitmin"] = 123,
							["criticalamount"] = 220,
							["id"] = 6603,
							["amount"] = 617,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 617,
									["overkill"] = 220,
									["amount"] = 617,
								},
							},
							["overkill"] = 220,
							["critical"] = 1,
							["criticalmax"] = 220,
							["count"] = 5,
							["hit"] = 3,
							["school"] = 1,
							["hitmax"] = 138,
							["MISS"] = 1,
							["hitamount"] = 397,
						},
						["Consecration"] = {
							["total"] = 585,
							["hitmin"] = 30,
							["criticalamount"] = 45,
							["id"] = 81297,
							["criticalmin"] = 45,
							["targets"] = {
								["Poison Sprite"] = {
									["total"] = 60,
									["amount"] = 60,
								},
								["Corruptor"] = {
									["total"] = 150,
									["amount"] = 150,
								},
								["Putridus Trickster"] = {
									["total"] = 375,
									["amount"] = 375,
								},
							},
							["criticalmax"] = 45,
							["critical"] = 1,
							["casts"] = 1,
							["count"] = 19,
							["hit"] = 18,
							["school"] = 2,
							["hitmax"] = 30,
							["amount"] = 585,
							["hitamount"] = 540,
						},
						["Avenger's Shield"] = {
							["total"] = 729,
							["hitmin"] = 345,
							["id"] = 31935,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 729,
									["amount"] = 729,
								},
							},
							["casts"] = 1,
							["count"] = 2,
							["hit"] = 2,
							["school"] = 2,
							["hitmax"] = 384,
							["amount"] = 729,
							["hitamount"] = 729,
						},
						["Retribution Aura"] = {
							["total"] = 52,
							["hitmin"] = 13,
							["id"] = 7294,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 52,
									["amount"] = 52,
								},
							},
							["casts"] = 1,
							["count"] = 4,
							["hit"] = 4,
							["school"] = 2,
							["hitmax"] = 13,
							["amount"] = 52,
							["hitamount"] = 52,
						},
						["Judgement of Righteousness"] = {
							["total"] = 287,
							["hitmin"] = 287,
							["id"] = 20187,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 287,
									["amount"] = 287,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 2,
							["hitmax"] = 287,
							["amount"] = 287,
							["hitamount"] = 287,
						},
					},
					["overkill"] = 236,
					["damagetaken"] = 747,
					["id"] = "0x00000000000447DB",
					["healspells"] = {
						[85673] = {
							["overheal"] = 0,
							["count"] = 1,
							["amount"] = 897,
							["school"] = 2,
							["max"] = 897,
							["targets"] = {
								["Myrony"] = {
									["overheal"] = 0,
									["amount"] = 897,
								},
							},
							["min"] = 897,
						},
					},
					["damagetakenspells"] = {
						["Melee"] = {
							["total"] = 747,
							["hitmin"] = 174,
							["id"] = 6603,
							["hit"] = 4,
							["hitmax"] = 199,
							["PARRY"] = 3,
							["count"] = 9,
							["amount"] = 747,
							["school"] = 1,
							["sources"] = {
								["Putridus Trickster"] = {
									["total"] = 747,
									["amount"] = 747,
								},
							},
							["MISS"] = 2,
							["hitamount"] = 747,
						},
					},
					["overheal"] = 0,
					["heal"] = 897,
					["manaspells"] = {
						[31930] = 240,
						[84627] = 138,
					},
					["ccdone"] = 2,
					["name"] = "Myrony",
					["mana"] = 378,
					["role"] = "TANK",
				}, -- [3]
				{
					["damagespells"] = {
						["Shadow Bolt"] = {
							["total"] = 165,
							["hitmin"] = 165,
							["id"] = 686,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 165,
									["amount"] = 165,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 32,
							["hitmax"] = 165,
							["amount"] = 165,
							["hitamount"] = 165,
						},
						["Melee (Haapdhon)"] = {
							["total"] = 294,
							["hitmin"] = 62,
							["id"] = 6603,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 294,
									["overkill"] = 35,
									["amount"] = 294,
								},
							},
							["overkill"] = 35,
							["glancing"] = 2,
							["count"] = 5,
							["hit"] = 3,
							["school"] = 1,
							["hitmax"] = 67,
							["amount"] = 294,
							["hitamount"] = 194,
						},
						["Shadow Bite (Haapdhon)"] = {
							["total"] = 160,
							["hitmin"] = 80,
							["id"] = 54049,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 160,
									["amount"] = 160,
								},
							},
							["casts"] = 2,
							["count"] = 2,
							["hit"] = 2,
							["school"] = 32,
							["hitmax"] = 80,
							["amount"] = 160,
							["hitamount"] = 160,
						},
						["Rain of Fire"] = {
							["total"] = 595,
							["hitmin"] = 85,
							["id"] = 42223,
							["targets"] = {
								["Poison Sprite"] = {
									["total"] = 85,
									["overkill"] = 50,
									["amount"] = 85,
								},
								["Putridus Trickster"] = {
									["total"] = 340,
									["amount"] = 340,
								},
								["Corruptor"] = {
									["total"] = 170,
									["overkill"] = 63,
									["amount"] = 170,
								},
							},
							["overkill"] = 113,
							["casts"] = 1,
							["count"] = 7,
							["hit"] = 7,
							["school"] = 4,
							["hitmax"] = 85,
							["amount"] = 595,
							["hitamount"] = 595,
						},
					},
					["last"] = 10944.349,
					["id"] = "0x000000000004825C",
					["class"] = "WARLOCK",
					["flag"] = 4369,
					["overkill"] = 148,
					["totaldamage"] = 1214,
					["role"] = "DAMAGER",
					["time"] = 5.6,
					["name"] = "Beardedrasta",
					["spec"] = 265,
					["damage"] = 1214,
				}, -- [4]
				{
					["overheal"] = 0,
					["last"] = 10944.245,
					["flag"] = 1298,
					["class"] = "PRIEST",
					["healspells"] = {
						[139] = {
							["overheal"] = 0,
							["max"] = 175,
							["targets"] = {
								["Fragrance"] = {
									["overheal"] = 0,
									["amount"] = 132,
								},
								["Myrony"] = {
									["overheal"] = 0,
									["amount"] = 175,
								},
							},
							["min"] = 132,
							["casts"] = 3,
							["count"] = 2,
							["amount"] = 307,
							["school"] = 2,
							["ishot"] = true,
						},
						[63544] = {
							["overheal"] = 0,
							["count"] = 2,
							["amount"] = 122,
							["school"] = 2,
							["max"] = 70,
							["targets"] = {
								["Fragrance"] = {
									["overheal"] = 0,
									["amount"] = 52,
								},
								["Myrony"] = {
									["overheal"] = 0,
									["amount"] = 70,
								},
							},
							["min"] = 52,
						},
					},
					["role"] = "HEALER",
					["name"] = "Nianhong",
					["heal"] = 429,
					["time"] = 6.5,
					["id"] = "0x00000000000467C0",
				}, -- [5]
				{
					["last"] = 10938.619,
					["name"] = "Haapdhon",
					["flag"] = 4369,
					["class"] = "PET",
					["id"] = "0xF143011D00000006",
					["time"] = 0,
				}, -- [6]
				{
					["last"] = 10938.634,
					["name"] = "Consecration",
					["flag"] = 4370,
					["class"] = "PET",
					["id"] = "0xF130A9EB000001F2",
					["time"] = 0,
				}, -- [7]
			},
			["type"] = "party",
			["damagetaken"] = 762,
			["overheal"] = 169,
			["etotaldamage"] = 762,
			["energy"] = 36,
			["overkill"] = 555,
			["edamagetaken"] = 8355,
			["heal"] = 1373,
			["name"] = "Putridus Trickster (2)",
			["mobname"] = "Putridus Trickster",
			["starttime"] = 1689857804,
			["edamage"] = 762,
			["last_action"] = 1689857814,
			["endtime"] = 1689857814,
		}, -- [3]
		{
			["mana"] = 632,
			["enemies"] = {
				{
					["damagespells"] = {
						[21337] = {
							["school"] = 8,
							["total"] = 21,
							["targets"] = {
								["Fragrance"] = {
									["total"] = 21,
									["amount"] = 21,
								},
							},
							["amount"] = 21,
						},
						[21331] = {
							["school"] = 8,
							["total"] = 39,
							["targets"] = {
								["Fragrance"] = {
									["total"] = 22,
									["amount"] = 22,
								},
								["Myrony"] = {
									["total"] = 17,
									["amount"] = 17,
								},
							},
							["amount"] = 39,
						},
					},
					["damagetaken"] = 2364,
					["flag"] = 68168,
					["class"] = "MONSTER",
					["damagetakenspells"] = {
						[6603] = {
							["school"] = 1,
							["total"] = 375,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 41,
									["amount"] = 41,
								},
								["Fragrance"] = {
									["total"] = 223,
									["amount"] = 223,
								},
								["Myrony"] = {
									["total"] = 111,
									["amount"] = 111,
								},
							},
							["amount"] = 375,
						},
						[20187] = {
							["school"] = 2,
							["total"] = 363,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 128,
									["amount"] = 128,
								},
								["Myrony"] = {
									["total"] = 235,
									["amount"] = 235,
								},
							},
							["amount"] = 363,
						},
						[980] = {
							["school"] = 32,
							["total"] = 23,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 23,
									["amount"] = 23,
								},
							},
							["amount"] = 23,
						},
						[35395] = {
							["sources"] = {
								["Fragrance"] = {
									["total"] = 314,
									["overkill"] = 234,
									["amount"] = 314,
								},
							},
							["amount"] = 314,
							["school"] = 1,
							["total"] = 314,
							["overkill"] = 234,
						},
						[879] = {
							["school"] = 2,
							["total"] = 705,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 705,
									["amount"] = 705,
								},
							},
							["amount"] = 705,
						},
						[25742] = {
							["school"] = 2,
							["total"] = 71,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 54,
									["amount"] = 54,
								},
								["Myrony"] = {
									["total"] = 17,
									["amount"] = 17,
								},
							},
							["amount"] = 71,
						},
						[96172] = {
							["school"] = 2,
							["total"] = 1,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 1,
									["amount"] = 1,
								},
							},
							["amount"] = 1,
						},
						[3044] = {
							["school"] = 64,
							["total"] = 323,
							["sources"] = {
								["Macius"] = {
									["total"] = 323,
									["amount"] = 323,
								},
							},
							["amount"] = 323,
						},
						[75] = {
							["school"] = 1,
							["total"] = 147,
							["sources"] = {
								["Macius"] = {
									["total"] = 147,
									["amount"] = 147,
								},
							},
							["amount"] = 147,
						},
						[172] = {
							["school"] = 32,
							["total"] = 42,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 42,
									["amount"] = 42,
								},
							},
							["amount"] = 42,
						},
					},
					["name"] = "Deeprot Tangler",
					["totaldamage"] = 60,
					["totaldamagetaken"] = 2364,
					["id"] = "0xF13033560000001C",
					["damage"] = 60,
				}, -- [1]
				{
					["damagespells"] = {
						[6603] = {
							["school"] = 1,
							["total"] = 417,
							["targets"] = {
								["Myrony"] = {
									["total"] = 417,
									["amount"] = 417,
								},
							},
							["amount"] = 417,
						},
						[13446] = {
							["school"] = 1,
							["total"] = 239,
							["targets"] = {
								["Myrony"] = {
									["total"] = 239,
									["amount"] = 239,
								},
							},
							["amount"] = 239,
						},
					},
					["damagetaken"] = 4700,
					["flag"] = 68168,
					["class"] = "MONSTER",
					["damagetakenspells"] = {
						[31935] = {
							["school"] = 2,
							["total"] = 308,
							["sources"] = {
								["Myrony"] = {
									["total"] = 308,
									["amount"] = 308,
								},
							},
							["amount"] = 308,
						},
						[6603] = {
							["school"] = 1,
							["total"] = 715,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 131,
									["amount"] = 131,
								},
								["Macius"] = {
									["total"] = 179,
									["amount"] = 179,
								},
								["Fragrance"] = {
									["total"] = 182,
									["amount"] = 182,
								},
								["Myrony"] = {
									["total"] = 223,
									["amount"] = 223,
								},
							},
							["amount"] = 715,
						},
						[7294] = {
							["school"] = 2,
							["total"] = 26,
							["sources"] = {
								["Myrony"] = {
									["total"] = 26,
									["amount"] = 26,
								},
							},
							["amount"] = 26,
						},
						[16827] = {
							["school"] = 1,
							["total"] = 261,
							["sources"] = {
								["Macius"] = {
									["total"] = 261,
									["amount"] = 261,
								},
							},
							["amount"] = 261,
						},
						[96172] = {
							["school"] = 2,
							["total"] = 1,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 1,
									["amount"] = 1,
								},
							},
							["amount"] = 1,
						},
						[980] = {
							["school"] = 32,
							["total"] = 24,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 24,
									["amount"] = 24,
								},
							},
							["amount"] = 24,
						},
						[35395] = {
							["school"] = 1,
							["total"] = 1595,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 702,
									["amount"] = 702,
								},
								["Myrony"] = {
									["total"] = 893,
									["amount"] = 893,
								},
							},
							["amount"] = 1595,
						},
						[75] = {
							["sources"] = {
								["Macius"] = {
									["total"] = 373,
									["overkill"] = 48,
									["amount"] = 373,
								},
							},
							["amount"] = 373,
							["school"] = 1,
							["total"] = 373,
							["overkill"] = 48,
						},
						[25742] = {
							["school"] = 2,
							["total"] = 98,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 27,
									["amount"] = 27,
								},
								["Myrony"] = {
									["total"] = 71,
									["amount"] = 71,
								},
							},
							["amount"] = 98,
						},
						[54049] = {
							["school"] = 32,
							["total"] = 152,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 152,
									["amount"] = 152,
								},
							},
							["amount"] = 152,
						},
						[3044] = {
							["school"] = 64,
							["total"] = 193,
							["sources"] = {
								["Macius"] = {
									["total"] = 193,
									["amount"] = 193,
								},
							},
							["amount"] = 193,
						},
						[2812] = {
							["school"] = 2,
							["total"] = 426,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 426,
									["amount"] = 426,
								},
							},
							["amount"] = 426,
						},
						[30108] = {
							["school"] = 32,
							["total"] = 98,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 98,
									["amount"] = 98,
								},
							},
							["amount"] = 98,
						},
						[172] = {
							["school"] = 32,
							["total"] = 88,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 88,
									["amount"] = 88,
								},
							},
							["amount"] = 88,
						},
						[56641] = {
							["school"] = 1,
							["total"] = 342,
							["sources"] = {
								["Macius"] = {
									["total"] = 342,
									["amount"] = 342,
								},
							},
							["amount"] = 342,
						},
					},
					["name"] = "Deeprot Stomper",
					["totaldamage"] = 656,
					["totaldamagetaken"] = 4700,
					["id"] = "0xF13033550000001B",
					["damage"] = 656,
				}, -- [2]
			},
			["starttime"] = 1689857783,
			["totaldamage"] = 7064,
			["time"] = 11,
			["totaldamagetaken"] = 716,
			["etotaldamagetaken"] = 7064,
			["damage"] = 7064,
			["players"] = {
				{
					["last"] = 10924.815,
					["flag"] = 1297,
					["class"] = "WARLOCK",
					["auras"] = {
						[980] = {
							["type"] = "DEBUFF",
							["count"] = 2,
							["school"] = 32,
							["targets"] = {
								["Deeprot Tangler"] = {
									["uptime"] = 2,
									["count"] = 1,
								},
								["Deeprot Stomper"] = {
									["uptime"] = 5,
									["count"] = 1,
								},
							},
							["uptime"] = 7,
						},
						[30108] = {
							["type"] = "DEBUFF",
							["count"] = 1,
							["school"] = 32,
							["targets"] = {
								["Deeprot Stomper"] = {
									["uptime"] = 6,
									["count"] = 1,
								},
							},
							["uptime"] = 6,
						},
						[172] = {
							["type"] = "DEBUFF",
							["count"] = 2,
							["school"] = 32,
							["targets"] = {
								["Deeprot Tangler"] = {
									["uptime"] = 4,
									["count"] = 1,
								},
								["Deeprot Stomper"] = {
									["uptime"] = 6,
									["count"] = 1,
								},
							},
							["uptime"] = 10,
						},
						[1120] = {
							["type"] = "DEBUFF",
							["count"] = 1,
							["school"] = 32,
							["targets"] = {
								["Deeprot Stomper"] = {
									["uptime"] = 1,
									["count"] = 1,
								},
							},
							["uptime"] = 1,
						},
					},
					["time"] = 9.91,
					["damage"] = 599,
					["overheal"] = 33,
					["id"] = "0x000000000004825C",
					["spec"] = 265,
					["healspells"] = {
						[63106] = {
							["overheal"] = 33,
							["count"] = 1,
							["amount"] = 0,
							["school"] = 32,
							["targets"] = {
								["Beardedrasta"] = {
									["overheal"] = 33,
									["amount"] = 0,
								},
							},
						},
					},
					["heal"] = 0,
					["name"] = "Beardedrasta",
					["damagespells"] = {
						["Bane of Agony (DoT)"] = {
							["total"] = 47,
							["hitmin"] = 12,
							["criticalamount"] = 23,
							["id"] = 980,
							["hitmax"] = 12,
							["targets"] = {
								["Deeprot Tangler"] = {
									["total"] = 23,
									["amount"] = 23,
								},
								["Deeprot Stomper"] = {
									["total"] = 24,
									["amount"] = 24,
								},
							},
							["count"] = 3,
							["hit"] = 2,
							["criticalmax"] = 23,
							["critical"] = 1,
							["amount"] = 47,
							["school"] = 32,
							["casts"] = 2,
							["criticalmin"] = 23,
							["hitamount"] = 24,
						},
						["Shadow Bite (Haapdhon)"] = {
							["total"] = 152,
							["hitmin"] = 152,
							["id"] = 54049,
							["targets"] = {
								["Deeprot Tangler"] = {
									["total"] = 0,
									["amount"] = 0,
								},
								["Deeprot Stomper"] = {
									["total"] = 152,
									["amount"] = 152,
								},
							},
							["hitmax"] = 152,
							["casts"] = 2,
							["count"] = 2,
							["amount"] = 152,
							["school"] = 32,
							["hit"] = 1,
							["MISS"] = 1,
							["hitamount"] = 152,
						},
						["Corruption (DoT)"] = {
							["total"] = 130,
							["hitmin"] = 42,
							["id"] = 172,
							["targets"] = {
								["Deeprot Tangler"] = {
									["total"] = 42,
									["amount"] = 42,
								},
								["Deeprot Stomper"] = {
									["total"] = 88,
									["amount"] = 88,
								},
							},
							["casts"] = 2,
							["count"] = 3,
							["hit"] = 3,
							["school"] = 32,
							["hitmax"] = 44,
							["amount"] = 130,
							["hitamount"] = 130,
						},
						["Unstable Affliction (DoT)"] = {
							["total"] = 98,
							["hitmin"] = 49,
							["id"] = 30108,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 98,
									["amount"] = 98,
								},
							},
							["casts"] = 2,
							["count"] = 2,
							["hit"] = 2,
							["school"] = 32,
							["hitmax"] = 49,
							["amount"] = 98,
							["hitamount"] = 98,
						},
						["Melee (Haapdhon)"] = {
							["DODGE"] = 1,
							["total"] = 172,
							["hitmin"] = 62,
							["id"] = 6603,
							["targets"] = {
								["Deeprot Tangler"] = {
									["total"] = 41,
									["amount"] = 41,
								},
								["Deeprot Stomper"] = {
									["total"] = 131,
									["amount"] = 131,
								},
							},
							["glancing"] = 1,
							["count"] = 4,
							["hit"] = 2,
							["school"] = 1,
							["hitmax"] = 69,
							["amount"] = 172,
							["hitamount"] = 131,
						},
					},
					["totaldamage"] = 599,
					["role"] = "DAMAGER",
				}, -- [1]
				{
					["ccdonespells"] = {
						[31935] = {
							["count"] = 1,
							["targets"] = {
								["Deeprot Stomper"] = 1,
							},
						},
					},
					["last"] = 10922.931,
					["flag"] = 1298,
					["class"] = "PALADIN",
					["auras"] = {
						[68055] = {
							["type"] = "DEBUFF",
							["count"] = 1,
							["school"] = 2,
							["targets"] = {
								["Deeprot Tangler"] = {
									["uptime"] = 3,
									["count"] = 1,
								},
							},
							["uptime"] = 3,
						},
						[31935] = {
							["type"] = "DEBUFF",
							["count"] = 1,
							["school"] = 2,
							["targets"] = {
								["Deeprot Stomper"] = {
									["uptime"] = 3,
									["count"] = 1,
								},
							},
							["uptime"] = 3,
						},
						[31930] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 2,
							["uptime"] = 10,
						},
					},
					["totaldamage"] = 1884,
					["time"] = 7.989999999999998,
					["totaldamagetaken"] = 673,
					["damage"] = 1884,
					["damagespells"] = {
						["Seal of Righteousness"] = {
							["total"] = 88,
							["hitmin"] = 17,
							["id"] = 25742,
							["targets"] = {
								["Deeprot Tangler"] = {
									["total"] = 17,
									["amount"] = 17,
								},
								["Deeprot Stomper"] = {
									["total"] = 71,
									["amount"] = 71,
								},
							},
							["casts"] = 1,
							["count"] = 5,
							["hit"] = 5,
							["school"] = 2,
							["hitmax"] = 18,
							["amount"] = 88,
							["hitamount"] = 88,
						},
						["Crusader Strike"] = {
							["total"] = 893,
							["hitmin"] = 349,
							["criticalamount"] = 544,
							["id"] = 35395,
							["hitmax"] = 349,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 893,
									["amount"] = 893,
								},
							},
							["count"] = 2,
							["hit"] = 1,
							["casts"] = 2,
							["critical"] = 1,
							["amount"] = 893,
							["school"] = 1,
							["criticalmin"] = 544,
							["criticalmax"] = 544,
							["hitamount"] = 349,
						},
						["Melee"] = {
							["DODGE"] = 1,
							["total"] = 334,
							["hitmin"] = 111,
							["id"] = 6603,
							["targets"] = {
								["Deeprot Tangler"] = {
									["total"] = 111,
									["amount"] = 111,
								},
								["Deeprot Stomper"] = {
									["total"] = 223,
									["amount"] = 223,
								},
							},
							["count"] = 4,
							["hit"] = 3,
							["school"] = 1,
							["hitmax"] = 112,
							["amount"] = 334,
							["hitamount"] = 334,
						},
						["Avenger's Shield"] = {
							["total"] = 308,
							["hitmin"] = 308,
							["id"] = 31935,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 308,
									["amount"] = 308,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 2,
							["hitmax"] = 308,
							["amount"] = 308,
							["hitamount"] = 308,
						},
						["Retribution Aura"] = {
							["total"] = 26,
							["hitmin"] = 13,
							["id"] = 7294,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 26,
									["amount"] = 26,
								},
							},
							["casts"] = 1,
							["count"] = 2,
							["hit"] = 2,
							["school"] = 2,
							["hitmax"] = 13,
							["amount"] = 26,
							["hitamount"] = 26,
						},
						["Judgement of Righteousness"] = {
							["total"] = 235,
							["hitmin"] = 235,
							["id"] = 20187,
							["targets"] = {
								["Deeprot Tangler"] = {
									["total"] = 235,
									["amount"] = 235,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 2,
							["hitmax"] = 235,
							["amount"] = 235,
							["hitamount"] = 235,
						},
					},
					["damagetaken"] = 673,
					["id"] = "0x00000000000447DB",
					["damagetakenspells"] = {
						["Strike"] = {
							["total"] = 239,
							["hitmin"] = 239,
							["id"] = 13446,
							["sources"] = {
								["Deeprot Stomper"] = {
									["total"] = 239,
									["amount"] = 239,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 1,
							["hitmax"] = 239,
							["amount"] = 239,
							["hitamount"] = 239,
						},
						["Entangling Roots (DoT)"] = {
							["total"] = 17,
							["hitmin"] = 8,
							["id"] = 21331,
							["hitmax"] = 9,
							["sources"] = {
								["Deeprot Tangler"] = {
									["total"] = 17,
									["amount"] = 17,
								},
							},
							["count"] = 2,
							["hit"] = 2,
							["school"] = 8,
							["resisted"] = 3,
							["amount"] = 17,
							["hitamount"] = 17,
						},
						["Melee"] = {
							["total"] = 417,
							["hitmin"] = 205,
							["id"] = 6603,
							["PARRY"] = 1,
							["sources"] = {
								["Deeprot Stomper"] = {
									["total"] = 417,
									["amount"] = 417,
								},
							},
							["count"] = 3,
							["hit"] = 2,
							["school"] = 1,
							["hitmax"] = 212,
							["amount"] = 417,
							["hitamount"] = 417,
						},
					},
					["name"] = "Myrony",
					["ccdone"] = 1,
					["manaspells"] = {
						[31930] = 300,
						[84627] = 92,
					},
					["mana"] = 392,
					["role"] = "TANK",
				}, -- [2]
				{
					["last"] = 10923.667,
					["flag"] = 1298,
					["class"] = "PALADIN",
					["auras"] = {
						[94686] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 1,
							["uptime"] = 7,
						},
						[59578] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 1,
							["uptime"] = 1,
						},
						[89906] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 2,
							["uptime"] = 10,
						},
					},
					["totaldamage"] = 2763,
					["time"] = 8.42,
					["totaldamagetaken"] = 43,
					["damage"] = 2763,
					["damagespells"] = {
						["Exorcism"] = {
							["total"] = 705,
							["hitmin"] = 705,
							["id"] = 879,
							["targets"] = {
								["Deeprot Tangler"] = {
									["total"] = 705,
									["amount"] = 705,
								},
							},
							["casts"] = 2,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 2,
							["hitmax"] = 705,
							["amount"] = 705,
							["hitamount"] = 705,
						},
						["Seal of Righteousness"] = {
							["total"] = 81,
							["hitmin"] = 27,
							["id"] = 25742,
							["targets"] = {
								["Deeprot Tangler"] = {
									["total"] = 54,
									["amount"] = 54,
								},
								["Deeprot Stomper"] = {
									["total"] = 27,
									["amount"] = 27,
								},
							},
							["casts"] = 1,
							["count"] = 3,
							["hit"] = 3,
							["school"] = 2,
							["hitmax"] = 27,
							["amount"] = 81,
							["hitamount"] = 81,
						},
						["Holy Wrath"] = {
							["total"] = 426,
							["criticalamount"] = 426,
							["id"] = 2812,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 426,
									["amount"] = 426,
								},
							},
							["casts"] = 1,
							["critical"] = 1,
							["amount"] = 426,
							["school"] = 2,
							["criticalmin"] = 426,
							["criticalmax"] = 426,
							["count"] = 1,
						},
						["Crusader Strike"] = {
							["criticalmin"] = 702,
							["total"] = 1016,
							["hitmin"] = 314,
							["criticalamount"] = 702,
							["id"] = 35395,
							["criticalmax"] = 702,
							["targets"] = {
								["Deeprot Tangler"] = {
									["total"] = 314,
									["overkill"] = 234,
									["amount"] = 314,
								},
								["Deeprot Stomper"] = {
									["total"] = 702,
									["amount"] = 702,
								},
							},
							["overkill"] = 234,
							["critical"] = 1,
							["casts"] = 2,
							["count"] = 2,
							["amount"] = 1016,
							["school"] = 1,
							["hitmax"] = 314,
							["hit"] = 1,
							["hitamount"] = 314,
						},
						["Hand of Light"] = {
							["total"] = 2,
							["hitmin"] = 1,
							["id"] = 96172,
							["targets"] = {
								["Deeprot Tangler"] = {
									["total"] = 1,
									["amount"] = 1,
								},
								["Deeprot Stomper"] = {
									["total"] = 1,
									["amount"] = 1,
								},
							},
							["casts"] = 1,
							["count"] = 2,
							["hit"] = 2,
							["school"] = 2,
							["hitmax"] = 1,
							["amount"] = 2,
							["hitamount"] = 2,
						},
						["Melee"] = {
							["total"] = 405,
							["hitmin"] = 182,
							["id"] = 6603,
							["targets"] = {
								["Deeprot Tangler"] = {
									["total"] = 223,
									["amount"] = 223,
								},
								["Deeprot Stomper"] = {
									["total"] = 182,
									["amount"] = 182,
								},
							},
							["count"] = 2,
							["hit"] = 2,
							["school"] = 1,
							["hitmax"] = 223,
							["amount"] = 405,
							["hitamount"] = 405,
						},
						["Judgement of Righteousness"] = {
							["total"] = 128,
							["hitmin"] = 128,
							["id"] = 20187,
							["targets"] = {
								["Deeprot Tangler"] = {
									["total"] = 128,
									["amount"] = 128,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 2,
							["hitmax"] = 128,
							["amount"] = 128,
							["hitamount"] = 128,
						},
					},
					["damagetaken"] = 43,
					["id"] = "0x0000000000048007",
					["damagetakenspells"] = {
						["Entangling Roots (DoT)"] = {
							["total"] = 22,
							["hitmin"] = 11,
							["id"] = 21331,
							["hitmax"] = 11,
							["sources"] = {
								["Deeprot Tangler"] = {
									["total"] = 22,
									["amount"] = 22,
								},
							},
							["count"] = 2,
							["hit"] = 2,
							["school"] = 8,
							["resisted"] = 2,
							["amount"] = 22,
							["hitamount"] = 22,
						},
						["Thorns"] = {
							["total"] = 21,
							["hitmin"] = 21,
							["id"] = 21337,
							["sources"] = {
								["Deeprot Tangler"] = {
									["total"] = 21,
									["amount"] = 21,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 8,
							["hitmax"] = 21,
							["amount"] = 21,
							["hitamount"] = 21,
						},
					},
					["overkill"] = 234,
					["name"] = "Fragrance",
					["manaspells"] = {
						[89906] = 240,
					},
					["mana"] = 240,
					["role"] = "DAMAGER",
				}, -- [3]
				{
					["damagespells"] = {
						["Steady Shot"] = {
							["total"] = 342,
							["hitmin"] = 101,
							["id"] = 56641,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 342,
									["amount"] = 342,
								},
							},
							["casts"] = 2,
							["count"] = 3,
							["hit"] = 3,
							["school"] = 1,
							["hitmax"] = 126,
							["amount"] = 342,
							["hitamount"] = 342,
						},
						["Claw (Cat)"] = {
							["total"] = 261,
							["hitmin"] = 86,
							["id"] = 16827,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 261,
									["amount"] = 261,
								},
							},
							["casts"] = 3,
							["count"] = 3,
							["hit"] = 3,
							["school"] = 1,
							["hitmax"] = 88,
							["amount"] = 261,
							["hitamount"] = 261,
						},
						["Auto Shot"] = {
							["total"] = 520,
							["hitmin"] = 121,
							["id"] = 75,
							["targets"] = {
								["Deeprot Tangler"] = {
									["total"] = 147,
									["amount"] = 147,
								},
								["Deeprot Stomper"] = {
									["total"] = 373,
									["overkill"] = 48,
									["amount"] = 373,
								},
							},
							["overkill"] = 48,
							["casts"] = 1,
							["count"] = 4,
							["hit"] = 4,
							["school"] = 1,
							["hitmax"] = 147,
							["amount"] = 520,
							["hitamount"] = 520,
						},
						["Melee (Cat)"] = {
							["DODGE"] = 1,
							["total"] = 179,
							["hitmin"] = 55,
							["criticalamount"] = 124,
							["id"] = 6603,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 179,
									["amount"] = 179,
								},
							},
							["hitmax"] = 55,
							["count"] = 3,
							["criticalmax"] = 124,
							["critical"] = 1,
							["amount"] = 179,
							["school"] = 1,
							["hit"] = 1,
							["criticalmin"] = 124,
							["hitamount"] = 55,
						},
						["Arcane Shot"] = {
							["total"] = 516,
							["hitmin"] = 160,
							["id"] = 3044,
							["targets"] = {
								["Deeprot Tangler"] = {
									["total"] = 323,
									["amount"] = 323,
								},
								["Deeprot Stomper"] = {
									["total"] = 193,
									["amount"] = 193,
								},
							},
							["casts"] = 3,
							["count"] = 3,
							["hit"] = 3,
							["school"] = 64,
							["hitmax"] = 193,
							["amount"] = 516,
							["hitamount"] = 516,
						},
					},
					["last"] = 10925.134,
					["flag"] = 1298,
					["id"] = "0x00000000000477A3",
					["class"] = "HUNTER",
					["time"] = 8.799999999999999,
					["overkill"] = 48,
					["energyspells"] = {
						[91954] = 27,
					},
					["name"] = "Macius",
					["totaldamage"] = 1818,
					["role"] = "DAMAGER",
					["energy"] = 27,
					["damage"] = 1818,
				}, -- [4]
			},
			["type"] = "party",
			["damagetaken"] = 716,
			["overheal"] = 33,
			["ccdone"] = 1,
			["energy"] = 27,
			["overkill"] = 282,
			["edamagetaken"] = 7064,
			["heal"] = 0,
			["name"] = "Deeprot Tangler",
			["mobname"] = "Deeprot Tangler",
			["etotaldamage"] = 716,
			["edamage"] = 716,
			["last_action"] = 1689857794,
			["endtime"] = 1689857794,
		}, -- [4]
		{
			["mana"] = 1341,
			["enemies"] = {
				{
					["damagespells"] = {
						[6603] = {
							["school"] = 1,
							["total"] = 165,
							["targets"] = {
								["Myrony"] = {
									["total"] = 165,
									["amount"] = 165,
								},
							},
							["amount"] = 165,
						},
						[11876] = {
							["school"] = 1,
							["total"] = 184,
							["targets"] = {
								["Fragrance"] = {
									["total"] = 184,
									["amount"] = 184,
								},
							},
							["amount"] = 184,
						},
					},
					["damagetaken"] = 3759,
					["flag"] = 2632,
					["class"] = "MONSTER",
					["damagetakenspells"] = {
						[31935] = {
							["school"] = 2,
							["total"] = 372,
							["sources"] = {
								["Myrony"] = {
									["total"] = 372,
									["amount"] = 372,
								},
							},
							["amount"] = 372,
						},
						[53595] = {
							["school"] = 1,
							["total"] = 37,
							["sources"] = {
								["Myrony"] = {
									["total"] = 37,
									["amount"] = 37,
								},
							},
							["amount"] = 37,
						},
						[7294] = {
							["school"] = 2,
							["total"] = 13,
							["sources"] = {
								["Myrony"] = {
									["total"] = 13,
									["amount"] = 13,
								},
							},
							["amount"] = 13,
						},
						[20187] = {
							["school"] = 2,
							["total"] = 268,
							["sources"] = {
								["Myrony"] = {
									["total"] = 268,
									["amount"] = 268,
								},
							},
							["amount"] = 268,
						},
						[1120] = {
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 134,
									["overkill"] = 44,
									["amount"] = 134,
								},
							},
							["amount"] = 134,
							["school"] = 32,
							["total"] = 134,
							["overkill"] = 44,
						},
						[88263] = {
							["school"] = 2,
							["total"] = 313,
							["sources"] = {
								["Myrony"] = {
									["total"] = 313,
									["amount"] = 313,
								},
							},
							["amount"] = 313,
						},
						[35395] = {
							["school"] = 1,
							["total"] = 723,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 378,
									["amount"] = 378,
								},
								["Myrony"] = {
									["total"] = 345,
									["amount"] = 345,
								},
							},
							["amount"] = 723,
						},
						[172] = {
							["school"] = 32,
							["total"] = 84,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 84,
									["amount"] = 84,
								},
							},
							["amount"] = 84,
						},
						[25742] = {
							["school"] = 2,
							["total"] = 193,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 54,
									["amount"] = 54,
								},
								["Myrony"] = {
									["total"] = 139,
									["amount"] = 139,
								},
							},
							["amount"] = 193,
						},
						[54049] = {
							["school"] = 32,
							["total"] = 169,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 169,
									["amount"] = 169,
								},
							},
							["amount"] = 169,
						},
						[96172] = {
							["school"] = 2,
							["total"] = 1,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 1,
									["amount"] = 1,
								},
							},
							["amount"] = 1,
						},
						[2812] = {
							["school"] = 2,
							["total"] = 142,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 142,
									["amount"] = 142,
								},
							},
							["amount"] = 142,
						},
						[30108] = {
							["school"] = 32,
							["total"] = 94,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 94,
									["amount"] = 94,
								},
							},
							["amount"] = 94,
						},
						[980] = {
							["school"] = 32,
							["total"] = 58,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 58,
									["amount"] = 58,
								},
							},
							["amount"] = 58,
						},
						[6603] = {
							["school"] = 1,
							["total"] = 1158,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 112,
									["amount"] = 112,
								},
								["Fragrance"] = {
									["total"] = 209,
									["amount"] = 209,
								},
								["Myrony"] = {
									["total"] = 837,
									["amount"] = 837,
								},
							},
							["amount"] = 1158,
						},
					},
					["name"] = "Deeprot Stomper",
					["totaldamage"] = 349,
					["totaldamagetaken"] = 3759,
					["id"] = "0xF130335500000019",
					["damage"] = 349,
				}, -- [1]
				{
					["damagespells"] = {
						[6603] = {
							["school"] = 1,
							["total"] = 388,
							["targets"] = {
								["Myrony"] = {
									["total"] = 388,
									["amount"] = 388,
								},
							},
							["amount"] = 388,
						},
						[21337] = {
							["school"] = 8,
							["total"] = 42,
							["targets"] = {
								["Fragrance"] = {
									["total"] = 42,
									["amount"] = 42,
								},
							},
							["amount"] = 42,
						},
					},
					["damagetaken"] = 3620,
					["flag"] = 68168,
					["class"] = "MONSTER",
					["damagetakenspells"] = {
						[31935] = {
							["school"] = 2,
							["total"] = 353,
							["sources"] = {
								["Myrony"] = {
									["total"] = 353,
									["amount"] = 353,
								},
							},
							["amount"] = 353,
						},
						[6603] = {
							["school"] = 1,
							["total"] = 747,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 232,
									["amount"] = 232,
								},
								["Fragrance"] = {
									["total"] = 405,
									["amount"] = 405,
								},
								["Myrony"] = {
									["total"] = 110,
									["amount"] = 110,
								},
							},
							["amount"] = 747,
						},
						[7294] = {
							["school"] = 2,
							["total"] = 26,
							["sources"] = {
								["Myrony"] = {
									["total"] = 26,
									["amount"] = 26,
								},
							},
							["amount"] = 26,
						},
						[20187] = {
							["school"] = 2,
							["total"] = 128,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 128,
									["amount"] = 128,
								},
							},
							["amount"] = 128,
						},
						[980] = {
							["school"] = 32,
							["total"] = 59,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 59,
									["amount"] = 59,
								},
							},
							["amount"] = 59,
						},
						[88263] = {
							["school"] = 2,
							["total"] = 330,
							["sources"] = {
								["Myrony"] = {
									["total"] = 330,
									["amount"] = 330,
								},
							},
							["amount"] = 330,
						},
						[35395] = {
							["sources"] = {
								["Fragrance"] = {
									["total"] = 650,
									["overkill"] = 81,
									["amount"] = 650,
								},
							},
							["amount"] = 650,
							["school"] = 1,
							["total"] = 650,
							["overkill"] = 81,
						},
						[172] = {
							["school"] = 32,
							["total"] = 126,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 126,
									["amount"] = 126,
								},
							},
							["amount"] = 126,
						},
						[25742] = {
							["school"] = 2,
							["total"] = 156,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 135,
									["amount"] = 135,
								},
								["Myrony"] = {
									["total"] = 21,
									["amount"] = 21,
								},
							},
							["amount"] = 156,
						},
						[54049] = {
							["school"] = 32,
							["total"] = 98,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 98,
									["amount"] = 98,
								},
							},
							["amount"] = 98,
						},
						[96172] = {
							["school"] = 2,
							["total"] = 2,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 2,
									["amount"] = 2,
								},
							},
							["amount"] = 2,
						},
						[2812] = {
							["school"] = 2,
							["total"] = 142,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 142,
									["amount"] = 142,
								},
							},
							["amount"] = 142,
						},
						[30108] = {
							["school"] = 32,
							["total"] = 47,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 47,
									["amount"] = 47,
								},
							},
							["amount"] = 47,
						},
						[53595] = {
							["school"] = 1,
							["total"] = 34,
							["sources"] = {
								["Myrony"] = {
									["total"] = 34,
									["amount"] = 34,
								},
							},
							["amount"] = 34,
						},
						[879] = {
							["school"] = 2,
							["total"] = 722,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 722,
									["amount"] = 722,
								},
							},
							["amount"] = 722,
						},
					},
					["name"] = "Deeprot Tangler",
					["totaldamage"] = 430,
					["totaldamagetaken"] = 3620,
					["id"] = "0xF13033560000001D",
					["damage"] = 430,
				}, -- [2]
			},
			["totaldamage"] = 7379,
			["time"] = 16,
			["starttime"] = 1689857756,
			["totaldamagetaken"] = 779,
			["etotaldamagetaken"] = 7379,
			["damage"] = 7379,
			["players"] = {
				{
					["ccdonespells"] = {
						[31935] = {
							["count"] = 2,
							["targets"] = {
								["Deeprot Tangler"] = 1,
								["Deeprot Stomper"] = 1,
							},
						},
					},
					["last"] = 10901.59,
					["flag"] = 1298,
					["class"] = "PALADIN",
					["auras"] = {
						[68055] = {
							["type"] = "DEBUFF",
							["count"] = 1,
							["school"] = 2,
							["targets"] = {
								["Deeprot Stomper"] = {
									["uptime"] = 4,
									["count"] = 1,
								},
							},
							["uptime"] = 4,
						},
						[31935] = {
							["type"] = "DEBUFF",
							["count"] = 2,
							["school"] = 2,
							["targets"] = {
								["Deeprot Tangler"] = {
									["uptime"] = 3,
									["count"] = 1,
								},
								["Deeprot Stomper"] = {
									["uptime"] = 3,
									["count"] = 1,
								},
							},
							["uptime"] = 3,
						},
						[139] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 2,
							["uptime"] = 11,
						},
					},
					["time"] = 13.8,
					["totaldamagetaken"] = 553,
					["damage"] = 3198,
					["damagespells"] = {
						["Crusader Strike"] = {
							["total"] = 345,
							["hitmin"] = 345,
							["id"] = 35395,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 345,
									["amount"] = 345,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 1,
							["hitmax"] = 345,
							["amount"] = 345,
							["hitamount"] = 345,
						},
						["Melee"] = {
							["total"] = 947,
							["hitmin"] = 101,
							["criticalamount"] = 244,
							["id"] = 6603,
							["amount"] = 947,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 837,
									["amount"] = 837,
								},
								["Deeprot Tangler"] = {
									["total"] = 110,
									["amount"] = 110,
								},
							},
							["criticalmin"] = 244,
							["critical"] = 1,
							["criticalmax"] = 244,
							["count"] = 8,
							["hit"] = 6,
							["school"] = 1,
							["hitmax"] = 135,
							["MISS"] = 1,
							["hitamount"] = 703,
						},
						["Seal of Righteousness"] = {
							["total"] = 160,
							["hitmin"] = 19,
							["id"] = 25742,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 139,
									["amount"] = 139,
								},
								["Deeprot Tangler"] = {
									["total"] = 21,
									["amount"] = 21,
								},
							},
							["casts"] = 1,
							["count"] = 8,
							["hit"] = 8,
							["school"] = 2,
							["hitmax"] = 21,
							["amount"] = 160,
							["hitamount"] = 160,
						},
						["Hammer of the Righteous (Physical)"] = {
							["total"] = 71,
							["hitmin"] = 34,
							["id"] = 53595,
							["targets"] = {
								["Deeprot Tangler"] = {
									["total"] = 34,
									["amount"] = 34,
								},
								["Deeprot Stomper"] = {
									["total"] = 37,
									["amount"] = 37,
								},
							},
							["casts"] = 1,
							["count"] = 2,
							["hit"] = 2,
							["school"] = 1,
							["hitmax"] = 37,
							["amount"] = 71,
							["hitamount"] = 71,
						},
						["Hammer of the Righteous"] = {
							["total"] = 643,
							["hitmin"] = 154,
							["id"] = 88263,
							["targets"] = {
								["Deeprot Tangler"] = {
									["total"] = 330,
									["amount"] = 330,
								},
								["Deeprot Stomper"] = {
									["total"] = 313,
									["amount"] = 313,
								},
							},
							["casts"] = 3,
							["count"] = 4,
							["hit"] = 4,
							["school"] = 2,
							["hitmax"] = 168,
							["amount"] = 643,
							["hitamount"] = 643,
						},
						["Avenger's Shield"] = {
							["total"] = 725,
							["hitmin"] = 353,
							["id"] = 31935,
							["targets"] = {
								["Deeprot Tangler"] = {
									["total"] = 353,
									["amount"] = 353,
								},
								["Deeprot Stomper"] = {
									["total"] = 372,
									["amount"] = 372,
								},
							},
							["casts"] = 1,
							["count"] = 2,
							["hit"] = 2,
							["school"] = 2,
							["hitmax"] = 372,
							["amount"] = 725,
							["hitamount"] = 725,
						},
						["Retribution Aura"] = {
							["total"] = 39,
							["hitmin"] = 13,
							["id"] = 7294,
							["targets"] = {
								["Deeprot Tangler"] = {
									["total"] = 26,
									["amount"] = 26,
								},
								["Deeprot Stomper"] = {
									["total"] = 13,
									["amount"] = 13,
								},
							},
							["casts"] = 1,
							["count"] = 3,
							["hit"] = 3,
							["school"] = 2,
							["hitmax"] = 13,
							["amount"] = 39,
							["hitamount"] = 39,
						},
						["Judgement of Righteousness"] = {
							["total"] = 268,
							["hitmin"] = 268,
							["id"] = 20187,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 268,
									["amount"] = 268,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 2,
							["hitmax"] = 268,
							["amount"] = 268,
							["hitamount"] = 268,
						},
					},
					["damagetaken"] = 553,
					["id"] = "0x00000000000447DB",
					["damagetakenspells"] = {
						["Melee"] = {
							["total"] = 553,
							["hitmin"] = 165,
							["id"] = 6603,
							["hitmax"] = 199,
							["PARRY"] = 6,
							["count"] = 9,
							["amount"] = 553,
							["school"] = 1,
							["sources"] = {
								["Deeprot Stomper"] = {
									["total"] = 165,
									["amount"] = 165,
								},
								["Deeprot Tangler"] = {
									["total"] = 388,
									["amount"] = 388,
								},
							},
							["hit"] = 3,
							["hitamount"] = 553,
						},
					},
					["manaspells"] = {
						[84627] = 368,
						[31930] = 480,
					},
					["ccdone"] = 2,
					["totaldamage"] = 3198,
					["mana"] = 848,
					["role"] = "TANK",
					["name"] = "Myrony",
				}, -- [1]
				{
					["last"] = 10901.738,
					["flag"] = 1298,
					["class"] = "PALADIN",
					["auras"] = {
						[89906] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 2,
							["uptime"] = 10,
						},
						[94686] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 1,
							["uptime"] = 6,
						},
					},
					["totaldamage"] = 2968,
					["time"] = 12.6,
					["totaldamagetaken"] = 226,
					["damage"] = 2968,
					["damagespells"] = {
						["Exorcism"] = {
							["total"] = 722,
							["hitmin"] = 722,
							["id"] = 879,
							["targets"] = {
								["Deeprot Tangler"] = {
									["total"] = 722,
									["amount"] = 722,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 2,
							["hitmax"] = 722,
							["amount"] = 722,
							["hitamount"] = 722,
						},
						["Seal of Righteousness"] = {
							["total"] = 189,
							["hitmin"] = 27,
							["criticalamount"] = 108,
							["id"] = 25742,
							["criticalmin"] = 54,
							["targets"] = {
								["Deeprot Tangler"] = {
									["total"] = 135,
									["amount"] = 135,
								},
								["Deeprot Stomper"] = {
									["total"] = 54,
									["amount"] = 54,
								},
							},
							["criticalmax"] = 54,
							["critical"] = 2,
							["casts"] = 1,
							["count"] = 5,
							["hit"] = 3,
							["school"] = 2,
							["hitmax"] = 27,
							["amount"] = 189,
							["hitamount"] = 81,
						},
						["Judgement of Righteousness"] = {
							["total"] = 128,
							["hitmin"] = 128,
							["id"] = 20187,
							["targets"] = {
								["Deeprot Tangler"] = {
									["total"] = 128,
									["amount"] = 128,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 2,
							["hitmax"] = 128,
							["amount"] = 128,
							["hitamount"] = 128,
						},
						["Crusader Strike"] = {
							["total"] = 1028,
							["hitmin"] = 314,
							["id"] = 35395,
							["targets"] = {
								["Deeprot Tangler"] = {
									["total"] = 650,
									["overkill"] = 81,
									["amount"] = 650,
								},
								["Deeprot Stomper"] = {
									["total"] = 378,
									["amount"] = 378,
								},
							},
							["overkill"] = 81,
							["casts"] = 3,
							["count"] = 3,
							["hit"] = 3,
							["school"] = 1,
							["hitmax"] = 378,
							["amount"] = 1028,
							["hitamount"] = 1028,
						},
						["Hand of Light"] = {
							["total"] = 3,
							["hitmin"] = 1,
							["id"] = 96172,
							["targets"] = {
								["Deeprot Tangler"] = {
									["total"] = 2,
									["amount"] = 2,
								},
								["Deeprot Stomper"] = {
									["total"] = 1,
									["amount"] = 1,
								},
							},
							["casts"] = 1,
							["count"] = 3,
							["hit"] = 3,
							["school"] = 2,
							["hitmax"] = 1,
							["amount"] = 3,
							["hitamount"] = 3,
						},
						["Melee"] = {
							["total"] = 614,
							["hitmin"] = 192,
							["id"] = 6603,
							["targets"] = {
								["Deeprot Tangler"] = {
									["total"] = 405,
									["amount"] = 405,
								},
								["Deeprot Stomper"] = {
									["total"] = 209,
									["amount"] = 209,
								},
							},
							["count"] = 3,
							["hit"] = 3,
							["school"] = 1,
							["hitmax"] = 213,
							["amount"] = 614,
							["hitamount"] = 614,
						},
						["Holy Wrath"] = {
							["total"] = 284,
							["hitmin"] = 142,
							["id"] = 2812,
							["targets"] = {
								["Deeprot Tangler"] = {
									["total"] = 142,
									["amount"] = 142,
								},
								["Deeprot Stomper"] = {
									["total"] = 142,
									["amount"] = 142,
								},
							},
							["casts"] = 1,
							["count"] = 2,
							["hit"] = 2,
							["school"] = 2,
							["hitmax"] = 142,
							["amount"] = 284,
							["hitamount"] = 284,
						},
					},
					["damagetaken"] = 226,
					["id"] = "0x0000000000048007",
					["damagetakenspells"] = {
						["War Stomp"] = {
							["total"] = 184,
							["hitmin"] = 184,
							["id"] = 11876,
							["sources"] = {
								["Deeprot Stomper"] = {
									["total"] = 184,
									["amount"] = 184,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 1,
							["hitmax"] = 184,
							["amount"] = 184,
							["hitamount"] = 184,
						},
						["Thorns"] = {
							["total"] = 42,
							["hitmin"] = 21,
							["id"] = 21337,
							["sources"] = {
								["Deeprot Tangler"] = {
									["total"] = 42,
									["amount"] = 42,
								},
							},
							["casts"] = 1,
							["count"] = 2,
							["hit"] = 2,
							["school"] = 8,
							["hitmax"] = 21,
							["amount"] = 42,
							["hitamount"] = 42,
						},
					},
					["overkill"] = 81,
					["name"] = "Fragrance",
					["manaspells"] = {
						[89906] = 216,
					},
					["mana"] = 216,
					["role"] = "DAMAGER",
				}, -- [2]
				{
					["last"] = 10902.681,
					["flag"] = 4369,
					["class"] = "WARLOCK",
					["auras"] = {
						[980] = {
							["type"] = "DEBUFF",
							["count"] = 2,
							["school"] = 32,
							["refresh"] = 1,
							["targets"] = {
								["Deeprot Tangler"] = {
									["uptime"] = 8,
									["count"] = 1,
								},
								["Deeprot Stomper"] = {
									["count"] = 1,
									["refresh"] = 1,
									["uptime"] = 6,
								},
							},
							["uptime"] = 13,
						},
						[30108] = {
							["type"] = "DEBUFF",
							["count"] = 2,
							["school"] = 32,
							["targets"] = {
								["Deeprot Tangler"] = {
									["uptime"] = 5,
									["count"] = 1,
								},
								["Deeprot Stomper"] = {
									["uptime"] = 7,
									["count"] = 1,
								},
							},
							["uptime"] = 10,
						},
						[172] = {
							["type"] = "DEBUFF",
							["count"] = 1,
							["school"] = 32,
							["targets"] = {
								["Deeprot Stomper"] = {
									["uptime"] = 2,
									["count"] = 1,
								},
							},
							["uptime"] = 2,
						},
						[1120] = {
							["type"] = "DEBUFF",
							["count"] = 1,
							["school"] = 32,
							["targets"] = {
								["Deeprot Stomper"] = {
									["uptime"] = 3,
									["count"] = 1,
								},
							},
							["uptime"] = 3,
						},
					},
					["time"] = 14.31,
					["damage"] = 1213,
					["overheal"] = 32,
					["id"] = "0x000000000004825C",
					["spec"] = 265,
					["healspells"] = {
						[63106] = {
							["overheal"] = 32,
							["max"] = 32,
							["count"] = 2,
							["amount"] = 32,
							["school"] = 32,
							["min"] = 32,
							["targets"] = {
								["Beardedrasta"] = {
									["overheal"] = 32,
									["amount"] = 32,
								},
							},
						},
					},
					["overkill"] = 44,
					["manaspells"] = {
						[31818] = 277,
					},
					["heal"] = 32,
					["name"] = "Beardedrasta",
					["mana"] = 277,
					["damagespells"] = {
						["Bane of Agony (DoT)"] = {
							["total"] = 117,
							["hitmin"] = 12,
							["criticalamount"] = 69,
							["id"] = 980,
							["casts"] = 3,
							["targets"] = {
								["Deeprot Tangler"] = {
									["total"] = 59,
									["amount"] = 59,
								},
								["Deeprot Stomper"] = {
									["total"] = 58,
									["amount"] = 58,
								},
							},
							["hitmax"] = 12,
							["count"] = 7,
							["criticalmax"] = 23,
							["critical"] = 3,
							["amount"] = 117,
							["school"] = 32,
							["hit"] = 4,
							["criticalmin"] = 23,
							["hitamount"] = 48,
						},
						["Melee (Haapdhon)"] = {
							["DODGE"] = 1,
							["total"] = 344,
							["hitmin"] = 60,
							["id"] = 6603,
							["targets"] = {
								["Deeprot Tangler"] = {
									["total"] = 232,
									["amount"] = 232,
								},
								["Deeprot Stomper"] = {
									["total"] = 112,
									["amount"] = 112,
								},
							},
							["glancing"] = 2,
							["count"] = 7,
							["hit"] = 4,
							["school"] = 1,
							["hitmax"] = 65,
							["amount"] = 344,
							["hitamount"] = 248,
						},
						["Drain Soul (DoT)"] = {
							["total"] = 134,
							["hitmin"] = 134,
							["id"] = 1120,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 134,
									["overkill"] = 44,
									["amount"] = 134,
								},
							},
							["overkill"] = 44,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 32,
							["hitmax"] = 134,
							["amount"] = 134,
							["hitamount"] = 134,
						},
						["Shadow Bite (Haapdhon)"] = {
							["total"] = 267,
							["hitmin"] = 98,
							["id"] = 54049,
							["targets"] = {
								["Deeprot Tangler"] = {
									["total"] = 98,
									["amount"] = 98,
								},
								["Deeprot Stomper"] = {
									["total"] = 169,
									["amount"] = 169,
								},
							},
							["amount"] = 267,
							["casts"] = 3,
							["count"] = 3,
							["hit"] = 2,
							["school"] = 32,
							["hitmax"] = 169,
							["MISS"] = 1,
							["hitamount"] = 267,
						},
						["Unstable Affliction (DoT)"] = {
							["total"] = 141,
							["hitmin"] = 47,
							["id"] = 30108,
							["targets"] = {
								["Deeprot Tangler"] = {
									["total"] = 47,
									["amount"] = 47,
								},
								["Deeprot Stomper"] = {
									["total"] = 94,
									["amount"] = 94,
								},
							},
							["count"] = 3,
							["hit"] = 3,
							["school"] = 32,
							["hitmax"] = 47,
							["amount"] = 141,
							["hitamount"] = 141,
						},
						["Corruption (DoT)"] = {
							["total"] = 210,
							["hitmin"] = 42,
							["id"] = 172,
							["targets"] = {
								["Deeprot Tangler"] = {
									["total"] = 126,
									["amount"] = 126,
								},
								["Deeprot Stomper"] = {
									["total"] = 84,
									["amount"] = 84,
								},
							},
							["casts"] = 2,
							["count"] = 5,
							["hit"] = 5,
							["school"] = 32,
							["hitmax"] = 42,
							["amount"] = 210,
							["hitamount"] = 210,
						},
					},
					["totaldamage"] = 1213,
					["role"] = "DAMAGER",
				}, -- [3]
				{
					["overheal"] = 0,
					["last"] = 10900.903,
					["flag"] = 1298,
					["class"] = "PRIEST",
					["healspells"] = {
						[63544] = {
							["overheal"] = 0,
							["count"] = 1,
							["amount"] = 70,
							["school"] = 2,
							["max"] = 70,
							["targets"] = {
								["Myrony"] = {
									["overheal"] = 0,
									["amount"] = 70,
								},
							},
							["min"] = 70,
						},
						[139] = {
							["overheal"] = 0,
							["targets"] = {
								["Myrony"] = {
									["overheal"] = 0,
									["amount"] = 700,
								},
							},
							["count"] = 4,
							["amount"] = 700,
							["school"] = 2,
							["max"] = 175,
							["ishot"] = true,
							["min"] = 175,
						},
					},
					["heal"] = 770,
					["role"] = "HEALER",
					["name"] = "Nianhong",
					["time"] = 12.01,
					["id"] = "0x00000000000467C0",
				}, -- [4]
			},
			["type"] = "party",
			["damagetaken"] = 779,
			["overheal"] = 32,
			["ccdone"] = 2,
			["overkill"] = 125,
			["edamagetaken"] = 7379,
			["heal"] = 802,
			["name"] = "Deeprot Stomper (5)",
			["mobname"] = "Deeprot Stomper",
			["etotaldamage"] = 779,
			["edamage"] = 779,
			["last_action"] = 1689857772,
			["endtime"] = 1689857772,
		}, -- [5]
		{
			["ccdone"] = 8,
			["mana"] = 1840,
			["enemies"] = {
				{
					["damagespells"] = {
						[15657] = {
							["school"] = 1,
							["total"] = 1045,
							["targets"] = {
								["Myrony"] = {
									["total"] = 1045,
									["amount"] = 498,
								},
							},
							["amount"] = 498,
						},
						[13298] = {
							["school"] = 8,
							["total"] = 61,
							["targets"] = {
								["Myrony"] = {
									["total"] = 61,
									["amount"] = 23,
								},
							},
							["amount"] = 23,
						},
						[6603] = {
							["school"] = 1,
							["total"] = 2588,
							["targets"] = {
								["Myrony"] = {
									["total"] = 2588,
									["amount"] = 1562,
								},
							},
							["amount"] = 1562,
						},
					},
					["damagetaken"] = 9612,
					["flag"] = 2632,
					["class"] = "MONSTER",
					["damagetakenspells"] = {
						[16827] = {
							["school"] = 1,
							["total"] = 420,
							["sources"] = {
								["Macius"] = {
									["total"] = 420,
									["amount"] = 420,
								},
							},
							["amount"] = 420,
						},
						[25742] = {
							["school"] = 2,
							["total"] = 233,
							["sources"] = {
								["Myrony"] = {
									["total"] = 233,
									["amount"] = 233,
								},
							},
							["amount"] = 233,
						},
						[35395] = {
							["sources"] = {
								["Myrony"] = {
									["total"] = 639,
									["overkill"] = 200,
									["amount"] = 639,
								},
							},
							["amount"] = 639,
							["school"] = 1,
							["total"] = 639,
							["overkill"] = 200,
						},
						[53595] = {
							["school"] = 1,
							["total"] = 71,
							["sources"] = {
								["Myrony"] = {
									["total"] = 71,
									["amount"] = 71,
								},
							},
							["amount"] = 71,
						},
						[6603] = {
							["school"] = 1,
							["total"] = 1604,
							["sources"] = {
								["Macius"] = {
									["total"] = 624,
									["amount"] = 624,
								},
								["Beardedrasta"] = {
									["total"] = 43,
									["amount"] = 43,
								},
								["Myrony"] = {
									["total"] = 937,
									["amount"] = 937,
								},
							},
							["amount"] = 1604,
						},
						[1120] = {
							["school"] = 32,
							["total"] = 134,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 134,
									["amount"] = 134,
								},
							},
							["amount"] = 134,
						},
						[2643] = {
							["sources"] = {
								["Macius"] = {
									["total"] = 1333,
									["overkill"] = 108,
									["amount"] = 1333,
								},
							},
							["amount"] = 1333,
							["school"] = 1,
							["total"] = 1333,
							["overkill"] = 108,
						},
						[980] = {
							["school"] = 32,
							["total"] = 130,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 130,
									["amount"] = 130,
								},
							},
							["amount"] = 130,
						},
						[56641] = {
							["school"] = 1,
							["total"] = 756,
							["sources"] = {
								["Macius"] = {
									["total"] = 756,
									["amount"] = 756,
								},
							},
							["amount"] = 756,
						},
						[2812] = {
							["school"] = 2,
							["total"] = 190,
							["sources"] = {
								["Myrony"] = {
									["total"] = 190,
									["amount"] = 190,
								},
							},
							["amount"] = 190,
						},
						[31935] = {
							["school"] = 2,
							["total"] = 1371,
							["sources"] = {
								["Myrony"] = {
									["total"] = 1371,
									["amount"] = 1371,
								},
							},
							["amount"] = 1371,
						},
						[20187] = {
							["school"] = 2,
							["total"] = 522,
							["sources"] = {
								["Myrony"] = {
									["total"] = 522,
									["amount"] = 522,
								},
							},
							["amount"] = 522,
						},
						[30108] = {
							["school"] = 32,
							["total"] = 235,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 235,
									["amount"] = 235,
								},
							},
							["amount"] = 235,
						},
						[81297] = {
							["school"] = 2,
							["total"] = 308,
							["sources"] = {
								["Myrony"] = {
									["total"] = 308,
									["amount"] = 308,
								},
							},
							["amount"] = 308,
						},
						[88263] = {
							["school"] = 2,
							["total"] = 684,
							["sources"] = {
								["Myrony"] = {
									["total"] = 684,
									["amount"] = 684,
								},
							},
							["amount"] = 684,
						},
						[75] = {
							["school"] = 1,
							["total"] = 814,
							["sources"] = {
								["Macius"] = {
									["total"] = 814,
									["amount"] = 814,
								},
							},
							["amount"] = 814,
						},
						[172] = {
							["school"] = 32,
							["total"] = 168,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 168,
									["amount"] = 168,
								},
							},
							["amount"] = 168,
						},
					},
					["name"] = "Putridus Trickster",
					["totaldamage"] = 3694,
					["totaldamagetaken"] = 9612,
					["id"] = "0xF1302E0F00000016",
					["damage"] = 2083,
				}, -- [1]
				{
					["damagespells"] = {
						[6603] = {
							["school"] = 1,
							["total"] = 794,
							["targets"] = {
								["Myrony"] = {
									["total"] = 403,
									["amount"] = 403,
								},
								["Nianhong"] = {
									["total"] = 391,
									["amount"] = 391,
								},
							},
							["amount"] = 794,
						},
					},
					["damagetaken"] = 4722,
					["id"] = "0xF1302E1000000011",
					["class"] = "MONSTER",
					["damagetakenspells"] = {
						[31935] = {
							["sources"] = {
								["Myrony"] = {
									["total"] = 782,
									["overkill"] = 282,
									["amount"] = 782,
								},
							},
							["amount"] = 782,
							["school"] = 2,
							["total"] = 782,
							["overkill"] = 282,
						},
						[6603] = {
							["school"] = 1,
							["total"] = 495,
							["sources"] = {
								["Myrony"] = {
									["total"] = 344,
									["amount"] = 344,
								},
								["Macius"] = {
									["total"] = 151,
									["amount"] = 151,
								},
							},
							["amount"] = 495,
						},
						[2643] = {
							["school"] = 1,
							["total"] = 762,
							["sources"] = {
								["Macius"] = {
									["total"] = 762,
									["amount"] = 762,
								},
							},
							["amount"] = 762,
						},
						[88263] = {
							["school"] = 2,
							["total"] = 352,
							["sources"] = {
								["Myrony"] = {
									["total"] = 352,
									["amount"] = 352,
								},
							},
							["amount"] = 352,
						},
						[980] = {
							["school"] = 32,
							["total"] = 180,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 180,
									["amount"] = 180,
								},
							},
							["amount"] = 180,
						},
						[35395] = {
							["school"] = 1,
							["total"] = 364,
							["sources"] = {
								["Myrony"] = {
									["total"] = 364,
									["amount"] = 364,
								},
							},
							["amount"] = 364,
						},
						[172] = {
							["school"] = 32,
							["total"] = 252,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 252,
									["amount"] = 252,
								},
							},
							["amount"] = 252,
						},
						[25742] = {
							["school"] = 2,
							["total"] = 44,
							["sources"] = {
								["Myrony"] = {
									["total"] = 44,
									["amount"] = 44,
								},
							},
							["amount"] = 44,
						},
						[20187] = {
							["school"] = 2,
							["total"] = 283,
							["sources"] = {
								["Myrony"] = {
									["total"] = 283,
									["amount"] = 283,
								},
							},
							["amount"] = 283,
						},
						[75] = {
							["school"] = 1,
							["total"] = 416,
							["sources"] = {
								["Macius"] = {
									["total"] = 416,
									["amount"] = 416,
								},
							},
							["amount"] = 416,
						},
						[2812] = {
							["school"] = 2,
							["total"] = 76,
							["sources"] = {
								["Myrony"] = {
									["total"] = 76,
									["amount"] = 76,
								},
							},
							["amount"] = 76,
						},
						[30108] = {
							["school"] = 32,
							["total"] = 235,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 235,
									["amount"] = 235,
								},
							},
							["amount"] = 235,
						},
						[56641] = {
							["school"] = 1,
							["total"] = 80,
							["sources"] = {
								["Macius"] = {
									["total"] = 80,
									["amount"] = 80,
								},
							},
							["amount"] = 80,
						},
						[16827] = {
							["school"] = 1,
							["total"] = 401,
							["sources"] = {
								["Macius"] = {
									["total"] = 401,
									["amount"] = 401,
								},
							},
							["amount"] = 401,
						},
					},
					["totaldamage"] = 794,
					["name"] = "Putridus Shadowstalker",
					["totaldamagetaken"] = 4722,
					["flag"] = 2632,
					["damage"] = 794,
				}, -- [2]
				{
					["damagespells"] = {
						[21331] = {
							["school"] = 8,
							["total"] = 41,
							["targets"] = {
								["Beardedrasta"] = {
									["total"] = 24,
									["amount"] = 20,
								},
								["Myrony"] = {
									["total"] = 17,
									["amount"] = 17,
								},
							},
							["amount"] = 37,
						},
						[6603] = {
							["school"] = 1,
							["total"] = 868,
							["targets"] = {
								["Myrony"] = {
									["total"] = 868,
									["amount"] = 527,
								},
							},
							["amount"] = 527,
						},
						[21337] = {
							["school"] = 8,
							["total"] = 72,
							["targets"] = {
								["Myrony"] = {
									["total"] = 72,
									["amount"] = 72,
								},
							},
							["amount"] = 72,
						},
					},
					["damagetaken"] = 4684,
					["flag"] = 2632,
					["class"] = "MONSTER",
					["damagetakenspells"] = {
						[31935] = {
							["school"] = 2,
							["total"] = 718,
							["sources"] = {
								["Myrony"] = {
									["total"] = 718,
									["amount"] = 718,
								},
							},
							["amount"] = 718,
						},
						[6603] = {
							["school"] = 1,
							["total"] = 1302,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 620,
									["amount"] = 620,
								},
								["Myrony"] = {
									["total"] = 682,
									["amount"] = 682,
								},
							},
							["amount"] = 1302,
						},
						[2643] = {
							["school"] = 1,
							["total"] = 608,
							["sources"] = {
								["Macius"] = {
									["total"] = 608,
									["amount"] = 608,
								},
							},
							["amount"] = 608,
						},
						[980] = {
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 275,
									["overkill"] = 32,
									["amount"] = 275,
								},
							},
							["amount"] = 275,
							["school"] = 32,
							["total"] = 275,
							["overkill"] = 32,
						},
						[35395] = {
							["school"] = 1,
							["total"] = 682,
							["sources"] = {
								["Myrony"] = {
									["total"] = 682,
									["amount"] = 682,
								},
							},
							["amount"] = 682,
						},
						[172] = {
							["school"] = 32,
							["total"] = 252,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 252,
									["amount"] = 252,
								},
							},
							["amount"] = 252,
						},
						[25742] = {
							["school"] = 2,
							["total"] = 95,
							["sources"] = {
								["Myrony"] = {
									["total"] = 95,
									["amount"] = 95,
								},
							},
							["amount"] = 95,
						},
						[54049] = {
							["school"] = 32,
							["total"] = 341,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 341,
									["amount"] = 341,
								},
							},
							["amount"] = 341,
						},
						[2812] = {
							["school"] = 2,
							["total"] = 76,
							["sources"] = {
								["Myrony"] = {
									["total"] = 76,
									["amount"] = 76,
								},
							},
							["amount"] = 76,
						},
						[88263] = {
							["school"] = 2,
							["total"] = 335,
							["sources"] = {
								["Myrony"] = {
									["total"] = 335,
									["amount"] = 335,
								},
							},
							["amount"] = 335,
						},
					},
					["name"] = "Deeprot Tangler",
					["totaldamage"] = 981,
					["totaldamagetaken"] = 4684,
					["id"] = "0xF13033560000000E",
					["damage"] = 636,
				}, -- [3]
			},
			["dispel"] = 2,
			["totaldamage"] = 19018,
			["time"] = 37,
			["starttime"] = 1689857703,
			["totaldamagetaken"] = 5469,
			["etotaldamagetaken"] = 19018,
			["damage"] = 19018,
			["players"] = {
				{
					["ccdonespells"] = {
						[31935] = {
							["count"] = 5,
							["targets"] = {
								["Putridus Trickster"] = 4,
								["Deeprot Tangler"] = 1,
							},
						},
						[2812] = {
							["count"] = 3,
							["targets"] = {
								["Putridus Shadowstalker"] = 1,
								["Putridus Trickster"] = 2,
							},
						},
					},
					["last"] = 10871.443,
					["flag"] = 1298,
					["mana"] = 1840,
					["auras"] = {
						[31935] = {
							["type"] = "DEBUFF",
							["count"] = 5,
							["school"] = 2,
							["targets"] = {
								["Putridus Trickster"] = {
									["uptime"] = 7,
									["count"] = 4,
								},
								["Deeprot Tangler"] = {
									["uptime"] = 3,
									["count"] = 1,
								},
							},
							["uptime"] = 7,
						},
						[139] = {
							["type"] = "BUFF",
							["count"] = 2,
							["school"] = 2,
							["refresh"] = 1,
							["uptime"] = 23,
						},
						[26573] = {
							["type"] = "DEBUFF",
							["count"] = 3,
							["school"] = 2,
							["targets"] = {
								["Putridus Trickster"] = {
									["uptime"] = 10,
									["count"] = 2,
								},
								["Myrony"] = {
									["uptime"] = 10,
									["count"] = 1,
								},
							},
							["uptime"] = 10,
						},
						[62124] = {
							["type"] = "DEBUFF",
							["count"] = 1,
							["school"] = 2,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["uptime"] = 3,
									["count"] = 1,
								},
							},
							["uptime"] = 3,
						},
						[31790] = {
							["type"] = "DEBUFF",
							["count"] = 1,
							["school"] = 1,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["uptime"] = 3,
									["count"] = 1,
								},
							},
							["uptime"] = 3,
						},
						[17] = {
							["type"] = "BUFF",
							["count"] = 2,
							["school"] = 2,
							["uptime"] = 16,
						},
						[31930] = {
							["type"] = "BUFF",
							["count"] = 3,
							["school"] = 2,
							["uptime"] = 23,
						},
						[2812] = {
							["type"] = "DEBUFF",
							["count"] = 3,
							["school"] = 2,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["uptime"] = 3,
									["count"] = 1,
								},
								["Putridus Trickster"] = {
									["uptime"] = 3,
									["count"] = 2,
								},
							},
							["uptime"] = 3,
						},
						[79105] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 2,
							["uptime"] = 36,
						},
						[68055] = {
							["type"] = "DEBUFF",
							["count"] = 3,
							["school"] = 2,
							["targets"] = {
								["Putridus Trickster"] = {
									["uptime"] = 20,
									["count"] = 2,
								},
								["Putridus Shadowstalker"] = {
									["uptime"] = 14,
									["count"] = 1,
								},
							},
							["uptime"] = 30,
						},
					},
					["role"] = "TANK",
					["time"] = 35.95,
					["totaldamagetaken"] = 5054,
					["damage"] = 9788,
					["damagespells"] = {
						["Seal of Righteousness"] = {
							["total"] = 372,
							["hitmin"] = 17,
							["id"] = 25742,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 44,
									["amount"] = 44,
								},
								["Deeprot Tangler"] = {
									["total"] = 95,
									["amount"] = 95,
								},
								["Putridus Trickster"] = {
									["total"] = 233,
									["amount"] = 233,
								},
							},
							["casts"] = 1,
							["count"] = 18,
							["hit"] = 18,
							["school"] = 2,
							["hitmax"] = 23,
							["amount"] = 372,
							["hitamount"] = 372,
						},
						["Hammer of the Righteous (Physical)"] = {
							["total"] = 71,
							["hitmin"] = 32,
							["id"] = 53595,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 71,
									["amount"] = 71,
								},
							},
							["casts"] = 1,
							["count"] = 2,
							["hit"] = 2,
							["school"] = 1,
							["hitmax"] = 39,
							["amount"] = 71,
							["hitamount"] = 71,
						},
						["Holy Wrath"] = {
							["total"] = 342,
							["hitmin"] = 76,
							["criticalamount"] = 114,
							["id"] = 2812,
							["criticalmin"] = 114,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 190,
									["amount"] = 190,
								},
								["Putridus Shadowstalker"] = {
									["total"] = 76,
									["amount"] = 76,
								},
								["Deeprot Tangler"] = {
									["total"] = 76,
									["amount"] = 76,
								},
							},
							["criticalmax"] = 114,
							["critical"] = 1,
							["casts"] = 1,
							["count"] = 4,
							["hit"] = 3,
							["school"] = 2,
							["hitmax"] = 76,
							["amount"] = 342,
							["hitamount"] = 228,
						},
						["Hammer of the Righteous"] = {
							["total"] = 1371,
							["hitmin"] = 158,
							["id"] = 88263,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 684,
									["amount"] = 684,
								},
								["Putridus Shadowstalker"] = {
									["total"] = 352,
									["amount"] = 352,
								},
								["Deeprot Tangler"] = {
									["total"] = 335,
									["amount"] = 335,
								},
							},
							["casts"] = 3,
							["count"] = 8,
							["hit"] = 8,
							["school"] = 2,
							["hitmax"] = 184,
							["amount"] = 1371,
							["hitamount"] = 1371,
						},
						["Melee"] = {
							["amount"] = 1963,
							["total"] = 1963,
							["hitmin"] = 82,
							["criticalamount"] = 472,
							["id"] = 6603,
							["blocked"] = 34,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 344,
									["amount"] = 344,
								},
								["Deeprot Tangler"] = {
									["total"] = 682,
									["amount"] = 682,
								},
								["Putridus Trickster"] = {
									["total"] = 937,
									["amount"] = 937,
								},
							},
							["criticalmin"] = 210,
							["critical"] = 2,
							["criticalmax"] = 262,
							["count"] = 16,
							["hit"] = 13,
							["school"] = 1,
							["hitmax"] = 136,
							["MISS"] = 1,
							["hitamount"] = 1491,
						},
						["Consecration"] = {
							["total"] = 308,
							["hitmin"] = 25,
							["id"] = 81297,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 308,
									["amount"] = 308,
								},
							},
							["casts"] = 1,
							["count"] = 12,
							["hit"] = 12,
							["school"] = 2,
							["hitmax"] = 27,
							["amount"] = 308,
							["hitamount"] = 308,
						},
						["Crusader Strike"] = {
							["DODGE"] = 1,
							["total"] = 1685,
							["hitmin"] = 294,
							["id"] = 35395,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 364,
									["amount"] = 364,
								},
								["Deeprot Tangler"] = {
									["total"] = 682,
									["amount"] = 682,
								},
								["Putridus Trickster"] = {
									["total"] = 639,
									["overkill"] = 200,
									["amount"] = 639,
								},
							},
							["overkill"] = 200,
							["casts"] = 6,
							["count"] = 6,
							["hit"] = 5,
							["school"] = 1,
							["hitmax"] = 364,
							["amount"] = 1685,
							["hitamount"] = 1685,
						},
						["Avenger's Shield"] = {
							["hitmin"] = 305,
							["criticalmin"] = 718,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 782,
									["overkill"] = 282,
									["amount"] = 782,
								},
								["Deeprot Tangler"] = {
									["total"] = 718,
									["amount"] = 718,
								},
								["Putridus Trickster"] = {
									["total"] = 1371,
									["amount"] = 1371,
								},
							},
							["amount"] = 2871,
							["MISS"] = 1,
							["total"] = 2871,
							["criticalamount"] = 1500,
							["id"] = 31935,
							["overkill"] = 282,
							["criticalmax"] = 782,
							["casts"] = 3,
							["hitmax"] = 360,
							["hit"] = 4,
							["school"] = 2,
							["critical"] = 2,
							["count"] = 7,
							["hitamount"] = 1371,
						},
						["Judgement of Righteousness"] = {
							["total"] = 805,
							["hitmin"] = 224,
							["id"] = 20187,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 522,
									["amount"] = 522,
								},
								["Putridus Shadowstalker"] = {
									["total"] = 283,
									["amount"] = 283,
								},
							},
							["casts"] = 3,
							["count"] = 3,
							["hit"] = 3,
							["school"] = 2,
							["hitmax"] = 298,
							["amount"] = 805,
							["hitamount"] = 805,
						},
					},
					["overkill"] = 482,
					["damagetaken"] = 3102,
					["id"] = "0x00000000000447DB",
					["healspells"] = {
						[85673] = {
							["overheal"] = 284,
							["count"] = 1,
							["amount"] = 589,
							["school"] = 2,
							["max"] = 589,
							["targets"] = {
								["Myrony"] = {
									["overheal"] = 284,
									["amount"] = 589,
								},
							},
							["min"] = 589,
						},
					},
					["damagetakenspells"] = {
						["Poison (DoT)"] = {
							["total"] = 61,
							["hitmin"] = 7,
							["id"] = 13298,
							["amount"] = 23,
							["hitmax"] = 8,
							["sources"] = {
								["Putridus Trickster"] = {
									["total"] = 61,
									["amount"] = 23,
								},
							},
							["count"] = 8,
							["ABSORB"] = 5,
							["school"] = 8,
							["resisted"] = 7,
							["hit"] = 3,
							["hitamount"] = 23,
						},
						["Entangling Roots (DoT)"] = {
							["total"] = 17,
							["hitmin"] = 7,
							["id"] = 21331,
							["hitmax"] = 10,
							["sources"] = {
								["Deeprot Tangler"] = {
									["total"] = 17,
									["amount"] = 17,
								},
							},
							["count"] = 2,
							["hit"] = 2,
							["school"] = 8,
							["resisted"] = 3,
							["amount"] = 17,
							["hitamount"] = 17,
						},
						["Melee"] = {
							["DODGE"] = 2,
							["total"] = 3859,
							["hitmin"] = 102,
							["id"] = 6603,
							["blocked"] = 43,
							["ABSORB"] = 7,
							["hitmax"] = 205,
							["PARRY"] = 22,
							["sources"] = {
								["Deeprot Tangler"] = {
									["total"] = 868,
									["amount"] = 527,
								},
								["Putridus Shadowstalker"] = {
									["total"] = 403,
									["amount"] = 403,
								},
								["Putridus Trickster"] = {
									["total"] = 2588,
									["amount"] = 1562,
								},
							},
							["count"] = 52,
							["amount"] = 2492,
							["school"] = 1,
							["hit"] = 15,
							["MISS"] = 6,
							["hitamount"] = 2492,
						},
						["Backstab"] = {
							["total"] = 1045,
							["hitmin"] = 241,
							["id"] = 15657,
							["hitmax"] = 257,
							["amount"] = 498,
							["casts"] = 4,
							["count"] = 4,
							["ABSORB"] = 2,
							["school"] = 1,
							["hit"] = 2,
							["sources"] = {
								["Putridus Trickster"] = {
									["total"] = 1045,
									["amount"] = 498,
								},
							},
							["hitamount"] = 498,
						},
						["Thorns"] = {
							["total"] = 72,
							["hitmin"] = 18,
							["id"] = 21337,
							["hitmax"] = 18,
							["sources"] = {
								["Deeprot Tangler"] = {
									["total"] = 72,
									["amount"] = 72,
								},
							},
							["casts"] = 1,
							["count"] = 5,
							["amount"] = 72,
							["school"] = 8,
							["hit"] = 4,
							["MISS"] = 1,
							["hitamount"] = 72,
						},
					},
					["overheal"] = 284,
					["heal"] = 589,
					["name"] = "Myrony",
					["ccdone"] = 8,
					["manaspells"] = {
						[84627] = 1150,
						[31930] = 690,
					},
					["class"] = "PALADIN",
					["totaldamage"] = 9788,
				}, -- [1]
				{
					["last"] = 10870.797,
					["flag"] = 66834,
					["class"] = "PRIEST",
					["auras"] = {
						[139] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 2,
							["uptime"] = 12,
						},
						[79105] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 2,
							["uptime"] = 36,
						},
						[20707] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 32,
							["uptime"] = 30,
						},
						[6788] = {
							["type"] = "DEBUFF",
							["count"] = 2,
							["school"] = 2,
							["targets"] = {
								["Myrony"] = {
									["uptime"] = 24,
									["count"] = 2,
								},
							},
							["uptime"] = 24,
						},
					},
					["absorbspells"] = {
						[17] = {
							["min"] = 7,
							["casts"] = 1,
							["count"] = 16,
							["amount"] = 1952,
							["max"] = 286,
							["targets"] = {
								["Myrony"] = 1952,
							},
							["school"] = 2,
						},
					},
					["role"] = "HEALER",
					["time"] = 33.97,
					["totaldamagetaken"] = 391,
					["overheal"] = 1484,
					["absorb"] = 1952,
					["damagetaken"] = 391,
					["id"] = "0x00000000000467C0",
					["healspells"] = {
						[2061] = {
							["overheal"] = 547,
							["max"] = 959,
							["targets"] = {
								["Myrony"] = {
									["overheal"] = 547,
									["amount"] = 1408,
								},
							},
							["min"] = 449,
							["casts"] = 2,
							["count"] = 2,
							["amount"] = 1408,
							["school"] = 2,
						},
						[63544] = {
							["overheal"] = 70,
							["count"] = 6,
							["amount"] = 309,
							["school"] = 2,
							["max"] = 70,
							["targets"] = {
								["Macius"] = {
									["overheal"] = 0,
									["amount"] = 48,
								},
								["Beardedrasta"] = {
									["overheal"] = 0,
									["amount"] = 55,
								},
								["Nianhong"] = {
									["overheal"] = 0,
									["amount"] = 66,
								},
								["Myrony"] = {
									["overheal"] = 70,
									["amount"] = 140,
								},
							},
							["min"] = 48,
						},
						[139] = {
							["overheal"] = 867,
							["max"] = 175,
							["targets"] = {
								["Beardedrasta"] = {
									["overheal"] = 324,
									["amount"] = 228,
								},
								["Nianhong"] = {
									["overheal"] = 0,
									["amount"] = 660,
								},
								["Myrony"] = {
									["overheal"] = 543,
									["amount"] = 682,
								},
							},
							["min"] = 18,
							["casts"] = 5,
							["count"] = 15,
							["amount"] = 1570,
							["school"] = 2,
							["ishot"] = true,
						},
						[56160] = {
							["overheal"] = 0,
							["count"] = 2,
							["amount"] = 496,
							["school"] = 2,
							["max"] = 248,
							["targets"] = {
								["Myrony"] = {
									["overheal"] = 0,
									["amount"] = 496,
								},
							},
							["min"] = 248,
						},
					},
					["damagetakenspells"] = {
						["Melee"] = {
							["total"] = 391,
							["hitmin"] = 180,
							["id"] = 6603,
							["sources"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 391,
									["amount"] = 391,
								},
							},
							["count"] = 2,
							["hit"] = 2,
							["school"] = 1,
							["hitmax"] = 211,
							["amount"] = 391,
							["hitamount"] = 391,
						},
					},
					["heal"] = 3783,
					["name"] = "Nianhong",
					["dispel"] = 2,
					["dispelspells"] = {
						[528] = {
							["spells"] = {
								[21062] = 2,
							},
							["count"] = 2,
							["targets"] = {
								["Myrony"] = 2,
							},
						},
					},
				}, -- [2]
				{
					["last"] = 10868.847,
					["flag"] = 1297,
					["class"] = "WARLOCK",
					["auras"] = {
						[172] = {
							["type"] = "DEBUFF",
							["count"] = 3,
							["school"] = 32,
							["targets"] = {
								["Putridus Trickster"] = {
									["uptime"] = 11,
									["count"] = 1,
								},
								["Putridus Shadowstalker"] = {
									["uptime"] = 18,
									["count"] = 1,
								},
								["Deeprot Tangler"] = {
									["uptime"] = 17,
									["count"] = 1,
								},
							},
							["uptime"] = 23,
						},
						[64368] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 32,
							["refresh"] = 2,
							["uptime"] = 14,
						},
						[1120] = {
							["type"] = "DEBUFF",
							["count"] = 1,
							["school"] = 32,
							["refresh"] = 1,
							["targets"] = {
								["Putridus Trickster"] = {
									["count"] = 1,
									["refresh"] = 1,
									["uptime"] = 10,
								},
							},
							["uptime"] = 10,
						},
						[79105] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 2,
							["uptime"] = 36,
						},
						[139] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 2,
							["uptime"] = 12,
						},
						[30108] = {
							["type"] = "DEBUFF",
							["count"] = 3,
							["school"] = 32,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["uptime"] = 15,
									["count"] = 1,
								},
								["Putridus Trickster"] = {
									["uptime"] = 14,
									["count"] = 2,
								},
							},
							["uptime"] = 19,
						},
						[980] = {
							["type"] = "DEBUFF",
							["count"] = 3,
							["school"] = 32,
							["targets"] = {
								["Putridus Trickster"] = {
									["uptime"] = 13,
									["count"] = 1,
								},
								["Putridus Shadowstalker"] = {
									["uptime"] = 19,
									["count"] = 1,
								},
								["Deeprot Tangler"] = {
									["uptime"] = 22,
									["count"] = 1,
								},
							},
							["uptime"] = 24,
						},
					},
					["time"] = 24.41,
					["totaldamagetaken"] = 24,
					["damage"] = 2865,
					["overheal"] = 204,
					["damagetaken"] = 20,
					["id"] = "0x000000000004825C",
					["spec"] = 265,
					["healspells"] = {
						[63106] = {
							["overheal"] = 204,
							["max"] = 10,
							["count"] = 7,
							["amount"] = 20,
							["school"] = 32,
							["min"] = 10,
							["targets"] = {
								["Beardedrasta"] = {
									["overheal"] = 204,
									["amount"] = 20,
								},
							},
						},
					},
					["damagetakenspells"] = {
						["Entangling Roots (DoT)"] = {
							["total"] = 24,
							["hitmin"] = 10,
							["id"] = 21331,
							["sources"] = {
								["Deeprot Tangler"] = {
									["total"] = 24,
									["amount"] = 20,
								},
							},
							["count"] = 2,
							["hit"] = 2,
							["school"] = 8,
							["hitmax"] = 10,
							["amount"] = 20,
							["hitamount"] = 20,
						},
					},
					["heal"] = 20,
					["name"] = "Beardedrasta",
					["overkill"] = 32,
					["damagespells"] = {
						["Bane of Agony (DoT)"] = {
							["criticalmax"] = 47,
							["total"] = 585,
							["hitmin"] = 12,
							["criticalamount"] = 117,
							["id"] = 980,
							["criticalmin"] = 23,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 130,
									["amount"] = 130,
								},
								["Putridus Shadowstalker"] = {
									["total"] = 180,
									["amount"] = 180,
								},
								["Deeprot Tangler"] = {
									["total"] = 275,
									["overkill"] = 32,
									["amount"] = 275,
								},
							},
							["overkill"] = 32,
							["critical"] = 3,
							["casts"] = 3,
							["count"] = 26,
							["hit"] = 23,
							["school"] = 32,
							["hitmax"] = 36,
							["amount"] = 585,
							["hitamount"] = 468,
						},
						["Shadow Bite (Haapdhon)"] = {
							["total"] = 341,
							["hitmin"] = 98,
							["id"] = 54049,
							["targets"] = {
								["Deeprot Tangler"] = {
									["total"] = 341,
									["amount"] = 341,
								},
							},
							["hitmax"] = 124,
							["casts"] = 5,
							["count"] = 5,
							["amount"] = 341,
							["school"] = 32,
							["hit"] = 3,
							["MISS"] = 2,
							["hitamount"] = 341,
						},
						["Drain Soul (DoT)"] = {
							["total"] = 134,
							["hitmin"] = 67,
							["id"] = 1120,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 134,
									["amount"] = 134,
								},
							},
							["casts"] = 2,
							["count"] = 2,
							["hit"] = 2,
							["school"] = 32,
							["hitmax"] = 67,
							["amount"] = 134,
							["hitamount"] = 134,
						},
						["Unstable Affliction (DoT)"] = {
							["total"] = 470,
							["hitmin"] = 47,
							["id"] = 30108,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 235,
									["amount"] = 235,
								},
								["Putridus Trickster"] = {
									["total"] = 235,
									["amount"] = 235,
								},
							},
							["count"] = 10,
							["hit"] = 10,
							["school"] = 32,
							["hitmax"] = 47,
							["amount"] = 470,
							["hitamount"] = 470,
						},
						["Corruption (DoT)"] = {
							["total"] = 672,
							["hitmin"] = 42,
							["id"] = 172,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 168,
									["amount"] = 168,
								},
								["Putridus Shadowstalker"] = {
									["total"] = 252,
									["amount"] = 252,
								},
								["Deeprot Tangler"] = {
									["total"] = 252,
									["amount"] = 252,
								},
							},
							["casts"] = 3,
							["count"] = 16,
							["hit"] = 16,
							["school"] = 32,
							["hitmax"] = 42,
							["amount"] = 672,
							["hitamount"] = 672,
						},
						["Melee (Haapdhon)"] = {
							["total"] = 663,
							["hitmin"] = 57,
							["id"] = 6603,
							["targets"] = {
								["Deeprot Tangler"] = {
									["total"] = 620,
									["amount"] = 620,
								},
								["Putridus Trickster"] = {
									["total"] = 43,
									["amount"] = 43,
								},
							},
							["glancing"] = 3,
							["hitmax"] = 66,
							["count"] = 14,
							["amount"] = 663,
							["school"] = 1,
							["hit"] = 9,
							["MISS"] = 2,
							["hitamount"] = 541,
						},
					},
					["totaldamage"] = 2865,
					["role"] = "DAMAGER",
				}, -- [3]
				{
					["damagespells"] = {
						["Steady Shot"] = {
							["blocked"] = 34,
							["total"] = 836,
							["hitmin"] = 80,
							["criticalamount"] = 214,
							["id"] = 56641,
							["hitmax"] = 118,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 756,
									["amount"] = 756,
								},
								["Putridus Shadowstalker"] = {
									["total"] = 80,
									["amount"] = 80,
								},
							},
							["count"] = 7,
							["hit"] = 6,
							["casts"] = 8,
							["critical"] = 1,
							["amount"] = 836,
							["school"] = 1,
							["criticalmin"] = 214,
							["criticalmax"] = 214,
							["hitamount"] = 622,
						},
						["Melee"] = {
							["total"] = 36,
							["hitmin"] = 36,
							["id"] = 6603,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 36,
									["amount"] = 36,
								},
							},
							["amount"] = 36,
							["blocked"] = 15,
							["count"] = 2,
							["hit"] = 1,
							["school"] = 1,
							["hitmax"] = 36,
							["MISS"] = 1,
							["hitamount"] = 36,
						},
						["Claw (Cat)"] = {
							["blocked"] = 25,
							["total"] = 821,
							["hitmin"] = 61,
							["criticalamount"] = 508,
							["id"] = 16827,
							["criticalmin"] = 168,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 420,
									["amount"] = 420,
								},
								["Putridus Shadowstalker"] = {
									["total"] = 401,
									["amount"] = 401,
								},
							},
							["criticalmax"] = 172,
							["critical"] = 3,
							["casts"] = 7,
							["count"] = 7,
							["hit"] = 4,
							["school"] = 1,
							["hitmax"] = 85,
							["amount"] = 821,
							["hitamount"] = 313,
						},
						["Auto Shot"] = {
							["total"] = 1230,
							["hitmin"] = 116,
							["id"] = 75,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 814,
									["amount"] = 814,
								},
								["Putridus Shadowstalker"] = {
									["total"] = 416,
									["amount"] = 416,
								},
							},
							["amount"] = 1230,
							["casts"] = 1,
							["count"] = 10,
							["hit"] = 9,
							["school"] = 1,
							["hitmax"] = 151,
							["MISS"] = 1,
							["hitamount"] = 1230,
						},
						["Multi-Shot"] = {
							["hitmin"] = 77,
							["criticalmin"] = 206,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 762,
									["amount"] = 762,
								},
								["Deeprot Tangler"] = {
									["total"] = 608,
									["amount"] = 608,
								},
								["Putridus Trickster"] = {
									["total"] = 1333,
									["overkill"] = 108,
									["amount"] = 1333,
								},
							},
							["amount"] = 2703,
							["MISS"] = 1,
							["total"] = 2703,
							["criticalamount"] = 440,
							["id"] = 2643,
							["blocked"] = 32,
							["overkill"] = 108,
							["criticalmax"] = 234,
							["casts"] = 6,
							["hitmax"] = 133,
							["hit"] = 20,
							["school"] = 1,
							["critical"] = 2,
							["count"] = 23,
							["hitamount"] = 2263,
						},
						["Melee (Cat)"] = {
							["DODGE"] = 1,
							["total"] = 739,
							["hitmin"] = 49,
							["criticalamount"] = 318,
							["id"] = 6603,
							["criticalmin"] = 98,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 624,
									["amount"] = 624,
								},
								["Putridus Shadowstalker"] = {
									["total"] = 115,
									["amount"] = 115,
								},
							},
							["critical"] = 3,
							["glancing"] = 3,
							["criticalmax"] = 112,
							["count"] = 12,
							["hit"] = 5,
							["school"] = 1,
							["hitmax"] = 60,
							["amount"] = 739,
							["hitamount"] = 278,
						},
					},
					["last"] = 10871.345,
					["totaldamage"] = 6365,
					["overkill"] = 108,
					["flag"] = 1298,
					["class"] = "HUNTER",
					["id"] = "0x00000000000477A3",
					["auras"] = {
						[465] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 2,
							["uptime"] = 30,
						},
						[139] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 2,
							["uptime"] = 1,
						},
						[79105] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 2,
							["uptime"] = 36,
						},
					},
					["energyspells"] = {
						[91954] = 63,
					},
					["role"] = "DAMAGER",
					["time"] = 29.16,
					["name"] = "Macius",
					["energy"] = 63,
					["damage"] = 6365,
				}, -- [4]
				{
					["last"] = 10867.722,
					["flag"] = 1298,
					["class"] = "PALADIN",
					["auras"] = {
						[93435] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 1,
							["uptime"] = 4,
						},
					},
					["role"] = "DAMAGER",
					["name"] = "Fragrance",
					["time"] = 0,
					["id"] = "0x0000000000048007",
				}, -- [5]
			},
			["type"] = "party",
			["damagetaken"] = 3513,
			["energy"] = 63,
			["absorb"] = 1952,
			["etotaldamage"] = 5469,
			["overkill"] = 622,
			["edamagetaken"] = 19018,
			["heal"] = 4392,
			["name"] = "Putridus Trickster",
			["mobname"] = "Putridus Trickster",
			["overheal"] = 1972,
			["edamage"] = 3513,
			["last_action"] = 1689857740,
			["endtime"] = 1689857740,
		}, -- [6]
		{
			["starttime"] = 1689857420,
			["eoverkill"] = 1269,
			["mana"] = 1249,
			["potion"] = 1,
			["enemies"] = {
				{
					["damagespells"] = {
						[6603] = {
							["school"] = 1,
							["total"] = 913,
							["targets"] = {
								["Fragrance"] = {
									["total"] = 913,
									["amount"] = 893,
								},
							},
							["amount"] = 893,
						},
						[12540] = {
							["school"] = 1,
							["total"] = 14,
							["targets"] = {
								["Fragrance"] = {
									["total"] = 14,
									["amount"] = 14,
								},
							},
							["amount"] = 14,
						},
					},
					["damagetaken"] = 3610,
					["flag"] = 68168,
					["class"] = "MONSTER",
					["damagetakenspells"] = {
						[53385] = {
							["school"] = 1,
							["total"] = 381,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 381,
									["amount"] = 381,
								},
							},
							["amount"] = 381,
						},
						[7294] = {
							["school"] = 2,
							["total"] = 65,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 65,
									["amount"] = 65,
								},
							},
							["amount"] = 65,
						},
						[20187] = {
							["school"] = 2,
							["total"] = 128,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 128,
									["amount"] = 128,
								},
							},
							["amount"] = 128,
						},
						[42223] = {
							["school"] = 4,
							["total"] = 164,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 164,
									["amount"] = 164,
								},
							},
							["amount"] = 164,
						},
						[2643] = {
							["school"] = 1,
							["total"] = 121,
							["sources"] = {
								["Macius"] = {
									["total"] = 121,
									["amount"] = 121,
								},
							},
							["amount"] = 121,
						},
						[172] = {
							["school"] = 32,
							["total"] = 132,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 132,
									["amount"] = 132,
								},
							},
							["amount"] = 132,
						},
						[25742] = {
							["school"] = 2,
							["total"] = 81,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 81,
									["amount"] = 81,
								},
							},
							["amount"] = 81,
						},
						[96172] = {
							["school"] = 2,
							["total"] = 3,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 3,
									["amount"] = 3,
								},
							},
							["amount"] = 3,
						},
						[6603] = {
							["school"] = 1,
							["total"] = 1303,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 831,
									["amount"] = 831,
								},
								["Beardedrasta"] = {
									["total"] = 472,
									["amount"] = 472,
								},
							},
							["amount"] = 1303,
						},
						[2812] = {
							["school"] = 2,
							["total"] = 31,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 31,
									["amount"] = 31,
								},
							},
							["amount"] = 31,
						},
						[30108] = {
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 196,
									["overkill"] = 27,
									["amount"] = 196,
								},
							},
							["amount"] = 196,
							["school"] = 32,
							["total"] = 196,
							["overkill"] = 27,
						},
						[85256] = {
							["school"] = 1,
							["total"] = 667,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 667,
									["amount"] = 667,
								},
							},
							["amount"] = 667,
						},
						[54049] = {
							["school"] = 32,
							["total"] = 338,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 338,
									["amount"] = 338,
								},
							},
							["amount"] = 338,
						},
					},
					["name"] = "Putridus Satyr",
					["totaldamage"] = 927,
					["totaldamagetaken"] = 3610,
					["id"] = "0xF1302E0E0000002B",
					["damage"] = 907,
				}, -- [1]
				{
					["damagespells"] = {
						[15657] = {
							["school"] = 1,
							["total"] = 1129,
							["targets"] = {
								["Macius"] = {
									["total"] = 289,
									["amount"] = 289,
								},
								["Beardedrasta"] = {
									["total"] = 303,
									["amount"] = 0,
								},
								["Myrony"] = {
									["total"] = 537,
									["amount"] = 537,
								},
							},
							["amount"] = 826,
						},
						[13298] = {
							["school"] = 8,
							["total"] = 12,
							["targets"] = {
								["Beardedrasta"] = {
									["total"] = 12,
									["amount"] = 12,
								},
							},
							["amount"] = 12,
						},
						[6603] = {
							["total"] = 9411,
							["amount"] = 8834,
							["school"] = 1,
							["targets"] = {
								["Myrony"] = {
									["total"] = 687,
									["amount"] = 687,
								},
								["Nianhong"] = {
									["total"] = 2440,
									["overkill"] = 45,
									["amount"] = 2440,
								},
								["Macius"] = {
									["total"] = 2142,
									["overkill"] = 182,
									["amount"] = 2142,
								},
								["Fragrance"] = {
									["total"] = 2842,
									["overkill"] = 449,
									["amount"] = 2446,
								},
								["Beardedrasta"] = {
									["total"] = 1300,
									["amount"] = 1119,
								},
							},
							["overkill"] = 676,
						},
					},
					["damagetaken"] = 9426,
					["flag"] = 2632,
					["class"] = "MONSTER",
					["damagetakenspells"] = {
						[16827] = {
							["school"] = 1,
							["total"] = 337,
							["sources"] = {
								["Macius"] = {
									["total"] = 337,
									["amount"] = 337,
								},
							},
							["amount"] = 337,
						},
						[25742] = {
							["school"] = 2,
							["total"] = 66,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 50,
									["amount"] = 50,
								},
								["Myrony"] = {
									["total"] = 16,
									["amount"] = 16,
								},
							},
							["amount"] = 66,
						},
						[81297] = {
							["school"] = 2,
							["total"] = 284,
							["sources"] = {
								["Myrony"] = {
									["total"] = 284,
									["amount"] = 284,
								},
							},
							["amount"] = 284,
						},
						[6603] = {
							["school"] = 1,
							["total"] = 1348,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 302,
									["amount"] = 302,
								},
								["Macius"] = {
									["total"] = 524,
									["amount"] = 524,
								},
								["Fragrance"] = {
									["total"] = 404,
									["amount"] = 404,
								},
								["Myrony"] = {
									["total"] = 118,
									["amount"] = 118,
								},
							},
							["amount"] = 1348,
						},
						[2643] = {
							["school"] = 1,
							["total"] = 817,
							["sources"] = {
								["Macius"] = {
									["total"] = 817,
									["amount"] = 817,
								},
							},
							["amount"] = 817,
						},
						[42223] = {
							["school"] = 4,
							["total"] = 1066,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 1066,
									["amount"] = 1066,
								},
							},
							["amount"] = 1066,
						},
						[53385] = {
							["school"] = 1,
							["total"] = 2272,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 2272,
									["amount"] = 2272,
								},
							},
							["amount"] = 2272,
						},
						[85256] = {
							["school"] = 1,
							["total"] = 645,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 645,
									["amount"] = 645,
								},
							},
							["amount"] = 645,
						},
						[96172] = {
							["school"] = 2,
							["total"] = 10,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 10,
									["amount"] = 10,
								},
							},
							["amount"] = 10,
						},
						[2812] = {
							["school"] = 2,
							["total"] = 212,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 212,
									["amount"] = 212,
								},
							},
							["amount"] = 212,
						},
						[20187] = {
							["school"] = 2,
							["total"] = 110,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 110,
									["amount"] = 110,
								},
							},
							["amount"] = 110,
						},
						[35395] = {
							["school"] = 1,
							["total"] = 346,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 346,
									["amount"] = 346,
								},
							},
							["amount"] = 346,
						},
						[75] = {
							["school"] = 1,
							["total"] = 733,
							["sources"] = {
								["Macius"] = {
									["total"] = 733,
									["amount"] = 733,
								},
							},
							["amount"] = 733,
						},
						[7294] = {
							["school"] = 2,
							["total"] = 405,
							["sources"] = {
								["Myrony"] = {
									["total"] = 52,
									["amount"] = 52,
								},
								["Nianhong"] = {
									["total"] = 26,
									["amount"] = 26,
								},
								["Macius"] = {
									["total"] = 117,
									["amount"] = 117,
								},
								["Fragrance"] = {
									["total"] = 146,
									["amount"] = 146,
								},
								["Beardedrasta"] = {
									["total"] = 64,
									["amount"] = 64,
								},
							},
							["amount"] = 405,
						},
						[879] = {
							["school"] = 2,
							["total"] = 489,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 489,
									["amount"] = 489,
								},
							},
							["amount"] = 489,
						},
						[54049] = {
							["school"] = 32,
							["total"] = 161,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 161,
									["amount"] = 161,
								},
							},
							["amount"] = 161,
						},
						[56641] = {
							["school"] = 1,
							["total"] = 125,
							["sources"] = {
								["Macius"] = {
									["total"] = 125,
									["amount"] = 125,
								},
							},
							["amount"] = 125,
						},
					},
					["name"] = "Putridus Trickster",
					["overkill"] = 676,
					["totaldamage"] = 10552,
					["totaldamagetaken"] = 9426,
					["id"] = "0xF1302E0F00000017",
					["damage"] = 9672,
				}, -- [2]
				{
					["damagespells"] = {
						[6603] = {
							["total"] = 1349,
							["amount"] = 1163,
							["school"] = 1,
							["targets"] = {
								["Beardedrasta"] = {
									["total"] = 227,
									["amount"] = 227,
								},
								["Fragrance"] = {
									["total"] = 186,
									["overkill"] = 182,
									["amount"] = 0,
								},
								["Myrony"] = {
									["total"] = 936,
									["amount"] = 936,
								},
							},
							["overkill"] = 182,
						},
					},
					["damagetaken"] = 2013,
					["flag"] = 2632,
					["class"] = "MONSTER",
					["damagetakenspells"] = {
						[42223] = {
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 246,
									["overkill"] = 3,
									["amount"] = 246,
								},
							},
							["amount"] = 246,
							["school"] = 4,
							["total"] = 246,
							["overkill"] = 3,
						},
						[53385] = {
							["school"] = 1,
							["total"] = 437,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 437,
									["amount"] = 437,
								},
							},
							["amount"] = 437,
						},
						[2812] = {
							["school"] = 2,
							["total"] = 93,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 93,
									["amount"] = 93,
								},
							},
							["amount"] = 93,
						},
						[7294] = {
							["school"] = 2,
							["total"] = 78,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 13,
									["amount"] = 13,
								},
								["Myrony"] = {
									["total"] = 65,
									["amount"] = 65,
								},
							},
							["amount"] = 78,
						},
						[2643] = {
							["sources"] = {
								["Macius"] = {
									["total"] = 873,
									["overkill"] = 161,
									["amount"] = 873,
								},
							},
							["amount"] = 873,
							["school"] = 1,
							["total"] = 873,
							["overkill"] = 161,
						},
						[81297] = {
							["school"] = 2,
							["total"] = 284,
							["sources"] = {
								["Myrony"] = {
									["total"] = 284,
									["amount"] = 284,
								},
							},
							["amount"] = 284,
						},
						[96172] = {
							["school"] = 2,
							["total"] = 2,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 2,
									["amount"] = 2,
								},
							},
							["amount"] = 2,
						},
					},
					["name"] = "Corruptor",
					["overkill"] = 182,
					["totaldamage"] = 1349,
					["totaldamagetaken"] = 2013,
					["id"] = "0xF1302FB900000015",
					["damage"] = 1163,
				}, -- [3]
				{
					["damagespells"] = {
						[6603] = {
							["school"] = 1,
							["total"] = 171,
							["targets"] = {
								["Myrony"] = {
									["total"] = 171,
									["amount"] = 171,
								},
							},
							["amount"] = 171,
						},
					},
					["damagetaken"] = 955,
					["id"] = "0xF1302FB800000018",
					["class"] = "MONSTER",
					["damagetakenspells"] = {
						[42223] = {
							["school"] = 4,
							["total"] = 82,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 82,
									["amount"] = 82,
								},
							},
							["amount"] = 82,
						},
						[53385] = {
							["school"] = 1,
							["total"] = 505,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 505,
									["amount"] = 505,
								},
							},
							["amount"] = 505,
						},
						[2812] = {
							["school"] = 2,
							["total"] = 102,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 102,
									["amount"] = 102,
								},
							},
							["amount"] = 102,
						},
						[7294] = {
							["school"] = 2,
							["total"] = 13,
							["sources"] = {
								["Myrony"] = {
									["total"] = 13,
									["amount"] = 13,
								},
							},
							["amount"] = 13,
						},
						[96172] = {
							["school"] = 2,
							["total"] = 3,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 3,
									["amount"] = 3,
								},
							},
							["amount"] = 3,
						},
						[2643] = {
							["school"] = 1,
							["total"] = 250,
							["sources"] = {
								["Macius"] = {
									["total"] = 250,
									["amount"] = 250,
								},
							},
							["amount"] = 250,
						},
					},
					["totaldamage"] = 171,
					["name"] = "Poison Sprite",
					["totaldamagetaken"] = 955,
					["flag"] = 2632,
					["damage"] = 171,
				}, -- [4]
				{
					["damagespells"] = {
						[6603] = {
							["total"] = 3262,
							["amount"] = 3262,
							["school"] = 1,
							["targets"] = {
								["Myrony"] = {
									["total"] = 186,
									["overkill"] = 182,
									["amount"] = 186,
								},
								["Nianhong"] = {
									["total"] = 408,
									["amount"] = 408,
								},
								["Beardedrasta"] = {
									["total"] = 1824,
									["overkill"] = 229,
									["amount"] = 1824,
								},
								["Fragrance"] = {
									["total"] = 617,
									["amount"] = 617,
								},
								["Macius"] = {
									["total"] = 227,
									["amount"] = 227,
								},
							},
							["overkill"] = 411,
						},
						[21331] = {
							["school"] = 8,
							["total"] = 19,
							["targets"] = {
								["Fragrance"] = {
									["total"] = 19,
									["amount"] = 19,
								},
							},
							["amount"] = 19,
						},
					},
					["damagetaken"] = 1774,
					["flag"] = 2632,
					["class"] = "MONSTER",
					["damagetakenspells"] = {
						[6603] = {
							["school"] = 1,
							["total"] = 143,
							["sources"] = {
								["Myrony"] = {
									["total"] = 143,
									["amount"] = 143,
								},
							},
							["amount"] = 143,
						},
						[42223] = {
							["school"] = 4,
							["total"] = 328,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 328,
									["amount"] = 328,
								},
							},
							["amount"] = 328,
						},
						[53385] = {
							["school"] = 1,
							["total"] = 788,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 788,
									["amount"] = 788,
								},
							},
							["amount"] = 788,
						},
						[25742] = {
							["school"] = 2,
							["total"] = 46,
							["sources"] = {
								["Myrony"] = {
									["total"] = 46,
									["amount"] = 46,
								},
							},
							["amount"] = 46,
						},
						[2643] = {
							["school"] = 1,
							["total"] = 258,
							["sources"] = {
								["Macius"] = {
									["total"] = 258,
									["amount"] = 258,
								},
							},
							["amount"] = 258,
						},
						[7294] = {
							["school"] = 2,
							["total"] = 127,
							["sources"] = {
								["Macius"] = {
									["total"] = 13,
									["amount"] = 13,
								},
								["Beardedrasta"] = {
									["total"] = 64,
									["amount"] = 64,
								},
								["Fragrance"] = {
									["total"] = 37,
									["amount"] = 37,
								},
								["Myrony"] = {
									["total"] = 13,
									["amount"] = 13,
								},
							},
							["amount"] = 127,
						},
						[96172] = {
							["school"] = 2,
							["total"] = 4,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 4,
									["amount"] = 4,
								},
							},
							["amount"] = 4,
						},
						[2812] = {
							["school"] = 2,
							["total"] = 80,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 80,
									["amount"] = 80,
								},
							},
							["amount"] = 80,
						},
					},
					["name"] = "Deeprot Tangler",
					["overkill"] = 411,
					["totaldamage"] = 3281,
					["totaldamagetaken"] = 1774,
					["id"] = "0xF13033560000000E",
					["damage"] = 3281,
				}, -- [5]
				{
					["damagespells"] = {
						[6603] = {
							["school"] = 1,
							["total"] = 2025,
							["targets"] = {
								["Beardedrasta"] = {
									["total"] = 673,
									["amount"] = 471,
								},
								["Fragrance"] = {
									["total"] = 1132,
									["amount"] = 960,
								},
								["Nianhong"] = {
									["total"] = 220,
									["amount"] = 220,
								},
							},
							["amount"] = 1651,
						},
						[9080] = {
							["school"] = 1,
							["total"] = 131,
							["targets"] = {
								["Beardedrasta"] = {
									["total"] = 49,
									["amount"] = 49,
								},
								["Fragrance"] = {
									["total"] = 44,
									["amount"] = 44,
								},
								["Nianhong"] = {
									["total"] = 38,
									["amount"] = 38,
								},
							},
							["amount"] = 131,
						},
					},
					["damagetaken"] = 1413,
					["flag"] = 2632,
					["class"] = "MONSTER",
					["damagetakenspells"] = {
						[2812] = {
							["school"] = 2,
							["total"] = 80,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 80,
									["amount"] = 80,
								},
							},
							["amount"] = 80,
						},
						[53385] = {
							["school"] = 1,
							["total"] = 595,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 595,
									["amount"] = 595,
								},
							},
							["amount"] = 595,
						},
						[7294] = {
							["school"] = 2,
							["total"] = 76,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 50,
									["amount"] = 50,
								},
								["Beardedrasta"] = {
									["total"] = 26,
									["amount"] = 26,
								},
							},
							["amount"] = 76,
						},
						[42223] = {
							["school"] = 4,
							["total"] = 410,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 410,
									["amount"] = 410,
								},
							},
							["amount"] = 410,
						},
						[2643] = {
							["school"] = 1,
							["total"] = 250,
							["sources"] = {
								["Macius"] = {
									["total"] = 250,
									["amount"] = 250,
								},
							},
							["amount"] = 250,
						},
						[96172] = {
							["school"] = 2,
							["total"] = 2,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 2,
									["amount"] = 2,
								},
							},
							["amount"] = 2,
						},
					},
					["name"] = "Putridus Shadowstalker",
					["totaldamage"] = 2156,
					["totaldamagetaken"] = 1413,
					["id"] = "0xF1302E1000000011",
					["damage"] = 1782,
				}, -- [6]
			},
			["energy"] = 9,
			["totaldamage"] = 19191,
			["time"] = 41,
			["overheal"] = 4970,
			["totaldamagetaken"] = 18436,
			["etotaldamagetaken"] = 19191,
			["damage"] = 19191,
			["players"] = {
				{
					["last"] = 10578.673,
					["flag"] = 4369,
					["class"] = "WARLOCK",
					["auras"] = {
						[172] = {
							["type"] = "DEBUFF",
							["count"] = 1,
							["school"] = 32,
							["targets"] = {
								["Putridus Satyr"] = {
									["uptime"] = 12,
									["count"] = 1,
								},
							},
							["uptime"] = 12,
						},
						[17] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 2,
							["uptime"] = 2,
						},
						[139] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 2,
							["refresh"] = 2,
							["uptime"] = 11,
						},
						[5740] = {
							["type"] = "BUFF",
							["uptime"] = 14,
							["school"] = 4,
							["refresh"] = 27,
							["targets"] = {
								["Poison Sprite"] = {
									["uptime"] = 3,
									["count"] = 3,
								},
								["Corruptor"] = {
									["count"] = 4,
									["refresh"] = 1,
									["uptime"] = 6,
								},
								["Putridus Shadowstalker"] = {
									["count"] = 2,
									["refresh"] = 4,
									["uptime"] = 12,
								},
								["Deeprot Tangler"] = {
									["count"] = 2,
									["refresh"] = 4,
									["uptime"] = 12,
								},
								["Putridus Satyr"] = {
									["count"] = 2,
									["refresh"] = 2,
									["uptime"] = 6,
								},
								["Putridus Trickster"] = {
									["count"] = 7,
									["refresh"] = 12,
									["uptime"] = 14,
								},
							},
							["count"] = 23,
						},
						[30108] = {
							["type"] = "DEBUFF",
							["count"] = 1,
							["school"] = 32,
							["targets"] = {
								["Putridus Satyr"] = {
									["uptime"] = 12,
									["count"] = 1,
								},
							},
							["uptime"] = 12,
						},
					},
					["time"] = 18,
					["totaldamagetaken"] = 4388,
					["damage"] = 4064,
					["overheal"] = 33,
					["damagetaken"] = 3702,
					["deathlog"] = {
						{
							["log"] = {
								{
									["time"] = 1689857487.74001,
									["source"] = "Deeprot Tangler",
									["amount"] = -524,
									["school"] = 1,
									["hp"] = 295,
									["spellid"] = 6603,
									["overkill"] = 229,
								}, -- [1]
								{
									["source"] = "Putridus Trickster",
									["amount"] = -12,
									["school"] = 8,
									["hp"] = 361,
									["spellid"] = 13298,
									["time"] = 1689857487.56602,
								}, -- [2]
								{
									["time"] = 1689857487.56603,
									["source"] = "Putridus Trickster",
									["amount"] = -66,
									["school"] = 1,
									["hp"] = 373,
									["spellid"] = 6603,
									["absorbed"] = 181,
								}, -- [3]
								{
									["source"] = "Putridus Trickster",
									["time"] = 1689857487.03904,
									["school"] = 1,
									["hp"] = 317,
									["spellid"] = 15657,
									["absorbed"] = 303,
								}, -- [4]
								{
									["source"] = "Putridus Shadowstalker",
									["time"] = 1689857486.19205,
									["school"] = 1,
									["hp"] = 317,
									["spellid"] = 6603,
									["absorbed"] = 202,
								}, -- [5]
								{
									["source"] = "Deeprot Tangler",
									["amount"] = -460,
									["school"] = 1,
									["hp"] = 581,
									["spellid"] = 6603,
									["time"] = 1689857485.71906,
								}, -- [6]
								{
									["source"] = "Putridus Trickster",
									["amount"] = -197,
									["school"] = 1,
									["hp"] = 498,
									["spellid"] = 6603,
									["time"] = 1689857485.50407,
								}, -- [7]
								{
									["source"] = "Putridus Shadowstalker",
									["amount"] = -49,
									["school"] = 1,
									["hp"] = 498,
									["spellid"] = 9080,
									["time"] = 1689857484.40608,
								}, -- [8]
								{
									["source"] = "Putridus Trickster",
									["amount"] = -420,
									["school"] = 1,
									["hp"] = 967,
									["spellid"] = 6603,
									["time"] = 1689857483.99809,
								}, -- [9]
								{
									["source"] = "Deeprot Tangler",
									["amount"] = -416,
									["school"] = 1,
									["hp"] = 1383,
									["spellid"] = 6603,
									["time"] = 1689857483.6851,
								}, -- [10]
								{
									["source"] = "Putridus Shadowstalker",
									["amount"] = -264,
									["school"] = 1,
									["hp"] = 1383,
									["spellid"] = 6603,
									["time"] = 1689857481.35911,
								}, -- [11]
								{
									["source"] = "Deeprot Tangler",
									["amount"] = -192,
									["school"] = 1,
									["hp"] = 281,
									["spellid"] = 6603,
									["time"] = 1689857475.19112,
								}, -- [12]
								{
									["source"] = "Putridus Trickster",
									["amount"] = -217,
									["school"] = 1,
									["hp"] = 498,
									["spellid"] = 6603,
									["time"] = 1689857474.87213,
								}, -- [13]
							},
							["time"] = 1689857487.74,
							["maxhp"] = 1383,
						}, -- [1]
					},
					["id"] = "0x000000000004825C",
					["spec"] = 265,
					["healspells"] = {
						[63106] = {
							["overheal"] = 33,
							["count"] = 1,
							["amount"] = 0,
							["school"] = 32,
							["targets"] = {
								["Beardedrasta"] = {
									["overheal"] = 33,
									["amount"] = 0,
								},
							},
						},
					},
					["damagetakenspells"] = {
						["Poison (DoT)"] = {
							["total"] = 12,
							["hitmin"] = 12,
							["id"] = 13298,
							["sources"] = {
								["Putridus Trickster"] = {
									["total"] = 12,
									["amount"] = 12,
								},
							},
							["count"] = 1,
							["hit"] = 1,
							["school"] = 8,
							["hitmax"] = 12,
							["amount"] = 12,
							["hitamount"] = 12,
						},
						["Melee"] = {
							["hitmin"] = 66,
							["criticalmin"] = 416,
							["sources"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 673,
									["amount"] = 471,
								},
								["Putridus Trickster"] = {
									["total"] = 1300,
									["amount"] = 1119,
								},
								["Deeprot Tangler"] = {
									["total"] = 1824,
									["overkill"] = 229,
									["amount"] = 1824,
								},
								["Corruptor"] = {
									["total"] = 227,
									["amount"] = 227,
								},
							},
							["amount"] = 3641,
							["MISS"] = 1,
							["total"] = 4024,
							["criticalamount"] = 1820,
							["id"] = 6603,
							["overkill"] = 229,
							["ABSORB"] = 1,
							["criticalmax"] = 524,
							["hitmax"] = 264,
							["hit"] = 9,
							["school"] = 1,
							["critical"] = 4,
							["count"] = 15,
							["hitamount"] = 1821,
						},
						["Hamstring"] = {
							["total"] = 49,
							["hitmin"] = 49,
							["id"] = 9080,
							["sources"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 49,
									["amount"] = 49,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 1,
							["hitmax"] = 49,
							["amount"] = 49,
							["hitamount"] = 49,
						},
						["Backstab"] = {
							["sources"] = {
								["Putridus Trickster"] = {
									["total"] = 303,
									["amount"] = 0,
								},
							},
							["total"] = 303,
							["count"] = 1,
							["amount"] = 0,
							["school"] = 1,
							["ABSORB"] = 1,
							["casts"] = 1,
							["id"] = 15657,
						},
					},
					["heal"] = 0,
					["name"] = "Beardedrasta",
					["death"] = 1,
					["overkill"] = 30,
					["damagespells"] = {
						["Corruption (DoT)"] = {
							["total"] = 132,
							["hitmin"] = 44,
							["id"] = 172,
							["targets"] = {
								["Putridus Satyr"] = {
									["total"] = 132,
									["amount"] = 132,
								},
							},
							["count"] = 3,
							["hit"] = 3,
							["school"] = 32,
							["hitmax"] = 44,
							["amount"] = 132,
							["hitamount"] = 132,
						},
						["Melee"] = {
							["total"] = 65,
							["hitmin"] = 65,
							["id"] = 6603,
							["targets"] = {
								["Putridus Satyr"] = {
									["total"] = 65,
									["amount"] = 65,
								},
							},
							["count"] = 1,
							["hit"] = 1,
							["school"] = 1,
							["hitmax"] = 65,
							["amount"] = 65,
							["hitamount"] = 65,
						},
						["Retribution Aura"] = {
							["total"] = 167,
							["hitmin"] = 12,
							["id"] = 7294,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 26,
									["amount"] = 26,
								},
								["Putridus Trickster"] = {
									["total"] = 64,
									["amount"] = 64,
								},
								["Deeprot Tangler"] = {
									["total"] = 64,
									["amount"] = 64,
								},
								["Corruptor"] = {
									["total"] = 13,
									["amount"] = 13,
								},
							},
							["casts"] = 1,
							["count"] = 13,
							["hit"] = 13,
							["school"] = 2,
							["hitmax"] = 13,
							["amount"] = 167,
							["hitamount"] = 167,
						},
						["Rain of Fire"] = {
							["total"] = 2296,
							["hitmin"] = 82,
							["id"] = 42223,
							["targets"] = {
								["Poison Sprite"] = {
									["total"] = 82,
									["amount"] = 82,
								},
								["Corruptor"] = {
									["total"] = 246,
									["overkill"] = 3,
									["amount"] = 246,
								},
								["Putridus Shadowstalker"] = {
									["total"] = 410,
									["amount"] = 410,
								},
								["Putridus Satyr"] = {
									["total"] = 164,
									["amount"] = 164,
								},
								["Putridus Trickster"] = {
									["total"] = 1066,
									["amount"] = 1066,
								},
								["Deeprot Tangler"] = {
									["total"] = 328,
									["amount"] = 328,
								},
							},
							["overkill"] = 3,
							["hitmax"] = 82,
							["casts"] = 3,
							["count"] = 33,
							["amount"] = 2296,
							["school"] = 4,
							["hit"] = 28,
							["MISS"] = 5,
							["hitamount"] = 2296,
						},
						["Unstable Affliction (DoT)"] = {
							["total"] = 196,
							["hitmin"] = 49,
							["id"] = 30108,
							["targets"] = {
								["Putridus Satyr"] = {
									["total"] = 196,
									["overkill"] = 27,
									["amount"] = 196,
								},
							},
							["overkill"] = 27,
							["count"] = 4,
							["hit"] = 4,
							["school"] = 32,
							["hitmax"] = 49,
							["amount"] = 196,
							["hitamount"] = 196,
						},
						["Melee (Haagroon)"] = {
							["DODGE"] = 2,
							["total"] = 709,
							["hitmin"] = 43,
							["id"] = 6603,
							["targets"] = {
								["Putridus Satyr"] = {
									["total"] = 407,
									["amount"] = 407,
								},
								["Putridus Trickster"] = {
									["total"] = 302,
									["amount"] = 302,
								},
							},
							["glancing"] = 3,
							["blocked"] = 18,
							["count"] = 14,
							["hit"] = 9,
							["school"] = 1,
							["hitmax"] = 69,
							["amount"] = 709,
							["hitamount"] = 557,
						},
						["Shadow Bite (Haagroon)"] = {
							["total"] = 499,
							["hitmin"] = 80,
							["id"] = 54049,
							["targets"] = {
								["Putridus Satyr"] = {
									["total"] = 338,
									["amount"] = 338,
								},
								["Putridus Trickster"] = {
									["total"] = 161,
									["amount"] = 161,
								},
							},
							["casts"] = 5,
							["count"] = 5,
							["hit"] = 5,
							["school"] = 32,
							["hitmax"] = 131,
							["amount"] = 499,
							["hitamount"] = 499,
						},
					},
					["totaldamage"] = 4064,
					["role"] = "DAMAGER",
				}, -- [1]
				{
					["last"] = 10557.98,
					["flag"] = 1298,
					["class"] = "PALADIN",
					["auras"] = {
						[31790] = {
							["type"] = "DEBUFF",
							["count"] = 1,
							["school"] = 1,
							["targets"] = {
								["Putridus Satyr"] = {
									["uptime"] = 3,
									["count"] = 1,
								},
							},
							["uptime"] = 3,
						},
						[139] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 2,
							["uptime"] = 2,
						},
						[26573] = {
							["type"] = "DEBUFF",
							["count"] = 4,
							["school"] = 2,
							["targets"] = {
								["Corruptor"] = {
									["uptime"] = 41,
									["count"] = 2,
								},
								["Putridus Trickster"] = {
									["uptime"] = 10,
									["count"] = 1,
								},
								["Myrony"] = {
									["uptime"] = 41,
									["count"] = 1,
								},
							},
							["uptime"] = 41,
						},
					},
					["time"] = 6.090000000000001,
					["totaldamagetaken"] = 2517,
					["damage"] = 1034,
					["damagespells"] = {
						["Consecration"] = {
							["total"] = 568,
							["hitmin"] = 25,
							["id"] = 81297,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 284,
									["amount"] = 284,
								},
								["Corruptor"] = {
									["total"] = 284,
									["amount"] = 284,
								},
							},
							["casts"] = 1,
							["count"] = 20,
							["hit"] = 20,
							["school"] = 2,
							["hitmax"] = 32,
							["amount"] = 568,
							["hitamount"] = 568,
						},
						["Retribution Aura"] = {
							["total"] = 143,
							["hitmin"] = 13,
							["id"] = 7294,
							["targets"] = {
								["Deeprot Tangler"] = {
									["total"] = 13,
									["amount"] = 13,
								},
								["Poison Sprite"] = {
									["total"] = 13,
									["amount"] = 13,
								},
								["Corruptor"] = {
									["total"] = 65,
									["amount"] = 65,
								},
								["Putridus Trickster"] = {
									["total"] = 52,
									["amount"] = 52,
								},
							},
							["casts"] = 1,
							["count"] = 11,
							["hit"] = 11,
							["school"] = 2,
							["hitmax"] = 13,
							["amount"] = 143,
							["hitamount"] = 143,
						},
						["Melee"] = {
							["total"] = 261,
							["hitmin"] = 118,
							["id"] = 6603,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 118,
									["amount"] = 118,
								},
								["Deeprot Tangler"] = {
									["total"] = 143,
									["amount"] = 143,
								},
							},
							["count"] = 2,
							["hit"] = 2,
							["school"] = 1,
							["hitmax"] = 143,
							["amount"] = 261,
							["hitamount"] = 261,
						},
						["Seal of Righteousness"] = {
							["total"] = 62,
							["hitmin"] = 16,
							["criticalamount"] = 46,
							["id"] = 25742,
							["criticalmin"] = 46,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 16,
									["amount"] = 16,
								},
								["Deeprot Tangler"] = {
									["total"] = 46,
									["amount"] = 46,
								},
							},
							["criticalmax"] = 46,
							["critical"] = 1,
							["casts"] = 1,
							["count"] = 2,
							["hit"] = 1,
							["school"] = 2,
							["hitmax"] = 16,
							["amount"] = 62,
							["hitamount"] = 16,
						},
					},
					["damagetaken"] = 2517,
					["deathlog"] = {
						{
							["log"] = {
								{
									["time"] = 1689857467.01701,
									["source"] = "Deeprot Tangler",
									["amount"] = -186,
									["school"] = 1,
									["hp"] = 4,
									["spellid"] = 6603,
									["overkill"] = 182,
								}, -- [1]
								{
									["source"] = "Putridus Trickster",
									["amount"] = -254,
									["school"] = 1,
									["hp"] = 4,
									["spellid"] = 15657,
									["time"] = 1689857465.96302,
								}, -- [2]
								{
									["source"] = "Corruptor",
									["amount"] = -191,
									["school"] = 1,
									["hp"] = 446,
									["spellid"] = 6603,
									["time"] = 1689857465.67903,
								}, -- [3]
								{
									["source"] = "Putridus Trickster",
									["amount"] = -283,
									["school"] = 1,
									["hp"] = 446,
									["spellid"] = 15657,
									["time"] = 1689857465.67904,
								}, -- [4]
								{
									["source"] = "Corruptor",
									["amount"] = -188,
									["school"] = 1,
									["hp"] = 970,
									["spellid"] = 6603,
									["time"] = 1689857464.47005,
								}, -- [5]
								{
									["source"] = "Putridus Trickster",
									["amount"] = -173,
									["school"] = 1,
									["hp"] = 970,
									["spellid"] = 6603,
									["time"] = 1689857464.47006,
								}, -- [6]
								{
									["source"] = "Putridus Trickster",
									["amount"] = -205,
									["school"] = 1,
									["hp"] = 1175,
									["spellid"] = 6603,
									["time"] = 1689857463.94907,
								}, -- [7]
								{
									["source"] = "Corruptor",
									["amount"] = -198,
									["school"] = 1,
									["hp"] = 1370,
									["spellid"] = 6603,
									["time"] = 1689857463.22908,
								}, -- [8]
								{
									["source"] = "Putridus Trickster",
									["amount"] = -153,
									["school"] = 1,
									["hp"] = 1523,
									["spellid"] = 6603,
									["time"] = 1689857462.50409,
								}, -- [9]
								{
									["source"] = "Corruptor",
									["amount"] = -204,
									["school"] = 1,
									["hp"] = 1727,
									["spellid"] = 6603,
									["time"] = 1689857462.2751,
								}, -- [10]
								{
									["source"] = "Putridus Trickster",
									["amount"] = -156,
									["school"] = 1,
									["hp"] = 1883,
									["spellid"] = 6603,
									["time"] = 1689857462.13011,
								}, -- [11]
								{
									["source"] = "Poison Sprite",
									["amount"] = -171,
									["school"] = 1,
									["hp"] = 2051,
									["spellid"] = 6603,
									["time"] = 1689857461.35812,
								}, -- [12]
								{
									["source"] = "Corruptor",
									["amount"] = -155,
									["school"] = 1,
									["hp"] = 2206,
									["spellid"] = 6603,
									["time"] = 1689857461.21313,
								}, -- [13]
							},
							["time"] = 1689857467.017,
							["maxhp"] = 2206,
						}, -- [1]
					},
					["id"] = "0x00000000000447DB",
					["damagetakenspells"] = {
						["Melee"] = {
							["DODGE"] = 1,
							["total"] = 1980,
							["hitmin"] = 153,
							["id"] = 6603,
							["hitmax"] = 205,
							["overkill"] = 182,
							["PARRY"] = 4,
							["sources"] = {
								["Poison Sprite"] = {
									["total"] = 171,
									["amount"] = 171,
								},
								["Corruptor"] = {
									["total"] = 936,
									["amount"] = 936,
								},
								["Deeprot Tangler"] = {
									["total"] = 186,
									["overkill"] = 182,
									["amount"] = 186,
								},
								["Putridus Trickster"] = {
									["total"] = 687,
									["amount"] = 687,
								},
								["Putridus Satyr"] = {
									["total"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 17,
							["amount"] = 1980,
							["school"] = 1,
							["hit"] = 11,
							["MISS"] = 1,
							["hitamount"] = 1980,
						},
						["Backstab"] = {
							["total"] = 537,
							["hitmin"] = 254,
							["id"] = 15657,
							["sources"] = {
								["Putridus Trickster"] = {
									["total"] = 537,
									["amount"] = 537,
								},
							},
							["casts"] = 2,
							["count"] = 2,
							["hit"] = 2,
							["school"] = 1,
							["hitmax"] = 283,
							["amount"] = 537,
							["hitamount"] = 537,
						},
					},
					["name"] = "Myrony",
					["death"] = 1,
					["totaldamage"] = 1034,
					["mana"] = 230,
					["role"] = "TANK",
					["manaspells"] = {
						[84627] = 230,
					},
				}, -- [2]
				{
					["ccdonespells"] = {
						[2812] = {
							["count"] = 14,
							["targets"] = {
								["Poison Sprite"] = 2,
								["Corruptor"] = 3,
								["Putridus Shadowstalker"] = 2,
								["Putridus Trickster"] = 6,
								["Putridus Satyr"] = 1,
							},
						},
					},
					["last"] = 10586.417,
					["flag"] = 1298,
					["class"] = "PALADIN",
					["auras"] = {
						[2812] = {
							["type"] = "DEBUFF",
							["count"] = 14,
							["school"] = 2,
							["targets"] = {
								["Poison Sprite"] = {
									["uptime"] = 3,
									["count"] = 2,
								},
								["Corruptor"] = {
									["uptime"] = 3,
									["count"] = 3,
								},
								["Putridus Shadowstalker"] = {
									["uptime"] = 6,
									["count"] = 2,
								},
								["Putridus Trickster"] = {
									["uptime"] = 6,
									["count"] = 6,
								},
								["Putridus Satyr"] = {
									["uptime"] = 3,
									["count"] = 1,
								},
							},
							["uptime"] = 6,
						},
						[17] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 2,
							["uptime"] = 8,
						},
						[94686] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 1,
							["uptime"] = 6,
						},
						[89906] = {
							["type"] = "BUFF",
							["count"] = 2,
							["school"] = 2,
							["uptime"] = 13,
						},
						[139] = {
							["type"] = "BUFF",
							["count"] = 2,
							["school"] = 2,
							["uptime"] = 17,
						},
						[25771] = {
							["type"] = "DEBUFF",
							["count"] = 1,
							["school"] = 2,
							["targets"] = {
								["Fragrance"] = {
									["uptime"] = 17,
									["count"] = 1,
								},
							},
							["uptime"] = 17,
						},
						[1022] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 2,
							["uptime"] = 9,
						},
					},
					["time"] = 26.95,
					["totaldamagetaken"] = 5767,
					["damage"] = 9649,
					["damagespells"] = {
						["Exorcism"] = {
							["total"] = 489,
							["criticalamount"] = 489,
							["id"] = 879,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 489,
									["amount"] = 489,
								},
							},
							["casts"] = 1,
							["critical"] = 1,
							["amount"] = 489,
							["school"] = 2,
							["criticalmin"] = 489,
							["criticalmax"] = 489,
							["count"] = 1,
						},
						["Melee"] = {
							["total"] = 1235,
							["hitmin"] = 199,
							["criticalamount"] = 404,
							["id"] = 6603,
							["targets"] = {
								["Putridus Satyr"] = {
									["total"] = 831,
									["amount"] = 831,
								},
								["Putridus Trickster"] = {
									["total"] = 404,
									["amount"] = 404,
								},
							},
							["criticalmin"] = 404,
							["critical"] = 1,
							["criticalmax"] = 404,
							["count"] = 5,
							["hit"] = 4,
							["school"] = 1,
							["hitmax"] = 224,
							["amount"] = 1235,
							["hitamount"] = 831,
						},
						["Retribution Aura"] = {
							["total"] = 298,
							["hitmin"] = 12,
							["id"] = 7294,
							["targets"] = {
								["Deeprot Tangler"] = {
									["total"] = 37,
									["amount"] = 37,
								},
								["Putridus Trickster"] = {
									["total"] = 146,
									["amount"] = 146,
								},
								["Putridus Shadowstalker"] = {
									["total"] = 50,
									["amount"] = 50,
								},
								["Putridus Satyr"] = {
									["total"] = 65,
									["amount"] = 65,
								},
							},
							["casts"] = 1,
							["count"] = 24,
							["hit"] = 24,
							["school"] = 2,
							["hitmax"] = 13,
							["amount"] = 298,
							["hitamount"] = 298,
						},
						["Crusader Strike"] = {
							["total"] = 346,
							["hitmin"] = 346,
							["id"] = 35395,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 346,
									["amount"] = 346,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 1,
							["hitmax"] = 346,
							["amount"] = 346,
							["hitamount"] = 346,
						},
						["Judgement of Righteousness"] = {
							["total"] = 238,
							["hitmin"] = 110,
							["id"] = 20187,
							["targets"] = {
								["Putridus Satyr"] = {
									["total"] = 128,
									["amount"] = 128,
								},
								["Putridus Trickster"] = {
									["total"] = 110,
									["amount"] = 110,
								},
							},
							["casts"] = 2,
							["count"] = 2,
							["hit"] = 2,
							["school"] = 2,
							["hitmax"] = 128,
							["amount"] = 238,
							["hitamount"] = 238,
						},
						["Templar's Verdict"] = {
							["total"] = 1312,
							["hitmin"] = 645,
							["id"] = 85256,
							["targets"] = {
								["Putridus Satyr"] = {
									["total"] = 667,
									["amount"] = 667,
								},
								["Putridus Trickster"] = {
									["total"] = 645,
									["amount"] = 645,
								},
							},
							["casts"] = 2,
							["count"] = 2,
							["hit"] = 2,
							["school"] = 1,
							["hitmax"] = 667,
							["amount"] = 1312,
							["hitamount"] = 1312,
						},
						["Seal of Righteousness"] = {
							["total"] = 131,
							["hitmin"] = 23,
							["id"] = 25742,
							["targets"] = {
								["Putridus Satyr"] = {
									["total"] = 81,
									["amount"] = 81,
								},
								["Putridus Trickster"] = {
									["total"] = 50,
									["amount"] = 50,
								},
							},
							["casts"] = 1,
							["count"] = 5,
							["hit"] = 5,
							["school"] = 2,
							["hitmax"] = 27,
							["amount"] = 131,
							["hitamount"] = 131,
						},
						["Hand of Light"] = {
							["total"] = 24,
							["hitmin"] = 1,
							["id"] = 96172,
							["targets"] = {
								["Poison Sprite"] = {
									["total"] = 3,
									["amount"] = 3,
								},
								["Deeprot Tangler"] = {
									["total"] = 4,
									["amount"] = 4,
								},
								["Corruptor"] = {
									["total"] = 2,
									["amount"] = 2,
								},
								["Putridus Trickster"] = {
									["total"] = 10,
									["amount"] = 10,
								},
								["Putridus Satyr"] = {
									["total"] = 3,
									["amount"] = 3,
								},
								["Putridus Shadowstalker"] = {
									["total"] = 2,
									["amount"] = 2,
								},
							},
							["casts"] = 1,
							["count"] = 24,
							["hit"] = 24,
							["school"] = 2,
							["hitmax"] = 1,
							["amount"] = 24,
							["hitamount"] = 24,
						},
						["Divine Storm"] = {
							["DODGE"] = 2,
							["hitmin"] = 127,
							["criticalmin"] = 390,
							["targets"] = {
								["Poison Sprite"] = {
									["total"] = 505,
									["amount"] = 505,
								},
								["Deeprot Tangler"] = {
									["total"] = 788,
									["amount"] = 788,
								},
								["Corruptor"] = {
									["total"] = 437,
									["amount"] = 437,
								},
								["Putridus Trickster"] = {
									["total"] = 2272,
									["amount"] = 2272,
								},
								["Putridus Satyr"] = {
									["total"] = 381,
									["amount"] = 381,
								},
								["Putridus Shadowstalker"] = {
									["total"] = 595,
									["amount"] = 595,
								},
							},
							["amount"] = 4978,
							["total"] = 4978,
							["criticalamount"] = 1220,
							["id"] = 53385,
							["blocked"] = 54,
							["criticalmax"] = 432,
							["casts"] = 4,
							["hitmax"] = 225,
							["hit"] = 19,
							["school"] = 1,
							["critical"] = 3,
							["count"] = 24,
							["hitamount"] = 3758,
						},
						["Holy Wrath"] = {
							["total"] = 598,
							["hitmin"] = 31,
							["criticalamount"] = 143,
							["id"] = 2812,
							["criticalmin"] = 46,
							["targets"] = {
								["Poison Sprite"] = {
									["total"] = 102,
									["amount"] = 102,
								},
								["Corruptor"] = {
									["total"] = 93,
									["amount"] = 93,
								},
								["Putridus Shadowstalker"] = {
									["total"] = 80,
									["amount"] = 80,
								},
								["Putridus Satyr"] = {
									["total"] = 31,
									["amount"] = 31,
								},
								["Putridus Trickster"] = {
									["total"] = 212,
									["amount"] = 212,
								},
								["Deeprot Tangler"] = {
									["total"] = 80,
									["amount"] = 80,
								},
							},
							["criticalmax"] = 51,
							["critical"] = 3,
							["casts"] = 2,
							["count"] = 17,
							["hit"] = 14,
							["school"] = 2,
							["hitmax"] = 34,
							["amount"] = 598,
							["hitamount"] = 455,
						},
					},
					["death"] = 1,
					["damagetaken"] = 4993,
					["deathlog"] = {
						{
							["log"] = {
								{
									["spellid"] = 6603,
									["source"] = "Putridus Trickster",
									["amount"] = -197,
									["school"] = 1,
									["time"] = 1689857495.58701,
									["hp"] = 320,
									["overkill"] = 85,
								}, -- [1]
								{
									["source"] = "Putridus Trickster",
									["amount"] = -208,
									["school"] = 1,
									["hp"] = 320,
									["spellid"] = 6603,
									["time"] = 1689857495.58702,
								}, -- [2]
								{
									["source"] = "Putridus Trickster",
									["amount"] = -210,
									["school"] = 1,
									["hp"] = 530,
									["spellid"] = 6603,
									["time"] = 1689857495.11003,
								}, -- [3]
								{
									["source"] = "Putridus Trickster",
									["amount"] = -177,
									["school"] = 1,
									["hp"] = 707,
									["spellid"] = 6603,
									["time"] = 1689857494.63104,
								}, -- [4]
								{
									["source"] = "Deeprot Tangler",
									["amount"] = -179,
									["school"] = 1,
									["hp"] = 886,
									["spellid"] = 6603,
									["time"] = 1689857494.20705,
								}, -- [5]
								{
									["hp"] = 1069,
									["source"] = "Putridus Trickster",
									["amount"] = -183,
									["school"] = 1,
									["spellid"] = 6603,
									["time"] = 1689857494.10306,
								}, -- [6]
								{
									["source"] = "Putridus Trickster",
									["amount"] = -185,
									["school"] = 1,
									["hp"] = 1121,
									["spellid"] = 6603,
									["time"] = 1689857493.60307,
								}, -- [7]
								{
									["source"] = "Putridus Shadowstalker",
									["amount"] = -174,
									["school"] = 1,
									["hp"] = 357,
									["spellid"] = 6603,
									["time"] = 1689857493.47108,
								}, -- [8]
								{
									["source"] = "Putridus Trickster",
									["amount"] = -376,
									["school"] = 1,
									["hp"] = 733,
									["spellid"] = 6603,
									["time"] = 1689857493.11709,
								}, -- [9]
								{
									["source"] = "Deeprot Tangler",
									["amount"] = -215,
									["school"] = 1,
									["hp"] = 948,
									["spellid"] = 6603,
									["time"] = 1689857492.1721,
								}, -- [10]
								{
									["source"] = "Putridus Trickster",
									["amount"] = -200,
									["school"] = 1,
									["hp"] = 1095,
									["spellid"] = 6603,
									["time"] = 1689857489.52511,
								}, -- [11]
								{
									["time"] = 1689857489.08812,
									["source"] = "Putridus Trickster",
									["amount"] = -185,
									["school"] = 1,
									["hp"] = 1280,
									["spellid"] = 6603,
								}, -- [12]
								{
									["time"] = 1689857488.63013,
									["source"] = "Putridus Shadowstalker",
									["amount"] = -354,
									["school"] = 1,
									["hp"] = 1634,
									["spellid"] = 6603,
								}, -- [13]
							},
							["time"] = 1689857495.587,
							["maxhp"] = 1824,
						}, -- [1]
					},
					["id"] = "0x0000000000048007",
					["healspells"] = {
						[635] = {
							["overheal"] = 0,
							["count"] = 1,
							["amount"] = 417,
							["school"] = 2,
							["max"] = 417,
							["targets"] = {
								["Fragrance"] = {
									["overheal"] = 0,
									["amount"] = 417,
								},
							},
							["min"] = 417,
						},
						[54172] = {
							["overheal"] = 638,
							["max"] = 38,
							["targets"] = {
								["Nianhong"] = {
									["overheal"] = 49,
									["amount"] = 281,
								},
								["Macius"] = {
									["overheal"] = 124,
									["amount"] = 48,
								},
								["Cat"] = {
									["overheal"] = 0,
									["amount"] = 136,
								},
								["Myrony"] = {
									["overheal"] = 0,
									["amount"] = 50,
								},
								["Consecration"] = {
									["overheal"] = 70,
									["amount"] = 0,
								},
								["Beardedrasta"] = {
									["overheal"] = 114,
									["amount"] = 60,
								},
								["Fragrance"] = {
									["overheal"] = 281,
									["amount"] = 171,
								},
								["Haagroon"] = {
									["overheal"] = 0,
									["amount"] = 212,
								},
							},
							["min"] = 21,
							["casts"] = 58,
							["count"] = 58,
							["amount"] = 958,
							["school"] = 2,
							["ishot"] = true,
						},
						[19750] = {
							["overheal"] = 523,
							["count"] = 1,
							["amount"] = 186,
							["school"] = 2,
							["max"] = 186,
							["targets"] = {
								["Fragrance"] = {
									["overheal"] = 523,
									["amount"] = 186,
								},
							},
							["min"] = 186,
						},
					},
					["damagetakenspells"] = {
						["Gouge"] = {
							["DODGE"] = 1,
							["total"] = 14,
							["hitmin"] = 14,
							["id"] = 12540,
							["hitmax"] = 14,
							["casts"] = 2,
							["count"] = 2,
							["amount"] = 14,
							["school"] = 1,
							["sources"] = {
								["Putridus Satyr"] = {
									["total"] = 14,
									["amount"] = 14,
								},
							},
							["hit"] = 1,
							["hitamount"] = 14,
						},
						["Entangling Roots (DoT)"] = {
							["total"] = 19,
							["hitmin"] = 9,
							["id"] = 21331,
							["hitmax"] = 10,
							["sources"] = {
								["Deeprot Tangler"] = {
									["total"] = 19,
									["amount"] = 19,
								},
							},
							["count"] = 2,
							["hit"] = 2,
							["school"] = 8,
							["resisted"] = 5,
							["amount"] = 19,
							["hitamount"] = 19,
						},
						["Melee"] = {
							["DODGE"] = 1,
							["hitmin"] = 165,
							["criticalmin"] = 354,
							["IMMUNE"] = 3,
							["sources"] = {
								["Corruptor"] = {
									["total"] = 186,
									["amount"] = 0,
								},
								["Putridus Trickster"] = {
									["total"] = 2842,
									["overkill"] = 85,
									["amount"] = 2446,
								},
								["Deeprot Tangler"] = {
									["total"] = 617,
									["amount"] = 617,
								},
								["Putridus Satyr"] = {
									["total"] = 913,
									["amount"] = 893,
								},
								["Putridus Shadowstalker"] = {
									["total"] = 1132,
									["amount"] = 960,
								},
							},
							["amount"] = 4916,
							["MISS"] = 2,
							["total"] = 5690,
							["criticalamount"] = 730,
							["id"] = 6603,
							["criticalmax"] = 376,
							["overkill"] = 85,
							["critical"] = 2,
							["PARRY"] = 1,
							["hitmax"] = 224,
							["hit"] = 22,
							["school"] = 1,
							["ABSORB"] = 4,
							["count"] = 35,
							["hitamount"] = 4186,
						},
						["Hamstring"] = {
							["total"] = 44,
							["hitmin"] = 44,
							["id"] = 9080,
							["sources"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 44,
									["amount"] = 44,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 1,
							["hitmax"] = 44,
							["amount"] = 44,
							["hitamount"] = 44,
						},
					},
					["overheal"] = 1161,
					["heal"] = 1561,
					["manaspells"] = {
						[89906] = 504,
					},
					["ccdone"] = 14,
					["totaldamage"] = 9649,
					["mana"] = 504,
					["role"] = "DAMAGER",
					["name"] = "Fragrance",
				}, -- [3]
				{
					["last"] = 10590.465,
					["flag"] = 1298,
					["class"] = "PRIEST",
					["auras"] = {
						[139] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 2,
							["uptime"] = 5,
						},
						[6788] = {
							["type"] = "DEBUFF",
							["count"] = 2,
							["school"] = 2,
							["targets"] = {
								["Fragrance"] = {
									["uptime"] = 15,
									["count"] = 1,
								},
								["Beardedrasta"] = {
									["uptime"] = 2,
									["count"] = 1,
								},
							},
							["uptime"] = 17,
						},
						[88688] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 1,
							["uptime"] = 3,
						},
						[465] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 2,
							["uptime"] = 5,
						},
					},
					["absorbspells"] = {
						[17] = {
							["min"] = 20,
							["casts"] = 1,
							["count"] = 8,
							["amount"] = 1460,
							["school"] = 2,
							["targets"] = {
								["Fragrance"] = 774,
								["Beardedrasta"] = 686,
							},
							["max"] = 303,
						},
					},
					["time"] = 35.83,
					["mana"] = 515,
					["totaldamagetaken"] = 3106,
					["manaspells"] = {
						[2023] = 515,
					},
					["damage"] = 26,
					["overheal"] = 3776,
					["absorb"] = 1460,
					["damagetaken"] = 3106,
					["deathlog"] = {
						{
							["log"] = {
								{
									["time"] = 1689857500.78901,
									["source"] = "Putridus Trickster",
									["amount"] = -165,
									["school"] = 1,
									["hp"] = 120,
									["spellid"] = 6603,
									["overkill"] = 45,
								}, -- [1]
								{
									["source"] = "Putridus Trickster",
									["amount"] = -224,
									["school"] = 1,
									["hp"] = 344,
									["spellid"] = 6603,
									["time"] = 1689857500.69202,
								}, -- [2]
								{
									["source"] = "Deeprot Tangler",
									["amount"] = -170,
									["school"] = 1,
									["hp"] = 514,
									["spellid"] = 6603,
									["time"] = 1689857500.24903,
								}, -- [3]
								{
									["source"] = "Putridus Trickster",
									["amount"] = -182,
									["school"] = 1,
									["hp"] = 696,
									["spellid"] = 6603,
									["time"] = 1689857499.63604,
								}, -- [4]
								{
									["source"] = "Putridus Trickster",
									["amount"] = -212,
									["school"] = 1,
									["hp"] = 908,
									["spellid"] = 6603,
									["time"] = 1689857499.26905,
								}, -- [5]
								{
									["source"] = "Putridus Trickster",
									["amount"] = -228,
									["school"] = 1,
									["hp"] = 968,
									["spellid"] = 6603,
									["time"] = 1689857498.12206,
								}, -- [6]
								{
									["source"] = "Putridus Shadowstalker",
									["amount"] = -38,
									["school"] = 1,
									["hp"] = 968,
									["spellid"] = 9080,
									["time"] = 1689857498.08107,
								}, -- [7]
								{
									["source"] = "Putridus Trickster",
									["amount"] = -226,
									["school"] = 1,
									["hp"] = 1232,
									["spellid"] = 6603,
									["time"] = 1689857497.76208,
								}, -- [8]
								{
									["source"] = "Putridus Trickster",
									["amount"] = -192,
									["school"] = 1,
									["hp"] = 1424,
									["spellid"] = 6603,
									["time"] = 1689857497.66509,
								}, -- [9]
								{
									["source"] = "Putridus Trickster",
									["amount"] = -183,
									["school"] = 1,
									["hp"] = 1845,
									["spellid"] = 6603,
									["time"] = 1689857496.2411,
								}, -- [10]
								{
									["source"] = "Deeprot Tangler",
									["amount"] = -238,
									["school"] = 1,
									["hp"] = 1845,
									["spellid"] = 6603,
									["time"] = 1689857496.24111,
								}, -- [11]
								{
									["source"] = "Putridus Shadowstalker",
									["amount"] = -220,
									["school"] = 1,
									["hp"] = 2065,
									["spellid"] = 6603,
									["time"] = 1689857496.20712,
								}, -- [12]
								{
									["source"] = "Putridus Trickster",
									["amount"] = -189,
									["school"] = 1,
									["hp"] = 2254,
									["spellid"] = 6603,
									["time"] = 1689857496.13713,
								}, -- [13]
							},
							["time"] = 1689857500.789,
							["maxhp"] = 2254,
						}, -- [1]
					},
					["id"] = "0x00000000000467C0",
					["healspells"] = {
						[56160] = {
							["overheal"] = 0,
							["count"] = 2,
							["amount"] = 381,
							["school"] = 2,
							["max"] = 196,
							["targets"] = {
								["Fragrance"] = {
									["overheal"] = 0,
									["amount"] = 185,
								},
								["Beardedrasta"] = {
									["overheal"] = 0,
									["amount"] = 196,
								},
							},
							["min"] = 185,
						},
						[63544] = {
							["min"] = 48,
							["count"] = 9,
							["amount"] = 440,
							["max"] = 70,
							["overheal"] = 67,
							["targets"] = {
								["Myrony"] = {
									["overheal"] = 0,
									["amount"] = 70,
								},
								["Nianhong"] = {
									["overheal"] = 67,
									["amount"] = 0,
								},
								["Macius"] = {
									["overheal"] = 0,
									["amount"] = 96,
								},
								["Fragrance"] = {
									["overheal"] = 0,
									["amount"] = 106,
								},
								["Beardedrasta"] = {
									["overheal"] = 0,
									["amount"] = 168,
								},
							},
							["school"] = 2,
						},
						[139] = {
							["overheal"] = 140,
							["criticalamount"] = 280,
							["max"] = 280,
							["targets"] = {
								["Nianhong"] = {
									["overheal"] = 0,
									["amount"] = 168,
								},
								["Macius"] = {
									["overheal"] = 0,
									["amount"] = 366,
								},
								["Fragrance"] = {
									["overheal"] = 0,
									["amount"] = 665,
								},
								["Beardedrasta"] = {
									["overheal"] = 140,
									["amount"] = 420,
								},
							},
							["criticalmin"] = 280,
							["min"] = 122,
							["casts"] = 9,
							["count"] = 12,
							["amount"] = 1619,
							["school"] = 2,
							["criticalmax"] = 280,
							["ishot"] = true,
							["critical"] = 1,
						},
						[101062] = {
							["overheal"] = 634,
							["count"] = 1,
							["amount"] = 358,
							["school"] = 2,
							["max"] = 358,
							["targets"] = {
								["Nianhong"] = {
									["overheal"] = 634,
									["amount"] = 358,
								},
							},
							["min"] = 358,
						},
						[2061] = {
							["overheal"] = 2935,
							["max"] = 1007,
							["targets"] = {
								["Nianhong"] = {
									["overheal"] = 942,
									["amount"] = 0,
								},
								["Fragrance"] = {
									["overheal"] = 1009,
									["amount"] = 1945,
								},
								["Beardedrasta"] = {
									["overheal"] = 984,
									["amount"] = 1246,
								},
							},
							["min"] = 264,
							["casts"] = 6,
							["count"] = 6,
							["amount"] = 3191,
							["school"] = 2,
						},
					},
					["damagetakenspells"] = {
						["Melee"] = {
							["DODGE"] = 1,
							["hitmin"] = 165,
							["criticalmin"] = 464,
							["sources"] = {
								["Deeprot Tangler"] = {
									["total"] = 408,
									["amount"] = 408,
								},
								["Putridus Shadowstalker"] = {
									["total"] = 220,
									["amount"] = 220,
								},
								["Putridus Trickster"] = {
									["total"] = 2440,
									["overkill"] = 45,
									["amount"] = 2440,
								},
							},
							["amount"] = 3068,
							["MISS"] = 3,
							["total"] = 3068,
							["criticalamount"] = 464,
							["id"] = 6603,
							["overkill"] = 45,
							["criticalmax"] = 464,
							["critical"] = 1,
							["hit"] = 13,
							["school"] = 1,
							["hitmax"] = 238,
							["count"] = 18,
							["hitamount"] = 2604,
						},
						["Hamstring"] = {
							["total"] = 38,
							["hitmin"] = 38,
							["id"] = 9080,
							["sources"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 38,
									["amount"] = 38,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 1,
							["hitmax"] = 38,
							["amount"] = 38,
							["hitamount"] = 38,
						},
					},
					["potionspells"] = {
						[3827] = 1,
					},
					["heal"] = 5989,
					["name"] = "Nianhong",
					["death"] = 1,
					["potion"] = 1,
					["damagespells"] = {
						["Retribution Aura"] = {
							["total"] = 26,
							["hitmin"] = 13,
							["id"] = 7294,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 26,
									["amount"] = 26,
								},
							},
							["casts"] = 1,
							["count"] = 2,
							["hit"] = 2,
							["school"] = 2,
							["hitmax"] = 13,
							["amount"] = 26,
							["hitamount"] = 26,
						},
					},
					["totaldamage"] = 26,
					["role"] = "HEALER",
				}, -- [4]
				{
					["last"] = 10573.305,
					["flag"] = 1298,
					["class"] = "HUNTER",
					["auras"] = {
						[139] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 2,
							["refresh"] = 1,
							["uptime"] = 9,
						},
					},
					["energyspells"] = {
						[91954] = 9,
					},
					["totaldamage"] = 4418,
					["time"] = 17.83,
					["totaldamagetaken"] = 2658,
					["damage"] = 4418,
					["damagespells"] = {
						["Steady Shot"] = {
							["total"] = 125,
							["hitmin"] = 125,
							["id"] = 56641,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 125,
									["amount"] = 125,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 1,
							["hitmax"] = 125,
							["amount"] = 125,
							["hitamount"] = 125,
						},
						["Melee"] = {
							["total"] = 112,
							["hitmin"] = 18,
							["id"] = 6603,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 112,
									["amount"] = 112,
								},
							},
							["hitmax"] = 51,
							["count"] = 7,
							["amount"] = 112,
							["school"] = 1,
							["hit"] = 4,
							["MISS"] = 3,
							["hitamount"] = 112,
						},
						["Claw (Cat)"] = {
							["DODGE"] = 1,
							["total"] = 337,
							["hitmin"] = 83,
							["id"] = 16827,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 337,
									["amount"] = 337,
								},
							},
							["casts"] = 5,
							["count"] = 5,
							["hit"] = 4,
							["school"] = 1,
							["hitmax"] = 85,
							["amount"] = 337,
							["hitamount"] = 337,
						},
						["Auto Shot"] = {
							["total"] = 733,
							["hitmin"] = 128,
							["id"] = 75,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 733,
									["amount"] = 733,
								},
							},
							["amount"] = 733,
							["casts"] = 1,
							["count"] = 6,
							["hit"] = 5,
							["school"] = 1,
							["hitmax"] = 153,
							["MISS"] = 1,
							["hitamount"] = 733,
						},
						["Melee (Cat)"] = {
							["criticalmin"] = 116,
							["total"] = 412,
							["hitmin"] = 62,
							["criticalamount"] = 116,
							["id"] = 6603,
							["amount"] = 412,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 412,
									["amount"] = 412,
								},
							},
							["critical"] = 1,
							["glancing"] = 1,
							["criticalmax"] = 116,
							["count"] = 7,
							["hit"] = 4,
							["school"] = 1,
							["hitmax"] = 64,
							["MISS"] = 1,
							["hitamount"] = 252,
						},
						["Multi-Shot"] = {
							["total"] = 2569,
							["hitmin"] = 101,
							["id"] = 2643,
							["targets"] = {
								["Poison Sprite"] = {
									["total"] = 250,
									["amount"] = 250,
								},
								["Corruptor"] = {
									["total"] = 873,
									["overkill"] = 161,
									["amount"] = 873,
								},
								["Putridus Shadowstalker"] = {
									["total"] = 250,
									["amount"] = 250,
								},
								["Putridus Satyr"] = {
									["total"] = 121,
									["amount"] = 121,
								},
								["Putridus Trickster"] = {
									["total"] = 817,
									["amount"] = 817,
								},
								["Deeprot Tangler"] = {
									["total"] = 258,
									["amount"] = 258,
								},
							},
							["overkill"] = 161,
							["amount"] = 2569,
							["casts"] = 4,
							["count"] = 22,
							["hit"] = 21,
							["school"] = 1,
							["hitmax"] = 136,
							["MISS"] = 1,
							["hitamount"] = 2569,
						},
						["Retribution Aura"] = {
							["total"] = 130,
							["hitmin"] = 13,
							["id"] = 7294,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 117,
									["amount"] = 117,
								},
								["Deeprot Tangler"] = {
									["total"] = 13,
									["amount"] = 13,
								},
							},
							["casts"] = 1,
							["count"] = 10,
							["hit"] = 10,
							["school"] = 2,
							["hitmax"] = 13,
							["amount"] = 130,
							["hitamount"] = 130,
						},
					},
					["damagetaken"] = 2658,
					["deathlog"] = {
						{
							["log"] = {
								{
									["time"] = 1689857483.12901,
									["source"] = "Putridus Trickster",
									["amount"] = -198,
									["school"] = 1,
									["hp"] = 16,
									["spellid"] = 6603,
									["overkill"] = 182,
								}, -- [1]
								{
									["source"] = "Putridus Trickster",
									["amount"] = -244,
									["school"] = 1,
									["hp"] = 260,
									["spellid"] = 6603,
									["time"] = 1689857483.01802,
								}, -- [2]
								{
									["source"] = "Deeprot Tangler",
									["amount"] = -227,
									["school"] = 1,
									["hp"] = 365,
									["spellid"] = 6603,
									["time"] = 1689857481.66503,
								}, -- [3]
								{
									["source"] = "Putridus Trickster",
									["amount"] = -209,
									["school"] = 1,
									["hp"] = 574,
									["spellid"] = 6603,
									["time"] = 1689857481.60204,
								}, -- [4]
								{
									["source"] = "Putridus Trickster",
									["amount"] = -246,
									["school"] = 1,
									["hp"] = 820,
									["spellid"] = 6603,
									["time"] = 1689857481.49805,
								}, -- [5]
								{
									["source"] = "Putridus Trickster",
									["amount"] = -225,
									["school"] = 1,
									["hp"] = 1045,
									["spellid"] = 6603,
									["time"] = 1689857479.98906,
								}, -- [6]
								{
									["time"] = 1689857478.47007,
									["source"] = "Putridus Trickster",
									["amount"] = -209,
									["school"] = 1,
									["hp"] = 1132,
									["spellid"] = 6603,
								}, -- [7]
								{
									["time"] = 1689857476.96308,
									["source"] = "Putridus Trickster",
									["amount"] = -227,
									["school"] = 1,
									["hp"] = 1359,
									["spellid"] = 6603,
								}, -- [8]
								{
									["source"] = "Putridus Trickster",
									["amount"] = -289,
									["school"] = 1,
									["hp"] = 1141,
									["spellid"] = 15657,
									["time"] = 1689857474.64309,
								}, -- [9]
								{
									["source"] = "Putridus Trickster",
									["amount"] = -216,
									["school"] = 1,
									["hp"] = 1598,
									["spellid"] = 6603,
									["time"] = 1689857470.7271,
								}, -- [10]
								{
									["source"] = "Putridus Trickster",
									["amount"] = -368,
									["school"] = 1,
									["hp"] = 1966,
									["spellid"] = 6603,
									["time"] = 1689857470.69111,
								}, -- [11]
							},
							["time"] = 1689857483.129,
							["maxhp"] = 1966,
						}, -- [1]
					},
					["id"] = "0x00000000000477A3",
					["overkill"] = 161,
					["name"] = "Macius",
					["death"] = 1,
					["role"] = "DAMAGER",
					["damagetakenspells"] = {
						["Melee"] = {
							["count"] = 11,
							["total"] = 2369,
							["hitmin"] = 198,
							["criticalamount"] = 368,
							["id"] = 6603,
							["criticalmin"] = 368,
							["hitmax"] = 246,
							["overkill"] = 182,
							["hit"] = 9,
							["criticalmax"] = 368,
							["critical"] = 1,
							["amount"] = 2369,
							["school"] = 1,
							["sources"] = {
								["Putridus Trickster"] = {
									["total"] = 2142,
									["overkill"] = 182,
									["amount"] = 2142,
								},
								["Deeprot Tangler"] = {
									["total"] = 227,
									["amount"] = 227,
								},
							},
							["MISS"] = 1,
							["hitamount"] = 2001,
						},
						["Backstab"] = {
							["total"] = 289,
							["hitmin"] = 289,
							["id"] = 15657,
							["sources"] = {
								["Putridus Trickster"] = {
									["total"] = 289,
									["amount"] = 289,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 1,
							["hitmax"] = 289,
							["amount"] = 289,
							["hitamount"] = 289,
						},
					},
					["energy"] = 9,
				}, -- [5]
				{
					["last"] = 10556.737,
					["name"] = "Haagroon",
					["flag"] = 4369,
					["class"] = "PET",
					["id"] = "0xF143011D00000005",
					["time"] = 0,
				}, -- [6]
				{
					["last"] = 10556.737,
					["name"] = "Cat",
					["flag"] = 4370,
					["class"] = "PET",
					["id"] = "0xF142F90400000004",
					["time"] = 0,
				}, -- [7]
				{
					["last"] = 10556.737,
					["name"] = "Consecration",
					["flag"] = 4370,
					["class"] = "PET",
					["id"] = "0xF130A9EB000001D1",
					["time"] = 0,
				}, -- [8]
			},
			["type"] = "party",
			["damagetaken"] = 16976,
			["death"] = 5,
			["ccdone"] = 14,
			["absorb"] = 1460,
			["overkill"] = 191,
			["edamagetaken"] = 19191,
			["heal"] = 7550,
			["name"] = "Putridus Satyr (2)",
			["mobname"] = "Putridus Satyr",
			["etotaldamage"] = 18436,
			["edamage"] = 16976,
			["last_action"] = 1689857461,
			["endtime"] = 1689857461,
		}, -- [7]
		{
			["mana"] = 720,
			["starttime"] = 1689857389,
			["enemies"] = {
				{
					["damagespells"] = {
						[6603] = {
							["school"] = 1,
							["total"] = 140,
							["targets"] = {
								["Myrony"] = {
									["total"] = 140,
									["amount"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["damagetaken"] = 3158,
					["flag"] = 68168,
					["class"] = "MONSTER",
					["damagetakenspells"] = {
						[6603] = {
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 245,
									["amount"] = 245,
								},
								["Macius"] = {
									["total"] = 153,
									["amount"] = 153,
								},
								["Myrony"] = {
									["total"] = 502,
									["overkill"] = 23,
									["amount"] = 502,
								},
							},
							["amount"] = 900,
							["school"] = 1,
							["total"] = 900,
							["overkill"] = 23,
						},
						[56641] = {
							["school"] = 1,
							["total"] = 339,
							["sources"] = {
								["Macius"] = {
									["total"] = 339,
									["amount"] = 339,
								},
							},
							["amount"] = 339,
						},
						[88263] = {
							["school"] = 2,
							["total"] = 155,
							["sources"] = {
								["Myrony"] = {
									["total"] = 155,
									["amount"] = 155,
								},
							},
							["amount"] = 155,
						},
						[20187] = {
							["school"] = 2,
							["total"] = 270,
							["sources"] = {
								["Myrony"] = {
									["total"] = 270,
									["amount"] = 270,
								},
							},
							["amount"] = 270,
						},
						[75] = {
							["school"] = 1,
							["total"] = 436,
							["sources"] = {
								["Macius"] = {
									["total"] = 436,
									["amount"] = 436,
								},
							},
							["amount"] = 436,
						},
						[25742] = {
							["school"] = 2,
							["total"] = 63,
							["sources"] = {
								["Myrony"] = {
									["total"] = 63,
									["amount"] = 63,
								},
							},
							["amount"] = 63,
						},
						[54049] = {
							["school"] = 32,
							["total"] = 79,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 79,
									["amount"] = 79,
								},
							},
							["amount"] = 79,
						},
						[2643] = {
							["school"] = 1,
							["total"] = 264,
							["sources"] = {
								["Macius"] = {
									["total"] = 264,
									["amount"] = 264,
								},
							},
							["amount"] = 264,
						},
						[2812] = {
							["school"] = 2,
							["total"] = 203,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 142,
									["amount"] = 142,
								},
								["Myrony"] = {
									["total"] = 61,
									["amount"] = 61,
								},
							},
							["amount"] = 203,
						},
						[42223] = {
							["school"] = 4,
							["total"] = 246,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 246,
									["amount"] = 246,
								},
							},
							["amount"] = 246,
						},
						[53595] = {
							["school"] = 1,
							["total"] = 32,
							["sources"] = {
								["Myrony"] = {
									["total"] = 32,
									["amount"] = 32,
								},
							},
							["amount"] = 32,
						},
						[16827] = {
							["school"] = 1,
							["total"] = 171,
							["sources"] = {
								["Macius"] = {
									["total"] = 171,
									["amount"] = 171,
								},
							},
							["amount"] = 171,
						},
					},
					["name"] = "Putridus Satyr",
					["totaldamage"] = 140,
					["totaldamagetaken"] = 3158,
					["id"] = "0xF1302E0E00000060",
					["damage"] = 0,
				}, -- [1]
				{
					["damagespells"] = {
						[21068] = {
							["school"] = 32,
							["total"] = 16,
							["targets"] = {
								["Fragrance"] = {
									["total"] = 16,
									["amount"] = 16,
								},
							},
							["amount"] = 16,
						},
					},
					["damagetaken"] = 416,
					["flag"] = 2632,
					["class"] = "MONSTER",
					["damagetakenspells"] = {
						[2812] = {
							["school"] = 2,
							["total"] = 91,
							["sources"] = {
								["Myrony"] = {
									["total"] = 91,
									["amount"] = 91,
								},
							},
							["amount"] = 91,
						},
						[42223] = {
							["school"] = 4,
							["total"] = 164,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 164,
									["amount"] = 164,
								},
							},
							["amount"] = 164,
						},
						[88263] = {
							["sources"] = {
								["Myrony"] = {
									["total"] = 161,
									["overkill"] = 56,
									["amount"] = 161,
								},
							},
							["amount"] = 161,
							["school"] = 2,
							["total"] = 161,
							["overkill"] = 56,
						},
					},
					["name"] = "Corruptor",
					["totaldamage"] = 16,
					["totaldamagetaken"] = 416,
					["id"] = "0xF1302FB900000031",
					["damage"] = 16,
				}, -- [2]
				{
					["id"] = "0xF1302FB80000005B",
					["name"] = "Poison Sprite",
					["totaldamagetaken"] = 398,
					["flag"] = 2632,
					["class"] = "MONSTER",
					["damagetaken"] = 398,
					["damagetakenspells"] = {
						[42223] = {
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 246,
									["overkill"] = 13,
									["amount"] = 246,
								},
							},
							["amount"] = 246,
							["school"] = 4,
							["total"] = 246,
							["overkill"] = 13,
						},
						[2812] = {
							["sources"] = {
								["Myrony"] = {
									["total"] = 152,
									["overkill"] = 21,
									["amount"] = 152,
								},
							},
							["amount"] = 152,
							["school"] = 2,
							["total"] = 152,
							["overkill"] = 21,
						},
					},
				}, -- [3]
				{
					["damagespells"] = {
						[6603] = {
							["school"] = 1,
							["total"] = 737,
							["targets"] = {
								["Fragrance"] = {
									["total"] = 737,
									["amount"] = 737,
								},
							},
							["amount"] = 737,
						},
					},
					["damagetaken"] = 4386,
					["flag"] = 2632,
					["class"] = "MONSTER",
					["damagetakenspells"] = {
						[16827] = {
							["school"] = 1,
							["total"] = 84,
							["sources"] = {
								["Macius"] = {
									["total"] = 84,
									["amount"] = 84,
								},
							},
							["amount"] = 84,
						},
						[1978] = {
							["school"] = 8,
							["total"] = 102,
							["sources"] = {
								["Macius"] = {
									["total"] = 102,
									["amount"] = 102,
								},
							},
							["amount"] = 102,
						},
						[25742] = {
							["school"] = 2,
							["total"] = 188,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 108,
									["amount"] = 108,
								},
								["Myrony"] = {
									["total"] = 80,
									["amount"] = 80,
								},
							},
							["amount"] = 188,
						},
						[35395] = {
							["school"] = 1,
							["total"] = 1081,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 731,
									["amount"] = 731,
								},
								["Myrony"] = {
									["total"] = 350,
									["amount"] = 350,
								},
							},
							["amount"] = 1081,
						},
						[6603] = {
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 176,
									["amount"] = 176,
								},
								["Macius"] = {
									["total"] = 108,
									["amount"] = 108,
								},
								["Fragrance"] = {
									["total"] = 382,
									["amount"] = 382,
								},
								["Myrony"] = {
									["total"] = 246,
									["overkill"] = 83,
									["amount"] = 246,
								},
							},
							["amount"] = 912,
							["school"] = 1,
							["total"] = 912,
							["overkill"] = 83,
						},
						[2643] = {
							["school"] = 1,
							["total"] = 132,
							["sources"] = {
								["Macius"] = {
									["total"] = 132,
									["amount"] = 132,
								},
							},
							["amount"] = 132,
						},
						[42223] = {
							["school"] = 4,
							["total"] = 164,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 164,
									["amount"] = 164,
								},
							},
							["amount"] = 164,
						},
						[88263] = {
							["school"] = 2,
							["total"] = 157,
							["sources"] = {
								["Myrony"] = {
									["total"] = 157,
									["amount"] = 157,
								},
							},
							["amount"] = 157,
						},
						[96172] = {
							["school"] = 2,
							["total"] = 2,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 2,
									["amount"] = 2,
								},
							},
							["amount"] = 2,
						},
						[2812] = {
							["school"] = 2,
							["total"] = 233,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 142,
									["amount"] = 142,
								},
								["Myrony"] = {
									["total"] = 91,
									["amount"] = 91,
								},
							},
							["amount"] = 233,
						},
						[172] = {
							["school"] = 32,
							["total"] = 44,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 44,
									["amount"] = 44,
								},
							},
							["amount"] = 44,
						},
						[20187] = {
							["school"] = 2,
							["total"] = 128,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 128,
									["amount"] = 128,
								},
							},
							["amount"] = 128,
						},
						[30108] = {
							["school"] = 32,
							["total"] = 49,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 49,
									["amount"] = 49,
								},
							},
							["amount"] = 49,
						},
						[75] = {
							["school"] = 1,
							["total"] = 245,
							["sources"] = {
								["Macius"] = {
									["total"] = 245,
									["amount"] = 245,
								},
							},
							["amount"] = 245,
						},
						[56641] = {
							["school"] = 1,
							["total"] = 109,
							["sources"] = {
								["Macius"] = {
									["total"] = 109,
									["amount"] = 109,
								},
							},
							["amount"] = 109,
						},
						[83077] = {
							["school"] = 8,
							["total"] = 204,
							["sources"] = {
								["Macius"] = {
									["total"] = 204,
									["amount"] = 204,
								},
							},
							["amount"] = 204,
						},
						[879] = {
							["school"] = 2,
							["total"] = 513,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 513,
									["amount"] = 513,
								},
							},
							["amount"] = 513,
						},
						[7294] = {
							["school"] = 2,
							["total"] = 39,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 39,
									["amount"] = 39,
								},
							},
							["amount"] = 39,
						},
					},
					["name"] = "Putridus Trickster",
					["totaldamage"] = 737,
					["totaldamagetaken"] = 4386,
					["id"] = "0xF1302E0F0000005C",
					["damage"] = 737,
				}, -- [4]
			},
			["totaldamage"] = 8358,
			["time"] = 11,
			["absorb"] = 140,
			["totaldamagetaken"] = 893,
			["etotaldamagetaken"] = 8358,
			["damage"] = 8358,
			["players"] = {
				{
					["last"] = 10530.865,
					["flag"] = 4369,
					["class"] = "WARLOCK",
					["auras"] = {
						[980] = {
							["type"] = "DEBUFF",
							["count"] = 1,
							["school"] = 32,
							["targets"] = {
								["Putridus Trickster"] = {
									["uptime"] = 2,
									["count"] = 1,
								},
							},
							["uptime"] = 2,
						},
						[30108] = {
							["type"] = "DEBUFF",
							["count"] = 1,
							["school"] = 32,
							["targets"] = {
								["Putridus Trickster"] = {
									["uptime"] = 4,
									["count"] = 1,
								},
							},
							["uptime"] = 4,
						},
						[172] = {
							["type"] = "DEBUFF",
							["count"] = 1,
							["school"] = 32,
							["targets"] = {
								["Putridus Trickster"] = {
									["uptime"] = 3,
									["count"] = 1,
								},
							},
							["uptime"] = 3,
						},
					},
					["time"] = 7.58,
					["damage"] = 1413,
					["overheal"] = 33,
					["id"] = "0x000000000004825C",
					["spec"] = 265,
					["healspells"] = {
						[63106] = {
							["overheal"] = 33,
							["count"] = 1,
							["amount"] = 0,
							["school"] = 32,
							["targets"] = {
								["Beardedrasta"] = {
									["overheal"] = 33,
									["amount"] = 0,
								},
							},
						},
					},
					["overkill"] = 13,
					["heal"] = 0,
					["name"] = "Beardedrasta",
					["damagespells"] = {
						["Corruption (DoT)"] = {
							["total"] = 44,
							["hitmin"] = 44,
							["id"] = 172,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 44,
									["amount"] = 44,
								},
							},
							["count"] = 1,
							["hit"] = 1,
							["school"] = 32,
							["hitmax"] = 44,
							["amount"] = 44,
							["hitamount"] = 44,
						},
						["Unstable Affliction (DoT)"] = {
							["total"] = 49,
							["hitmin"] = 49,
							["id"] = 30108,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 49,
									["amount"] = 49,
								},
							},
							["count"] = 1,
							["hit"] = 1,
							["school"] = 32,
							["hitmax"] = 49,
							["amount"] = 49,
							["hitamount"] = 49,
						},
						["Shadow Bite (Haagroon)"] = {
							["total"] = 79,
							["hitmin"] = 79,
							["id"] = 54049,
							["targets"] = {
								["Putridus Satyr"] = {
									["total"] = 79,
									["amount"] = 79,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 32,
							["hitmax"] = 79,
							["amount"] = 79,
							["hitamount"] = 79,
						},
						["Melee (Haagroon)"] = {
							["total"] = 421,
							["hitmin"] = 61,
							["criticalamount"] = 134,
							["id"] = 6603,
							["criticalmin"] = 134,
							["targets"] = {
								["Putridus Satyr"] = {
									["total"] = 245,
									["amount"] = 245,
								},
								["Putridus Trickster"] = {
									["total"] = 176,
									["amount"] = 176,
								},
							},
							["critical"] = 1,
							["glancing"] = 1,
							["criticalmax"] = 134,
							["count"] = 6,
							["hit"] = 4,
							["school"] = 1,
							["hitmax"] = 62,
							["amount"] = 421,
							["hitamount"] = 245,
						},
						["Rain of Fire"] = {
							["total"] = 820,
							["hitmin"] = 82,
							["id"] = 42223,
							["targets"] = {
								["Putridus Satyr"] = {
									["total"] = 246,
									["amount"] = 246,
								},
								["Poison Sprite"] = {
									["total"] = 246,
									["overkill"] = 13,
									["amount"] = 246,
								},
								["Corruptor"] = {
									["total"] = 164,
									["amount"] = 164,
								},
								["Putridus Trickster"] = {
									["total"] = 164,
									["amount"] = 164,
								},
							},
							["overkill"] = 13,
							["amount"] = 820,
							["casts"] = 1,
							["count"] = 11,
							["hit"] = 10,
							["school"] = 4,
							["hitmax"] = 82,
							["MISS"] = 1,
							["hitamount"] = 820,
						},
					},
					["totaldamage"] = 1413,
					["role"] = "DAMAGER",
				}, -- [1]
				{
					["ccdonespells"] = {
						[2812] = {
							["count"] = 4,
							["targets"] = {
								["Putridus Satyr"] = 1,
								["Poison Sprite"] = 1,
								["Putridus Trickster"] = 1,
								["Corruptor"] = 1,
							},
						},
					},
					["last"] = 10531.33,
					["flag"] = 1298,
					["class"] = "PALADIN",
					["auras"] = {
						[2812] = {
							["type"] = "DEBUFF",
							["count"] = 4,
							["school"] = 2,
							["targets"] = {
								["Putridus Satyr"] = {
									["uptime"] = 2,
									["count"] = 1,
								},
								["Poison Sprite"] = {
									["uptime"] = 2,
									["count"] = 1,
								},
								["Putridus Trickster"] = {
									["uptime"] = 2,
									["count"] = 1,
								},
								["Corruptor"] = {
									["uptime"] = 2,
									["count"] = 1,
								},
							},
							["uptime"] = 2,
						},
						[17] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 2,
							["uptime"] = 6,
						},
						[31930] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 2,
							["uptime"] = 6,
						},
						[139] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 2,
							["uptime"] = 9,
						},
						[68055] = {
							["type"] = "DEBUFF",
							["count"] = 1,
							["school"] = 2,
							["targets"] = {
								["Putridus Satyr"] = {
									["uptime"] = 2,
									["count"] = 1,
								},
							},
							["uptime"] = 2,
						},
					},
					["time"] = 10.31,
					["totaldamagetaken"] = 140,
					["damage"] = 2411,
					["damagespells"] = {
						["Crusader Strike"] = {
							["total"] = 350,
							["hitmin"] = 350,
							["id"] = 35395,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 350,
									["amount"] = 350,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 1,
							["hitmax"] = 350,
							["amount"] = 350,
							["hitamount"] = 350,
						},
						["Melee"] = {
							["total"] = 748,
							["hitmin"] = 109,
							["id"] = 6603,
							["targets"] = {
								["Putridus Satyr"] = {
									["total"] = 502,
									["overkill"] = 23,
									["amount"] = 502,
								},
								["Putridus Trickster"] = {
									["total"] = 246,
									["overkill"] = 83,
									["amount"] = 246,
								},
							},
							["overkill"] = 106,
							["count"] = 6,
							["hit"] = 6,
							["school"] = 1,
							["hitmax"] = 134,
							["amount"] = 748,
							["hitamount"] = 748,
						},
						["Judgement of Righteousness"] = {
							["total"] = 270,
							["hitmin"] = 270,
							["id"] = 20187,
							["targets"] = {
								["Putridus Satyr"] = {
									["total"] = 270,
									["amount"] = 270,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 2,
							["hitmax"] = 270,
							["amount"] = 270,
							["hitamount"] = 270,
						},
						["Seal of Righteousness"] = {
							["total"] = 143,
							["hitmin"] = 19,
							["criticalamount"] = 42,
							["id"] = 25742,
							["criticalmin"] = 42,
							["targets"] = {
								["Putridus Satyr"] = {
									["total"] = 63,
									["amount"] = 63,
								},
								["Putridus Trickster"] = {
									["total"] = 80,
									["amount"] = 80,
								},
							},
							["criticalmax"] = 42,
							["critical"] = 1,
							["casts"] = 1,
							["count"] = 6,
							["hit"] = 5,
							["school"] = 2,
							["hitmax"] = 21,
							["amount"] = 143,
							["hitamount"] = 101,
						},
						["Hammer of the Righteous (Physical)"] = {
							["total"] = 32,
							["hitmin"] = 32,
							["id"] = 53595,
							["targets"] = {
								["Putridus Satyr"] = {
									["total"] = 32,
									["amount"] = 32,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 1,
							["hitmax"] = 32,
							["amount"] = 32,
							["hitamount"] = 32,
						},
						["Hammer of the Righteous"] = {
							["total"] = 473,
							["hitmin"] = 155,
							["id"] = 88263,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 157,
									["amount"] = 157,
								},
								["Corruptor"] = {
									["total"] = 161,
									["overkill"] = 56,
									["amount"] = 161,
								},
								["Putridus Satyr"] = {
									["total"] = 155,
									["amount"] = 155,
								},
							},
							["overkill"] = 56,
							["casts"] = 1,
							["count"] = 3,
							["hit"] = 3,
							["school"] = 2,
							["hitmax"] = 161,
							["amount"] = 473,
							["hitamount"] = 473,
						},
						["Holy Wrath"] = {
							["count"] = 5,
							["total"] = 395,
							["hitmin"] = 61,
							["criticalamount"] = 273,
							["id"] = 2812,
							["hitmax"] = 61,
							["targets"] = {
								["Putridus Satyr"] = {
									["total"] = 61,
									["amount"] = 61,
								},
								["Poison Sprite"] = {
									["total"] = 152,
									["overkill"] = 21,
									["amount"] = 152,
								},
								["Putridus Trickster"] = {
									["total"] = 91,
									["amount"] = 91,
								},
								["Corruptor"] = {
									["total"] = 91,
									["amount"] = 91,
								},
							},
							["overkill"] = 21,
							["hit"] = 2,
							["casts"] = 1,
							["critical"] = 3,
							["amount"] = 395,
							["school"] = 2,
							["criticalmin"] = 91,
							["criticalmax"] = 91,
							["hitamount"] = 122,
						},
					},
					["damagetaken"] = 0,
					["id"] = "0x00000000000447DB",
					["damagetakenspells"] = {
						["Melee"] = {
							["total"] = 140,
							["id"] = 6603,
							["sources"] = {
								["Putridus Trickster"] = {
									["total"] = 0,
									["amount"] = 0,
								},
								["Putridus Satyr"] = {
									["total"] = 140,
									["amount"] = 0,
								},
							},
							["count"] = 7,
							["amount"] = 0,
							["school"] = 1,
							["ABSORB"] = 1,
							["MISS"] = 1,
							["PARRY"] = 5,
						},
					},
					["overkill"] = 183,
					["manaspells"] = {
						[84627] = 276,
						[31930] = 180,
					},
					["ccdone"] = 4,
					["totaldamage"] = 2411,
					["mana"] = 456,
					["role"] = "TANK",
					["name"] = "Myrony",
				}, -- [2]
				{
					["overheal"] = 275,
					["last"] = 10531.33,
					["absorb"] = 140,
					["flag"] = 1298,
					["class"] = "PRIEST",
					["healspells"] = {
						[63544] = {
							["overheal"] = 0,
							["count"] = 1,
							["amount"] = 70,
							["school"] = 2,
							["max"] = 70,
							["targets"] = {
								["Myrony"] = {
									["overheal"] = 0,
									["amount"] = 70,
								},
							},
							["min"] = 70,
						},
						[139] = {
							["overheal"] = 275,
							["max"] = 177,
							["targets"] = {
								["Myrony"] = {
									["overheal"] = 0,
									["amount"] = 531,
								},
								["Beardedrasta"] = {
									["overheal"] = 275,
									["amount"] = 285,
								},
							},
							["min"] = 5,
							["casts"] = 2,
							["count"] = 7,
							["amount"] = 816,
							["school"] = 2,
							["ishot"] = true,
						},
						[56160] = {
							["overheal"] = 0,
							["count"] = 1,
							["amount"] = 248,
							["school"] = 2,
							["max"] = 248,
							["targets"] = {
								["Myrony"] = {
									["overheal"] = 0,
									["amount"] = 248,
								},
							},
							["min"] = 248,
						},
					},
					["auras"] = {
						[6788] = {
							["type"] = "DEBUFF",
							["count"] = 1,
							["school"] = 2,
							["targets"] = {
								["Myrony"] = {
									["uptime"] = 6,
									["count"] = 1,
								},
							},
							["uptime"] = 6,
						},
					},
					["absorbspells"] = {
						[17] = {
							["min"] = 140,
							["casts"] = 1,
							["count"] = 1,
							["amount"] = 140,
							["school"] = 2,
							["targets"] = {
								["Myrony"] = 140,
							},
							["max"] = 140,
						},
					},
					["role"] = "HEALER",
					["name"] = "Nianhong",
					["heal"] = 1134,
					["time"] = 10.3,
					["id"] = "0x00000000000467C0",
				}, -- [3]
				{
					["damagespells"] = {
						["Steady Shot"] = {
							["total"] = 448,
							["hitmin"] = 109,
							["id"] = 56641,
							["targets"] = {
								["Putridus Satyr"] = {
									["total"] = 339,
									["amount"] = 339,
								},
								["Putridus Trickster"] = {
									["total"] = 109,
									["amount"] = 109,
								},
							},
							["casts"] = 4,
							["count"] = 4,
							["hit"] = 4,
							["school"] = 1,
							["hitmax"] = 117,
							["amount"] = 448,
							["hitamount"] = 448,
						},
						["Serpent Sting (DoT)"] = {
							["total"] = 102,
							["criticalamount"] = 102,
							["id"] = 1978,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 102,
									["amount"] = 102,
								},
							},
							["criticalmax"] = 102,
							["critical"] = 1,
							["amount"] = 102,
							["school"] = 8,
							["criticalmin"] = 102,
							["count"] = 1,
						},
						["Improved Serpent Sting"] = {
							["total"] = 204,
							["criticalamount"] = 204,
							["id"] = 83077,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 204,
									["amount"] = 204,
								},
							},
							["casts"] = 1,
							["critical"] = 1,
							["amount"] = 204,
							["school"] = 8,
							["criticalmin"] = 204,
							["criticalmax"] = 204,
							["count"] = 1,
						},
						["Auto Shot"] = {
							["total"] = 681,
							["hitmin"] = 119,
							["criticalamount"] = 300,
							["id"] = 75,
							["criticalmin"] = 300,
							["targets"] = {
								["Putridus Satyr"] = {
									["total"] = 436,
									["amount"] = 436,
								},
								["Putridus Trickster"] = {
									["total"] = 245,
									["amount"] = 245,
								},
							},
							["criticalmax"] = 300,
							["critical"] = 1,
							["casts"] = 1,
							["count"] = 4,
							["hit"] = 3,
							["school"] = 1,
							["hitmax"] = 136,
							["amount"] = 681,
							["hitamount"] = 381,
						},
						["Multi-Shot"] = {
							["total"] = 396,
							["hitmin"] = 132,
							["criticalamount"] = 264,
							["id"] = 2643,
							["hitmax"] = 132,
							["targets"] = {
								["Putridus Satyr"] = {
									["total"] = 264,
									["amount"] = 264,
								},
								["Putridus Trickster"] = {
									["total"] = 132,
									["amount"] = 132,
								},
							},
							["count"] = 2,
							["hit"] = 1,
							["casts"] = 1,
							["critical"] = 1,
							["amount"] = 396,
							["school"] = 1,
							["criticalmin"] = 264,
							["criticalmax"] = 264,
							["hitamount"] = 132,
						},
						["Melee (Cat)"] = {
							["DODGE"] = 1,
							["total"] = 261,
							["hitmin"] = 51,
							["criticalamount"] = 102,
							["id"] = 6603,
							["count"] = 5,
							["targets"] = {
								["Putridus Satyr"] = {
									["total"] = 153,
									["amount"] = 153,
								},
								["Putridus Trickster"] = {
									["total"] = 108,
									["amount"] = 108,
								},
							},
							["hitmax"] = 59,
							["glancing"] = 1,
							["criticalmax"] = 102,
							["critical"] = 1,
							["amount"] = 261,
							["school"] = 1,
							["hit"] = 2,
							["criticalmin"] = 102,
							["hitamount"] = 110,
						},
						["Claw (Cat)"] = {
							["total"] = 255,
							["hitmin"] = 84,
							["id"] = 16827,
							["targets"] = {
								["Putridus Satyr"] = {
									["total"] = 171,
									["amount"] = 171,
								},
								["Putridus Trickster"] = {
									["total"] = 84,
									["amount"] = 84,
								},
							},
							["casts"] = 3,
							["count"] = 3,
							["hit"] = 3,
							["school"] = 1,
							["hitmax"] = 86,
							["amount"] = 255,
							["hitamount"] = 255,
						},
					},
					["last"] = 10531.151,
					["id"] = "0x00000000000477A3",
					["flag"] = 1298,
					["class"] = "HUNTER",
					["totaldamage"] = 2347,
					["auras"] = {
						[1978] = {
							["type"] = "DEBUFF",
							["count"] = 1,
							["school"] = 8,
							["targets"] = {
								["Putridus Trickster"] = {
									["uptime"] = 4,
									["count"] = 1,
								},
							},
							["uptime"] = 4,
						},
					},
					["energyspells"] = {
						[91954] = 36,
					},
					["role"] = "DAMAGER",
					["name"] = "Macius",
					["time"] = 10.1,
					["energy"] = 36,
					["damage"] = 2347,
				}, -- [4]
				{
					["ccdonespells"] = {
						[2812] = {
							["count"] = 2,
							["targets"] = {
								["Putridus Trickster"] = 1,
								["Putridus Satyr"] = 1,
							},
						},
					},
					["last"] = 10530.58,
					["flag"] = 1298,
					["class"] = "PALADIN",
					["auras"] = {
						[2812] = {
							["type"] = "DEBUFF",
							["count"] = 2,
							["school"] = 2,
							["targets"] = {
								["Putridus Trickster"] = {
									["uptime"] = 2,
									["count"] = 1,
								},
								["Putridus Satyr"] = {
									["uptime"] = 2,
									["count"] = 1,
								},
							},
							["uptime"] = 2,
						},
						[89906] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 2,
							["uptime"] = 5,
						},
					},
					["time"] = 9.370000000000003,
					["totaldamagetaken"] = 753,
					["damage"] = 2187,
					["damagespells"] = {
						["Crusader Strike"] = {
							["total"] = 731,
							["hitmin"] = 357,
							["id"] = 35395,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 731,
									["amount"] = 731,
								},
							},
							["casts"] = 2,
							["count"] = 2,
							["hit"] = 2,
							["school"] = 1,
							["hitmax"] = 374,
							["amount"] = 731,
							["hitamount"] = 731,
						},
						["Exorcism"] = {
							["total"] = 513,
							["criticalamount"] = 513,
							["id"] = 879,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 513,
									["amount"] = 513,
								},
							},
							["casts"] = 1,
							["critical"] = 1,
							["amount"] = 513,
							["school"] = 2,
							["criticalmin"] = 513,
							["criticalmax"] = 513,
							["count"] = 1,
						},
						["Seal of Righteousness"] = {
							["total"] = 108,
							["hitmin"] = 27,
							["criticalamount"] = 54,
							["id"] = 25742,
							["criticalmin"] = 54,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 108,
									["amount"] = 108,
								},
							},
							["criticalmax"] = 54,
							["critical"] = 1,
							["casts"] = 1,
							["count"] = 3,
							["hit"] = 2,
							["school"] = 2,
							["hitmax"] = 27,
							["amount"] = 108,
							["hitamount"] = 54,
						},
						["Melee"] = {
							["total"] = 382,
							["hitmin"] = 189,
							["id"] = 6603,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 382,
									["amount"] = 382,
								},
							},
							["count"] = 2,
							["hit"] = 2,
							["school"] = 1,
							["hitmax"] = 193,
							["amount"] = 382,
							["hitamount"] = 382,
						},
						["Judgement of Righteousness"] = {
							["total"] = 128,
							["hitmin"] = 128,
							["id"] = 20187,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 128,
									["amount"] = 128,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 2,
							["hitmax"] = 128,
							["amount"] = 128,
							["hitamount"] = 128,
						},
						["Hand of Light"] = {
							["total"] = 2,
							["hitmin"] = 1,
							["id"] = 96172,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 2,
									["amount"] = 2,
								},
							},
							["casts"] = 1,
							["count"] = 2,
							["hit"] = 2,
							["school"] = 2,
							["hitmax"] = 1,
							["amount"] = 2,
							["hitamount"] = 2,
						},
						["Retribution Aura"] = {
							["total"] = 39,
							["hitmin"] = 13,
							["id"] = 7294,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 39,
									["amount"] = 39,
								},
							},
							["casts"] = 1,
							["count"] = 3,
							["hit"] = 3,
							["school"] = 2,
							["hitmax"] = 13,
							["amount"] = 39,
							["hitamount"] = 39,
						},
						["Holy Wrath"] = {
							["total"] = 284,
							["hitmin"] = 142,
							["id"] = 2812,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 142,
									["amount"] = 142,
								},
								["Putridus Satyr"] = {
									["total"] = 142,
									["amount"] = 142,
								},
							},
							["casts"] = 1,
							["count"] = 2,
							["hit"] = 2,
							["school"] = 2,
							["hitmax"] = 142,
							["amount"] = 284,
							["hitamount"] = 284,
						},
					},
					["damagetaken"] = 753,
					["id"] = "0x0000000000048007",
					["damagetakenspells"] = {
						["Melee"] = {
							["total"] = 737,
							["hitmin"] = 158,
							["criticalamount"] = 414,
							["id"] = 6603,
							["hitmax"] = 165,
							["count"] = 3,
							["hit"] = 2,
							["criticalmax"] = 414,
							["critical"] = 1,
							["amount"] = 737,
							["school"] = 1,
							["sources"] = {
								["Putridus Trickster"] = {
									["total"] = 737,
									["amount"] = 737,
								},
							},
							["criticalmin"] = 414,
							["hitamount"] = 323,
						},
						["Corruption (DoT)"] = {
							["total"] = 16,
							["hitmin"] = 4,
							["id"] = 21068,
							["hitmax"] = 4,
							["sources"] = {
								["Corruptor"] = {
									["total"] = 16,
									["amount"] = 16,
								},
							},
							["count"] = 4,
							["hit"] = 4,
							["school"] = 32,
							["resisted"] = 4,
							["amount"] = 16,
							["hitamount"] = 16,
						},
					},
					["manaspells"] = {
						[89906] = 264,
					},
					["ccdone"] = 2,
					["totaldamage"] = 2187,
					["mana"] = 264,
					["role"] = "DAMAGER",
					["name"] = "Fragrance",
				}, -- [5]
			},
			["type"] = "party",
			["damagetaken"] = 753,
			["etotaldamage"] = 893,
			["overheal"] = 308,
			["energy"] = 36,
			["overkill"] = 196,
			["edamagetaken"] = 8358,
			["heal"] = 1134,
			["name"] = "Putridus Satyr",
			["mobname"] = "Putridus Satyr",
			["ccdone"] = 6,
			["edamage"] = 753,
			["last_action"] = 1689857400,
			["endtime"] = 1689857400,
		}, -- [8]
		{
			["mana"] = 779,
			["enemies"] = {
				{
					["id"] = "0xF1302FB800000061",
					["name"] = "Poison Sprite",
					["totaldamagetaken"] = 853,
					["flag"] = 2632,
					["class"] = "MONSTER",
					["damagetaken"] = 853,
					["damagetakenspells"] = {
						[42223] = {
							["school"] = 4,
							["total"] = 82,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 82,
									["amount"] = 82,
								},
							},
							["amount"] = 82,
						},
						[35395] = {
							["school"] = 1,
							["total"] = 204,
							["sources"] = {
								["Myrony"] = {
									["total"] = 204,
									["amount"] = 204,
								},
							},
							["amount"] = 204,
						},
						[25742] = {
							["school"] = 2,
							["total"] = 19,
							["sources"] = {
								["Myrony"] = {
									["total"] = 19,
									["amount"] = 19,
								},
							},
							["amount"] = 19,
						},
						[6603] = {
							["school"] = 1,
							["total"] = 96,
							["sources"] = {
								["Myrony"] = {
									["total"] = 96,
									["amount"] = 96,
								},
							},
							["amount"] = 96,
						},
						[81297] = {
							["school"] = 2,
							["total"] = 162,
							["sources"] = {
								["Myrony"] = {
									["total"] = 162,
									["amount"] = 162,
								},
							},
							["amount"] = 162,
						},
						[2812] = {
							["sources"] = {
								["Fragrance"] = {
									["total"] = 142,
									["overkill"] = 56,
									["amount"] = 142,
								},
								["Myrony"] = {
									["total"] = 148,
									["amount"] = 148,
								},
							},
							["amount"] = 290,
							["school"] = 2,
							["total"] = 290,
							["overkill"] = 56,
						},
					},
				}, -- [1]
				{
					["damagespells"] = {
						[6603] = {
							["school"] = 1,
							["total"] = 674,
							["targets"] = {
								["Fragrance"] = {
									["total"] = 164,
									["amount"] = 164,
								},
								["Myrony"] = {
									["total"] = 510,
									["amount"] = 510,
								},
							},
							["amount"] = 674,
						},
					},
					["damagetaken"] = 4223,
					["flag"] = 68168,
					["class"] = "MONSTER",
					["damagetakenspells"] = {
						[81297] = {
							["school"] = 2,
							["total"] = 219,
							["sources"] = {
								["Myrony"] = {
									["total"] = 219,
									["amount"] = 219,
								},
							},
							["amount"] = 219,
						},
						[6603] = {
							["school"] = 1,
							["total"] = 1028,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 320,
									["amount"] = 320,
								},
								["Macius"] = {
									["total"] = 388,
									["amount"] = 388,
								},
								["Fragrance"] = {
									["total"] = 201,
									["amount"] = 201,
								},
								["Myrony"] = {
									["total"] = 119,
									["amount"] = 119,
								},
							},
							["amount"] = 1028,
						},
						[7294] = {
							["school"] = 2,
							["total"] = 52,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 13,
									["amount"] = 13,
								},
								["Myrony"] = {
									["total"] = 39,
									["amount"] = 39,
								},
							},
							["amount"] = 52,
						},
						[16827] = {
							["school"] = 1,
							["total"] = 169,
							["sources"] = {
								["Macius"] = {
									["total"] = 169,
									["amount"] = 169,
								},
							},
							["amount"] = 169,
						},
						[20187] = {
							["school"] = 2,
							["total"] = 316,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 128,
									["amount"] = 128,
								},
								["Myrony"] = {
									["total"] = 188,
									["amount"] = 188,
								},
							},
							["amount"] = 316,
						},
						[2643] = {
							["school"] = 1,
							["total"] = 97,
							["sources"] = {
								["Macius"] = {
									["total"] = 97,
									["amount"] = 97,
								},
							},
							["amount"] = 97,
						},
						[35395] = {
							["sources"] = {
								["Fragrance"] = {
									["total"] = 712,
									["overkill"] = 84,
									["amount"] = 712,
								},
							},
							["amount"] = 712,
							["school"] = 1,
							["total"] = 712,
							["overkill"] = 84,
						},
						[879] = {
							["school"] = 2,
							["total"] = 534,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 534,
									["amount"] = 534,
								},
							},
							["amount"] = 534,
						},
						[25742] = {
							["school"] = 2,
							["total"] = 100,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 81,
									["amount"] = 81,
								},
								["Myrony"] = {
									["total"] = 19,
									["amount"] = 19,
								},
							},
							["amount"] = 100,
						},
						[54049] = {
							["school"] = 32,
							["total"] = 162,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 162,
									["amount"] = 162,
								},
							},
							["amount"] = 162,
						},
						[96172] = {
							["school"] = 2,
							["total"] = 2,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 2,
									["amount"] = 2,
								},
							},
							["amount"] = 2,
						},
						[2812] = {
							["school"] = 2,
							["total"] = 182,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 71,
									["amount"] = 71,
								},
								["Myrony"] = {
									["total"] = 111,
									["amount"] = 111,
								},
							},
							["amount"] = 182,
						},
						[42223] = {
							["school"] = 4,
							["total"] = 164,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 164,
									["amount"] = 164,
								},
							},
							["amount"] = 164,
						},
						[56641] = {
							["school"] = 1,
							["total"] = 289,
							["sources"] = {
								["Macius"] = {
									["total"] = 289,
									["amount"] = 289,
								},
							},
							["amount"] = 289,
						},
						[75] = {
							["school"] = 1,
							["total"] = 197,
							["sources"] = {
								["Macius"] = {
									["total"] = 197,
									["amount"] = 197,
								},
							},
							["amount"] = 197,
						},
					},
					["name"] = "Putridus Trickster",
					["totaldamage"] = 674,
					["totaldamagetaken"] = 4223,
					["id"] = "0xF1302E0F00000089",
					["damage"] = 674,
				}, -- [2]
				{
					["damagespells"] = {
						[6603] = {
							["school"] = 1,
							["total"] = 143,
							["targets"] = {
								["Myrony"] = {
									["total"] = 143,
									["amount"] = 143,
								},
							},
							["amount"] = 143,
						},
					},
					["damagetaken"] = 2663,
					["flag"] = 2632,
					["class"] = "MONSTER",
					["damagetakenspells"] = {
						[81297] = {
							["school"] = 2,
							["total"] = 219,
							["sources"] = {
								["Myrony"] = {
									["total"] = 219,
									["amount"] = 219,
								},
							},
							["amount"] = 219,
						},
						[6603] = {
							["school"] = 1,
							["total"] = 763,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 48,
									["amount"] = 48,
								},
								["Macius"] = {
									["total"] = 108,
									["amount"] = 108,
								},
								["Fragrance"] = {
									["total"] = 214,
									["amount"] = 214,
								},
								["Myrony"] = {
									["total"] = 393,
									["amount"] = 393,
								},
							},
							["amount"] = 763,
						},
						[7294] = {
							["school"] = 2,
							["total"] = 13,
							["sources"] = {
								["Myrony"] = {
									["total"] = 13,
									["amount"] = 13,
								},
							},
							["amount"] = 13,
						},
						[2643] = {
							["school"] = 1,
							["total"] = 98,
							["sources"] = {
								["Macius"] = {
									["total"] = 98,
									["amount"] = 98,
								},
							},
							["amount"] = 98,
						},
						[75] = {
							["school"] = 1,
							["total"] = 93,
							["sources"] = {
								["Macius"] = {
									["total"] = 93,
									["amount"] = 93,
								},
							},
							["amount"] = 93,
						},
						[25742] = {
							["school"] = 2,
							["total"] = 90,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 27,
									["amount"] = 27,
								},
								["Myrony"] = {
									["total"] = 63,
									["amount"] = 63,
								},
							},
							["amount"] = 90,
						},
						[96172] = {
							["school"] = 2,
							["total"] = 1,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 1,
									["amount"] = 1,
								},
							},
							["amount"] = 1,
						},
						[3044] = {
							["sources"] = {
								["Macius"] = {
									["total"] = 142,
									["overkill"] = 4,
									["amount"] = 142,
								},
							},
							["amount"] = 142,
							["school"] = 64,
							["total"] = 142,
							["overkill"] = 4,
						},
						[2812] = {
							["school"] = 2,
							["total"] = 145,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 71,
									["amount"] = 71,
								},
								["Myrony"] = {
									["total"] = 74,
									["amount"] = 74,
								},
							},
							["amount"] = 145,
						},
						[42223] = {
							["school"] = 4,
							["total"] = 327,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 327,
									["amount"] = 327,
								},
							},
							["amount"] = 327,
						},
						[85256] = {
							["school"] = 1,
							["total"] = 678,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 678,
									["amount"] = 678,
								},
							},
							["amount"] = 678,
						},
						[56641] = {
							["school"] = 1,
							["total"] = 94,
							["sources"] = {
								["Macius"] = {
									["total"] = 94,
									["amount"] = 94,
								},
							},
							["amount"] = 94,
						},
					},
					["name"] = "Putridus Satyr",
					["totaldamage"] = 143,
					["totaldamagetaken"] = 2663,
					["id"] = "0xF1302E0E00000085",
					["damage"] = 143,
				}, -- [3]
			},
			["starttime"] = 1689857363,
			["totaldamage"] = 7739,
			["time"] = 11,
			["totaldamagetaken"] = 817,
			["etotaldamagetaken"] = 7739,
			["damage"] = 7739,
			["players"] = {
				{
					["ccdonespells"] = {
						[2812] = {
							["count"] = 4,
							["targets"] = {
								["Poison Sprite"] = 2,
								["Putridus Trickster"] = 1,
								["Putridus Satyr"] = 1,
							},
						},
					},
					["last"] = 10504.301,
					["flag"] = 1298,
					["class"] = "PALADIN",
					["auras"] = {
						[68055] = {
							["type"] = "DEBUFF",
							["count"] = 1,
							["school"] = 2,
							["targets"] = {
								["Putridus Trickster"] = {
									["uptime"] = 3,
									["count"] = 1,
								},
							},
							["uptime"] = 3,
						},
					},
					["role"] = "TANK",
					["time"] = 10.01,
					["totaldamagetaken"] = 653,
					["damage"] = 2086,
					["damagespells"] = {
						["Melee"] = {
							["total"] = 608,
							["hitmin"] = 96,
							["id"] = 6603,
							["targets"] = {
								["Poison Sprite"] = {
									["total"] = 96,
									["amount"] = 96,
								},
								["Putridus Satyr"] = {
									["total"] = 393,
									["amount"] = 393,
								},
								["Putridus Trickster"] = {
									["total"] = 119,
									["amount"] = 119,
								},
							},
							["count"] = 5,
							["hit"] = 5,
							["school"] = 1,
							["hitmax"] = 140,
							["amount"] = 608,
							["hitamount"] = 608,
						},
						["Seal of Righteousness"] = {
							["total"] = 101,
							["hitmin"] = 19,
							["id"] = 25742,
							["targets"] = {
								["Poison Sprite"] = {
									["total"] = 19,
									["amount"] = 19,
								},
								["Putridus Satyr"] = {
									["total"] = 63,
									["amount"] = 63,
								},
								["Putridus Trickster"] = {
									["total"] = 19,
									["amount"] = 19,
								},
							},
							["casts"] = 1,
							["count"] = 5,
							["hit"] = 5,
							["school"] = 2,
							["hitmax"] = 22,
							["amount"] = 101,
							["hitamount"] = 101,
						},
						["Judgement of Righteousness"] = {
							["total"] = 188,
							["hitmin"] = 188,
							["id"] = 20187,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 188,
									["amount"] = 188,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 2,
							["hitmax"] = 188,
							["amount"] = 188,
							["hitamount"] = 188,
						},
						["Consecration"] = {
							["total"] = 600,
							["hitmin"] = 27,
							["id"] = 81297,
							["targets"] = {
								["Poison Sprite"] = {
									["total"] = 162,
									["amount"] = 162,
								},
								["Putridus Trickster"] = {
									["total"] = 219,
									["amount"] = 219,
								},
								["Putridus Satyr"] = {
									["total"] = 219,
									["amount"] = 219,
								},
							},
							["casts"] = 1,
							["count"] = 22,
							["hit"] = 22,
							["school"] = 2,
							["hitmax"] = 30,
							["amount"] = 600,
							["hitamount"] = 600,
						},
						["Crusader Strike"] = {
							["total"] = 204,
							["hitmin"] = 204,
							["id"] = 35395,
							["targets"] = {
								["Putridus Satyr"] = {
									["total"] = 0,
									["amount"] = 0,
								},
								["Poison Sprite"] = {
									["total"] = 204,
									["amount"] = 204,
								},
							},
							["amount"] = 204,
							["casts"] = 2,
							["count"] = 2,
							["hit"] = 1,
							["school"] = 1,
							["hitmax"] = 204,
							["MISS"] = 1,
							["hitamount"] = 204,
						},
						["Retribution Aura"] = {
							["total"] = 52,
							["hitmin"] = 13,
							["id"] = 7294,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 39,
									["amount"] = 39,
								},
								["Putridus Satyr"] = {
									["total"] = 13,
									["amount"] = 13,
								},
							},
							["casts"] = 1,
							["count"] = 4,
							["hit"] = 4,
							["school"] = 2,
							["hitmax"] = 13,
							["amount"] = 52,
							["hitamount"] = 52,
						},
						["Holy Wrath"] = {
							["total"] = 333,
							["hitmin"] = 74,
							["criticalamount"] = 111,
							["id"] = 2812,
							["criticalmin"] = 111,
							["targets"] = {
								["Poison Sprite"] = {
									["total"] = 148,
									["amount"] = 148,
								},
								["Putridus Trickster"] = {
									["total"] = 111,
									["amount"] = 111,
								},
								["Putridus Satyr"] = {
									["total"] = 74,
									["amount"] = 74,
								},
							},
							["criticalmax"] = 111,
							["critical"] = 1,
							["casts"] = 1,
							["count"] = 4,
							["hit"] = 3,
							["school"] = 2,
							["hitmax"] = 74,
							["amount"] = 333,
							["hitamount"] = 222,
						},
					},
					["damagetaken"] = 653,
					["id"] = "0x00000000000447DB",
					["damagetakenspells"] = {
						["Melee"] = {
							["DODGE"] = 1,
							["total"] = 653,
							["hitmin"] = 143,
							["id"] = 6603,
							["hitmax"] = 193,
							["PARRY"] = 5,
							["sources"] = {
								["Poison Sprite"] = {
									["total"] = 0,
									["amount"] = 0,
								},
								["Putridus Satyr"] = {
									["total"] = 143,
									["amount"] = 143,
								},
								["Putridus Trickster"] = {
									["total"] = 510,
									["amount"] = 510,
								},
							},
							["count"] = 11,
							["amount"] = 653,
							["school"] = 1,
							["hit"] = 4,
							["MISS"] = 1,
							["hitamount"] = 653,
						},
					},
					["name"] = "Myrony",
					["ccdone"] = 4,
					["mana"] = 635,
					["totaldamage"] = 2086,
					["manaspells"] = {
						[31930] = 319,
						[84627] = 316,
					},
				}, -- [1]
				{
					["ccdonespells"] = {
						[2812] = {
							["count"] = 3,
							["targets"] = {
								["Poison Sprite"] = 1,
								["Putridus Trickster"] = 1,
								["Putridus Satyr"] = 1,
							},
						},
					},
					["last"] = 10503.343,
					["flag"] = 1298,
					["class"] = "PALADIN",
					["auras"] = {
						[2812] = {
							["type"] = "DEBUFF",
							["count"] = 3,
							["school"] = 2,
							["targets"] = {
								["Poison Sprite"] = {
									["uptime"] = 1,
									["count"] = 1,
								},
								["Putridus Trickster"] = {
									["uptime"] = 1,
									["count"] = 1,
								},
								["Putridus Satyr"] = {
									["uptime"] = 1,
									["count"] = 1,
								},
							},
							["uptime"] = 1,
						},
						[89906] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 2,
							["uptime"] = 7,
						},
						[139] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 2,
							["uptime"] = 9,
						},
						[94686] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 1,
							["refresh"] = 1,
							["uptime"] = 10,
						},
					},
					["role"] = "DAMAGER",
					["time"] = 8.75,
					["totaldamagetaken"] = 164,
					["damage"] = 2875,
					["damagespells"] = {
						["Exorcism"] = {
							["total"] = 534,
							["criticalamount"] = 534,
							["id"] = 879,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 534,
									["amount"] = 534,
								},
							},
							["casts"] = 1,
							["critical"] = 1,
							["amount"] = 534,
							["school"] = 2,
							["criticalmin"] = 534,
							["criticalmax"] = 534,
							["count"] = 1,
						},
						["Seal of Righteousness"] = {
							["total"] = 108,
							["hitmin"] = 27,
							["id"] = 25742,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 81,
									["amount"] = 81,
								},
								["Putridus Satyr"] = {
									["total"] = 27,
									["amount"] = 27,
								},
							},
							["casts"] = 1,
							["count"] = 4,
							["hit"] = 4,
							["school"] = 2,
							["hitmax"] = 27,
							["amount"] = 108,
							["hitamount"] = 108,
						},
						["Retribution Aura"] = {
							["total"] = 13,
							["hitmin"] = 13,
							["id"] = 7294,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 13,
									["amount"] = 13,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 2,
							["hitmax"] = 13,
							["amount"] = 13,
							["hitamount"] = 13,
						},
						["Templar's Verdict"] = {
							["total"] = 678,
							["hitmin"] = 678,
							["id"] = 85256,
							["targets"] = {
								["Putridus Satyr"] = {
									["total"] = 678,
									["amount"] = 678,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 1,
							["hitmax"] = 678,
							["amount"] = 678,
							["hitamount"] = 678,
						},
						["Melee"] = {
							["total"] = 415,
							["hitmin"] = 201,
							["id"] = 6603,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 201,
									["amount"] = 201,
								},
								["Putridus Satyr"] = {
									["total"] = 214,
									["amount"] = 214,
								},
							},
							["count"] = 2,
							["hit"] = 2,
							["school"] = 1,
							["hitmax"] = 214,
							["amount"] = 415,
							["hitamount"] = 415,
						},
						["Judgement of Righteousness"] = {
							["total"] = 128,
							["hitmin"] = 128,
							["id"] = 20187,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 128,
									["amount"] = 128,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 2,
							["hitmax"] = 128,
							["amount"] = 128,
							["hitamount"] = 128,
						},
						["Hand of Light"] = {
							["total"] = 3,
							["hitmin"] = 1,
							["id"] = 96172,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 2,
									["amount"] = 2,
								},
								["Putridus Satyr"] = {
									["total"] = 1,
									["amount"] = 1,
								},
							},
							["casts"] = 1,
							["count"] = 3,
							["hit"] = 3,
							["school"] = 2,
							["hitmax"] = 1,
							["amount"] = 3,
							["hitamount"] = 3,
						},
						["Crusader Strike"] = {
							["total"] = 712,
							["hitmin"] = 356,
							["id"] = 35395,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 712,
									["overkill"] = 84,
									["amount"] = 712,
								},
							},
							["overkill"] = 84,
							["casts"] = 2,
							["count"] = 2,
							["hit"] = 2,
							["school"] = 1,
							["hitmax"] = 356,
							["amount"] = 712,
							["hitamount"] = 712,
						},
						["Holy Wrath"] = {
							["total"] = 284,
							["hitmin"] = 71,
							["id"] = 2812,
							["targets"] = {
								["Poison Sprite"] = {
									["total"] = 142,
									["overkill"] = 56,
									["amount"] = 142,
								},
								["Putridus Trickster"] = {
									["total"] = 71,
									["amount"] = 71,
								},
								["Putridus Satyr"] = {
									["total"] = 71,
									["amount"] = 71,
								},
							},
							["overkill"] = 56,
							["casts"] = 1,
							["count"] = 4,
							["hit"] = 4,
							["school"] = 2,
							["hitmax"] = 71,
							["amount"] = 284,
							["hitamount"] = 284,
						},
					},
					["damagetaken"] = 164,
					["id"] = "0x0000000000048007",
					["damagetakenspells"] = {
						["Melee"] = {
							["total"] = 164,
							["hitmin"] = 164,
							["id"] = 6603,
							["sources"] = {
								["Putridus Trickster"] = {
									["total"] = 164,
									["amount"] = 164,
								},
							},
							["count"] = 1,
							["hit"] = 1,
							["school"] = 1,
							["hitmax"] = 164,
							["amount"] = 164,
							["hitamount"] = 164,
						},
					},
					["manaspells"] = {
						[89906] = 144,
					},
					["name"] = "Fragrance",
					["ccdone"] = 3,
					["mana"] = 144,
					["overkill"] = 140,
					["totaldamage"] = 2875,
				}, -- [2]
				{
					["damagespells"] = {
						["Steady Shot"] = {
							["total"] = 383,
							["hitmin"] = 94,
							["id"] = 56641,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 289,
									["amount"] = 289,
								},
								["Putridus Satyr"] = {
									["total"] = 94,
									["amount"] = 94,
								},
							},
							["casts"] = 4,
							["count"] = 4,
							["hit"] = 4,
							["school"] = 1,
							["hitmax"] = 97,
							["amount"] = 383,
							["hitamount"] = 383,
						},
						["Claw (Cat)"] = {
							["total"] = 169,
							["hitmin"] = 84,
							["id"] = 16827,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 169,
									["amount"] = 169,
								},
							},
							["amount"] = 169,
							["casts"] = 3,
							["count"] = 3,
							["hit"] = 2,
							["school"] = 1,
							["hitmax"] = 85,
							["MISS"] = 1,
							["hitamount"] = 169,
						},
						["Auto Shot"] = {
							["total"] = 290,
							["hitmin"] = 90,
							["id"] = 75,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 197,
									["amount"] = 197,
								},
								["Putridus Satyr"] = {
									["total"] = 93,
									["amount"] = 93,
								},
							},
							["casts"] = 1,
							["count"] = 3,
							["hit"] = 3,
							["school"] = 1,
							["hitmax"] = 107,
							["amount"] = 290,
							["hitamount"] = 290,
						},
						["Multi-Shot"] = {
							["total"] = 195,
							["hitmin"] = 97,
							["id"] = 2643,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 97,
									["amount"] = 97,
								},
								["Putridus Satyr"] = {
									["total"] = 98,
									["amount"] = 98,
								},
							},
							["casts"] = 1,
							["count"] = 2,
							["hit"] = 2,
							["school"] = 1,
							["hitmax"] = 98,
							["amount"] = 195,
							["hitamount"] = 195,
						},
						["Melee (Cat)"] = {
							["critical"] = 3,
							["total"] = 496,
							["hitmin"] = 44,
							["criticalamount"] = 344,
							["id"] = 6603,
							["criticalmin"] = 100,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 388,
									["amount"] = 388,
								},
								["Putridus Satyr"] = {
									["total"] = 108,
									["amount"] = 108,
								},
							},
							["blocked"] = 18,
							["glancing"] = 1,
							["criticalmax"] = 126,
							["count"] = 6,
							["hit"] = 2,
							["school"] = 1,
							["hitmax"] = 57,
							["amount"] = 496,
							["hitamount"] = 101,
						},
						["Arcane Shot"] = {
							["total"] = 142,
							["hitmin"] = 142,
							["id"] = 3044,
							["targets"] = {
								["Putridus Satyr"] = {
									["total"] = 142,
									["overkill"] = 4,
									["amount"] = 142,
								},
							},
							["overkill"] = 4,
							["casts"] = 1,
							["count"] = 1,
							["amount"] = 142,
							["school"] = 64,
							["hitmax"] = 142,
							["hit"] = 1,
							["hitamount"] = 142,
						},
					},
					["last"] = 10504.615,
					["flag"] = 4370,
					["id"] = "0x00000000000477A3",
					["class"] = "HUNTER",
					["time"] = 10.02,
					["overkill"] = 4,
					["energyspells"] = {
						[91954] = 36,
					},
					["name"] = "Macius",
					["totaldamage"] = 1675,
					["role"] = "DAMAGER",
					["energy"] = 36,
					["damage"] = 1675,
				}, -- [3]
				{
					["damagespells"] = {
						["Rain of Fire"] = {
							["criticalmin"] = 163,
							["total"] = 573,
							["hitmin"] = 82,
							["criticalamount"] = 163,
							["id"] = 42223,
							["criticalmax"] = 163,
							["targets"] = {
								["Poison Sprite"] = {
									["total"] = 82,
									["amount"] = 82,
								},
								["Putridus Trickster"] = {
									["total"] = 164,
									["amount"] = 164,
								},
								["Putridus Satyr"] = {
									["total"] = 327,
									["amount"] = 327,
								},
							},
							["critical"] = 1,
							["amount"] = 573,
							["casts"] = 1,
							["count"] = 7,
							["hit"] = 5,
							["school"] = 4,
							["hitmax"] = 82,
							["MISS"] = 1,
							["hitamount"] = 410,
						},
						["Melee (Haagroon)"] = {
							["total"] = 368,
							["hitmin"] = 66,
							["criticalamount"] = 254,
							["id"] = 6603,
							["count"] = 4,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 320,
									["amount"] = 320,
								},
								["Putridus Satyr"] = {
									["total"] = 48,
									["amount"] = 48,
								},
							},
							["hitmax"] = 66,
							["glancing"] = 1,
							["criticalmax"] = 130,
							["critical"] = 2,
							["amount"] = 368,
							["school"] = 1,
							["hit"] = 1,
							["criticalmin"] = 124,
							["hitamount"] = 66,
						},
						["Shadow Bite (Haagroon)"] = {
							["total"] = 162,
							["hitmin"] = 80,
							["id"] = 54049,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 162,
									["amount"] = 162,
								},
							},
							["casts"] = 2,
							["count"] = 2,
							["hit"] = 2,
							["school"] = 32,
							["hitmax"] = 82,
							["amount"] = 162,
							["hitamount"] = 162,
						},
					},
					["last"] = 10500.045,
					["id"] = "0x000000000004825C",
					["class"] = "WARLOCK",
					["flag"] = 1297,
					["auras"] = {
						[172] = {
							["type"] = "DEBUFF",
							["count"] = 1,
							["school"] = 32,
							["targets"] = {
								["Putridus Satyr"] = {
									["uptime"] = 1,
									["count"] = 1,
								},
							},
							["uptime"] = 1,
						},
					},
					["totaldamage"] = 1103,
					["role"] = "DAMAGER",
					["time"] = 4.18,
					["name"] = "Beardedrasta",
					["spec"] = 265,
					["damage"] = 1103,
				}, -- [4]
				{
					["overheal"] = 0,
					["last"] = 10502.559,
					["flag"] = 1298,
					["class"] = "PRIEST",
					["healspells"] = {
						[63544] = {
							["overheal"] = 0,
							["count"] = 1,
							["amount"] = 53,
							["school"] = 2,
							["max"] = 53,
							["targets"] = {
								["Fragrance"] = {
									["overheal"] = 0,
									["amount"] = 53,
								},
							},
							["min"] = 53,
						},
						[139] = {
							["overheal"] = 0,
							["targets"] = {
								["Fragrance"] = {
									["overheal"] = 0,
									["amount"] = 266,
								},
							},
							["count"] = 2,
							["amount"] = 266,
							["school"] = 2,
							["max"] = 133,
							["ishot"] = true,
							["min"] = 133,
						},
					},
					["heal"] = 319,
					["role"] = "HEALER",
					["name"] = "Nianhong",
					["time"] = 5.98,
					["id"] = "0x00000000000467C0",
				}, -- [5]
			},
			["type"] = "party",
			["damagetaken"] = 817,
			["overheal"] = 0,
			["energy"] = 36,
			["ccdone"] = 7,
			["overkill"] = 144,
			["edamagetaken"] = 7739,
			["heal"] = 319,
			["name"] = "Poison Sprite",
			["mobname"] = "Poison Sprite",
			["etotaldamage"] = 817,
			["edamage"] = 817,
			["last_action"] = 1689857373,
			["endtime"] = 1689857374,
		}, -- [9]
		{
			["overheal"] = 597,
			["mana"] = 2107,
			["enemies"] = {
				{
					["damagespells"] = {
						[6603] = {
							["school"] = 1,
							["total"] = 823,
							["targets"] = {
								["Myrony"] = {
									["total"] = 823,
									["amount"] = 823,
								},
							},
							["amount"] = 823,
						},
						[21910] = {
							["school"] = 4,
							["total"] = 396,
							["targets"] = {
								["Myrony"] = {
									["total"] = 396,
									["amount"] = 396,
								},
							},
							["amount"] = 396,
						},
					},
					["damagetaken"] = 28218,
					["flag"] = 68168,
					["class"] = "BOSS",
					["damagetakenspells"] = {
						[16827] = {
							["school"] = 1,
							["total"] = 839,
							["sources"] = {
								["Macius"] = {
									["total"] = 839,
									["amount"] = 839,
								},
							},
							["amount"] = 839,
						},
						[1978] = {
							["school"] = 8,
							["total"] = 730,
							["sources"] = {
								["Macius"] = {
									["total"] = 730,
									["amount"] = 730,
								},
							},
							["amount"] = 730,
						},
						[25742] = {
							["school"] = 2,
							["total"] = 794,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 432,
									["amount"] = 432,
								},
								["Myrony"] = {
									["total"] = 362,
									["amount"] = 362,
								},
							},
							["amount"] = 794,
						},
						[35395] = {
							["school"] = 1,
							["total"] = 4490,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 2743,
									["amount"] = 2743,
								},
								["Myrony"] = {
									["total"] = 1747,
									["amount"] = 1747,
								},
							},
							["amount"] = 4490,
						},
						[589] = {
							["sources"] = {
								["Nianhong"] = {
									["total"] = 387,
									["overkill"] = 19,
									["amount"] = 387,
								},
							},
							["amount"] = 387,
							["school"] = 32,
							["total"] = 387,
							["overkill"] = 19,
						},
						[53595] = {
							["school"] = 1,
							["total"] = 34,
							["sources"] = {
								["Myrony"] = {
									["total"] = 34,
									["amount"] = 34,
								},
							},
							["amount"] = 34,
						},
						[6603] = {
							["school"] = 1,
							["total"] = 5757,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 1018,
									["amount"] = 1018,
								},
								["Macius"] = {
									["total"] = 1002,
									["amount"] = 1002,
								},
								["Fragrance"] = {
									["total"] = 1963,
									["amount"] = 1963,
								},
								["Myrony"] = {
									["total"] = 1774,
									["amount"] = 1774,
								},
							},
							["amount"] = 5757,
						},
						[88263] = {
							["school"] = 2,
							["total"] = 143,
							["sources"] = {
								["Myrony"] = {
									["total"] = 143,
									["amount"] = 143,
								},
							},
							["amount"] = 143,
						},
						[88625] = {
							["school"] = 2,
							["total"] = 184,
							["sources"] = {
								["Nianhong"] = {
									["total"] = 184,
									["amount"] = 184,
								},
							},
							["amount"] = 184,
						},
						[172] = {
							["school"] = 32,
							["total"] = 571,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 571,
									["amount"] = 571,
								},
							},
							["amount"] = 571,
						},
						[980] = {
							["school"] = 32,
							["total"] = 410,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 410,
									["amount"] = 410,
								},
							},
							["amount"] = 410,
						},
						[686] = {
							["school"] = 32,
							["total"] = 990,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 990,
									["amount"] = 990,
								},
							},
							["amount"] = 990,
						},
						[3044] = {
							["school"] = 64,
							["total"] = 481,
							["sources"] = {
								["Macius"] = {
									["total"] = 481,
									["amount"] = 481,
								},
							},
							["amount"] = 481,
						},
						[85256] = {
							["school"] = 1,
							["total"] = 1772,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 1772,
									["amount"] = 1772,
								},
							},
							["amount"] = 1772,
						},
						[5019] = {
							["school"] = 1,
							["total"] = 489,
							["sources"] = {
								["Nianhong"] = {
									["total"] = 489,
									["amount"] = 489,
								},
							},
							["amount"] = 489,
						},
						[96172] = {
							["school"] = 2,
							["total"] = 10,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 10,
									["amount"] = 10,
								},
							},
							["amount"] = 10,
						},
						[7294] = {
							["school"] = 2,
							["total"] = 52,
							["sources"] = {
								["Myrony"] = {
									["total"] = 52,
									["amount"] = 52,
								},
							},
							["amount"] = 52,
						},
						[56641] = {
							["school"] = 1,
							["total"] = 1239,
							["sources"] = {
								["Macius"] = {
									["total"] = 1239,
									["amount"] = 1239,
								},
							},
							["amount"] = 1239,
						},
						[31935] = {
							["school"] = 2,
							["total"] = 673,
							["sources"] = {
								["Myrony"] = {
									["total"] = 673,
									["amount"] = 673,
								},
							},
							["amount"] = 673,
						},
						[14914] = {
							["school"] = 2,
							["total"] = 328,
							["sources"] = {
								["Nianhong"] = {
									["total"] = 328,
									["amount"] = 328,
								},
							},
							["amount"] = 328,
						},
						[20187] = {
							["school"] = 2,
							["total"] = 1450,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 896,
									["amount"] = 896,
								},
								["Myrony"] = {
									["total"] = 554,
									["amount"] = 554,
								},
							},
							["amount"] = 1450,
						},
						[53301] = {
							["school"] = 4,
							["total"] = 2154,
							["sources"] = {
								["Macius"] = {
									["total"] = 2154,
									["amount"] = 2154,
								},
							},
							["amount"] = 2154,
						},
						[30108] = {
							["school"] = 32,
							["total"] = 490,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 490,
									["amount"] = 490,
								},
							},
							["amount"] = 490,
						},
						[879] = {
							["school"] = 2,
							["total"] = 1135,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 726,
									["amount"] = 726,
								},
								["Myrony"] = {
									["total"] = 409,
									["amount"] = 409,
								},
							},
							["amount"] = 1135,
						},
						[83077] = {
							["school"] = 8,
							["total"] = 327,
							["sources"] = {
								["Macius"] = {
									["total"] = 327,
									["amount"] = 327,
								},
							},
							["amount"] = 327,
						},
						[54049] = {
							["school"] = 32,
							["total"] = 889,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 889,
									["amount"] = 889,
								},
							},
							["amount"] = 889,
						},
						[75] = {
							["school"] = 1,
							["total"] = 1400,
							["sources"] = {
								["Macius"] = {
									["total"] = 1400,
									["amount"] = 1400,
								},
							},
							["amount"] = 1400,
						},
					},
					["name"] = "Tinkerer Gizlock",
					["totaldamage"] = 1219,
					["totaldamagetaken"] = 28218,
					["id"] = "0xF130352100000093",
					["damage"] = 1219,
				}, -- [1]
			},
			["success"] = true,
			["totaldamage"] = 28218,
			["time"] = 40,
			["energy"] = 108,
			["totaldamagetaken"] = 1219,
			["etotaldamagetaken"] = 28218,
			["damage"] = 28218,
			["players"] = {
				{
					["last"] = 10480.703,
					["flag"] = 1297,
					["class"] = "WARLOCK",
					["auras"] = {
						[172] = {
							["type"] = "DEBUFF",
							["count"] = 2,
							["school"] = 32,
							["refresh"] = 1,
							["targets"] = {
								["Tinkerer Gizlock"] = {
									["count"] = 2,
									["refresh"] = 1,
									["uptime"] = 38,
								},
							},
							["uptime"] = 38,
						},
						[64368] = {
							["type"] = "BUFF",
							["count"] = 2,
							["school"] = 32,
							["uptime"] = 17,
						},
						[980] = {
							["type"] = "DEBUFF",
							["count"] = 1,
							["school"] = 32,
							["refresh"] = 1,
							["targets"] = {
								["Tinkerer Gizlock"] = {
									["count"] = 1,
									["refresh"] = 1,
									["uptime"] = 38,
								},
							},
							["uptime"] = 38,
						},
						[93435] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 1,
							["uptime"] = 34,
						},
						[30108] = {
							["type"] = "DEBUFF",
							["count"] = 2,
							["school"] = 32,
							["targets"] = {
								["Tinkerer Gizlock"] = {
									["uptime"] = 30,
									["count"] = 2,
								},
							},
							["uptime"] = 30,
						},
					},
					["time"] = 39.20999999999999,
					["damage"] = 4368,
					["overheal"] = 330,
					["id"] = "0x000000000004825C",
					["spec"] = 265,
					["healspells"] = {
						[63106] = {
							["overheal"] = 330,
							["count"] = 10,
							["amount"] = 0,
							["school"] = 32,
							["targets"] = {
								["Beardedrasta"] = {
									["overheal"] = 330,
									["amount"] = 0,
								},
							},
						},
					},
					["heal"] = 0,
					["name"] = "Beardedrasta",
					["damagespells"] = {
						["Bane of Agony (DoT)"] = {
							["total"] = 410,
							["hitmin"] = 12,
							["id"] = 980,
							["targets"] = {
								["Tinkerer Gizlock"] = {
									["total"] = 410,
									["amount"] = 410,
								},
							},
							["casts"] = 2,
							["count"] = 19,
							["hit"] = 19,
							["school"] = 32,
							["hitmax"] = 38,
							["amount"] = 410,
							["hitamount"] = 410,
						},
						["Corruption (DoT)"] = {
							["total"] = 571,
							["hitmin"] = 44,
							["criticalamount"] = 87,
							["id"] = 172,
							["criticalmin"] = 87,
							["targets"] = {
								["Tinkerer Gizlock"] = {
									["total"] = 571,
									["amount"] = 571,
								},
							},
							["criticalmax"] = 87,
							["critical"] = 1,
							["casts"] = 3,
							["count"] = 12,
							["hit"] = 11,
							["school"] = 32,
							["hitmax"] = 44,
							["amount"] = 571,
							["hitamount"] = 484,
						},
						["Shadow Bolt"] = {
							["total"] = 990,
							["hitmin"] = 163,
							["id"] = 686,
							["targets"] = {
								["Tinkerer Gizlock"] = {
									["total"] = 990,
									["amount"] = 990,
								},
							},
							["amount"] = 990,
							["casts"] = 8,
							["count"] = 9,
							["hit"] = 6,
							["school"] = 32,
							["hitmax"] = 166,
							["MISS"] = 3,
							["hitamount"] = 990,
						},
						["Unstable Affliction (DoT)"] = {
							["total"] = 490,
							["hitmin"] = 49,
							["id"] = 30108,
							["targets"] = {
								["Tinkerer Gizlock"] = {
									["total"] = 490,
									["amount"] = 490,
								},
							},
							["casts"] = 2,
							["count"] = 10,
							["hit"] = 10,
							["school"] = 32,
							["hitmax"] = 49,
							["amount"] = 490,
							["hitamount"] = 490,
						},
						["Melee (Haagroon)"] = {
							["DODGE"] = 1,
							["hitmin"] = 59,
							["criticalmin"] = 118,
							["targets"] = {
								["Tinkerer Gizlock"] = {
									["total"] = 1018,
									["amount"] = 1018,
								},
							},
							["glancing"] = 5,
							["amount"] = 1018,
							["MISS"] = 2,
							["total"] = 1018,
							["criticalamount"] = 494,
							["id"] = 6603,
							["PARRY"] = 2,
							["criticalmax"] = 128,
							["hitmax"] = 64,
							["hit"] = 5,
							["school"] = 1,
							["critical"] = 4,
							["count"] = 19,
							["hitamount"] = 305,
						},
						["Shadow Bite (Haagroon)"] = {
							["criticalmin"] = 305,
							["total"] = 889,
							["hitmin"] = 125,
							["criticalamount"] = 305,
							["id"] = 54049,
							["criticalmax"] = 305,
							["targets"] = {
								["Tinkerer Gizlock"] = {
									["total"] = 889,
									["amount"] = 889,
								},
							},
							["critical"] = 1,
							["amount"] = 889,
							["casts"] = 7,
							["count"] = 7,
							["hit"] = 4,
							["school"] = 32,
							["hitmax"] = 155,
							["MISS"] = 2,
							["hitamount"] = 584,
						},
					},
					["totaldamage"] = 4368,
					["role"] = "DAMAGER",
				}, -- [1]
				{
					["damagespells"] = {
						["Explosive Shot (DoT)"] = {
							["total"] = 2154,
							["hitmin"] = 178,
							["id"] = 53301,
							["targets"] = {
								["Tinkerer Gizlock"] = {
									["total"] = 2154,
									["amount"] = 2154,
								},
							},
							["casts"] = 4,
							["count"] = 12,
							["hit"] = 12,
							["school"] = 4,
							["hitmax"] = 181,
							["amount"] = 2154,
							["hitamount"] = 2154,
						},
						["Auto Shot"] = {
							["total"] = 1400,
							["hitmin"] = 99,
							["id"] = 75,
							["targets"] = {
								["Tinkerer Gizlock"] = {
									["total"] = 1400,
									["amount"] = 1400,
								},
							},
							["amount"] = 1400,
							["casts"] = 1,
							["count"] = 15,
							["hit"] = 13,
							["school"] = 1,
							["hitmax"] = 117,
							["MISS"] = 2,
							["hitamount"] = 1400,
						},
						["Steady Shot"] = {
							["total"] = 1239,
							["hitmin"] = 95,
							["id"] = 56641,
							["targets"] = {
								["Tinkerer Gizlock"] = {
									["total"] = 1239,
									["amount"] = 1239,
								},
							},
							["amount"] = 1239,
							["casts"] = 13,
							["count"] = 13,
							["hit"] = 12,
							["school"] = 1,
							["hitmax"] = 110,
							["MISS"] = 1,
							["hitamount"] = 1239,
						},
						["Improved Serpent Sting"] = {
							["total"] = 327,
							["hitmin"] = 109,
							["criticalamount"] = 218,
							["id"] = 83077,
							["criticalmin"] = 218,
							["targets"] = {
								["Tinkerer Gizlock"] = {
									["total"] = 327,
									["amount"] = 327,
								},
							},
							["criticalmax"] = 218,
							["critical"] = 1,
							["casts"] = 2,
							["count"] = 2,
							["hit"] = 1,
							["school"] = 8,
							["hitmax"] = 109,
							["amount"] = 327,
							["hitamount"] = 109,
						},
						["Claw (Cat)"] = {
							["DODGE"] = 1,
							["total"] = 839,
							["hitmin"] = 83,
							["criticalamount"] = 168,
							["id"] = 16827,
							["criticalmin"] = 168,
							["targets"] = {
								["Tinkerer Gizlock"] = {
									["total"] = 839,
									["amount"] = 839,
								},
							},
							["criticalmax"] = 168,
							["critical"] = 1,
							["casts"] = 10,
							["count"] = 10,
							["hit"] = 8,
							["school"] = 1,
							["hitmax"] = 84,
							["amount"] = 839,
							["hitamount"] = 671,
						},
						["Serpent Sting (DoT)"] = {
							["total"] = 730,
							["hitmin"] = 73,
							["id"] = 1978,
							["targets"] = {
								["Tinkerer Gizlock"] = {
									["total"] = 730,
									["amount"] = 730,
								},
							},
							["casts"] = 2,
							["count"] = 10,
							["hit"] = 10,
							["school"] = 8,
							["hitmax"] = 73,
							["amount"] = 730,
							["hitamount"] = 730,
						},
						["Melee (Cat)"] = {
							["DODGE"] = 1,
							["hitmin"] = 36,
							["criticalmin"] = 100,
							["targets"] = {
								["Tinkerer Gizlock"] = {
									["total"] = 1002,
									["amount"] = 1002,
								},
							},
							["glancing"] = 4,
							["amount"] = 1002,
							["MISS"] = 3,
							["total"] = 1002,
							["criticalamount"] = 306,
							["id"] = 6603,
							["blocked"] = 15,
							["criticalmax"] = 104,
							["PARRY"] = 1,
							["hitmax"] = 63,
							["hit"] = 10,
							["school"] = 1,
							["critical"] = 3,
							["count"] = 22,
							["hitamount"] = 546,
						},
						["Arcane Shot"] = {
							["total"] = 481,
							["hitmin"] = 156,
							["id"] = 3044,
							["targets"] = {
								["Tinkerer Gizlock"] = {
									["total"] = 481,
									["amount"] = 481,
								},
							},
							["casts"] = 3,
							["count"] = 3,
							["hit"] = 3,
							["school"] = 64,
							["hitmax"] = 163,
							["amount"] = 481,
							["hitamount"] = 481,
						},
					},
					["last"] = 10480.218,
					["flag"] = 1298,
					["id"] = "0x00000000000477A3",
					["class"] = "HUNTER",
					["totaldamage"] = 8172,
					["auras"] = {
						[93435] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 1,
							["uptime"] = 34,
						},
						[1978] = {
							["type"] = "DEBUFF",
							["count"] = 2,
							["school"] = 8,
							["targets"] = {
								["Tinkerer Gizlock"] = {
									["uptime"] = 30,
									["count"] = 2,
								},
							},
							["uptime"] = 30,
						},
						[53301] = {
							["type"] = "DEBUFF",
							["count"] = 4,
							["school"] = 4,
							["targets"] = {
								["Tinkerer Gizlock"] = {
									["uptime"] = 8,
									["count"] = 4,
								},
							},
							["uptime"] = 8,
						},
					},
					["energyspells"] = {
						[91954] = 108,
					},
					["name"] = "Macius",
					["time"] = 38.69,
					["role"] = "DAMAGER",
					["energy"] = 108,
					["damage"] = 8172,
				}, -- [2]
				{
					["last"] = 10478.649,
					["flag"] = 1298,
					["class"] = "PRIEST",
					["auras"] = {
						[93435] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 1,
							["uptime"] = 34,
						},
						[589] = {
							["type"] = "DEBUFF",
							["count"] = 2,
							["school"] = 32,
							["targets"] = {
								["Tinkerer Gizlock"] = {
									["uptime"] = 27,
									["count"] = 2,
								},
							},
							["uptime"] = 27,
						},
						[14914] = {
							["type"] = "DEBUFF",
							["count"] = 1,
							["school"] = 2,
							["targets"] = {
								["Tinkerer Gizlock"] = {
									["uptime"] = 5,
									["count"] = 1,
								},
							},
							["uptime"] = 5,
						},
					},
					["role"] = "HEALER",
					["time"] = 15.48,
					["damage"] = 1388,
					["overheal"] = 267,
					["id"] = "0x00000000000467C0",
					["healspells"] = {
						[139] = {
							["overheal"] = 267,
							["criticalamount"] = 354,
							["max"] = 354,
							["targets"] = {
								["Myrony"] = {
									["overheal"] = 0,
									["amount"] = 885,
								},
								["Beardedrasta"] = {
									["overheal"] = 267,
									["amount"] = 13,
								},
							},
							["criticalmin"] = 354,
							["min"] = 13,
							["casts"] = 2,
							["count"] = 6,
							["amount"] = 898,
							["school"] = 2,
							["criticalmax"] = 354,
							["ishot"] = true,
							["critical"] = 1,
						},
						[63544] = {
							["overheal"] = 0,
							["criticalamount"] = 140,
							["max"] = 140,
							["targets"] = {
								["Myrony"] = {
									["overheal"] = 0,
									["amount"] = 140,
								},
							},
							["min"] = 140,
							["criticalmax"] = 140,
							["critical"] = 1,
							["amount"] = 140,
							["school"] = 2,
							["criticalmin"] = 140,
							["count"] = 1,
						},
					},
					["overkill"] = 19,
					["heal"] = 1038,
					["name"] = "Nianhong",
					["damagespells"] = {
						["Shoot"] = {
							["total"] = 489,
							["hitmin"] = 33,
							["criticalamount"] = 124,
							["id"] = 5019,
							["criticalmin"] = 57,
							["targets"] = {
								["Tinkerer Gizlock"] = {
									["total"] = 489,
									["amount"] = 489,
								},
							},
							["criticalmax"] = 67,
							["critical"] = 2,
							["casts"] = 1,
							["count"] = 11,
							["hit"] = 9,
							["school"] = 1,
							["hitmax"] = 49,
							["amount"] = 489,
							["hitamount"] = 365,
						},
						["Holy Fire"] = {
							["total"] = 288,
							["hitmin"] = 288,
							["id"] = 14914,
							["targets"] = {
								["Tinkerer Gizlock"] = {
									["total"] = 288,
									["amount"] = 288,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 2,
							["hitmax"] = 288,
							["amount"] = 288,
							["hitamount"] = 288,
						},
						["Holy Word: Chastise"] = {
							["total"] = 184,
							["hitmin"] = 184,
							["id"] = 88625,
							["targets"] = {
								["Tinkerer Gizlock"] = {
									["total"] = 184,
									["amount"] = 184,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 2,
							["hitmax"] = 184,
							["amount"] = 184,
							["hitamount"] = 184,
						},
						["Shadow Word: Pain (DoT)"] = {
							["total"] = 387,
							["hitmin"] = 43,
							["id"] = 589,
							["targets"] = {
								["Tinkerer Gizlock"] = {
									["total"] = 387,
									["overkill"] = 19,
									["amount"] = 387,
								},
							},
							["overkill"] = 19,
							["casts"] = 2,
							["count"] = 9,
							["hit"] = 9,
							["school"] = 32,
							["hitmax"] = 43,
							["amount"] = 387,
							["hitamount"] = 387,
						},
						["Holy Fire (DoT)"] = {
							["total"] = 40,
							["hitmin"] = 9,
							["criticalamount"] = 13,
							["id"] = 14914,
							["targets"] = {
								["Tinkerer Gizlock"] = {
									["total"] = 40,
									["amount"] = 40,
								},
							},
							["hitmax"] = 9,
							["count"] = 4,
							["criticalmax"] = 13,
							["critical"] = 1,
							["amount"] = 40,
							["school"] = 2,
							["hit"] = 3,
							["criticalmin"] = 13,
							["hitamount"] = 27,
						},
					},
					["totaldamage"] = 1388,
				}, -- [3]
				{
					["damagespells"] = {
						["Exorcism"] = {
							["total"] = 726,
							["hitmin"] = 726,
							["id"] = 879,
							["targets"] = {
								["Tinkerer Gizlock"] = {
									["total"] = 726,
									["amount"] = 726,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 2,
							["hitmax"] = 726,
							["amount"] = 726,
							["hitamount"] = 726,
						},
						["Seal of Righteousness"] = {
							["total"] = 432,
							["hitmin"] = 27,
							["criticalamount"] = 108,
							["id"] = 25742,
							["criticalmin"] = 54,
							["targets"] = {
								["Tinkerer Gizlock"] = {
									["total"] = 432,
									["amount"] = 432,
								},
							},
							["criticalmax"] = 54,
							["critical"] = 2,
							["casts"] = 1,
							["count"] = 14,
							["hit"] = 12,
							["school"] = 2,
							["hitmax"] = 27,
							["amount"] = 432,
							["hitamount"] = 324,
						},
						["Crusader Strike"] = {
							["DODGE"] = 1,
							["total"] = 2743,
							["hitmin"] = 307,
							["criticalamount"] = 698,
							["id"] = 35395,
							["hitmax"] = 376,
							["targets"] = {
								["Tinkerer Gizlock"] = {
									["total"] = 2743,
									["amount"] = 2743,
								},
							},
							["count"] = 8,
							["hit"] = 6,
							["casts"] = 8,
							["critical"] = 1,
							["amount"] = 2743,
							["school"] = 1,
							["criticalmin"] = 698,
							["criticalmax"] = 698,
							["hitamount"] = 2045,
						},
						["Melee"] = {
							["DODGE"] = 1,
							["total"] = 1963,
							["hitmin"] = 186,
							["id"] = 6603,
							["targets"] = {
								["Tinkerer Gizlock"] = {
									["total"] = 1963,
									["amount"] = 1963,
								},
							},
							["glancing"] = 2,
							["count"] = 11,
							["hit"] = 8,
							["school"] = 1,
							["hitmax"] = 222,
							["amount"] = 1963,
							["hitamount"] = 1610,
						},
						["Hand of Light"] = {
							["total"] = 10,
							["hitmin"] = 1,
							["id"] = 96172,
							["targets"] = {
								["Tinkerer Gizlock"] = {
									["total"] = 10,
									["amount"] = 10,
								},
							},
							["casts"] = 1,
							["count"] = 10,
							["hit"] = 10,
							["school"] = 2,
							["hitmax"] = 1,
							["amount"] = 10,
							["hitamount"] = 10,
						},
						["Templar's Verdict"] = {
							["total"] = 1772,
							["hitmin"] = 541,
							["id"] = 85256,
							["targets"] = {
								["Tinkerer Gizlock"] = {
									["total"] = 1772,
									["amount"] = 1772,
								},
							},
							["casts"] = 3,
							["count"] = 3,
							["hit"] = 3,
							["school"] = 1,
							["hitmax"] = 668,
							["amount"] = 1772,
							["hitamount"] = 1772,
						},
						["Judgement of Righteousness"] = {
							["total"] = 896,
							["hitmin"] = 128,
							["criticalamount"] = 512,
							["id"] = 20187,
							["criticalmin"] = 256,
							["targets"] = {
								["Tinkerer Gizlock"] = {
									["total"] = 896,
									["amount"] = 896,
								},
							},
							["criticalmax"] = 256,
							["critical"] = 2,
							["casts"] = 5,
							["count"] = 5,
							["hit"] = 3,
							["school"] = 2,
							["hitmax"] = 128,
							["amount"] = 896,
							["hitamount"] = 384,
						},
					},
					["last"] = 10480.703,
					["totaldamage"] = 8542,
					["flag"] = 1298,
					["mana"] = 912,
					["id"] = "0x0000000000048007",
					["auras"] = {
						[93435] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 1,
							["uptime"] = 34,
						},
						[59578] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 1,
							["uptime"] = 2,
						},
						[89906] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 2,
							["refresh"] = 2,
							["uptime"] = 19,
						},
					},
					["class"] = "PALADIN",
					["time"] = 38.83,
					["role"] = "DAMAGER",
					["name"] = "Fragrance",
					["manaspells"] = {
						[89906] = 912,
					},
					["damage"] = 8542,
				}, -- [4]
				{
					["ccdonespells"] = {
						[31935] = {
							["count"] = 2,
							["targets"] = {
								["Tinkerer Gizlock"] = 2,
							},
						},
					},
					["last"] = 10480.598,
					["flag"] = 1298,
					["class"] = "PALADIN",
					["auras"] = {
						[62124] = {
							["type"] = "DEBUFF",
							["count"] = 1,
							["school"] = 2,
							["targets"] = {
								["Tinkerer Gizlock"] = {
									["uptime"] = 3,
									["count"] = 1,
								},
							},
							["uptime"] = 3,
						},
						[31935] = {
							["type"] = "DEBUFF",
							["count"] = 2,
							["school"] = 2,
							["targets"] = {
								["Tinkerer Gizlock"] = {
									["uptime"] = 6,
									["count"] = 2,
								},
							},
							["uptime"] = 6,
						},
						[31930] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 2,
							["refresh"] = 1,
							["uptime"] = 19,
						},
						[139] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 2,
							["uptime"] = 12,
						},
						[93435] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 1,
							["uptime"] = 34,
						},
					},
					["role"] = "TANK",
					["time"] = 38.48,
					["totaldamagetaken"] = 1219,
					["damage"] = 5748,
					["damagespells"] = {
						["Exorcism"] = {
							["total"] = 409,
							["hitmin"] = 409,
							["id"] = 879,
							["targets"] = {
								["Tinkerer Gizlock"] = {
									["total"] = 409,
									["amount"] = 409,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 2,
							["hitmax"] = 409,
							["amount"] = 409,
							["hitamount"] = 409,
						},
						["Melee"] = {
							["total"] = 1774,
							["hitmin"] = 74,
							["id"] = 6603,
							["targets"] = {
								["Tinkerer Gizlock"] = {
									["total"] = 1774,
									["amount"] = 1774,
								},
							},
							["blocked"] = 31,
							["count"] = 17,
							["hit"] = 17,
							["school"] = 1,
							["hitmax"] = 122,
							["amount"] = 1774,
							["hitamount"] = 1774,
						},
						["Hammer of the Righteous (Physical)"] = {
							["total"] = 34,
							["hitmin"] = 34,
							["id"] = 53595,
							["targets"] = {
								["Tinkerer Gizlock"] = {
									["total"] = 34,
									["amount"] = 34,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 1,
							["hitmax"] = 34,
							["amount"] = 34,
							["hitamount"] = 34,
						},
						["Retribution Aura"] = {
							["total"] = 52,
							["hitmin"] = 13,
							["id"] = 7294,
							["targets"] = {
								["Tinkerer Gizlock"] = {
									["total"] = 52,
									["amount"] = 52,
								},
							},
							["casts"] = 1,
							["count"] = 4,
							["hit"] = 4,
							["school"] = 2,
							["hitmax"] = 13,
							["amount"] = 52,
							["hitamount"] = 52,
						},
						["Hammer of the Righteous"] = {
							["total"] = 143,
							["hitmin"] = 143,
							["id"] = 88263,
							["targets"] = {
								["Tinkerer Gizlock"] = {
									["total"] = 143,
									["amount"] = 143,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 2,
							["hitmax"] = 143,
							["amount"] = 143,
							["hitamount"] = 143,
						},
						["Seal of Righteousness"] = {
							["total"] = 362,
							["hitmin"] = 17,
							["criticalamount"] = 38,
							["id"] = 25742,
							["criticalmin"] = 38,
							["targets"] = {
								["Tinkerer Gizlock"] = {
									["total"] = 362,
									["amount"] = 362,
								},
							},
							["criticalmax"] = 38,
							["critical"] = 1,
							["casts"] = 1,
							["count"] = 19,
							["hit"] = 18,
							["school"] = 2,
							["hitmax"] = 19,
							["amount"] = 362,
							["hitamount"] = 324,
						},
						["Crusader Strike"] = {
							["total"] = 1747,
							["hitmin"] = 188,
							["criticalamount"] = 438,
							["id"] = 35395,
							["hitmax"] = 250,
							["targets"] = {
								["Tinkerer Gizlock"] = {
									["total"] = 1747,
									["amount"] = 1747,
								},
							},
							["count"] = 7,
							["hit"] = 6,
							["casts"] = 7,
							["critical"] = 1,
							["amount"] = 1747,
							["school"] = 1,
							["criticalmin"] = 438,
							["criticalmax"] = 438,
							["hitamount"] = 1309,
						},
						["Avenger's Shield"] = {
							["total"] = 673,
							["hitmin"] = 336,
							["id"] = 31935,
							["targets"] = {
								["Tinkerer Gizlock"] = {
									["total"] = 673,
									["amount"] = 673,
								},
							},
							["casts"] = 2,
							["count"] = 2,
							["hit"] = 2,
							["school"] = 2,
							["hitmax"] = 337,
							["amount"] = 673,
							["hitamount"] = 673,
						},
						["Judgement of Righteousness"] = {
							["total"] = 554,
							["hitmin"] = 179,
							["id"] = 20187,
							["targets"] = {
								["Tinkerer Gizlock"] = {
									["total"] = 554,
									["amount"] = 554,
								},
							},
							["casts"] = 3,
							["count"] = 3,
							["hit"] = 3,
							["school"] = 2,
							["hitmax"] = 188,
							["amount"] = 554,
							["hitamount"] = 554,
						},
					},
					["damagetaken"] = 1219,
					["id"] = "0x00000000000447DB",
					["damagetakenspells"] = {
						["Melee"] = {
							["total"] = 823,
							["hitmin"] = 181,
							["id"] = 6603,
							["hit"] = 4,
							["hitmax"] = 231,
							["PARRY"] = 4,
							["count"] = 12,
							["amount"] = 823,
							["school"] = 1,
							["sources"] = {
								["Tinkerer Gizlock"] = {
									["total"] = 823,
									["amount"] = 823,
								},
							},
							["MISS"] = 4,
							["hitamount"] = 823,
						},
						["Goblin Dragon Gun"] = {
							["total"] = 396,
							["hitmin"] = 93,
							["id"] = 21910,
							["sources"] = {
								["Tinkerer Gizlock"] = {
									["total"] = 396,
									["amount"] = 396,
								},
							},
							["hitmax"] = 108,
							["casts"] = 1,
							["count"] = 4,
							["hit"] = 4,
							["school"] = 4,
							["resisted"] = 98,
							["amount"] = 396,
							["hitamount"] = 396,
						},
					},
					["manaspells"] = {
						[31930] = 1015,
						[84627] = 180,
					},
					["ccdone"] = 2,
					["name"] = "Myrony",
					["mana"] = 1195,
					["totaldamage"] = 5748,
				}, -- [5]
			},
			["type"] = "party",
			["damagetaken"] = 1219,
			["gotboss"] = 13601,
			["ccdone"] = 2,
			["etotaldamage"] = 1219,
			["overkill"] = 19,
			["edamagetaken"] = 28218,
			["heal"] = 1038,
			["name"] = "Tinkerer Gizlock",
			["mobname"] = "Tinkerer Gizlock",
			["starttime"] = 1689857310,
			["edamage"] = 1219,
			["last_action"] = 1689857350,
			["endtime"] = 1689857350,
		}, -- [10]
		{
			["mana"] = 1483,
			["overheal"] = 2084,
			["enemies"] = {
				{
					["damagespells"] = {
						[6603] = {
							["school"] = 1,
							["total"] = 1124,
							["targets"] = {
								["Myrony"] = {
									["total"] = 1124,
									["amount"] = 523,
								},
							},
							["amount"] = 523,
						},
					},
					["damagetaken"] = 2848,
					["flag"] = 2632,
					["class"] = "MONSTER",
					["damagetakenspells"] = {
						[42223] = {
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 655,
									["overkill"] = 53,
									["amount"] = 655,
								},
							},
							["amount"] = 655,
							["school"] = 4,
							["total"] = 655,
							["overkill"] = 53,
						},
						[2812] = {
							["school"] = 2,
							["total"] = 138,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 138,
									["amount"] = 138,
								},
							},
							["amount"] = 138,
						},
						[53385] = {
							["sources"] = {
								["Fragrance"] = {
									["total"] = 904,
									["overkill"] = 296,
									["amount"] = 904,
								},
							},
							["amount"] = 904,
							["school"] = 1,
							["total"] = 904,
							["overkill"] = 296,
						},
						[2643] = {
							["school"] = 1,
							["total"] = 355,
							["sources"] = {
								["Macius"] = {
									["total"] = 355,
									["amount"] = 355,
								},
							},
							["amount"] = 355,
						},
						[75] = {
							["school"] = 1,
							["total"] = 99,
							["sources"] = {
								["Macius"] = {
									["total"] = 99,
									["amount"] = 99,
								},
							},
							["amount"] = 99,
						},
						[7294] = {
							["school"] = 2,
							["total"] = 39,
							["sources"] = {
								["Myrony"] = {
									["total"] = 39,
									["amount"] = 39,
								},
							},
							["amount"] = 39,
						},
						[81297] = {
							["school"] = 2,
							["total"] = 654,
							["sources"] = {
								["Myrony"] = {
									["total"] = 654,
									["amount"] = 654,
								},
							},
							["amount"] = 654,
						},
						[96172] = {
							["school"] = 2,
							["total"] = 4,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 4,
									["amount"] = 4,
								},
							},
							["amount"] = 4,
						},
					},
					["name"] = "Corruptor",
					["totaldamage"] = 1124,
					["totaldamagetaken"] = 2848,
					["id"] = "0xF1302FB90000008C",
					["damage"] = 523,
				}, -- [1]
				{
					["damagespells"] = {
						[6603] = {
							["school"] = 1,
							["total"] = 1003,
							["targets"] = {
								["Myrony"] = {
									["total"] = 1003,
									["amount"] = 635,
								},
							},
							["amount"] = 635,
						},
						[13298] = {
							["school"] = 8,
							["total"] = 35,
							["targets"] = {
								["Myrony"] = {
									["total"] = 35,
									["amount"] = 26,
								},
							},
							["amount"] = 26,
						},
					},
					["damagetaken"] = 4715,
					["flag"] = 2632,
					["class"] = "MONSTER",
					["damagetakenspells"] = {
						[81297] = {
							["school"] = 2,
							["total"] = 292,
							["sources"] = {
								["Myrony"] = {
									["total"] = 292,
									["amount"] = 292,
								},
							},
							["amount"] = 292,
						},
						[56641] = {
							["school"] = 1,
							["total"] = 87,
							["sources"] = {
								["Macius"] = {
									["total"] = 87,
									["amount"] = 87,
								},
							},
							["amount"] = 87,
						},
						[53385] = {
							["school"] = 1,
							["total"] = 397,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 397,
									["amount"] = 397,
								},
							},
							["amount"] = 397,
						},
						[7294] = {
							["school"] = 2,
							["total"] = 52,
							["sources"] = {
								["Myrony"] = {
									["total"] = 52,
									["amount"] = 52,
								},
							},
							["amount"] = 52,
						},
						[2643] = {
							["school"] = 1,
							["total"] = 188,
							["sources"] = {
								["Macius"] = {
									["total"] = 188,
									["amount"] = 188,
								},
							},
							["amount"] = 188,
						},
						[20187] = {
							["school"] = 2,
							["total"] = 124,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 124,
									["amount"] = 124,
								},
							},
							["amount"] = 124,
						},
						[88263] = {
							["school"] = 2,
							["total"] = 165,
							["sources"] = {
								["Myrony"] = {
									["total"] = 165,
									["amount"] = 165,
								},
							},
							["amount"] = 165,
						},
						[35395] = {
							["school"] = 1,
							["total"] = 990,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 318,
									["amount"] = 318,
								},
								["Myrony"] = {
									["total"] = 672,
									["amount"] = 672,
								},
							},
							["amount"] = 990,
						},
						[75] = {
							["sources"] = {
								["Macius"] = {
									["total"] = 193,
									["overkill"] = 63,
									["amount"] = 193,
								},
							},
							["amount"] = 193,
							["school"] = 1,
							["total"] = 193,
							["overkill"] = 63,
						},
						[25742] = {
							["school"] = 2,
							["total"] = 194,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 26,
									["amount"] = 26,
								},
								["Myrony"] = {
									["total"] = 168,
									["amount"] = 168,
								},
							},
							["amount"] = 194,
						},
						[96172] = {
							["school"] = 2,
							["total"] = 3,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 3,
									["amount"] = 3,
								},
							},
							["amount"] = 3,
						},
						[53595] = {
							["school"] = 1,
							["total"] = 33,
							["sources"] = {
								["Myrony"] = {
									["total"] = 33,
									["amount"] = 33,
								},
							},
							["amount"] = 33,
						},
						[2812] = {
							["school"] = 2,
							["total"] = 46,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 46,
									["amount"] = 46,
								},
							},
							["amount"] = 46,
						},
						[42223] = {
							["school"] = 4,
							["total"] = 246,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 246,
									["amount"] = 246,
								},
							},
							["amount"] = 246,
						},
						[16827] = {
							["school"] = 1,
							["total"] = 84,
							["sources"] = {
								["Macius"] = {
									["total"] = 84,
									["amount"] = 84,
								},
							},
							["amount"] = 84,
						},
						[6603] = {
							["school"] = 1,
							["total"] = 1621,
							["sources"] = {
								["Macius"] = {
									["total"] = 55,
									["amount"] = 55,
								},
								["Fragrance"] = {
									["total"] = 556,
									["amount"] = 556,
								},
								["Myrony"] = {
									["total"] = 1010,
									["amount"] = 1010,
								},
							},
							["amount"] = 1621,
						},
					},
					["name"] = "Putridus Trickster",
					["totaldamage"] = 1038,
					["totaldamagetaken"] = 4715,
					["id"] = "0xF1302E0F00000087",
					["damage"] = 661,
				}, -- [2]
				{
					["id"] = "0xF1302FB800000091",
					["name"] = "Poison Sprite",
					["totaldamagetaken"] = 1098,
					["flag"] = 2632,
					["class"] = "MONSTER",
					["damagetaken"] = 1098,
					["damagetakenspells"] = {
						[42223] = {
							["school"] = 4,
							["total"] = 164,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 164,
									["amount"] = 164,
								},
							},
							["amount"] = 164,
						},
						[53385] = {
							["sources"] = {
								["Fragrance"] = {
									["total"] = 560,
									["overkill"] = 265,
									["amount"] = 560,
								},
							},
							["amount"] = 560,
							["school"] = 1,
							["total"] = 560,
							["overkill"] = 265,
						},
						[2812] = {
							["school"] = 2,
							["total"] = 69,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 69,
									["amount"] = 69,
								},
							},
							["amount"] = 69,
						},
						[81297] = {
							["school"] = 2,
							["total"] = 206,
							["sources"] = {
								["Myrony"] = {
									["total"] = 206,
									["amount"] = 206,
								},
							},
							["amount"] = 206,
						},
						[2643] = {
							["school"] = 1,
							["total"] = 97,
							["sources"] = {
								["Macius"] = {
									["total"] = 97,
									["amount"] = 97,
								},
							},
							["amount"] = 97,
						},
						[96172] = {
							["school"] = 2,
							["total"] = 2,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 2,
									["amount"] = 2,
								},
							},
							["amount"] = 2,
						},
					},
				}, -- [3]
				{
					["damagespells"] = {
						[12540] = {
							["school"] = 1,
							["total"] = 14,
							["targets"] = {
								["Fragrance"] = {
									["total"] = 14,
									["amount"] = 0,
								},
							},
							["amount"] = 0,
						},
						[6603] = {
							["school"] = 1,
							["total"] = 1201,
							["targets"] = {
								["Fragrance"] = {
									["total"] = 1201,
									["amount"] = 478,
								},
							},
							["amount"] = 478,
						},
						[15667] = {
							["school"] = 1,
							["total"] = 209,
							["targets"] = {
								["Fragrance"] = {
									["total"] = 209,
									["amount"] = 209,
								},
							},
							["amount"] = 209,
						},
					},
					["damagetaken"] = 4546,
					["flag"] = 2632,
					["class"] = "MONSTER",
					["damagetakenspells"] = {
						[16827] = {
							["school"] = 1,
							["total"] = 170,
							["sources"] = {
								["Macius"] = {
									["total"] = 170,
									["amount"] = 170,
								},
							},
							["amount"] = 170,
						},
						[25742] = {
							["school"] = 2,
							["total"] = 53,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 53,
									["amount"] = 53,
								},
							},
							["amount"] = 53,
						},
						[81297] = {
							["school"] = 2,
							["total"] = 280,
							["sources"] = {
								["Myrony"] = {
									["total"] = 280,
									["amount"] = 280,
								},
							},
							["amount"] = 280,
						},
						[6603] = {
							["school"] = 1,
							["total"] = 996,
							["sources"] = {
								["Macius"] = {
									["total"] = 168,
									["amount"] = 168,
								},
								["Fragrance"] = {
									["total"] = 760,
									["amount"] = 760,
								},
								["Beardedrasta"] = {
									["total"] = 68,
									["amount"] = 68,
								},
							},
							["amount"] = 996,
						},
						[3044] = {
							["sources"] = {
								["Macius"] = {
									["total"] = 144,
									["overkill"] = 106,
									["amount"] = 144,
								},
							},
							["amount"] = 144,
							["school"] = 64,
							["total"] = 144,
							["overkill"] = 106,
						},
						[2643] = {
							["school"] = 1,
							["total"] = 184,
							["sources"] = {
								["Macius"] = {
									["total"] = 184,
									["amount"] = 184,
								},
							},
							["amount"] = 184,
						},
						[42223] = {
							["school"] = 4,
							["total"] = 328,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 328,
									["amount"] = 328,
								},
							},
							["amount"] = 328,
						},
						[53385] = {
							["school"] = 1,
							["total"] = 618,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 618,
									["amount"] = 618,
								},
							},
							["amount"] = 618,
						},
						[85256] = {
							["school"] = 1,
							["total"] = 651,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 651,
									["amount"] = 651,
								},
							},
							["amount"] = 651,
						},
						[96172] = {
							["school"] = 2,
							["total"] = 3,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 3,
									["amount"] = 3,
								},
							},
							["amount"] = 3,
						},
						[2812] = {
							["school"] = 2,
							["total"] = 46,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 46,
									["amount"] = 46,
								},
							},
							["amount"] = 46,
						},
						[20187] = {
							["school"] = 2,
							["total"] = 124,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 124,
									["amount"] = 124,
								},
							},
							["amount"] = 124,
						},
						[75] = {
							["school"] = 1,
							["total"] = 400,
							["sources"] = {
								["Macius"] = {
									["total"] = 400,
									["amount"] = 400,
								},
							},
							["amount"] = 400,
						},
						[88263] = {
							["school"] = 2,
							["total"] = 158,
							["sources"] = {
								["Myrony"] = {
									["total"] = 158,
									["amount"] = 158,
								},
							},
							["amount"] = 158,
						},
						[7294] = {
							["school"] = 2,
							["total"] = 39,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 39,
									["amount"] = 39,
								},
							},
							["amount"] = 39,
						},
						[54049] = {
							["school"] = 32,
							["total"] = 83,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 83,
									["amount"] = 83,
								},
							},
							["amount"] = 83,
						},
						[56641] = {
							["school"] = 1,
							["total"] = 269,
							["sources"] = {
								["Macius"] = {
									["total"] = 269,
									["amount"] = 269,
								},
							},
							["amount"] = 269,
						},
					},
					["name"] = "Putridus Satyr",
					["totaldamage"] = 1424,
					["totaldamagetaken"] = 4546,
					["id"] = "0xF1302E0E00000086",
					["damage"] = 687,
				}, -- [4]
			},
			["totaldamage"] = 13207,
			["time"] = 19,
			["ccdone"] = 5,
			["totaldamagetaken"] = 3586,
			["etotaldamagetaken"] = 13207,
			["damage"] = 13207,
			["players"] = {
				{
					["ccdonespells"] = {
						[2812] = {
							["count"] = 5,
							["targets"] = {
								["Putridus Satyr"] = 1,
								["Poison Sprite"] = 1,
								["Putridus Trickster"] = 1,
								["Corruptor"] = 2,
							},
						},
					},
					["last"] = 10429.583,
					["flag"] = 1298,
					["class"] = "PALADIN",
					["auras"] = {
						[2812] = {
							["type"] = "DEBUFF",
							["count"] = 5,
							["school"] = 2,
							["targets"] = {
								["Putridus Satyr"] = {
									["uptime"] = 3,
									["count"] = 1,
								},
								["Poison Sprite"] = {
									["uptime"] = 1,
									["count"] = 1,
								},
								["Putridus Trickster"] = {
									["uptime"] = 3,
									["count"] = 1,
								},
								["Corruptor"] = {
									["uptime"] = 2,
									["count"] = 2,
								},
							},
							["uptime"] = 3,
						},
						[89906] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 2,
							["refresh"] = 1,
							["uptime"] = 14,
						},
						[94686] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 1,
							["uptime"] = 9,
						},
					},
					["role"] = "DAMAGER",
					["time"] = 17.73,
					["totaldamagetaken"] = 1424,
					["damage"] = 5441,
					["overheal"] = 398,
					["overkill"] = 561,
					["damagetaken"] = 687,
					["id"] = "0x0000000000048007",
					["healspells"] = {
						[54172] = {
							["overheal"] = 398,
							["max"] = 28,
							["targets"] = {
								["Nianhong"] = {
									["overheal"] = 144,
									["amount"] = 0,
								},
								["Beardedrasta"] = {
									["overheal"] = 34,
									["amount"] = 51,
								},
								["Cat"] = {
									["overheal"] = 66,
									["amount"] = 0,
								},
								["Myrony"] = {
									["overheal"] = 49,
									["amount"] = 49,
								},
								["Consecration"] = {
									["overheal"] = 47,
									["amount"] = 0,
								},
								["Macius"] = {
									["overheal"] = 4,
									["amount"] = 112,
								},
								["Fragrance"] = {
									["overheal"] = 21,
									["amount"] = 0,
								},
								["Haagroon"] = {
									["overheal"] = 33,
									["amount"] = 101,
								},
							},
							["min"] = 11,
							["casts"] = 30,
							["count"] = 30,
							["amount"] = 313,
							["school"] = 2,
							["ishot"] = true,
						},
					},
					["damagetakenspells"] = {
						["Gouge"] = {
							["sources"] = {
								["Putridus Satyr"] = {
									["total"] = 14,
									["amount"] = 0,
								},
							},
							["total"] = 14,
							["count"] = 1,
							["amount"] = 0,
							["school"] = 1,
							["ABSORB"] = 1,
							["casts"] = 1,
							["id"] = 12540,
						},
						["Melee"] = {
							["DODGE"] = 1,
							["total"] = 1201,
							["hitmin"] = 152,
							["id"] = 6603,
							["hit"] = 3,
							["hitmax"] = 169,
							["sources"] = {
								["Putridus Satyr"] = {
									["total"] = 1201,
									["amount"] = 478,
								},
							},
							["count"] = 9,
							["ABSORB"] = 4,
							["school"] = 1,
							["amount"] = 478,
							["MISS"] = 1,
							["hitamount"] = 478,
						},
						["Sinister Strike"] = {
							["total"] = 209,
							["hitmin"] = 209,
							["id"] = 15667,
							["sources"] = {
								["Putridus Satyr"] = {
									["total"] = 209,
									["amount"] = 209,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 1,
							["hitmax"] = 209,
							["amount"] = 209,
							["hitamount"] = 209,
						},
					},
					["damagespells"] = {
						["Seal of Righteousness"] = {
							["total"] = 79,
							["hitmin"] = 26,
							["id"] = 25742,
							["targets"] = {
								["Putridus Satyr"] = {
									["total"] = 53,
									["amount"] = 53,
								},
								["Putridus Trickster"] = {
									["total"] = 26,
									["amount"] = 26,
								},
							},
							["casts"] = 1,
							["count"] = 3,
							["hit"] = 3,
							["school"] = 2,
							["hitmax"] = 27,
							["amount"] = 79,
							["hitamount"] = 79,
						},
						["Retribution Aura"] = {
							["total"] = 39,
							["hitmin"] = 13,
							["id"] = 7294,
							["targets"] = {
								["Putridus Satyr"] = {
									["total"] = 39,
									["amount"] = 39,
								},
							},
							["casts"] = 1,
							["count"] = 3,
							["hit"] = 3,
							["school"] = 2,
							["hitmax"] = 13,
							["amount"] = 39,
							["hitamount"] = 39,
						},
						["Crusader Strike"] = {
							["total"] = 318,
							["hitmin"] = 318,
							["id"] = 35395,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 318,
									["amount"] = 318,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 1,
							["hitmax"] = 318,
							["amount"] = 318,
							["hitamount"] = 318,
						},
						["Melee"] = {
							["total"] = 1316,
							["hitmin"] = 131,
							["criticalamount"] = 774,
							["id"] = 6603,
							["criticalmin"] = 360,
							["targets"] = {
								["Putridus Satyr"] = {
									["total"] = 760,
									["amount"] = 760,
								},
								["Putridus Trickster"] = {
									["total"] = 556,
									["amount"] = 556,
								},
							},
							["blocked"] = 56,
							["critical"] = 2,
							["criticalmax"] = 414,
							["count"] = 5,
							["hit"] = 3,
							["school"] = 1,
							["hitmax"] = 215,
							["amount"] = 1316,
							["hitamount"] = 542,
						},
						["Holy Wrath"] = {
							["total"] = 299,
							["hitmin"] = 46,
							["criticalamount"] = 69,
							["id"] = 2812,
							["criticalmin"] = 69,
							["targets"] = {
								["Putridus Satyr"] = {
									["total"] = 46,
									["amount"] = 46,
								},
								["Poison Sprite"] = {
									["total"] = 69,
									["amount"] = 69,
								},
								["Putridus Trickster"] = {
									["total"] = 46,
									["amount"] = 46,
								},
								["Corruptor"] = {
									["total"] = 138,
									["amount"] = 138,
								},
							},
							["criticalmax"] = 69,
							["critical"] = 1,
							["casts"] = 1,
							["count"] = 6,
							["hit"] = 5,
							["school"] = 2,
							["hitmax"] = 46,
							["amount"] = 299,
							["hitamount"] = 230,
						},
						["Divine Storm"] = {
							["DODGE"] = 1,
							["hitmin"] = 143,
							["criticalmin"] = 354,
							["targets"] = {
								["Putridus Satyr"] = {
									["total"] = 618,
									["amount"] = 618,
								},
								["Poison Sprite"] = {
									["total"] = 560,
									["overkill"] = 265,
									["amount"] = 560,
								},
								["Corruptor"] = {
									["total"] = 904,
									["overkill"] = 296,
									["amount"] = 904,
								},
								["Putridus Trickster"] = {
									["total"] = 397,
									["amount"] = 397,
								},
							},
							["amount"] = 2479,
							["total"] = 2479,
							["criticalamount"] = 1170,
							["id"] = 53385,
							["criticalmax"] = 420,
							["overkill"] = 561,
							["critical"] = 3,
							["casts"] = 2,
							["hitmax"] = 215,
							["hit"] = 7,
							["school"] = 1,
							["blocked"] = 60,
							["count"] = 11,
							["hitamount"] = 1309,
						},
						["Hand of Light"] = {
							["total"] = 12,
							["hitmin"] = 1,
							["id"] = 96172,
							["targets"] = {
								["Putridus Satyr"] = {
									["total"] = 3,
									["amount"] = 3,
								},
								["Poison Sprite"] = {
									["total"] = 2,
									["amount"] = 2,
								},
								["Corruptor"] = {
									["total"] = 4,
									["amount"] = 4,
								},
								["Putridus Trickster"] = {
									["total"] = 3,
									["amount"] = 3,
								},
							},
							["casts"] = 1,
							["count"] = 12,
							["hit"] = 12,
							["school"] = 2,
							["hitmax"] = 1,
							["amount"] = 12,
							["hitamount"] = 12,
						},
						["Templar's Verdict"] = {
							["total"] = 651,
							["hitmin"] = 651,
							["id"] = 85256,
							["targets"] = {
								["Putridus Satyr"] = {
									["total"] = 651,
									["amount"] = 651,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 1,
							["hitmax"] = 651,
							["amount"] = 651,
							["hitamount"] = 651,
						},
						["Judgement of Righteousness"] = {
							["total"] = 248,
							["hitmin"] = 124,
							["id"] = 20187,
							["targets"] = {
								["Putridus Satyr"] = {
									["total"] = 124,
									["amount"] = 124,
								},
								["Putridus Trickster"] = {
									["total"] = 124,
									["amount"] = 124,
								},
							},
							["casts"] = 2,
							["count"] = 2,
							["hit"] = 2,
							["school"] = 2,
							["hitmax"] = 124,
							["amount"] = 248,
							["hitamount"] = 248,
						},
					},
					["heal"] = 313,
					["manaspells"] = {
						[89906] = 345,
					},
					["ccdone"] = 5,
					["mana"] = 345,
					["totaldamage"] = 5441,
					["name"] = "Fragrance",
				}, -- [1]
				{
					["overheal"] = 640,
					["last"] = 10427.806,
					["absorb"] = 1715,
					["flag"] = 1298,
					["class"] = "PRIEST",
					["healspells"] = {
						[63544] = {
							["overheal"] = 0,
							["count"] = 1,
							["amount"] = 70,
							["school"] = 2,
							["max"] = 70,
							["targets"] = {
								["Myrony"] = {
									["overheal"] = 0,
									["amount"] = 70,
								},
							},
							["min"] = 70,
						},
						[139] = {
							["overheal"] = 640,
							["max"] = 177,
							["targets"] = {
								["Fragrance"] = {
									["overheal"] = 256,
									["amount"] = 0,
								},
								["Myrony"] = {
									["overheal"] = 384,
									["amount"] = 324,
								},
							},
							["min"] = 9,
							["casts"] = 2,
							["count"] = 6,
							["amount"] = 324,
							["school"] = 2,
							["ishot"] = true,
						},
						[56160] = {
							["overheal"] = 0,
							["count"] = 1,
							["amount"] = 248,
							["school"] = 2,
							["max"] = 248,
							["targets"] = {
								["Myrony"] = {
									["overheal"] = 0,
									["amount"] = 248,
								},
							},
							["min"] = 248,
						},
					},
					["auras"] = {
						[6788] = {
							["type"] = "DEBUFF",
							["count"] = 1,
							["school"] = 2,
							["targets"] = {
								["Myrony"] = {
									["uptime"] = 2,
									["count"] = 1,
								},
							},
							["uptime"] = 2,
						},
					},
					["absorbspells"] = {
						[17] = {
							["min"] = 9,
							["casts"] = 1,
							["count"] = 12,
							["amount"] = 1715,
							["max"] = 203,
							["targets"] = {
								["Fragrance"] = 737,
								["Myrony"] = 978,
							},
							["school"] = 2,
						},
					},
					["role"] = "HEALER",
					["name"] = "Nianhong",
					["heal"] = 642,
					["time"] = 14.96,
					["id"] = "0x00000000000467C0",
				}, -- [2]
				{
					["last"] = 10427.667,
					["flag"] = 1298,
					["class"] = "PALADIN",
					["auras"] = {
						[26573] = {
							["type"] = "DEBUFF",
							["count"] = 3,
							["school"] = 2,
							["targets"] = {
								["Corruptor"] = {
									["uptime"] = 17,
									["count"] = 2,
								},
								["Myrony"] = {
									["uptime"] = 10,
									["count"] = 1,
								},
							},
							["uptime"] = 17,
						},
						[17] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 2,
							["uptime"] = 6,
						},
						[139] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 2,
							["uptime"] = 12,
						},
						[31930] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 2,
							["uptime"] = 10,
						},
					},
					["totaldamage"] = 3729,
					["time"] = 14.39,
					["totaldamagetaken"] = 2162,
					["damage"] = 3729,
					["damagespells"] = {
						["Melee"] = {
							["total"] = 1010,
							["hitmin"] = 118,
							["criticalamount"] = 258,
							["id"] = 6603,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 1010,
									["amount"] = 1010,
								},
							},
							["criticalmin"] = 258,
							["critical"] = 1,
							["criticalmax"] = 258,
							["count"] = 7,
							["hit"] = 6,
							["school"] = 1,
							["hitmax"] = 136,
							["amount"] = 1010,
							["hitamount"] = 752,
						},
						["Hammer of the Righteous (Physical)"] = {
							["total"] = 33,
							["hitmin"] = 33,
							["id"] = 53595,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 33,
									["amount"] = 33,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 1,
							["hitmax"] = 33,
							["amount"] = 33,
							["hitamount"] = 33,
						},
						["Retribution Aura"] = {
							["total"] = 91,
							["hitmin"] = 13,
							["id"] = 7294,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 52,
									["amount"] = 52,
								},
								["Corruptor"] = {
									["total"] = 39,
									["amount"] = 39,
								},
							},
							["casts"] = 1,
							["count"] = 7,
							["hit"] = 7,
							["school"] = 2,
							["hitmax"] = 13,
							["amount"] = 91,
							["hitamount"] = 91,
						},
						["Hammer of the Righteous"] = {
							["total"] = 323,
							["hitmin"] = 158,
							["id"] = 88263,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 165,
									["amount"] = 165,
								},
								["Putridus Satyr"] = {
									["total"] = 158,
									["amount"] = 158,
								},
							},
							["casts"] = 1,
							["count"] = 2,
							["hit"] = 2,
							["school"] = 2,
							["hitmax"] = 165,
							["amount"] = 323,
							["hitamount"] = 323,
						},
						["Consecration"] = {
							["total"] = 1432,
							["hitmin"] = 26,
							["criticalamount"] = 84,
							["id"] = 81297,
							["criticalmin"] = 42,
							["targets"] = {
								["Putridus Satyr"] = {
									["total"] = 280,
									["amount"] = 280,
								},
								["Poison Sprite"] = {
									["total"] = 206,
									["amount"] = 206,
								},
								["Putridus Trickster"] = {
									["total"] = 292,
									["amount"] = 292,
								},
								["Corruptor"] = {
									["total"] = 654,
									["amount"] = 654,
								},
							},
							["criticalmax"] = 42,
							["critical"] = 2,
							["casts"] = 1,
							["count"] = 48,
							["hit"] = 46,
							["school"] = 2,
							["hitmax"] = 30,
							["amount"] = 1432,
							["hitamount"] = 1348,
						},
						["Crusader Strike"] = {
							["total"] = 672,
							["hitmin"] = 212,
							["id"] = 35395,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 672,
									["amount"] = 672,
								},
							},
							["casts"] = 3,
							["count"] = 3,
							["hit"] = 3,
							["school"] = 1,
							["hitmax"] = 239,
							["amount"] = 672,
							["hitamount"] = 672,
						},
						["Seal of Righteousness"] = {
							["total"] = 168,
							["hitmin"] = 18,
							["id"] = 25742,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 168,
									["amount"] = 168,
								},
							},
							["casts"] = 1,
							["count"] = 8,
							["hit"] = 8,
							["school"] = 2,
							["hitmax"] = 22,
							["amount"] = 168,
							["hitamount"] = 168,
						},
					},
					["damagetaken"] = 1184,
					["id"] = "0x00000000000447DB",
					["healspells"] = {
						[85673] = {
							["overheal"] = 1046,
							["criticalamount"] = 634,
							["max"] = 634,
							["targets"] = {
								["Myrony"] = {
									["overheal"] = 1046,
									["amount"] = 634,
								},
							},
							["min"] = 634,
							["criticalmax"] = 634,
							["critical"] = 1,
							["amount"] = 634,
							["school"] = 2,
							["criticalmin"] = 634,
							["count"] = 1,
						},
					},
					["damagetakenspells"] = {
						["Poison (DoT)"] = {
							["total"] = 35,
							["hitmin"] = 8,
							["id"] = 13298,
							["amount"] = 26,
							["hitmax"] = 9,
							["sources"] = {
								["Putridus Trickster"] = {
									["total"] = 35,
									["amount"] = 26,
								},
							},
							["count"] = 4,
							["ABSORB"] = 1,
							["school"] = 8,
							["resisted"] = 4,
							["hit"] = 3,
							["hitamount"] = 26,
						},
						["Melee"] = {
							["total"] = 2127,
							["hitmin"] = 122,
							["id"] = 6603,
							["ABSORB"] = 5,
							["blocked"] = 52,
							["PARRY"] = 5,
							["amount"] = 1158,
							["sources"] = {
								["Putridus Trickster"] = {
									["total"] = 1003,
									["amount"] = 635,
								},
								["Corruptor"] = {
									["total"] = 1124,
									["amount"] = 523,
								},
							},
							["count"] = 21,
							["hit"] = 7,
							["school"] = 1,
							["hitmax"] = 203,
							["MISS"] = 4,
							["hitamount"] = 1158,
						},
					},
					["overheal"] = 1046,
					["heal"] = 634,
					["name"] = "Myrony",
					["manaspells"] = {
						[84627] = 270,
						[31930] = 290,
					},
					["mana"] = 560,
					["role"] = "TANK",
				}, -- [3]
				{
					["damagespells"] = {
						["Steady Shot"] = {
							["total"] = 356,
							["hitmin"] = 87,
							["id"] = 56641,
							["targets"] = {
								["Putridus Satyr"] = {
									["total"] = 269,
									["amount"] = 269,
								},
								["Putridus Trickster"] = {
									["total"] = 87,
									["amount"] = 87,
								},
							},
							["casts"] = 4,
							["count"] = 4,
							["hit"] = 4,
							["school"] = 1,
							["hitmax"] = 94,
							["amount"] = 356,
							["hitamount"] = 356,
						},
						["Auto Shot"] = {
							["total"] = 692,
							["hitmin"] = 86,
							["id"] = 75,
							["targets"] = {
								["Putridus Trickster"] = {
									["total"] = 193,
									["overkill"] = 63,
									["amount"] = 193,
								},
								["Putridus Satyr"] = {
									["total"] = 400,
									["amount"] = 400,
								},
								["Corruptor"] = {
									["total"] = 99,
									["amount"] = 99,
								},
							},
							["overkill"] = 63,
							["casts"] = 1,
							["count"] = 7,
							["hit"] = 7,
							["school"] = 1,
							["hitmax"] = 107,
							["amount"] = 692,
							["hitamount"] = 692,
						},
						["Claw (Cat)"] = {
							["total"] = 254,
							["hitmin"] = 84,
							["id"] = 16827,
							["targets"] = {
								["Putridus Satyr"] = {
									["total"] = 170,
									["amount"] = 170,
								},
								["Putridus Trickster"] = {
									["total"] = 84,
									["amount"] = 84,
								},
							},
							["casts"] = 3,
							["count"] = 3,
							["hit"] = 3,
							["school"] = 1,
							["hitmax"] = 86,
							["amount"] = 254,
							["hitamount"] = 254,
						},
						["Melee (Cat)"] = {
							["total"] = 223,
							["hitmin"] = 55,
							["id"] = 6603,
							["targets"] = {
								["Putridus Satyr"] = {
									["total"] = 168,
									["amount"] = 168,
								},
								["Putridus Trickster"] = {
									["total"] = 55,
									["amount"] = 55,
								},
							},
							["glancing"] = 1,
							["amount"] = 223,
							["count"] = 5,
							["hit"] = 3,
							["school"] = 1,
							["hitmax"] = 63,
							["MISS"] = 1,
							["hitamount"] = 174,
						},
						["Multi-Shot"] = {
							["total"] = 824,
							["hitmin"] = 84,
							["id"] = 2643,
							["targets"] = {
								["Putridus Satyr"] = {
									["total"] = 184,
									["amount"] = 184,
								},
								["Poison Sprite"] = {
									["total"] = 97,
									["amount"] = 97,
								},
								["Corruptor"] = {
									["total"] = 355,
									["amount"] = 355,
								},
								["Putridus Trickster"] = {
									["total"] = 188,
									["amount"] = 188,
								},
							},
							["casts"] = 2,
							["count"] = 9,
							["hit"] = 9,
							["school"] = 1,
							["hitmax"] = 98,
							["amount"] = 824,
							["hitamount"] = 824,
						},
						["Arcane Shot"] = {
							["total"] = 144,
							["hitmin"] = 144,
							["id"] = 3044,
							["targets"] = {
								["Putridus Satyr"] = {
									["total"] = 144,
									["overkill"] = 106,
									["amount"] = 144,
								},
							},
							["overkill"] = 106,
							["casts"] = 1,
							["count"] = 1,
							["amount"] = 144,
							["school"] = 64,
							["hitmax"] = 144,
							["hit"] = 1,
							["hitamount"] = 144,
						},
					},
					["last"] = 10430.728,
					["flag"] = 1298,
					["id"] = "0x00000000000477A3",
					["class"] = "HUNTER",
					["time"] = 15.95,
					["overkill"] = 169,
					["energyspells"] = {
						[91954] = 45,
					},
					["name"] = "Macius",
					["totaldamage"] = 2493,
					["role"] = "DAMAGER",
					["energy"] = 45,
					["damage"] = 2493,
				}, -- [4]
				{
					["last"] = 10415.052,
					["name"] = "Haagroon",
					["flag"] = 4369,
					["class"] = "PET",
					["id"] = "0xF143011D00000005",
					["time"] = 0,
				}, -- [5]
				{
					["last"] = 10424.229,
					["flag"] = 1297,
					["class"] = "WARLOCK",
					["auras"] = {
						[5740] = {
							["type"] = "BUFF",
							["count"] = 7,
							["school"] = 4,
							["targets"] = {
								["Putridus Satyr"] = {
									["uptime"] = 8,
									["count"] = 1,
								},
								["Poison Sprite"] = {
									["uptime"] = 5,
									["count"] = 1,
								},
								["Corruptor"] = {
									["uptime"] = 6,
									["count"] = 3,
								},
								["Putridus Trickster"] = {
									["uptime"] = 8,
									["count"] = 1,
								},
							},
							["uptime"] = 8,
						},
					},
					["time"] = 9.18,
					["damage"] = 1544,
					["damagespells"] = {
						["Shadow Bite (Haagroon)"] = {
							["total"] = 83,
							["hitmin"] = 83,
							["id"] = 54049,
							["targets"] = {
								["Putridus Satyr"] = {
									["total"] = 83,
									["amount"] = 83,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 32,
							["hitmax"] = 83,
							["amount"] = 83,
							["hitamount"] = 83,
						},
						["Melee (Haagroon)"] = {
							["total"] = 68,
							["hitmin"] = 68,
							["id"] = 6603,
							["targets"] = {
								["Putridus Satyr"] = {
									["total"] = 68,
									["amount"] = 68,
								},
							},
							["count"] = 1,
							["hit"] = 1,
							["school"] = 1,
							["hitmax"] = 68,
							["amount"] = 68,
							["hitamount"] = 68,
						},
						["Rain of Fire"] = {
							["hitmin"] = 82,
							["criticalmin"] = 163,
							["targets"] = {
								["Putridus Satyr"] = {
									["total"] = 328,
									["amount"] = 328,
								},
								["Poison Sprite"] = {
									["total"] = 164,
									["amount"] = 164,
								},
								["Putridus Trickster"] = {
									["total"] = 246,
									["amount"] = 246,
								},
								["Corruptor"] = {
									["total"] = 655,
									["overkill"] = 53,
									["amount"] = 655,
								},
							},
							["amount"] = 1393,
							["MISS"] = 1,
							["total"] = 1393,
							["criticalamount"] = 163,
							["id"] = 42223,
							["overkill"] = 53,
							["criticalmax"] = 163,
							["casts"] = 1,
							["count"] = 17,
							["hit"] = 15,
							["school"] = 4,
							["critical"] = 1,
							["hitmax"] = 82,
							["hitamount"] = 1230,
						},
					},
					["id"] = "0x000000000004825C",
					["spec"] = 265,
					["overkill"] = 53,
					["name"] = "Beardedrasta",
					["manaspells"] = {
						[31818] = 578,
					},
					["mana"] = 578,
					["totaldamage"] = 1544,
					["role"] = "DAMAGER",
				}, -- [6]
				{
					["last"] = 10415.052,
					["name"] = "Cat",
					["flag"] = 4370,
					["class"] = "PET",
					["id"] = "0xF142F90400000004",
					["time"] = 0,
				}, -- [7]
				{
					["last"] = 10421.478,
					["name"] = "Consecration",
					["flag"] = 4370,
					["class"] = "PET",
					["id"] = "0xF130A9EB00000144",
					["time"] = 0,
				}, -- [8]
			},
			["type"] = "party",
			["damagetaken"] = 1871,
			["etotaldamage"] = 3586,
			["energy"] = 45,
			["absorb"] = 1715,
			["overkill"] = 783,
			["edamagetaken"] = 13207,
			["heal"] = 1589,
			["name"] = "Corruptor",
			["mobname"] = "Corruptor",
			["starttime"] = 1689857280,
			["edamage"] = 1871,
			["last_action"] = 1689857299,
			["endtime"] = 1689857299,
		}, -- [11]
		{
			["mana"] = 1085,
			["enemies"] = {
				{
					["id"] = "0xF1303355000000C0",
					["name"] = "Deeprot Stomper",
					["totaldamagetaken"] = 2252,
					["flag"] = 68168,
					["class"] = "MONSTER",
					["damagetaken"] = 2252,
					["damagetakenspells"] = {
						[6603] = {
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 181,
									["overkill"] = 126,
									["amount"] = 181,
								},
								["Macius"] = {
									["total"] = 147,
									["amount"] = 147,
								},
								["Fragrance"] = {
									["total"] = 184,
									["amount"] = 184,
								},
								["Myrony"] = {
									["total"] = 104,
									["amount"] = 104,
								},
							},
							["amount"] = 616,
							["school"] = 1,
							["total"] = 616,
							["overkill"] = 126,
						},
						[56641] = {
							["school"] = 1,
							["total"] = 177,
							["sources"] = {
								["Macius"] = {
									["total"] = 177,
									["amount"] = 177,
								},
							},
							["amount"] = 177,
						},
						[35395] = {
							["school"] = 1,
							["total"] = 221,
							["sources"] = {
								["Myrony"] = {
									["total"] = 221,
									["amount"] = 221,
								},
							},
							["amount"] = 221,
						},
						[879] = {
							["school"] = 2,
							["total"] = 707,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 707,
									["amount"] = 707,
								},
							},
							["amount"] = 707,
						},
						[25742] = {
							["school"] = 2,
							["total"] = 44,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 26,
									["amount"] = 26,
								},
								["Myrony"] = {
									["total"] = 18,
									["amount"] = 18,
								},
							},
							["amount"] = 44,
						},
						[54049] = {
							["school"] = 32,
							["total"] = 105,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 105,
									["amount"] = 105,
								},
							},
							["amount"] = 105,
						},
						[75] = {
							["school"] = 1,
							["total"] = 87,
							["sources"] = {
								["Macius"] = {
									["total"] = 87,
									["amount"] = 87,
								},
							},
							["amount"] = 87,
						},
						[20187] = {
							["school"] = 2,
							["total"] = 124,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 124,
									["amount"] = 124,
								},
							},
							["amount"] = 124,
						},
						[16827] = {
							["school"] = 1,
							["total"] = 171,
							["sources"] = {
								["Macius"] = {
									["total"] = 171,
									["amount"] = 171,
								},
							},
							["amount"] = 171,
						},
					},
				}, -- [1]
				{
					["damagespells"] = {
						[6603] = {
							["school"] = 1,
							["total"] = 684,
							["targets"] = {
								["Myrony"] = {
									["total"] = 489,
									["amount"] = 489,
								},
								["Beardedrasta"] = {
									["total"] = 195,
									["amount"] = 195,
								},
							},
							["amount"] = 684,
						},
					},
					["damagetaken"] = 4698,
					["flag"] = 2632,
					["class"] = "MONSTER",
					["damagetakenspells"] = {
						[75] = {
							["school"] = 1,
							["total"] = 274,
							["sources"] = {
								["Macius"] = {
									["total"] = 274,
									["amount"] = 274,
								},
							},
							["amount"] = 274,
						},
						[2643] = {
							["school"] = 1,
							["total"] = 198,
							["sources"] = {
								["Macius"] = {
									["total"] = 198,
									["amount"] = 198,
								},
							},
							["amount"] = 198,
						},
						[6603] = {
							["sources"] = {
								["Macius"] = {
									["total"] = 268,
									["amount"] = 268,
								},
								["Beardedrasta"] = {
									["total"] = 302,
									["amount"] = 302,
								},
								["Fragrance"] = {
									["total"] = 583,
									["amount"] = 583,
								},
								["Myrony"] = {
									["total"] = 229,
									["overkill"] = 46,
									["amount"] = 229,
								},
							},
							["amount"] = 1382,
							["school"] = 1,
							["total"] = 1382,
							["overkill"] = 46,
						},
						[7294] = {
							["school"] = 2,
							["total"] = 52,
							["sources"] = {
								["Myrony"] = {
									["total"] = 39,
									["amount"] = 39,
								},
								["Beardedrasta"] = {
									["total"] = 13,
									["amount"] = 13,
								},
							},
							["amount"] = 52,
						},
						[16827] = {
							["school"] = 1,
							["total"] = 168,
							["sources"] = {
								["Macius"] = {
									["total"] = 168,
									["amount"] = 168,
								},
							},
							["amount"] = 168,
						},
						[54049] = {
							["school"] = 32,
							["total"] = 153,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 153,
									["amount"] = 153,
								},
							},
							["amount"] = 153,
						},
						[980] = {
							["school"] = 32,
							["total"] = 84,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 84,
									["amount"] = 84,
								},
							},
							["amount"] = 84,
						},
						[35395] = {
							["school"] = 1,
							["total"] = 821,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 604,
									["amount"] = 604,
								},
								["Myrony"] = {
									["total"] = 217,
									["amount"] = 217,
								},
							},
							["amount"] = 821,
						},
						[879] = {
							["school"] = 2,
							["total"] = 600,
							["sources"] = {
								["Myrony"] = {
									["total"] = 600,
									["amount"] = 600,
								},
							},
							["amount"] = 600,
						},
						[25742] = {
							["school"] = 2,
							["total"] = 115,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 78,
									["amount"] = 78,
								},
								["Myrony"] = {
									["total"] = 37,
									["amount"] = 37,
								},
							},
							["amount"] = 115,
						},
						[96172] = {
							["school"] = 2,
							["total"] = 2,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 2,
									["amount"] = 2,
								},
							},
							["amount"] = 2,
						},
						[3044] = {
							["school"] = 64,
							["total"] = 135,
							["sources"] = {
								["Macius"] = {
									["total"] = 135,
									["amount"] = 135,
								},
							},
							["amount"] = 135,
						},
						[2812] = {
							["school"] = 2,
							["total"] = 92,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 92,
									["amount"] = 92,
								},
							},
							["amount"] = 92,
						},
						[30108] = {
							["school"] = 32,
							["total"] = 147,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 147,
									["amount"] = 147,
								},
							},
							["amount"] = 147,
						},
						[56641] = {
							["school"] = 1,
							["total"] = 343,
							["sources"] = {
								["Macius"] = {
									["total"] = 343,
									["amount"] = 343,
								},
							},
							["amount"] = 343,
						},
						[172] = {
							["school"] = 32,
							["total"] = 132,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 132,
									["amount"] = 132,
								},
							},
							["amount"] = 132,
						},
					},
					["name"] = "Putridus Shadowstalker",
					["totaldamage"] = 684,
					["totaldamagetaken"] = 4698,
					["id"] = "0xF1302E10000000BF",
					["damage"] = 684,
				}, -- [2]
				{
					["damagespells"] = {
						[6603] = {
							["school"] = 1,
							["total"] = 351,
							["targets"] = {
								["Myrony"] = {
									["total"] = 163,
									["amount"] = 163,
								},
								["Macius"] = {
									["total"] = 188,
									["amount"] = 188,
								},
							},
							["amount"] = 351,
						},
					},
					["damagetaken"] = 875,
					["flag"] = 2632,
					["class"] = "MONSTER",
					["damagetakenspells"] = {
						[6603] = {
							["school"] = 1,
							["total"] = 90,
							["sources"] = {
								["Myrony"] = {
									["total"] = 90,
									["amount"] = 90,
								},
							},
							["amount"] = 90,
						},
						[2812] = {
							["sources"] = {
								["Fragrance"] = {
									["total"] = 92,
									["overkill"] = 42,
									["amount"] = 92,
								},
							},
							["amount"] = 92,
							["school"] = 2,
							["total"] = 92,
							["overkill"] = 42,
						},
						[35395] = {
							["school"] = 1,
							["total"] = 200,
							["sources"] = {
								["Myrony"] = {
									["total"] = 200,
									["amount"] = 200,
								},
							},
							["amount"] = 200,
						},
						[25742] = {
							["school"] = 2,
							["total"] = 18,
							["sources"] = {
								["Myrony"] = {
									["total"] = 18,
									["amount"] = 18,
								},
							},
							["amount"] = 18,
						},
						[2643] = {
							["school"] = 1,
							["total"] = 182,
							["sources"] = {
								["Macius"] = {
									["total"] = 182,
									["amount"] = 182,
								},
							},
							["amount"] = 182,
						},
						[7294] = {
							["school"] = 2,
							["total"] = 26,
							["sources"] = {
								["Myrony"] = {
									["total"] = 13,
									["amount"] = 13,
								},
								["Macius"] = {
									["total"] = 13,
									["amount"] = 13,
								},
							},
							["amount"] = 26,
						},
						[56641] = {
							["school"] = 1,
							["total"] = 86,
							["sources"] = {
								["Macius"] = {
									["total"] = 86,
									["amount"] = 86,
								},
							},
							["amount"] = 86,
						},
						[20187] = {
							["school"] = 2,
							["total"] = 181,
							["sources"] = {
								["Myrony"] = {
									["total"] = 181,
									["amount"] = 181,
								},
							},
							["amount"] = 181,
						},
					},
					["name"] = "Corruptor",
					["totaldamage"] = 351,
					["totaldamagetaken"] = 875,
					["id"] = "0xF1302FB9000000BC",
					["damage"] = 351,
				}, -- [3]
				{
					["damagespells"] = {
						[6603] = {
							["school"] = 1,
							["total"] = 739,
							["targets"] = {
								["Fragrance"] = {
									["total"] = 739,
									["amount"] = 739,
								},
							},
							["amount"] = 739,
						},
					},
					["damagetaken"] = 3469,
					["flag"] = 2632,
					["class"] = "MONSTER",
					["damagetakenspells"] = {
						[31935] = {
							["sources"] = {
								["Myrony"] = {
									["total"] = 987,
									["overkill"] = 575,
									["amount"] = 987,
								},
							},
							["amount"] = 987,
							["school"] = 2,
							["total"] = 987,
							["overkill"] = 575,
						},
						[53385] = {
							["school"] = 1,
							["total"] = 364,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 364,
									["amount"] = 364,
								},
							},
							["amount"] = 364,
						},
						[7294] = {
							["school"] = 2,
							["total"] = 39,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 39,
									["amount"] = 39,
								},
							},
							["amount"] = 39,
						},
						[2643] = {
							["school"] = 1,
							["total"] = 183,
							["sources"] = {
								["Macius"] = {
									["total"] = 183,
									["amount"] = 183,
								},
							},
							["amount"] = 183,
						},
						[35395] = {
							["sources"] = {
								["Myrony"] = {
									["total"] = 249,
									["overkill"] = 171,
									["amount"] = 249,
								},
							},
							["amount"] = 249,
							["school"] = 1,
							["total"] = 249,
							["overkill"] = 171,
						},
						[879] = {
							["sources"] = {
								["Fragrance"] = {
									["total"] = 1057,
									["overkill"] = 224,
									["amount"] = 1057,
								},
							},
							["amount"] = 1057,
							["school"] = 2,
							["total"] = 1057,
							["overkill"] = 224,
						},
						[25742] = {
							["school"] = 2,
							["total"] = 38,
							["sources"] = {
								["Myrony"] = {
									["total"] = 38,
									["amount"] = 38,
								},
							},
							["amount"] = 38,
						},
						[96172] = {
							["school"] = 2,
							["total"] = 2,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 2,
									["amount"] = 2,
								},
							},
							["amount"] = 2,
						},
						[2812] = {
							["school"] = 2,
							["total"] = 92,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 92,
									["amount"] = 92,
								},
							},
							["amount"] = 92,
						},
						[6603] = {
							["school"] = 1,
							["total"] = 334,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 215,
									["amount"] = 215,
								},
								["Myrony"] = {
									["total"] = 119,
									["amount"] = 119,
								},
							},
							["amount"] = 334,
						},
						[20187] = {
							["school"] = 2,
							["total"] = 124,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 124,
									["amount"] = 124,
								},
							},
							["amount"] = 124,
						},
					},
					["name"] = "Poison Sprite",
					["totaldamage"] = 739,
					["totaldamagetaken"] = 3469,
					["id"] = "0xF1302FB8000000C2",
					["damage"] = 739,
				}, -- [4]
			},
			["starttime"] = 1689857257,
			["totaldamage"] = 11294,
			["time"] = 18,
			["totaldamagetaken"] = 1774,
			["etotaldamagetaken"] = 11294,
			["damage"] = 11294,
			["players"] = {
				{
					["ccdonespells"] = {
						[31935] = {
							["count"] = 1,
							["targets"] = {
								["Poison Sprite"] = 1,
							},
						},
					},
					["last"] = 10406.781,
					["flag"] = 1298,
					["class"] = "PALADIN",
					["auras"] = {
						[68055] = {
							["type"] = "DEBUFF",
							["count"] = 1,
							["school"] = 2,
							["targets"] = {
								["Corruptor"] = {
									["uptime"] = 5,
									["count"] = 1,
								},
							},
							["uptime"] = 5,
						},
						[31935] = {
							["type"] = "DEBUFF",
							["count"] = 1,
							["school"] = 2,
							["targets"] = {
								["Poison Sprite"] = {
									["uptime"] = 1,
									["count"] = 1,
								},
							},
							["uptime"] = 1,
						},
						[31930] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 2,
							["uptime"] = 8,
						},
						[139] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 2,
							["uptime"] = 12,
						},
					},
					["totaldamage"] = 3360,
					["time"] = 17.34,
					["totaldamagetaken"] = 652,
					["damage"] = 3360,
					["damagespells"] = {
						["Exorcism"] = {
							["total"] = 600,
							["criticalamount"] = 600,
							["id"] = 879,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 600,
									["amount"] = 600,
								},
							},
							["casts"] = 1,
							["critical"] = 1,
							["amount"] = 600,
							["school"] = 2,
							["criticalmin"] = 600,
							["criticalmax"] = 600,
							["count"] = 1,
						},
						["Melee"] = {
							["total"] = 542,
							["hitmin"] = 90,
							["id"] = 6603,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 104,
									["amount"] = 104,
								},
								["Poison Sprite"] = {
									["total"] = 119,
									["amount"] = 119,
								},
								["Putridus Shadowstalker"] = {
									["total"] = 229,
									["overkill"] = 46,
									["amount"] = 229,
								},
								["Corruptor"] = {
									["total"] = 90,
									["amount"] = 90,
								},
							},
							["overkill"] = 46,
							["count"] = 5,
							["hit"] = 5,
							["school"] = 1,
							["hitmax"] = 119,
							["amount"] = 542,
							["hitamount"] = 542,
						},
						["Avenger's Shield"] = {
							["hitmax"] = 353,
							["total"] = 987,
							["hitmin"] = 353,
							["criticalamount"] = 634,
							["id"] = 31935,
							["critical"] = 1,
							["targets"] = {
								["Poison Sprite"] = {
									["total"] = 987,
									["overkill"] = 575,
									["amount"] = 987,
								},
							},
							["overkill"] = 575,
							["hit"] = 1,
							["casts"] = 1,
							["count"] = 2,
							["amount"] = 987,
							["school"] = 2,
							["criticalmin"] = 634,
							["criticalmax"] = 634,
							["hitamount"] = 353,
						},
						["Seal of Righteousness"] = {
							["total"] = 111,
							["hitmin"] = 18,
							["id"] = 25742,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 18,
									["amount"] = 18,
								},
								["Poison Sprite"] = {
									["total"] = 38,
									["amount"] = 38,
								},
								["Putridus Shadowstalker"] = {
									["total"] = 37,
									["amount"] = 37,
								},
								["Corruptor"] = {
									["total"] = 18,
									["amount"] = 18,
								},
							},
							["casts"] = 1,
							["count"] = 6,
							["hit"] = 6,
							["school"] = 2,
							["hitmax"] = 19,
							["amount"] = 111,
							["hitamount"] = 111,
						},
						["Crusader Strike"] = {
							["total"] = 887,
							["hitmin"] = 200,
							["id"] = 35395,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 221,
									["amount"] = 221,
								},
								["Poison Sprite"] = {
									["total"] = 249,
									["overkill"] = 171,
									["amount"] = 249,
								},
								["Putridus Shadowstalker"] = {
									["total"] = 217,
									["amount"] = 217,
								},
								["Corruptor"] = {
									["total"] = 200,
									["amount"] = 200,
								},
							},
							["overkill"] = 171,
							["casts"] = 4,
							["count"] = 4,
							["hit"] = 4,
							["school"] = 1,
							["hitmax"] = 249,
							["amount"] = 887,
							["hitamount"] = 887,
						},
						["Retribution Aura"] = {
							["total"] = 52,
							["hitmin"] = 13,
							["id"] = 7294,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 39,
									["amount"] = 39,
								},
								["Corruptor"] = {
									["total"] = 13,
									["amount"] = 13,
								},
							},
							["casts"] = 1,
							["count"] = 4,
							["hit"] = 4,
							["school"] = 2,
							["hitmax"] = 13,
							["amount"] = 52,
							["hitamount"] = 52,
						},
						["Judgement of Righteousness"] = {
							["total"] = 181,
							["hitmin"] = 181,
							["id"] = 20187,
							["targets"] = {
								["Corruptor"] = {
									["total"] = 181,
									["amount"] = 181,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 2,
							["hitmax"] = 181,
							["amount"] = 181,
							["hitamount"] = 181,
						},
					},
					["damagetaken"] = 652,
					["id"] = "0x00000000000447DB",
					["damagetakenspells"] = {
						["Melee"] = {
							["DODGE"] = 1,
							["total"] = 652,
							["hitmin"] = 122,
							["id"] = 6603,
							["blocked"] = 51,
							["hitmax"] = 210,
							["sources"] = {
								["Deeprot Stomper"] = {
									["total"] = 0,
									["amount"] = 0,
								},
								["Putridus Shadowstalker"] = {
									["total"] = 489,
									["amount"] = 489,
								},
								["Corruptor"] = {
									["total"] = 163,
									["amount"] = 163,
								},
							},
							["count"] = 7,
							["amount"] = 652,
							["school"] = 1,
							["PARRY"] = 2,
							["hit"] = 4,
							["hitamount"] = 652,
						},
					},
					["overkill"] = 792,
					["name"] = "Myrony",
					["ccdone"] = 1,
					["mana"] = 763,
					["role"] = "TANK",
					["manaspells"] = {
						[31930] = 493,
						[84627] = 270,
					},
				}, -- [1]
				{
					["last"] = 10406.619,
					["flag"] = 4370,
					["class"] = "HUNTER",
					["energyspells"] = {
						[91954] = 54,
					},
					["totaldamage"] = 2432,
					["time"] = 17.19,
					["totaldamagetaken"] = 188,
					["damage"] = 2432,
					["damagespells"] = {
						["Steady Shot"] = {
							["total"] = 606,
							["hitmin"] = 83,
							["criticalamount"] = 170,
							["id"] = 56641,
							["criticalmin"] = 170,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 177,
									["amount"] = 177,
								},
								["Corruptor"] = {
									["total"] = 86,
									["amount"] = 86,
								},
								["Putridus Shadowstalker"] = {
									["total"] = 343,
									["amount"] = 343,
								},
							},
							["criticalmax"] = 170,
							["critical"] = 1,
							["casts"] = 6,
							["count"] = 6,
							["hit"] = 5,
							["school"] = 1,
							["hitmax"] = 91,
							["amount"] = 606,
							["hitamount"] = 436,
						},
						["Claw (Cat)"] = {
							["total"] = 339,
							["hitmin"] = 84,
							["id"] = 16827,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 171,
									["amount"] = 171,
								},
								["Putridus Shadowstalker"] = {
									["total"] = 168,
									["amount"] = 168,
								},
							},
							["amount"] = 339,
							["casts"] = 5,
							["count"] = 5,
							["hit"] = 4,
							["school"] = 1,
							["hitmax"] = 86,
							["MISS"] = 1,
							["hitamount"] = 339,
						},
						["Multi-Shot"] = {
							["total"] = 563,
							["hitmin"] = 82,
							["id"] = 2643,
							["targets"] = {
								["Poison Sprite"] = {
									["total"] = 183,
									["amount"] = 183,
								},
								["Corruptor"] = {
									["total"] = 182,
									["amount"] = 182,
								},
								["Putridus Shadowstalker"] = {
									["total"] = 198,
									["amount"] = 198,
								},
							},
							["casts"] = 2,
							["count"] = 6,
							["hit"] = 6,
							["school"] = 1,
							["hitmax"] = 100,
							["amount"] = 563,
							["hitamount"] = 563,
						},
						["Auto Shot"] = {
							["total"] = 361,
							["hitmin"] = 87,
							["id"] = 75,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 87,
									["amount"] = 87,
								},
								["Putridus Shadowstalker"] = {
									["total"] = 274,
									["amount"] = 274,
								},
							},
							["hitmax"] = 96,
							["casts"] = 1,
							["count"] = 5,
							["amount"] = 361,
							["school"] = 1,
							["hit"] = 4,
							["MISS"] = 1,
							["hitamount"] = 361,
						},
						["Retribution Aura"] = {
							["total"] = 13,
							["hitmin"] = 13,
							["id"] = 7294,
							["targets"] = {
								["Corruptor"] = {
									["total"] = 13,
									["amount"] = 13,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 2,
							["hitmax"] = 13,
							["amount"] = 13,
							["hitamount"] = 13,
						},
						["Melee (Cat)"] = {
							["amount"] = 415,
							["total"] = 415,
							["hitmin"] = 49,
							["criticalamount"] = 218,
							["id"] = 6603,
							["critical"] = 2,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 147,
									["amount"] = 147,
								},
								["Putridus Shadowstalker"] = {
									["total"] = 268,
									["amount"] = 268,
								},
							},
							["criticalmin"] = 98,
							["glancing"] = 2,
							["criticalmax"] = 120,
							["count"] = 9,
							["hit"] = 2,
							["school"] = 1,
							["hitmax"] = 56,
							["MISS"] = 3,
							["hitamount"] = 105,
						},
						["Arcane Shot"] = {
							["total"] = 135,
							["hitmin"] = 135,
							["id"] = 3044,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 135,
									["amount"] = 135,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 64,
							["hitmax"] = 135,
							["amount"] = 135,
							["hitamount"] = 135,
						},
					},
					["damagetaken"] = 188,
					["id"] = "0x00000000000477A3",
					["damagetakenspells"] = {
						["Melee"] = {
							["total"] = 188,
							["hitmin"] = 188,
							["id"] = 6603,
							["sources"] = {
								["Corruptor"] = {
									["total"] = 188,
									["amount"] = 188,
								},
							},
							["count"] = 1,
							["hit"] = 1,
							["school"] = 1,
							["hitmax"] = 188,
							["amount"] = 188,
							["hitamount"] = 188,
						},
					},
					["name"] = "Macius",
					["energy"] = 54,
					["role"] = "DAMAGER",
				}, -- [2]
				{
					["last"] = 10406.724,
					["flag"] = 1297,
					["class"] = "WARLOCK",
					["auras"] = {
						[980] = {
							["type"] = "DEBUFF",
							["count"] = 2,
							["school"] = 32,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["uptime"] = 10,
									["count"] = 1,
								},
							},
							["uptime"] = 10,
						},
						[30108] = {
							["type"] = "DEBUFF",
							["count"] = 2,
							["school"] = 32,
							["targets"] = {
								["Deeprot Stomper"] = {
									["uptime"] = 2,
									["count"] = 1,
								},
								["Putridus Shadowstalker"] = {
									["uptime"] = 11,
									["count"] = 1,
								},
							},
							["uptime"] = 13,
						},
						[172] = {
							["type"] = "DEBUFF",
							["count"] = 2,
							["school"] = 32,
							["targets"] = {
								["Deeprot Stomper"] = {
									["uptime"] = 2,
									["count"] = 1,
								},
								["Putridus Shadowstalker"] = {
									["uptime"] = 11,
									["count"] = 1,
								},
							},
							["uptime"] = 13,
						},
					},
					["time"] = 11.89,
					["totaldamagetaken"] = 195,
					["damage"] = 1117,
					["damagespells"] = {
						["Bane of Agony (DoT)"] = {
							["total"] = 84,
							["hitmin"] = 12,
							["criticalamount"] = 23,
							["id"] = 980,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 84,
									["amount"] = 84,
								},
							},
							["hitmax"] = 25,
							["count"] = 5,
							["criticalmax"] = 23,
							["critical"] = 1,
							["amount"] = 84,
							["school"] = 32,
							["hit"] = 4,
							["criticalmin"] = 23,
							["hitamount"] = 61,
						},
						["Corruption (DoT)"] = {
							["total"] = 132,
							["hitmin"] = 44,
							["id"] = 172,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 132,
									["amount"] = 132,
								},
							},
							["count"] = 3,
							["hit"] = 3,
							["school"] = 32,
							["hitmax"] = 44,
							["amount"] = 132,
							["hitamount"] = 132,
						},
						["Melee"] = {
							["glancing"] = 1,
							["total"] = 44,
							["count"] = 1,
							["amount"] = 44,
							["school"] = 1,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 44,
									["amount"] = 44,
								},
							},
							["id"] = 6603,
						},
						["Unstable Affliction (DoT)"] = {
							["total"] = 147,
							["hitmin"] = 49,
							["id"] = 30108,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 147,
									["amount"] = 147,
								},
							},
							["count"] = 3,
							["hit"] = 3,
							["school"] = 32,
							["hitmax"] = 49,
							["amount"] = 147,
							["hitamount"] = 147,
						},
						["Retribution Aura"] = {
							["total"] = 13,
							["hitmin"] = 13,
							["id"] = 7294,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 13,
									["amount"] = 13,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 2,
							["hitmax"] = 13,
							["amount"] = 13,
							["hitamount"] = 13,
						},
						["Melee (Haagroon)"] = {
							["hitmin"] = 60,
							["criticalmin"] = 132,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 181,
									["overkill"] = 126,
									["amount"] = 181,
								},
								["Putridus Shadowstalker"] = {
									["total"] = 258,
									["amount"] = 258,
								},
							},
							["glancing"] = 4,
							["amount"] = 439,
							["MISS"] = 2,
							["total"] = 439,
							["criticalamount"] = 132,
							["id"] = 6603,
							["overkill"] = 126,
							["criticalmax"] = 132,
							["count"] = 9,
							["hit"] = 2,
							["school"] = 1,
							["hitmax"] = 68,
							["critical"] = 1,
							["hitamount"] = 128,
						},
						["Shadow Bite (Haagroon)"] = {
							["total"] = 258,
							["hitmin"] = 105,
							["id"] = 54049,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 105,
									["amount"] = 105,
								},
								["Putridus Shadowstalker"] = {
									["total"] = 153,
									["amount"] = 153,
								},
							},
							["amount"] = 258,
							["casts"] = 3,
							["count"] = 3,
							["hit"] = 2,
							["school"] = 32,
							["hitmax"] = 153,
							["MISS"] = 1,
							["hitamount"] = 258,
						},
					},
					["damagetaken"] = 195,
					["id"] = "0x000000000004825C",
					["spec"] = 265,
					["healspells"] = {
						[63106] = {
							["overheal"] = 0,
							["count"] = 2,
							["amount"] = 66,
							["school"] = 32,
							["max"] = 33,
							["targets"] = {
								["Beardedrasta"] = {
									["overheal"] = 0,
									["amount"] = 66,
								},
							},
							["min"] = 33,
						},
					},
					["overkill"] = 126,
					["heal"] = 66,
					["name"] = "Beardedrasta",
					["overheal"] = 0,
					["damagetakenspells"] = {
						["Melee"] = {
							["total"] = 195,
							["hitmin"] = 195,
							["id"] = 6603,
							["sources"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 195,
									["amount"] = 195,
								},
							},
							["count"] = 1,
							["hit"] = 1,
							["school"] = 1,
							["hitmax"] = 195,
							["amount"] = 195,
							["hitamount"] = 195,
						},
					},
					["totaldamage"] = 1117,
					["role"] = "DAMAGER",
				}, -- [3]
				{
					["overheal"] = 0,
					["last"] = 10405.161,
					["flag"] = 1298,
					["class"] = "PRIEST",
					["healspells"] = {
						[63544] = {
							["overheal"] = 0,
							["count"] = 2,
							["amount"] = 118,
							["school"] = 2,
							["max"] = 67,
							["targets"] = {
								["Fragrance"] = {
									["overheal"] = 0,
									["amount"] = 51,
								},
								["Myrony"] = {
									["overheal"] = 0,
									["amount"] = 67,
								},
							},
							["min"] = 51,
						},
						[139] = {
							["overheal"] = 0,
							["max"] = 168,
							["targets"] = {
								["Myrony"] = {
									["overheal"] = 0,
									["amount"] = 672,
								},
							},
							["min"] = 168,
							["casts"] = 2,
							["count"] = 4,
							["amount"] = 672,
							["school"] = 2,
							["ishot"] = true,
						},
						[56160] = {
							["overheal"] = 0,
							["count"] = 1,
							["amount"] = 179,
							["school"] = 2,
							["max"] = 179,
							["targets"] = {
								["Fragrance"] = {
									["overheal"] = 0,
									["amount"] = 179,
								},
							},
							["min"] = 179,
						},
					},
					["auras"] = {
						[465] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 2,
							["uptime"] = 17,
						},
						[6788] = {
							["type"] = "DEBUFF",
							["count"] = 1,
							["school"] = 2,
							["targets"] = {
								["Fragrance"] = {
									["uptime"] = 1,
									["count"] = 1,
								},
							},
							["uptime"] = 1,
						},
					},
					["heal"] = 969,
					["role"] = "HEALER",
					["name"] = "Nianhong",
					["time"] = 15.5,
					["id"] = "0x00000000000467C0",
				}, -- [4]
				{
					["ccdonespells"] = {
						[2812] = {
							["count"] = 2,
							["targets"] = {
								["Putridus Shadowstalker"] = 1,
								["Poison Sprite"] = 1,
							},
						},
					},
					["last"] = 10405.831,
					["flag"] = 1298,
					["class"] = "PALADIN",
					["auras"] = {
						[2812] = {
							["type"] = "DEBUFF",
							["count"] = 2,
							["school"] = 2,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["uptime"] = 3,
									["count"] = 1,
								},
								["Poison Sprite"] = {
									["uptime"] = 1,
									["count"] = 1,
								},
							},
							["uptime"] = 3,
						},
						[59578] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 1,
							["uptime"] = 1,
						},
						[94686] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 1,
							["refresh"] = 1,
							["uptime"] = 8,
						},
						[89906] = {
							["type"] = "BUFF",
							["count"] = 2,
							["school"] = 2,
							["uptime"] = 15,
						},
						[139] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 2,
							["uptime"] = 3,
						},
						[17] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 2,
							["uptime"] = 1,
						},
					},
					["role"] = "DAMAGER",
					["time"] = 16.56,
					["totaldamagetaken"] = 739,
					["damage"] = 4385,
					["damagespells"] = {
						["Exorcism"] = {
							["criticalmin"] = 1057,
							["total"] = 1764,
							["hitmin"] = 707,
							["criticalamount"] = 1057,
							["id"] = 879,
							["criticalmax"] = 1057,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 707,
									["amount"] = 707,
								},
								["Poison Sprite"] = {
									["total"] = 1057,
									["overkill"] = 224,
									["amount"] = 1057,
								},
							},
							["overkill"] = 224,
							["critical"] = 1,
							["casts"] = 2,
							["count"] = 2,
							["hit"] = 1,
							["school"] = 2,
							["hitmax"] = 707,
							["amount"] = 1764,
							["hitamount"] = 707,
						},
						["Divine Storm"] = {
							["total"] = 364,
							["hitmin"] = 180,
							["id"] = 53385,
							["targets"] = {
								["Poison Sprite"] = {
									["total"] = 364,
									["amount"] = 364,
								},
							},
							["casts"] = 1,
							["count"] = 2,
							["hit"] = 2,
							["school"] = 1,
							["hitmax"] = 184,
							["amount"] = 364,
							["hitamount"] = 364,
						},
						["Retribution Aura"] = {
							["total"] = 39,
							["hitmin"] = 13,
							["id"] = 7294,
							["targets"] = {
								["Poison Sprite"] = {
									["total"] = 39,
									["amount"] = 39,
								},
							},
							["casts"] = 1,
							["count"] = 3,
							["hit"] = 3,
							["school"] = 2,
							["hitmax"] = 13,
							["amount"] = 39,
							["hitamount"] = 39,
						},
						["Holy Wrath"] = {
							["total"] = 276,
							["hitmin"] = 92,
							["id"] = 2812,
							["targets"] = {
								["Poison Sprite"] = {
									["total"] = 92,
									["amount"] = 92,
								},
								["Putridus Shadowstalker"] = {
									["total"] = 92,
									["amount"] = 92,
								},
								["Corruptor"] = {
									["total"] = 92,
									["overkill"] = 42,
									["amount"] = 92,
								},
							},
							["overkill"] = 42,
							["casts"] = 1,
							["count"] = 3,
							["hit"] = 3,
							["school"] = 2,
							["hitmax"] = 92,
							["amount"] = 276,
							["hitamount"] = 276,
						},
						["Melee"] = {
							["total"] = 982,
							["hitmin"] = 181,
							["id"] = 6603,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 184,
									["amount"] = 184,
								},
								["Poison Sprite"] = {
									["total"] = 215,
									["amount"] = 215,
								},
								["Putridus Shadowstalker"] = {
									["total"] = 583,
									["amount"] = 583,
								},
							},
							["count"] = 5,
							["hit"] = 5,
							["school"] = 1,
							["hitmax"] = 218,
							["amount"] = 982,
							["hitamount"] = 982,
						},
						["Seal of Righteousness"] = {
							["total"] = 104,
							["hitmin"] = 26,
							["id"] = 25742,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 26,
									["amount"] = 26,
								},
								["Putridus Shadowstalker"] = {
									["total"] = 78,
									["amount"] = 78,
								},
							},
							["casts"] = 1,
							["count"] = 4,
							["hit"] = 4,
							["school"] = 2,
							["hitmax"] = 26,
							["amount"] = 104,
							["hitamount"] = 104,
						},
						["Hand of Light"] = {
							["total"] = 4,
							["hitmin"] = 1,
							["id"] = 96172,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 2,
									["amount"] = 2,
								},
								["Poison Sprite"] = {
									["total"] = 2,
									["amount"] = 2,
								},
							},
							["casts"] = 1,
							["count"] = 4,
							["hit"] = 4,
							["school"] = 2,
							["hitmax"] = 1,
							["amount"] = 4,
							["hitamount"] = 4,
						},
						["Crusader Strike"] = {
							["total"] = 604,
							["hitmin"] = 294,
							["id"] = 35395,
							["targets"] = {
								["Putridus Shadowstalker"] = {
									["total"] = 604,
									["amount"] = 604,
								},
							},
							["casts"] = 2,
							["count"] = 2,
							["hit"] = 2,
							["school"] = 1,
							["hitmax"] = 310,
							["amount"] = 604,
							["hitamount"] = 604,
						},
						["Judgement of Righteousness"] = {
							["total"] = 248,
							["hitmin"] = 124,
							["id"] = 20187,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 124,
									["amount"] = 124,
								},
								["Poison Sprite"] = {
									["total"] = 124,
									["amount"] = 124,
								},
							},
							["casts"] = 2,
							["count"] = 2,
							["hit"] = 2,
							["school"] = 2,
							["hitmax"] = 124,
							["amount"] = 248,
							["hitamount"] = 248,
						},
					},
					["overheal"] = 22,
					["damagetaken"] = 739,
					["id"] = "0x0000000000048007",
					["healspells"] = {
						[54172] = {
							["overheal"] = 22,
							["max"] = 26,
							["targets"] = {
								["Beardedrasta"] = {
									["overheal"] = 0,
									["amount"] = 52,
								},
								["Nianhong"] = {
									["overheal"] = 22,
									["amount"] = 0,
								},
								["Fragrance"] = {
									["overheal"] = 0,
									["amount"] = 44,
								},
								["Haagroon"] = {
									["overheal"] = 0,
									["amount"] = 21,
								},
							},
							["min"] = 21,
							["casts"] = 6,
							["count"] = 6,
							["amount"] = 117,
							["school"] = 2,
							["ishot"] = true,
						},
					},
					["overkill"] = 266,
					["damagetakenspells"] = {
						["Melee"] = {
							["total"] = 739,
							["hitmin"] = 197,
							["criticalamount"] = 338,
							["id"] = 6603,
							["criticalmin"] = 338,
							["criticalmax"] = 338,
							["critical"] = 1,
							["sources"] = {
								["Poison Sprite"] = {
									["total"] = 739,
									["amount"] = 739,
								},
							},
							["count"] = 3,
							["hit"] = 2,
							["school"] = 1,
							["hitmax"] = 204,
							["amount"] = 739,
							["hitamount"] = 401,
						},
					},
					["heal"] = 117,
					["name"] = "Fragrance",
					["ccdone"] = 2,
					["mana"] = 322,
					["manaspells"] = {
						[89906] = 322,
					},
					["totaldamage"] = 4385,
				}, -- [5]
				{
					["last"] = 10400.305,
					["name"] = "Haagroon",
					["flag"] = 4369,
					["class"] = "PET",
					["id"] = "0xF143011D00000005",
					["time"] = 0,
				}, -- [6]
			},
			["type"] = "party",
			["damagetaken"] = 1774,
			["ccdone"] = 3,
			["etotaldamage"] = 1774,
			["energy"] = 54,
			["overkill"] = 1184,
			["edamagetaken"] = 11294,
			["heal"] = 1152,
			["name"] = "Deeprot Stomper (4)",
			["mobname"] = "Deeprot Stomper",
			["overheal"] = 22,
			["edamage"] = 1774,
			["last_action"] = 1689857275,
			["endtime"] = 1689857275,
		}, -- [12]
		{
			["mana"] = 920,
			["energy"] = 74,
			["enemies"] = {
				{
					["damagespells"] = {
						[13446] = {
							["school"] = 1,
							["total"] = 243,
							["targets"] = {
								["Fragrance"] = {
									["total"] = 243,
									["amount"] = 243,
								},
							},
							["amount"] = 243,
						},
						[6603] = {
							["school"] = 1,
							["total"] = 175,
							["targets"] = {
								["Myrony"] = {
									["total"] = 175,
									["amount"] = 175,
								},
							},
							["amount"] = 175,
						},
					},
					["damagetaken"] = 3341,
					["flag"] = 68168,
					["class"] = "MONSTER",
					["damagetakenspells"] = {
						[6603] = {
							["school"] = 1,
							["total"] = 608,
							["sources"] = {
								["Macius"] = {
									["total"] = 53,
									["amount"] = 53,
								},
								["Beardedrasta"] = {
									["total"] = 48,
									["amount"] = 48,
								},
								["Fragrance"] = {
									["total"] = 406,
									["amount"] = 406,
								},
								["Myrony"] = {
									["total"] = 101,
									["amount"] = 101,
								},
							},
							["amount"] = 608,
						},
						[7294] = {
							["school"] = 2,
							["total"] = 13,
							["sources"] = {
								["Myrony"] = {
									["total"] = 13,
									["amount"] = 13,
								},
							},
							["amount"] = 13,
						},
						[56641] = {
							["school"] = 1,
							["total"] = 189,
							["sources"] = {
								["Macius"] = {
									["total"] = 189,
									["amount"] = 189,
								},
							},
							["amount"] = 189,
						},
						[879] = {
							["school"] = 2,
							["total"] = 705,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 705,
									["amount"] = 705,
								},
							},
							["amount"] = 705,
						},
						[980] = {
							["school"] = 32,
							["total"] = 12,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 12,
									["amount"] = 12,
								},
							},
							["amount"] = 12,
						},
						[35395] = {
							["school"] = 1,
							["total"] = 242,
							["sources"] = {
								["Myrony"] = {
									["total"] = 242,
									["amount"] = 242,
								},
							},
							["amount"] = 242,
						},
						[172] = {
							["school"] = 32,
							["total"] = 44,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 44,
									["amount"] = 44,
								},
							},
							["amount"] = 44,
						},
						[25742] = {
							["school"] = 2,
							["total"] = 102,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 52,
									["amount"] = 52,
								},
								["Myrony"] = {
									["total"] = 50,
									["amount"] = 50,
								},
							},
							["amount"] = 102,
						},
						[96172] = {
							["school"] = 2,
							["total"] = 1,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 1,
									["amount"] = 1,
								},
							},
							["amount"] = 1,
						},
						[3044] = {
							["sources"] = {
								["Macius"] = {
									["total"] = 139,
									["overkill"] = 58,
									["amount"] = 139,
								},
							},
							["amount"] = 139,
							["school"] = 64,
							["total"] = 139,
							["overkill"] = 58,
						},
						[85256] = {
							["school"] = 1,
							["total"] = 634,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 634,
									["amount"] = 634,
								},
							},
							["amount"] = 634,
						},
						[30108] = {
							["school"] = 32,
							["total"] = 49,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 49,
									["amount"] = 49,
								},
							},
							["amount"] = 49,
						},
						[53301] = {
							["school"] = 4,
							["total"] = 474,
							["sources"] = {
								["Macius"] = {
									["total"] = 474,
									["amount"] = 474,
								},
							},
							["amount"] = 474,
						},
						[54049] = {
							["school"] = 32,
							["total"] = 129,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 129,
									["amount"] = 129,
								},
							},
							["amount"] = 129,
						},
					},
					["name"] = "Deeprot Stomper",
					["totaldamage"] = 418,
					["totaldamagetaken"] = 3341,
					["id"] = "0xF1303355000000B1",
					["damage"] = 418,
				}, -- [1]
				{
					["damagespells"] = {
						[6603] = {
							["school"] = 1,
							["total"] = 925,
							["targets"] = {
								["Myrony"] = {
									["total"] = 925,
									["amount"] = 268,
								},
							},
							["amount"] = 268,
						},
						[15667] = {
							["school"] = 1,
							["total"] = 189,
							["targets"] = {
								["Myrony"] = {
									["total"] = 189,
									["amount"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["damagetaken"] = 9096,
					["flag"] = 2632,
					["class"] = "MONSTER",
					["damagetakenspells"] = {
						[16827] = {
							["school"] = 1,
							["total"] = 342,
							["sources"] = {
								["Macius"] = {
									["total"] = 342,
									["amount"] = 342,
								},
							},
							["amount"] = 342,
						},
						[25742] = {
							["school"] = 2,
							["total"] = 152,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 78,
									["amount"] = 78,
								},
								["Myrony"] = {
									["total"] = 74,
									["amount"] = 74,
								},
							},
							["amount"] = 152,
						},
						[81297] = {
							["school"] = 2,
							["total"] = 391,
							["sources"] = {
								["Myrony"] = {
									["total"] = 391,
									["amount"] = 391,
								},
							},
							["amount"] = 391,
						},
						[53595] = {
							["school"] = 1,
							["total"] = 36,
							["sources"] = {
								["Myrony"] = {
									["total"] = 36,
									["amount"] = 36,
								},
							},
							["amount"] = 36,
						},
						[6603] = {
							["school"] = 1,
							["total"] = 1540,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 213,
									["amount"] = 213,
								},
								["Macius"] = {
									["total"] = 464,
									["amount"] = 464,
								},
								["Fragrance"] = {
									["total"] = 560,
									["amount"] = 560,
								},
								["Myrony"] = {
									["total"] = 303,
									["amount"] = 303,
								},
							},
							["amount"] = 1540,
						},
						[2643] = {
							["school"] = 1,
							["total"] = 567,
							["sources"] = {
								["Macius"] = {
									["total"] = 567,
									["amount"] = 567,
								},
							},
							["amount"] = 567,
						},
						[42223] = {
							["school"] = 4,
							["total"] = 654,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 654,
									["amount"] = 654,
								},
							},
							["amount"] = 654,
						},
						[53385] = {
							["school"] = 1,
							["total"] = 587,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 587,
									["amount"] = 587,
								},
							},
							["amount"] = 587,
						},
						[88263] = {
							["school"] = 2,
							["total"] = 446,
							["sources"] = {
								["Myrony"] = {
									["total"] = 446,
									["amount"] = 446,
								},
							},
							["amount"] = 446,
						},
						[96172] = {
							["school"] = 2,
							["total"] = 4,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 4,
									["amount"] = 4,
								},
							},
							["amount"] = 4,
						},
						[2812] = {
							["school"] = 2,
							["total"] = 288,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 92,
									["amount"] = 92,
								},
								["Myrony"] = {
									["total"] = 196,
									["amount"] = 196,
								},
							},
							["amount"] = 288,
						},
						[31935] = {
							["school"] = 2,
							["total"] = 665,
							["sources"] = {
								["Myrony"] = {
									["total"] = 665,
									["amount"] = 665,
								},
							},
							["amount"] = 665,
						},
						[20187] = {
							["school"] = 2,
							["total"] = 372,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 372,
									["amount"] = 372,
								},
							},
							["amount"] = 372,
						},
						[54049] = {
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 160,
									["overkill"] = 43,
									["amount"] = 160,
								},
							},
							["amount"] = 160,
							["school"] = 32,
							["total"] = 160,
							["overkill"] = 43,
						},
						[75] = {
							["sources"] = {
								["Macius"] = {
									["total"] = 795,
									["overkill"] = 173,
									["amount"] = 795,
								},
							},
							["amount"] = 795,
							["school"] = 1,
							["total"] = 795,
							["overkill"] = 173,
						},
						[35395] = {
							["school"] = 1,
							["total"] = 556,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 342,
									["amount"] = 342,
								},
								["Myrony"] = {
									["total"] = 214,
									["amount"] = 214,
								},
							},
							["amount"] = 556,
						},
						[7294] = {
							["school"] = 2,
							["total"] = 26,
							["sources"] = {
								["Myrony"] = {
									["total"] = 26,
									["amount"] = 26,
								},
							},
							["amount"] = 26,
						},
						[879] = {
							["school"] = 2,
							["total"] = 1051,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 1051,
									["amount"] = 1051,
								},
							},
							["amount"] = 1051,
						},
						[56641] = {
							["school"] = 1,
							["total"] = 464,
							["sources"] = {
								["Macius"] = {
									["total"] = 464,
									["amount"] = 464,
								},
							},
							["amount"] = 464,
						},
					},
					["name"] = "Putridus Satyr",
					["totaldamage"] = 1114,
					["totaldamagetaken"] = 9096,
					["id"] = "0xF1302E0E000000AF",
					["damage"] = 268,
				}, -- [2]
				{
					["damagespells"] = {
						[6603] = {
							["school"] = 1,
							["total"] = 800,
							["targets"] = {
								["Fragrance"] = {
									["total"] = 800,
									["amount"] = 800,
								},
							},
							["amount"] = 800,
						},
					},
					["damagetaken"] = 2661,
					["flag"] = 2632,
					["class"] = "MONSTER",
					["damagetakenspells"] = {
						[53385] = {
							["school"] = 1,
							["total"] = 1021,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 1021,
									["amount"] = 1021,
								},
							},
							["amount"] = 1021,
						},
						[7294] = {
							["school"] = 2,
							["total"] = 52,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 52,
									["amount"] = 52,
								},
							},
							["amount"] = 52,
						},
						[2643] = {
							["school"] = 1,
							["total"] = 375,
							["sources"] = {
								["Macius"] = {
									["total"] = 375,
									["amount"] = 375,
								},
							},
							["amount"] = 375,
						},
						[88263] = {
							["school"] = 2,
							["total"] = 298,
							["sources"] = {
								["Myrony"] = {
									["total"] = 298,
									["amount"] = 298,
								},
							},
							["amount"] = 298,
						},
						[25742] = {
							["school"] = 2,
							["total"] = 36,
							["sources"] = {
								["Myrony"] = {
									["total"] = 36,
									["amount"] = 36,
								},
							},
							["amount"] = 36,
						},
						[96172] = {
							["school"] = 2,
							["total"] = 5,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 5,
									["amount"] = 5,
								},
							},
							["amount"] = 5,
						},
						[53595] = {
							["school"] = 1,
							["total"] = 35,
							["sources"] = {
								["Myrony"] = {
									["total"] = 35,
									["amount"] = 35,
								},
							},
							["amount"] = 35,
						},
						[2812] = {
							["school"] = 2,
							["total"] = 285,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 138,
									["amount"] = 138,
								},
								["Myrony"] = {
									["total"] = 147,
									["amount"] = 147,
								},
							},
							["amount"] = 285,
						},
						[42223] = {
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 164,
									["overkill"] = 23,
									["amount"] = 164,
								},
							},
							["amount"] = 164,
							["school"] = 4,
							["total"] = 164,
							["overkill"] = 23,
						},
						[6603] = {
							["school"] = 1,
							["total"] = 200,
							["sources"] = {
								["Myrony"] = {
									["total"] = 200,
									["amount"] = 200,
								},
							},
							["amount"] = 200,
						},
						[20187] = {
							["sources"] = {
								["Myrony"] = {
									["total"] = 190,
									["overkill"] = 139,
									["amount"] = 190,
								},
							},
							["amount"] = 190,
							["school"] = 2,
							["total"] = 190,
							["overkill"] = 139,
						},
					},
					["name"] = "Poison Sprite",
					["totaldamage"] = 800,
					["totaldamagetaken"] = 2661,
					["id"] = "0xF1302FB8000000B4",
					["damage"] = 800,
				}, -- [3]
				{
					["damagespells"] = {
						[6603] = {
							["school"] = 1,
							["total"] = 167,
							["targets"] = {
								["Myrony"] = {
									["total"] = 167,
									["amount"] = 167,
								},
							},
							["amount"] = 167,
						},
					},
					["damagetaken"] = 922,
					["flag"] = 2632,
					["class"] = "MONSTER",
					["damagetakenspells"] = {
						[2812] = {
							["school"] = 2,
							["total"] = 46,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 46,
									["amount"] = 46,
								},
							},
							["amount"] = 46,
						},
						[31935] = {
							["school"] = 2,
							["total"] = 319,
							["sources"] = {
								["Myrony"] = {
									["total"] = 319,
									["amount"] = 319,
								},
							},
							["amount"] = 319,
						},
						[53385] = {
							["school"] = 1,
							["total"] = 184,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 184,
									["amount"] = 184,
								},
							},
							["amount"] = 184,
						},
						[88263] = {
							["sources"] = {
								["Myrony"] = {
									["total"] = 141,
									["overkill"] = 89,
									["amount"] = 141,
								},
							},
							["amount"] = 141,
							["school"] = 2,
							["total"] = 141,
							["overkill"] = 89,
						},
						[81297] = {
							["school"] = 2,
							["total"] = 27,
							["sources"] = {
								["Myrony"] = {
									["total"] = 27,
									["amount"] = 27,
								},
							},
							["amount"] = 27,
						},
						[2643] = {
							["school"] = 1,
							["total"] = 191,
							["sources"] = {
								["Macius"] = {
									["total"] = 191,
									["amount"] = 191,
								},
							},
							["amount"] = 191,
						},
						[96172] = {
							["school"] = 2,
							["total"] = 1,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 1,
									["amount"] = 1,
								},
							},
							["amount"] = 1,
						},
						[7294] = {
							["school"] = 2,
							["total"] = 13,
							["sources"] = {
								["Myrony"] = {
									["total"] = 13,
									["amount"] = 13,
								},
							},
							["amount"] = 13,
						},
					},
					["name"] = "Corruptor",
					["totaldamage"] = 167,
					["totaldamagetaken"] = 922,
					["id"] = "0xF1302FB9000000B0",
					["damage"] = 167,
				}, -- [4]
			},
			["totaldamage"] = 16020,
			["time"] = 22,
			["absorb"] = 846,
			["totaldamagetaken"] = 2499,
			["etotaldamagetaken"] = 16020,
			["damage"] = 16020,
			["players"] = {
				{
					["last"] = 10377.127,
					["flag"] = 1297,
					["class"] = "WARLOCK",
					["auras"] = {
						[172] = {
							["type"] = "DEBUFF",
							["count"] = 1,
							["school"] = 32,
							["targets"] = {
								["Deeprot Stomper"] = {
									["uptime"] = 3,
									["count"] = 1,
								},
							},
							["uptime"] = 3,
						},
						[980] = {
							["type"] = "DEBUFF",
							["count"] = 1,
							["school"] = 32,
							["targets"] = {
								["Deeprot Stomper"] = {
									["uptime"] = 2,
									["count"] = 1,
								},
							},
							["uptime"] = 2,
						},
						[5740] = {
							["type"] = "BUFF",
							["count"] = 8,
							["school"] = 4,
							["targets"] = {
								["Poison Sprite"] = {
									["uptime"] = 2,
									["count"] = 2,
								},
								["Putridus Satyr"] = {
									["uptime"] = 8,
									["count"] = 3,
								},
							},
							["uptime"] = 10,
						},
						[30108] = {
							["type"] = "DEBUFF",
							["count"] = 1,
							["school"] = 32,
							["targets"] = {
								["Deeprot Stomper"] = {
									["uptime"] = 3,
									["count"] = 1,
								},
							},
							["uptime"] = 3,
						},
					},
					["time"] = 17.23,
					["damage"] = 1473,
					["overheal"] = 0,
					["id"] = "0x000000000004825C",
					["spec"] = 265,
					["healspells"] = {
						[63106] = {
							["overheal"] = 0,
							["count"] = 1,
							["amount"] = 33,
							["school"] = 32,
							["max"] = 33,
							["targets"] = {
								["Beardedrasta"] = {
									["overheal"] = 0,
									["amount"] = 33,
								},
							},
							["min"] = 33,
						},
					},
					["overkill"] = 66,
					["heal"] = 33,
					["name"] = "Beardedrasta",
					["damagespells"] = {
						["Bane of Agony (DoT)"] = {
							["total"] = 12,
							["hitmin"] = 12,
							["id"] = 980,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 12,
									["amount"] = 12,
								},
							},
							["count"] = 1,
							["hit"] = 1,
							["school"] = 32,
							["hitmax"] = 12,
							["amount"] = 12,
							["hitamount"] = 12,
						},
						["Corruption (DoT)"] = {
							["total"] = 44,
							["hitmin"] = 44,
							["id"] = 172,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 44,
									["amount"] = 44,
								},
							},
							["count"] = 1,
							["hit"] = 1,
							["school"] = 32,
							["hitmax"] = 44,
							["amount"] = 44,
							["hitamount"] = 44,
						},
						["Melee"] = {
							["total"] = 48,
							["hitmin"] = 48,
							["id"] = 6603,
							["targets"] = {
								["Putridus Satyr"] = {
									["total"] = 48,
									["amount"] = 48,
								},
							},
							["count"] = 1,
							["hit"] = 1,
							["school"] = 1,
							["hitmax"] = 48,
							["amount"] = 48,
							["hitamount"] = 48,
						},
						["Rain of Fire"] = {
							["criticalmax"] = 163,
							["total"] = 818,
							["hitmin"] = 82,
							["criticalamount"] = 326,
							["id"] = 42223,
							["criticalmin"] = 163,
							["targets"] = {
								["Putridus Satyr"] = {
									["total"] = 654,
									["amount"] = 654,
								},
								["Poison Sprite"] = {
									["total"] = 164,
									["overkill"] = 23,
									["amount"] = 164,
								},
							},
							["overkill"] = 23,
							["critical"] = 2,
							["casts"] = 2,
							["count"] = 8,
							["hit"] = 6,
							["school"] = 4,
							["hitmax"] = 82,
							["amount"] = 818,
							["hitamount"] = 492,
						},
						["Unstable Affliction (DoT)"] = {
							["total"] = 49,
							["hitmin"] = 49,
							["id"] = 30108,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 49,
									["amount"] = 49,
								},
							},
							["count"] = 1,
							["hit"] = 1,
							["school"] = 32,
							["hitmax"] = 49,
							["amount"] = 49,
							["hitamount"] = 49,
						},
						["Melee (Haagroon)"] = {
							["total"] = 213,
							["hitmin"] = 48,
							["id"] = 6603,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 48,
									["amount"] = 48,
								},
								["Putridus Satyr"] = {
									["total"] = 165,
									["amount"] = 165,
								},
							},
							["glancing"] = 2,
							["blocked"] = 20,
							["count"] = 4,
							["hit"] = 2,
							["school"] = 1,
							["hitmax"] = 61,
							["amount"] = 213,
							["hitamount"] = 109,
						},
						["Shadow Bite (Haagroon)"] = {
							["total"] = 289,
							["hitmin"] = 80,
							["id"] = 54049,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 129,
									["amount"] = 129,
								},
								["Putridus Satyr"] = {
									["total"] = 160,
									["overkill"] = 43,
									["amount"] = 160,
								},
							},
							["overkill"] = 43,
							["casts"] = 3,
							["count"] = 3,
							["hit"] = 3,
							["school"] = 32,
							["hitmax"] = 129,
							["amount"] = 289,
							["hitamount"] = 289,
						},
					},
					["totaldamage"] = 1473,
					["role"] = "DAMAGER",
				}, -- [1]
				{
					["ccdonespells"] = {
						[2812] = {
							["count"] = 6,
							["targets"] = {
								["Poison Sprite"] = 3,
								["Corruptor"] = 1,
								["Putridus Satyr"] = 2,
							},
						},
					},
					["last"] = 10375.561,
					["flag"] = 1298,
					["class"] = "PALADIN",
					["auras"] = {
						[2812] = {
							["type"] = "DEBUFF",
							["count"] = 6,
							["school"] = 2,
							["targets"] = {
								["Poison Sprite"] = {
									["uptime"] = 3,
									["count"] = 3,
								},
								["Corruptor"] = {
									["uptime"] = 2,
									["count"] = 1,
								},
								["Putridus Satyr"] = {
									["uptime"] = 3,
									["count"] = 2,
								},
							},
							["uptime"] = 3,
						},
						[59578] = {
							["type"] = "BUFF",
							["count"] = 2,
							["school"] = 1,
							["uptime"] = 3,
						},
						[89906] = {
							["type"] = "BUFF",
							["count"] = 2,
							["school"] = 2,
							["uptime"] = 13,
						},
					},
					["totaldamage"] = 6331,
					["time"] = 17.81,
					["totaldamagetaken"] = 1043,
					["damage"] = 6331,
					["damagespells"] = {
						["Exorcism"] = {
							["total"] = 1756,
							["hitmin"] = 705,
							["criticalamount"] = 1051,
							["id"] = 879,
							["criticalmin"] = 1051,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 705,
									["amount"] = 705,
								},
								["Putridus Satyr"] = {
									["total"] = 1051,
									["amount"] = 1051,
								},
							},
							["criticalmax"] = 1051,
							["critical"] = 1,
							["casts"] = 2,
							["count"] = 2,
							["hit"] = 1,
							["school"] = 2,
							["hitmax"] = 705,
							["amount"] = 1756,
							["hitamount"] = 705,
						},
						["Divine Storm"] = {
							["total"] = 1792,
							["hitmin"] = 184,
							["id"] = 53385,
							["targets"] = {
								["Poison Sprite"] = {
									["total"] = 1021,
									["amount"] = 1021,
								},
								["Corruptor"] = {
									["total"] = 184,
									["amount"] = 184,
								},
								["Putridus Satyr"] = {
									["total"] = 587,
									["amount"] = 587,
								},
							},
							["amount"] = 1792,
							["casts"] = 2,
							["count"] = 10,
							["hit"] = 9,
							["school"] = 1,
							["hitmax"] = 215,
							["MISS"] = 1,
							["hitamount"] = 1792,
						},
						["Retribution Aura"] = {
							["total"] = 52,
							["hitmin"] = 13,
							["id"] = 7294,
							["targets"] = {
								["Poison Sprite"] = {
									["total"] = 52,
									["amount"] = 52,
								},
							},
							["casts"] = 1,
							["count"] = 4,
							["hit"] = 4,
							["school"] = 2,
							["hitmax"] = 13,
							["amount"] = 52,
							["hitamount"] = 52,
						},
						["Crusader Strike"] = {
							["total"] = 342,
							["hitmin"] = 342,
							["id"] = 35395,
							["targets"] = {
								["Putridus Satyr"] = {
									["total"] = 342,
									["amount"] = 342,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 1,
							["hitmax"] = 342,
							["amount"] = 342,
							["hitamount"] = 342,
						},
						["Judgement of Righteousness"] = {
							["total"] = 372,
							["hitmin"] = 124,
							["criticalamount"] = 248,
							["id"] = 20187,
							["hitmax"] = 124,
							["targets"] = {
								["Putridus Satyr"] = {
									["total"] = 372,
									["amount"] = 372,
								},
							},
							["count"] = 2,
							["hit"] = 1,
							["casts"] = 2,
							["critical"] = 1,
							["amount"] = 372,
							["school"] = 2,
							["criticalmin"] = 248,
							["criticalmax"] = 248,
							["hitamount"] = 124,
						},
						["Hand of Light"] = {
							["total"] = 11,
							["hitmin"] = 1,
							["id"] = 96172,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 1,
									["amount"] = 1,
								},
								["Poison Sprite"] = {
									["total"] = 5,
									["amount"] = 5,
								},
								["Corruptor"] = {
									["total"] = 1,
									["amount"] = 1,
								},
								["Putridus Satyr"] = {
									["total"] = 4,
									["amount"] = 4,
								},
							},
							["casts"] = 1,
							["count"] = 11,
							["hit"] = 11,
							["school"] = 2,
							["hitmax"] = 1,
							["amount"] = 11,
							["hitamount"] = 11,
						},
						["Seal of Righteousness"] = {
							["total"] = 130,
							["hitmin"] = 26,
							["id"] = 25742,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 52,
									["amount"] = 52,
								},
								["Putridus Satyr"] = {
									["total"] = 78,
									["amount"] = 78,
								},
							},
							["casts"] = 1,
							["count"] = 5,
							["hit"] = 5,
							["school"] = 2,
							["hitmax"] = 26,
							["amount"] = 130,
							["hitamount"] = 130,
						},
						["Templar's Verdict"] = {
							["total"] = 634,
							["hitmin"] = 634,
							["id"] = 85256,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 634,
									["amount"] = 634,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 1,
							["hitmax"] = 634,
							["amount"] = 634,
							["hitamount"] = 634,
						},
						["Melee"] = {
							["total"] = 966,
							["hitmin"] = 210,
							["criticalamount"] = 756,
							["id"] = 6603,
							["hitmax"] = 210,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 406,
									["amount"] = 406,
								},
								["Putridus Satyr"] = {
									["total"] = 560,
									["amount"] = 560,
								},
							},
							["count"] = 5,
							["hit"] = 1,
							["criticalmax"] = 406,
							["critical"] = 2,
							["amount"] = 966,
							["school"] = 1,
							["criticalmin"] = 350,
							["MISS"] = 2,
							["hitamount"] = 210,
						},
						["Holy Wrath"] = {
							["total"] = 276,
							["hitmin"] = 46,
							["id"] = 2812,
							["targets"] = {
								["Poison Sprite"] = {
									["total"] = 138,
									["amount"] = 138,
								},
								["Corruptor"] = {
									["total"] = 46,
									["amount"] = 46,
								},
								["Putridus Satyr"] = {
									["total"] = 92,
									["amount"] = 92,
								},
							},
							["casts"] = 1,
							["count"] = 6,
							["hit"] = 6,
							["school"] = 2,
							["hitmax"] = 46,
							["amount"] = 276,
							["hitamount"] = 276,
						},
					},
					["damagetaken"] = 1043,
					["id"] = "0x0000000000048007",
					["healspells"] = {
						[54172] = {
							["overheal"] = 447,
							["max"] = 26,
							["targets"] = {
								["Nianhong"] = {
									["overheal"] = 99,
									["amount"] = 0,
								},
								["Cat"] = {
									["overheal"] = 103,
									["amount"] = 14,
								},
								["Myrony"] = {
									["overheal"] = 0,
									["amount"] = 47,
								},
								["Macius"] = {
									["overheal"] = 68,
									["amount"] = 0,
								},
								["Beardedrasta"] = {
									["overheal"] = 84,
									["amount"] = 0,
								},
								["Fragrance"] = {
									["overheal"] = 0,
									["amount"] = 143,
								},
								["Haagroon"] = {
									["overheal"] = 93,
									["amount"] = 0,
								},
							},
							["min"] = 14,
							["casts"] = 27,
							["count"] = 27,
							["amount"] = 204,
							["school"] = 2,
							["ishot"] = true,
						},
					},
					["damagetakenspells"] = {
						["Strike"] = {
							["total"] = 243,
							["hitmin"] = 243,
							["id"] = 13446,
							["sources"] = {
								["Deeprot Stomper"] = {
									["total"] = 243,
									["amount"] = 243,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 1,
							["hitmax"] = 243,
							["amount"] = 243,
							["hitamount"] = 243,
						},
						["Melee"] = {
							["total"] = 800,
							["hitmin"] = 170,
							["id"] = 6603,
							["sources"] = {
								["Poison Sprite"] = {
									["total"] = 800,
									["amount"] = 800,
								},
							},
							["count"] = 4,
							["hit"] = 4,
							["school"] = 1,
							["hitmax"] = 214,
							["amount"] = 800,
							["hitamount"] = 800,
						},
					},
					["overheal"] = 447,
					["heal"] = 204,
					["manaspells"] = {
						[89906] = 460,
					},
					["ccdone"] = 6,
					["mana"] = 460,
					["role"] = "DAMAGER",
					["name"] = "Fragrance",
				}, -- [2]
				{
					["damagespells"] = {
						["Steady Shot"] = {
							["total"] = 653,
							["hitmin"] = 86,
							["criticalamount"] = 194,
							["id"] = 56641,
							["criticalmin"] = 194,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 189,
									["amount"] = 189,
								},
								["Putridus Satyr"] = {
									["total"] = 464,
									["amount"] = 464,
								},
							},
							["criticalmax"] = 194,
							["critical"] = 1,
							["casts"] = 7,
							["count"] = 6,
							["hit"] = 5,
							["school"] = 1,
							["hitmax"] = 96,
							["amount"] = 653,
							["hitamount"] = 459,
						},
						["Auto Shot"] = {
							["hitmin"] = 94,
							["criticalmin"] = 196,
							["targets"] = {
								["Putridus Satyr"] = {
									["total"] = 795,
									["overkill"] = 173,
									["amount"] = 795,
								},
							},
							["amount"] = 795,
							["MISS"] = 1,
							["total"] = 795,
							["criticalamount"] = 598,
							["id"] = 75,
							["overkill"] = 173,
							["criticalmax"] = 206,
							["casts"] = 1,
							["count"] = 6,
							["hit"] = 2,
							["school"] = 1,
							["critical"] = 3,
							["hitmax"] = 103,
							["hitamount"] = 197,
						},
						["Multi-Shot"] = {
							["criticalmax"] = 190,
							["total"] = 1133,
							["hitmin"] = 84,
							["criticalamount"] = 190,
							["id"] = 2643,
							["hitmax"] = 100,
							["targets"] = {
								["Poison Sprite"] = {
									["total"] = 375,
									["amount"] = 375,
								},
								["Corruptor"] = {
									["total"] = 191,
									["amount"] = 191,
								},
								["Putridus Satyr"] = {
									["total"] = 567,
									["amount"] = 567,
								},
							},
							["count"] = 13,
							["hit"] = 10,
							["casts"] = 4,
							["critical"] = 1,
							["amount"] = 1133,
							["school"] = 1,
							["criticalmin"] = 190,
							["MISS"] = 2,
							["hitamount"] = 943,
						},
						["Claw (Cat)"] = {
							["DODGE"] = 1,
							["total"] = 342,
							["hitmin"] = 85,
							["id"] = 16827,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 0,
									["amount"] = 0,
								},
								["Putridus Satyr"] = {
									["total"] = 342,
									["amount"] = 342,
								},
							},
							["casts"] = 5,
							["count"] = 5,
							["amount"] = 342,
							["school"] = 1,
							["hitmax"] = 86,
							["hit"] = 4,
							["hitamount"] = 342,
						},
						["Explosive Shot (DoT)"] = {
							["total"] = 474,
							["hitmin"] = 158,
							["id"] = 53301,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 474,
									["amount"] = 474,
								},
							},
							["count"] = 3,
							["hit"] = 3,
							["school"] = 4,
							["hitmax"] = 158,
							["amount"] = 474,
							["hitamount"] = 474,
						},
						["Melee (Cat)"] = {
							["total"] = 517,
							["hitmin"] = 56,
							["criticalamount"] = 226,
							["id"] = 6603,
							["hitmax"] = 64,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 53,
									["amount"] = 53,
								},
								["Putridus Satyr"] = {
									["total"] = 464,
									["amount"] = 464,
								},
							},
							["count"] = 7,
							["glancing"] = 1,
							["criticalmax"] = 114,
							["critical"] = 2,
							["amount"] = 517,
							["school"] = 1,
							["hit"] = 4,
							["criticalmin"] = 112,
							["hitamount"] = 238,
						},
						["Arcane Shot"] = {
							["total"] = 139,
							["hitmin"] = 139,
							["id"] = 3044,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 139,
									["overkill"] = 58,
									["amount"] = 139,
								},
							},
							["overkill"] = 58,
							["casts"] = 1,
							["count"] = 1,
							["amount"] = 139,
							["school"] = 64,
							["hitmax"] = 139,
							["hit"] = 1,
							["hitamount"] = 139,
						},
					},
					["last"] = 10377.271,
					["role"] = "DAMAGER",
					["overkill"] = 231,
					["flag"] = 1298,
					["class"] = "HUNTER",
					["id"] = "0x00000000000477A3",
					["auras"] = {
						[53301] = {
							["type"] = "DEBUFF",
							["count"] = 1,
							["school"] = 4,
							["targets"] = {
								["Deeprot Stomper"] = {
									["uptime"] = 2,
									["count"] = 1,
								},
							},
							["uptime"] = 2,
						},
					},
					["energyspells"] = {
						[91954] = 54,
						[34720] = 20,
					},
					["totaldamage"] = 4053,
					["time"] = 19.83,
					["name"] = "Macius",
					["energy"] = 74,
					["damage"] = 4053,
				}, -- [3]
				{
					["overheal"] = 660,
					["absorb"] = 846,
					["last"] = 10377.029,
					["id"] = "0x00000000000467C0",
					["class"] = "PRIEST",
					["healspells"] = {
						[63544] = {
							["overheal"] = 0,
							["count"] = 1,
							["amount"] = 67,
							["school"] = 2,
							["max"] = 67,
							["targets"] = {
								["Myrony"] = {
									["overheal"] = 0,
									["amount"] = 67,
								},
							},
							["min"] = 67,
						},
						[139] = {
							["overheal"] = 660,
							["max"] = 168,
							["targets"] = {
								["Myrony"] = {
									["overheal"] = 382,
									["amount"] = 290,
								},
								["Beardedrasta"] = {
									["overheal"] = 278,
									["amount"] = 274,
								},
							},
							["min"] = 122,
							["casts"] = 2,
							["count"] = 8,
							["amount"] = 564,
							["school"] = 2,
							["ishot"] = true,
						},
						[56160] = {
							["overheal"] = 0,
							["count"] = 1,
							["amount"] = 239,
							["school"] = 2,
							["max"] = 239,
							["targets"] = {
								["Myrony"] = {
									["overheal"] = 0,
									["amount"] = 239,
								},
							},
							["min"] = 239,
						},
					},
					["auras"] = {
						[6788] = {
							["type"] = "DEBUFF",
							["count"] = 1,
							["school"] = 2,
							["targets"] = {
								["Myrony"] = {
									["uptime"] = 14,
									["count"] = 1,
								},
							},
							["uptime"] = 14,
						},
					},
					["absorbspells"] = {
						[17] = {
							["min"] = 143,
							["casts"] = 1,
							["count"] = 5,
							["amount"] = 846,
							["school"] = 2,
							["targets"] = {
								["Myrony"] = 846,
							},
							["max"] = 191,
						},
					},
					["time"] = 19.88,
					["flag"] = 1298,
					["role"] = "HEALER",
					["name"] = "Nianhong",
					["heal"] = 870,
				}, -- [4]
				{
					["ccdonespells"] = {
						[31935] = {
							["count"] = 3,
							["targets"] = {
								["Putridus Satyr"] = 2,
								["Corruptor"] = 1,
							},
						},
						[2812] = {
							["count"] = 3,
							["targets"] = {
								["Putridus Satyr"] = 2,
								["Poison Sprite"] = 1,
							},
						},
					},
					["last"] = 10375.624,
					["flag"] = 1298,
					["class"] = "PALADIN",
					["auras"] = {
						[2812] = {
							["type"] = "DEBUFF",
							["count"] = 3,
							["school"] = 2,
							["targets"] = {
								["Putridus Satyr"] = {
									["uptime"] = 2,
									["count"] = 2,
								},
								["Poison Sprite"] = {
									["uptime"] = 2,
									["count"] = 1,
								},
							},
							["uptime"] = 2,
						},
						[17] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 2,
							["uptime"] = 14,
						},
						[31930] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 2,
							["uptime"] = 6,
						},
						[139] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 2,
							["uptime"] = 12,
						},
						[26573] = {
							["type"] = "DEBUFF",
							["count"] = 5,
							["school"] = 2,
							["targets"] = {
								["Deeprot Stomper"] = {
									["uptime"] = 14,
									["count"] = 1,
								},
								["Putridus Satyr"] = {
									["uptime"] = 14,
									["count"] = 2,
								},
								["Corruptor"] = {
									["uptime"] = 14,
									["count"] = 1,
								},
								["Myrony"] = {
									["uptime"] = 10,
									["count"] = 1,
								},
							},
							["uptime"] = 14,
						},
						[31935] = {
							["type"] = "DEBUFF",
							["count"] = 3,
							["school"] = 2,
							["targets"] = {
								["Putridus Satyr"] = {
									["uptime"] = 3,
									["count"] = 2,
								},
								["Corruptor"] = {
									["uptime"] = 3,
									["count"] = 1,
								},
							},
							["uptime"] = 3,
						},
					},
					["role"] = "TANK",
					["time"] = 17.5,
					["totaldamagetaken"] = 1456,
					["damage"] = 4163,
					["damagespells"] = {
						["Melee"] = {
							["total"] = 604,
							["hitmin"] = 75,
							["id"] = 6603,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 101,
									["amount"] = 101,
								},
								["Poison Sprite"] = {
									["total"] = 200,
									["amount"] = 200,
								},
								["Putridus Satyr"] = {
									["total"] = 303,
									["amount"] = 303,
								},
							},
							["amount"] = 604,
							["blocked"] = 31,
							["count"] = 7,
							["hit"] = 6,
							["school"] = 1,
							["hitmax"] = 127,
							["MISS"] = 1,
							["hitamount"] = 604,
						},
						["Hammer of the Righteous (Physical)"] = {
							["total"] = 71,
							["hitmin"] = 35,
							["id"] = 53595,
							["targets"] = {
								["Putridus Satyr"] = {
									["total"] = 36,
									["amount"] = 36,
								},
								["Poison Sprite"] = {
									["total"] = 35,
									["amount"] = 35,
								},
							},
							["casts"] = 1,
							["count"] = 2,
							["hit"] = 2,
							["school"] = 1,
							["hitmax"] = 36,
							["amount"] = 71,
							["hitamount"] = 71,
						},
						["Retribution Aura"] = {
							["total"] = 52,
							["hitmin"] = 13,
							["id"] = 7294,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 13,
									["amount"] = 13,
								},
								["Putridus Satyr"] = {
									["total"] = 26,
									["amount"] = 26,
								},
								["Corruptor"] = {
									["total"] = 13,
									["amount"] = 13,
								},
							},
							["casts"] = 1,
							["count"] = 4,
							["hit"] = 4,
							["school"] = 2,
							["hitmax"] = 13,
							["amount"] = 52,
							["hitamount"] = 52,
						},
						["Judgement of Righteousness"] = {
							["total"] = 190,
							["hitmin"] = 190,
							["id"] = 20187,
							["targets"] = {
								["Poison Sprite"] = {
									["total"] = 190,
									["overkill"] = 139,
									["amount"] = 190,
								},
							},
							["overkill"] = 139,
							["casts"] = 1,
							["count"] = 1,
							["amount"] = 190,
							["school"] = 2,
							["hitmax"] = 190,
							["hit"] = 1,
							["hitamount"] = 190,
						},
						["Hammer of the Righteous"] = {
							["total"] = 885,
							["hitmin"] = 141,
							["id"] = 88263,
							["targets"] = {
								["Poison Sprite"] = {
									["total"] = 298,
									["amount"] = 298,
								},
								["Putridus Satyr"] = {
									["total"] = 446,
									["amount"] = 446,
								},
								["Corruptor"] = {
									["total"] = 141,
									["overkill"] = 89,
									["amount"] = 141,
								},
							},
							["overkill"] = 89,
							["casts"] = 3,
							["count"] = 6,
							["amount"] = 885,
							["school"] = 2,
							["hitmax"] = 157,
							["hit"] = 6,
							["hitamount"] = 885,
						},
						["Avenger's Shield"] = {
							["total"] = 984,
							["hitmin"] = 319,
							["id"] = 31935,
							["targets"] = {
								["Putridus Satyr"] = {
									["total"] = 665,
									["amount"] = 665,
								},
								["Corruptor"] = {
									["total"] = 319,
									["amount"] = 319,
								},
							},
							["casts"] = 1,
							["count"] = 3,
							["hit"] = 3,
							["school"] = 2,
							["hitmax"] = 336,
							["amount"] = 984,
							["hitamount"] = 984,
						},
						["Consecration"] = {
							["total"] = 418,
							["hitmin"] = 27,
							["criticalamount"] = 40,
							["id"] = 81297,
							["criticalmin"] = 40,
							["targets"] = {
								["Corruptor"] = {
									["total"] = 27,
									["amount"] = 27,
								},
								["Putridus Satyr"] = {
									["total"] = 391,
									["amount"] = 391,
								},
							},
							["criticalmax"] = 40,
							["critical"] = 1,
							["casts"] = 1,
							["count"] = 15,
							["hit"] = 14,
							["school"] = 2,
							["hitmax"] = 27,
							["amount"] = 418,
							["hitamount"] = 378,
						},
						["Crusader Strike"] = {
							["total"] = 456,
							["hitmin"] = 214,
							["id"] = 35395,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 242,
									["amount"] = 242,
								},
								["Putridus Satyr"] = {
									["total"] = 214,
									["amount"] = 214,
								},
							},
							["casts"] = 2,
							["count"] = 2,
							["hit"] = 2,
							["school"] = 1,
							["hitmax"] = 242,
							["amount"] = 456,
							["hitamount"] = 456,
						},
						["Seal of Righteousness"] = {
							["total"] = 160,
							["hitmin"] = 18,
							["criticalamount"] = 68,
							["id"] = 25742,
							["hitmax"] = 19,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 50,
									["amount"] = 50,
								},
								["Poison Sprite"] = {
									["total"] = 36,
									["amount"] = 36,
								},
								["Putridus Satyr"] = {
									["total"] = 74,
									["amount"] = 74,
								},
							},
							["count"] = 7,
							["hit"] = 5,
							["casts"] = 1,
							["critical"] = 2,
							["amount"] = 160,
							["school"] = 2,
							["criticalmin"] = 32,
							["criticalmax"] = 36,
							["hitamount"] = 92,
						},
						["Holy Wrath"] = {
							["total"] = 343,
							["hitmin"] = 98,
							["criticalamount"] = 147,
							["id"] = 2812,
							["criticalmin"] = 147,
							["targets"] = {
								["Putridus Satyr"] = {
									["total"] = 196,
									["amount"] = 196,
								},
								["Poison Sprite"] = {
									["total"] = 147,
									["amount"] = 147,
								},
							},
							["criticalmax"] = 147,
							["critical"] = 1,
							["casts"] = 1,
							["count"] = 3,
							["hit"] = 2,
							["school"] = 2,
							["hitmax"] = 98,
							["amount"] = 343,
							["hitamount"] = 196,
						},
					},
					["damagetaken"] = 610,
					["id"] = "0x00000000000447DB",
					["damagetakenspells"] = {
						["Melee"] = {
							["total"] = 1267,
							["hitmin"] = 118,
							["id"] = 6603,
							["ABSORB"] = 4,
							["blocked"] = 50,
							["PARRY"] = 6,
							["amount"] = 610,
							["sources"] = {
								["Deeprot Stomper"] = {
									["total"] = 175,
									["amount"] = 175,
								},
								["Poison Sprite"] = {
									["total"] = 0,
									["amount"] = 0,
								},
								["Putridus Satyr"] = {
									["total"] = 925,
									["amount"] = 268,
								},
								["Corruptor"] = {
									["total"] = 167,
									["amount"] = 167,
								},
							},
							["count"] = 15,
							["hit"] = 4,
							["school"] = 1,
							["hitmax"] = 175,
							["MISS"] = 1,
							["hitamount"] = 610,
						},
						["Sinister Strike"] = {
							["sources"] = {
								["Putridus Satyr"] = {
									["total"] = 189,
									["amount"] = 0,
								},
							},
							["total"] = 189,
							["count"] = 1,
							["amount"] = 0,
							["school"] = 1,
							["ABSORB"] = 1,
							["casts"] = 1,
							["id"] = 15667,
						},
					},
					["overkill"] = 228,
					["name"] = "Myrony",
					["ccdone"] = 6,
					["manaspells"] = {
						[84627] = 315,
						[31930] = 145,
					},
					["mana"] = 460,
					["totaldamage"] = 4163,
				}, -- [5]
				{
					["last"] = 10361.643,
					["name"] = "Cat",
					["flag"] = 4370,
					["class"] = "PET",
					["id"] = "0xF142F90400000004",
					["time"] = 0,
				}, -- [6]
				{
					["last"] = 10361.643,
					["name"] = "Haagroon",
					["flag"] = 4369,
					["class"] = "PET",
					["id"] = "0xF143011D00000005",
					["time"] = 0,
				}, -- [7]
			},
			["type"] = "party",
			["damagetaken"] = 1653,
			["ccdone"] = 12,
			["etotaldamage"] = 2499,
			["overheal"] = 1107,
			["overkill"] = 525,
			["edamagetaken"] = 16020,
			["heal"] = 1107,
			["name"] = "Deeprot Stomper (3)",
			["mobname"] = "Deeprot Stomper",
			["starttime"] = 1689857225,
			["edamage"] = 1653,
			["last_action"] = 1689857246,
			["endtime"] = 1689857247,
		}, -- [13]
		{
			["mana"] = 2447,
			["starttime"] = 1689857161,
			["enemies"] = {
				{
					["damagespells"] = {
						[13446] = {
							["school"] = 1,
							["total"] = 207,
							["targets"] = {
								["Myrony"] = {
									["total"] = 207,
									["amount"] = 207,
								},
							},
							["amount"] = 207,
						},
						[11876] = {
							["school"] = 1,
							["total"] = 641,
							["targets"] = {
								["Beardedrasta"] = {
									["total"] = 251,
									["amount"] = 251,
								},
								["Fragrance"] = {
									["total"] = 186,
									["amount"] = 186,
								},
								["Myrony"] = {
									["total"] = 204,
									["amount"] = 116,
								},
							},
							["amount"] = 553,
						},
						[6603] = {
							["school"] = 1,
							["total"] = 1388,
							["targets"] = {
								["Nianhong"] = {
									["total"] = 164,
									["amount"] = 164,
								},
								["Beardedrasta"] = {
									["total"] = 220,
									["amount"] = 220,
								},
								["Fragrance"] = {
									["total"] = 345,
									["amount"] = 345,
								},
								["Myrony"] = {
									["total"] = 659,
									["amount"] = 151,
								},
							},
							["amount"] = 880,
						},
					},
					["damagetaken"] = 9100,
					["flag"] = 2632,
					["class"] = "MONSTER",
					["damagetakenspells"] = {
						[16827] = {
							["school"] = 1,
							["total"] = 340,
							["sources"] = {
								["Macius"] = {
									["total"] = 340,
									["amount"] = 340,
								},
							},
							["amount"] = 340,
						},
						[25742] = {
							["school"] = 2,
							["total"] = 339,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 234,
									["amount"] = 234,
								},
								["Myrony"] = {
									["total"] = 105,
									["amount"] = 105,
								},
							},
							["amount"] = 339,
						},
						[35395] = {
							["school"] = 1,
							["total"] = 1880,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 1665,
									["amount"] = 1665,
								},
								["Myrony"] = {
									["total"] = 215,
									["amount"] = 215,
								},
							},
							["amount"] = 1880,
						},
						[53595] = {
							["school"] = 1,
							["total"] = 95,
							["sources"] = {
								["Myrony"] = {
									["total"] = 95,
									["amount"] = 95,
								},
							},
							["amount"] = 95,
						},
						[6603] = {
							["sources"] = {
								["Macius"] = {
									["total"] = 615,
									["amount"] = 615,
								},
								["Fragrance"] = {
									["total"] = 944,
									["overkill"] = 220,
									["amount"] = 944,
								},
								["Myrony"] = {
									["total"] = 679,
									["amount"] = 679,
								},
							},
							["amount"] = 2238,
							["school"] = 1,
							["total"] = 2238,
							["overkill"] = 220,
						},
						[3044] = {
							["school"] = 64,
							["total"] = 553,
							["sources"] = {
								["Macius"] = {
									["total"] = 553,
									["amount"] = 553,
								},
							},
							["amount"] = 553,
						},
						[2643] = {
							["school"] = 1,
							["total"] = 359,
							["sources"] = {
								["Macius"] = {
									["total"] = 359,
									["amount"] = 359,
								},
							},
							["amount"] = 359,
						},
						[53385] = {
							["school"] = 1,
							["total"] = 219,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 219,
									["amount"] = 219,
								},
							},
							["amount"] = 219,
						},
						[85256] = {
							["school"] = 1,
							["total"] = 634,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 634,
									["amount"] = 634,
								},
							},
							["amount"] = 634,
						},
						[96172] = {
							["school"] = 2,
							["total"] = 6,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 6,
									["amount"] = 6,
								},
							},
							["amount"] = 6,
						},
						[2812] = {
							["school"] = 2,
							["total"] = 69,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 69,
									["amount"] = 69,
								},
							},
							["amount"] = 69,
						},
						[31935] = {
							["school"] = 2,
							["total"] = 315,
							["sources"] = {
								["Myrony"] = {
									["total"] = 315,
									["amount"] = 315,
								},
							},
							["amount"] = 315,
						},
						[20187] = {
							["school"] = 2,
							["total"] = 728,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 372,
									["amount"] = 372,
								},
								["Myrony"] = {
									["total"] = 356,
									["amount"] = 356,
								},
							},
							["amount"] = 728,
						},
						[53301] = {
							["school"] = 4,
							["total"] = 316,
							["sources"] = {
								["Macius"] = {
									["total"] = 316,
									["amount"] = 316,
								},
							},
							["amount"] = 316,
						},
						[7294] = {
							["school"] = 2,
							["total"] = 65,
							["sources"] = {
								["Nianhong"] = {
									["total"] = 13,
									["amount"] = 13,
								},
								["Beardedrasta"] = {
									["total"] = 13,
									["amount"] = 13,
								},
								["Fragrance"] = {
									["total"] = 26,
									["amount"] = 26,
								},
								["Myrony"] = {
									["total"] = 13,
									["amount"] = 13,
								},
							},
							["amount"] = 65,
						},
						[88263] = {
							["school"] = 2,
							["total"] = 577,
							["sources"] = {
								["Myrony"] = {
									["total"] = 577,
									["amount"] = 577,
								},
							},
							["amount"] = 577,
						},
						[56641] = {
							["school"] = 1,
							["total"] = 367,
							["sources"] = {
								["Macius"] = {
									["total"] = 367,
									["amount"] = 367,
								},
							},
							["amount"] = 367,
						},
					},
					["name"] = "Deeprot Stomper",
					["totaldamage"] = 2236,
					["totaldamagetaken"] = 9100,
					["id"] = "0xF130335500000084",
					["damage"] = 1640,
				}, -- [1]
				{
					["damagespells"] = {
						[12540] = {
							["school"] = 1,
							["total"] = 13,
							["targets"] = {
								["Myrony"] = {
									["total"] = 13,
									["amount"] = 13,
								},
							},
							["amount"] = 13,
						},
						[15667] = {
							["school"] = 1,
							["total"] = 225,
							["targets"] = {
								["Nianhong"] = {
									["total"] = 225,
									["amount"] = 225,
								},
							},
							["amount"] = 225,
						},
						[6603] = {
							["school"] = 1,
							["total"] = 2040,
							["targets"] = {
								["Beardedrasta"] = {
									["total"] = 1066,
									["amount"] = 620,
								},
								["Nianhong"] = {
									["total"] = 172,
									["amount"] = 172,
								},
								["Myrony"] = {
									["total"] = 802,
									["amount"] = 458,
								},
							},
							["amount"] = 1250,
						},
					},
					["damagetaken"] = 9079,
					["id"] = "0xF1302E0E0000004E",
					["class"] = "MONSTER",
					["damagetakenspells"] = {
						[16827] = {
							["school"] = 1,
							["total"] = 342,
							["sources"] = {
								["Macius"] = {
									["total"] = 342,
									["amount"] = 342,
								},
							},
							["amount"] = 342,
						},
						[25742] = {
							["school"] = 2,
							["total"] = 307,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 208,
									["amount"] = 208,
								},
								["Myrony"] = {
									["total"] = 99,
									["amount"] = 99,
								},
							},
							["amount"] = 307,
						},
						[35395] = {
							["school"] = 1,
							["total"] = 1496,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 1274,
									["amount"] = 1274,
								},
								["Myrony"] = {
									["total"] = 222,
									["amount"] = 222,
								},
							},
							["amount"] = 1496,
						},
						[53595] = {
							["school"] = 1,
							["total"] = 23,
							["sources"] = {
								["Myrony"] = {
									["total"] = 23,
									["amount"] = 23,
								},
							},
							["amount"] = 23,
						},
						[6603] = {
							["sources"] = {
								["Macius"] = {
									["total"] = 279,
									["overkill"] = 38,
									["amount"] = 279,
								},
								["Fragrance"] = {
									["total"] = 1053,
									["amount"] = 1053,
								},
								["Myrony"] = {
									["total"] = 547,
									["amount"] = 547,
								},
							},
							["amount"] = 1879,
							["school"] = 1,
							["total"] = 1879,
							["overkill"] = 38,
						},
						[2643] = {
							["sources"] = {
								["Macius"] = {
									["total"] = 636,
									["overkill"] = 161,
									["amount"] = 636,
								},
							},
							["amount"] = 636,
							["school"] = 1,
							["total"] = 636,
							["overkill"] = 161,
						},
						[53385] = {
							["school"] = 1,
							["total"] = 362,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 362,
									["amount"] = 362,
								},
							},
							["amount"] = 362,
						},
						[88263] = {
							["school"] = 2,
							["total"] = 608,
							["sources"] = {
								["Myrony"] = {
									["total"] = 608,
									["amount"] = 608,
								},
							},
							["amount"] = 608,
						},
						[96172] = {
							["school"] = 2,
							["total"] = 4,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 4,
									["amount"] = 4,
								},
							},
							["amount"] = 4,
						},
						[2812] = {
							["school"] = 2,
							["total"] = 138,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 138,
									["amount"] = 138,
								},
							},
							["amount"] = 138,
						},
						[31935] = {
							["school"] = 2,
							["total"] = 317,
							["sources"] = {
								["Myrony"] = {
									["total"] = 317,
									["amount"] = 317,
								},
							},
							["amount"] = 317,
						},
						[20187] = {
							["school"] = 2,
							["total"] = 325,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 124,
									["amount"] = 124,
								},
								["Myrony"] = {
									["total"] = 201,
									["amount"] = 201,
								},
							},
							["amount"] = 325,
						},
						[172] = {
							["school"] = 32,
							["total"] = 44,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 44,
									["amount"] = 44,
								},
							},
							["amount"] = 44,
						},
						[75] = {
							["school"] = 1,
							["total"] = 97,
							["sources"] = {
								["Macius"] = {
									["total"] = 97,
									["amount"] = 97,
								},
							},
							["amount"] = 97,
						},
						[30108] = {
							["school"] = 32,
							["total"] = 49,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 49,
									["amount"] = 49,
								},
							},
							["amount"] = 49,
						},
						[7294] = {
							["school"] = 2,
							["total"] = 91,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 39,
									["amount"] = 39,
								},
								["Nianhong"] = {
									["total"] = 13,
									["amount"] = 13,
								},
								["Myrony"] = {
									["total"] = 39,
									["amount"] = 39,
								},
							},
							["amount"] = 91,
						},
						[879] = {
							["school"] = 2,
							["total"] = 2086,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 2086,
									["amount"] = 2086,
								},
							},
							["amount"] = 2086,
						},
						[56641] = {
							["school"] = 1,
							["total"] = 275,
							["sources"] = {
								["Macius"] = {
									["total"] = 275,
									["amount"] = 275,
								},
							},
							["amount"] = 275,
						},
					},
					["totaldamage"] = 2278,
					["name"] = "Putridus Satyr",
					["totaldamagetaken"] = 9079,
					["flag"] = 2632,
					["damage"] = 1488,
				}, -- [2]
				{
					["damagespells"] = {
						[6603] = {
							["school"] = 1,
							["total"] = 592,
							["targets"] = {
								["Beardedrasta"] = {
									["total"] = 240,
									["amount"] = 240,
								},
								["Nianhong"] = {
									["total"] = 191,
									["amount"] = 191,
								},
								["Myrony"] = {
									["total"] = 161,
									["amount"] = 161,
								},
							},
							["amount"] = 592,
						},
					},
					["damagetaken"] = 842,
					["id"] = "0xF1302FB900000047",
					["class"] = "MONSTER",
					["damagetakenspells"] = {
						[2812] = {
							["school"] = 2,
							["total"] = 69,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 69,
									["amount"] = 69,
								},
							},
							["amount"] = 69,
						},
						[31935] = {
							["school"] = 2,
							["total"] = 610,
							["sources"] = {
								["Myrony"] = {
									["total"] = 610,
									["amount"] = 610,
								},
							},
							["amount"] = 610,
						},
						[75] = {
							["sources"] = {
								["Macius"] = {
									["total"] = 108,
									["overkill"] = 9,
									["amount"] = 108,
								},
							},
							["amount"] = 108,
							["school"] = 1,
							["total"] = 108,
							["overkill"] = 9,
						},
						[25742] = {
							["school"] = 2,
							["total"] = 16,
							["sources"] = {
								["Myrony"] = {
									["total"] = 16,
									["amount"] = 16,
								},
							},
							["amount"] = 16,
						},
						[7294] = {
							["school"] = 2,
							["total"] = 39,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 13,
									["amount"] = 13,
								},
								["Nianhong"] = {
									["total"] = 13,
									["amount"] = 13,
								},
								["Myrony"] = {
									["total"] = 13,
									["amount"] = 13,
								},
							},
							["amount"] = 39,
						},
					},
					["totaldamage"] = 592,
					["name"] = "Corruptor",
					["totaldamagetaken"] = 842,
					["flag"] = 2632,
					["damage"] = 592,
				}, -- [3]
				{
					["id"] = "0xF1302FB80000004B",
					["name"] = "Poison Sprite",
					["totaldamagetaken"] = 904,
					["flag"] = 2632,
					["class"] = "MONSTER",
					["damagetaken"] = 904,
					["damagetakenspells"] = {
						[6603] = {
							["school"] = 1,
							["total"] = 162,
							["sources"] = {
								["Myrony"] = {
									["total"] = 106,
									["amount"] = 106,
								},
								["Macius"] = {
									["total"] = 56,
									["amount"] = 56,
								},
							},
							["amount"] = 162,
						},
						[31935] = {
							["school"] = 2,
							["total"] = 341,
							["sources"] = {
								["Myrony"] = {
									["total"] = 341,
									["amount"] = 341,
								},
							},
							["amount"] = 341,
						},
						[25742] = {
							["school"] = 2,
							["total"] = 37,
							["sources"] = {
								["Myrony"] = {
									["total"] = 37,
									["amount"] = 37,
								},
							},
							["amount"] = 37,
						},
						[56641] = {
							["sources"] = {
								["Macius"] = {
									["total"] = 93,
									["overkill"] = 71,
									["amount"] = 93,
								},
							},
							["amount"] = 93,
							["school"] = 1,
							["total"] = 93,
							["overkill"] = 71,
						},
						[16827] = {
							["school"] = 1,
							["total"] = 84,
							["sources"] = {
								["Macius"] = {
									["total"] = 84,
									["amount"] = 84,
								},
							},
							["amount"] = 84,
						},
						[20187] = {
							["school"] = 2,
							["total"] = 187,
							["sources"] = {
								["Myrony"] = {
									["total"] = 187,
									["amount"] = 187,
								},
							},
							["amount"] = 187,
						},
					},
				}, -- [4]
			},
			["totaldamage"] = 19925,
			["time"] = 44,
			["ccdone"] = 7,
			["totaldamagetaken"] = 5106,
			["etotaldamagetaken"] = 19925,
			["damage"] = 19925,
			["players"] = {
				{
					["ccdonespells"] = {
						[2812] = {
							["count"] = 3,
							["targets"] = {
								["Putridus Satyr"] = 2,
								["Corruptor"] = 1,
							},
						},
					},
					["last"] = 10332.155,
					["flag"] = 1298,
					["mana"] = 828,
					["auras"] = {
						[2812] = {
							["type"] = "DEBUFF",
							["count"] = 3,
							["school"] = 2,
							["targets"] = {
								["Putridus Satyr"] = {
									["uptime"] = 3,
									["count"] = 2,
								},
								["Corruptor"] = {
									["uptime"] = 1,
									["count"] = 1,
								},
							},
							["uptime"] = 3,
						},
						[59578] = {
							["type"] = "BUFF",
							["count"] = 2,
							["school"] = 1,
							["uptime"] = 3,
						},
						[94686] = {
							["type"] = "BUFF",
							["count"] = 2,
							["school"] = 1,
							["uptime"] = 19,
						},
						[89906] = {
							["type"] = "BUFF",
							["count"] = 2,
							["school"] = 2,
							["refresh"] = 2,
							["uptime"] = 37,
						},
						[93435] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 1,
							["uptime"] = 17,
						},
					},
					["role"] = "DAMAGER",
					["time"] = 36.61,
					["totaldamagetaken"] = 531,
					["damage"] = 9487,
					["damagespells"] = {
						["Exorcism"] = {
							["total"] = 2086,
							["criticalamount"] = 2086,
							["id"] = 879,
							["targets"] = {
								["Putridus Satyr"] = {
									["total"] = 2086,
									["amount"] = 2086,
								},
							},
							["casts"] = 2,
							["critical"] = 2,
							["amount"] = 2086,
							["school"] = 2,
							["criticalmin"] = 1032,
							["criticalmax"] = 1054,
							["count"] = 2,
						},
						["Melee"] = {
							["DODGE"] = 1,
							["total"] = 1997,
							["hitmin"] = 175,
							["criticalamount"] = 412,
							["id"] = 6603,
							["criticalmin"] = 412,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 944,
									["overkill"] = 220,
									["amount"] = 944,
								},
								["Putridus Satyr"] = {
									["total"] = 1053,
									["amount"] = 1053,
								},
							},
							["overkill"] = 220,
							["critical"] = 1,
							["criticalmax"] = 412,
							["count"] = 10,
							["hit"] = 8,
							["school"] = 1,
							["hitmax"] = 220,
							["amount"] = 1997,
							["hitamount"] = 1585,
						},
						["Retribution Aura"] = {
							["total"] = 26,
							["hitmin"] = 13,
							["id"] = 7294,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 26,
									["amount"] = 26,
								},
							},
							["casts"] = 1,
							["count"] = 2,
							["hit"] = 2,
							["school"] = 2,
							["hitmax"] = 13,
							["amount"] = 26,
							["hitamount"] = 26,
						},
						["Divine Storm"] = {
							["total"] = 581,
							["hitmin"] = 180,
							["id"] = 53385,
							["targets"] = {
								["Putridus Satyr"] = {
									["total"] = 362,
									["amount"] = 362,
								},
								["Deeprot Stomper"] = {
									["total"] = 219,
									["amount"] = 219,
								},
							},
							["casts"] = 1,
							["count"] = 3,
							["hit"] = 3,
							["school"] = 1,
							["hitmax"] = 219,
							["amount"] = 581,
							["hitamount"] = 581,
						},
						["Holy Wrath"] = {
							["total"] = 276,
							["hitmin"] = 69,
							["id"] = 2812,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 69,
									["amount"] = 69,
								},
								["Corruptor"] = {
									["total"] = 69,
									["amount"] = 69,
								},
								["Putridus Satyr"] = {
									["total"] = 138,
									["amount"] = 138,
								},
							},
							["casts"] = 1,
							["count"] = 4,
							["hit"] = 4,
							["school"] = 2,
							["hitmax"] = 69,
							["amount"] = 276,
							["hitamount"] = 276,
						},
						["Seal of Righteousness"] = {
							["total"] = 442,
							["hitmin"] = 26,
							["criticalamount"] = 156,
							["id"] = 25742,
							["criticalmin"] = 52,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 234,
									["amount"] = 234,
								},
								["Putridus Satyr"] = {
									["total"] = 208,
									["amount"] = 208,
								},
							},
							["criticalmax"] = 52,
							["critical"] = 3,
							["casts"] = 1,
							["count"] = 14,
							["hit"] = 11,
							["school"] = 2,
							["hitmax"] = 26,
							["amount"] = 442,
							["hitamount"] = 286,
						},
						["Templar's Verdict"] = {
							["total"] = 634,
							["hitmin"] = 634,
							["id"] = 85256,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 634,
									["amount"] = 634,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 1,
							["hitmax"] = 634,
							["amount"] = 634,
							["hitamount"] = 634,
						},
						["Hand of Light"] = {
							["total"] = 10,
							["hitmin"] = 1,
							["id"] = 96172,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 6,
									["amount"] = 6,
								},
								["Putridus Satyr"] = {
									["total"] = 4,
									["amount"] = 4,
								},
							},
							["casts"] = 1,
							["count"] = 10,
							["hit"] = 10,
							["school"] = 2,
							["hitmax"] = 1,
							["amount"] = 10,
							["hitamount"] = 10,
						},
						["Crusader Strike"] = {
							["total"] = 2939,
							["hitmin"] = 297,
							["criticalamount"] = 1988,
							["id"] = 35395,
							["hitmax"] = 328,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 1665,
									["amount"] = 1665,
								},
								["Putridus Satyr"] = {
									["total"] = 1274,
									["amount"] = 1274,
								},
							},
							["count"] = 6,
							["hit"] = 3,
							["casts"] = 6,
							["critical"] = 3,
							["amount"] = 2939,
							["school"] = 1,
							["criticalmin"] = 598,
							["criticalmax"] = 714,
							["hitamount"] = 951,
						},
						["Judgement of Righteousness"] = {
							["total"] = 496,
							["hitmin"] = 124,
							["id"] = 20187,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 372,
									["amount"] = 372,
								},
								["Putridus Satyr"] = {
									["total"] = 124,
									["amount"] = 124,
								},
							},
							["casts"] = 4,
							["count"] = 4,
							["hit"] = 4,
							["school"] = 2,
							["hitmax"] = 124,
							["amount"] = 496,
							["hitamount"] = 496,
						},
					},
					["damagetakenspells"] = {
						["Melee"] = {
							["total"] = 345,
							["hitmin"] = 160,
							["id"] = 6603,
							["sources"] = {
								["Deeprot Stomper"] = {
									["total"] = 345,
									["amount"] = 345,
								},
							},
							["count"] = 2,
							["hit"] = 2,
							["school"] = 1,
							["hitmax"] = 185,
							["amount"] = 345,
							["hitamount"] = 345,
						},
						["War Stomp"] = {
							["total"] = 186,
							["hitmin"] = 186,
							["id"] = 11876,
							["sources"] = {
								["Deeprot Stomper"] = {
									["total"] = 186,
									["amount"] = 186,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 1,
							["hitmax"] = 186,
							["amount"] = 186,
							["hitamount"] = 186,
						},
					},
					["damagetaken"] = 531,
					["id"] = "0x0000000000048007",
					["healspells"] = {
						[54172] = {
							["overheal"] = 187,
							["max"] = 23,
							["targets"] = {
								["Cat"] = {
									["overheal"] = 46,
									["amount"] = 0,
								},
								["Myrony"] = {
									["overheal"] = 0,
									["amount"] = 23,
								},
								["Beardedrasta"] = {
									["overheal"] = 57,
									["amount"] = 0,
								},
								["Fragrance"] = {
									["overheal"] = 22,
									["amount"] = 0,
								},
								["Macius"] = {
									["overheal"] = 62,
									["amount"] = 8,
								},
							},
							["min"] = 8,
							["casts"] = 9,
							["count"] = 9,
							["amount"] = 31,
							["school"] = 2,
							["ishot"] = true,
						},
						[635] = {
							["overheal"] = 1136,
							["count"] = 1,
							["amount"] = 531,
							["school"] = 2,
							["max"] = 531,
							["targets"] = {
								["Fragrance"] = {
									["overheal"] = 1136,
									["amount"] = 531,
								},
							},
							["min"] = 531,
						},
					},
					["overkill"] = 220,
					["overheal"] = 1323,
					["heal"] = 562,
					["name"] = "Fragrance",
					["ccdone"] = 3,
					["class"] = "PALADIN",
					["manaspells"] = {
						[89906] = 828,
					},
					["totaldamage"] = 9487,
				}, -- [1]
				{
					["last"] = 10334.585,
					["flag"] = 1298,
					["class"] = "PRIEST",
					["auras"] = {
						[7294] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 2,
							["uptime"] = 43,
						},
						[6788] = {
							["type"] = "DEBUFF",
							["count"] = 2,
							["school"] = 2,
							["targets"] = {
								["Myrony"] = {
									["uptime"] = 15,
									["count"] = 1,
								},
								["Beardedrasta"] = {
									["uptime"] = 15,
									["count"] = 1,
								},
							},
							["uptime"] = 24,
						},
						[139] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 2,
							["uptime"] = 12,
						},
						[93435] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 1,
							["uptime"] = 17,
						},
					},
					["absorbspells"] = {
						[17] = {
							["min"] = 88,
							["casts"] = 1,
							["count"] = 7,
							["amount"] = 1157,
							["school"] = 2,
							["targets"] = {
								["Myrony"] = 940,
								["Beardedrasta"] = 217,
							},
							["max"] = 217,
						},
					},
					["time"] = 31.67,
					["totaldamagetaken"] = 752,
					["damage"] = 39,
					["overheal"] = 1012,
					["absorb"] = 1157,
					["damagetaken"] = 752,
					["id"] = "0x00000000000467C0",
					["healspells"] = {
						[2061] = {
							["overheal"] = 415,
							["count"] = 1,
							["amount"] = 692,
							["school"] = 2,
							["max"] = 692,
							["targets"] = {
								["Beardedrasta"] = {
									["overheal"] = 415,
									["amount"] = 692,
								},
							},
							["min"] = 692,
						},
						[63544] = {
							["overheal"] = 0,
							["count"] = 4,
							["amount"] = 240,
							["school"] = 2,
							["max"] = 67,
							["targets"] = {
								["Beardedrasta"] = {
									["overheal"] = 0,
									["amount"] = 110,
								},
								["Nianhong"] = {
									["overheal"] = 0,
									["amount"] = 63,
								},
								["Myrony"] = {
									["overheal"] = 0,
									["amount"] = 67,
								},
							},
							["min"] = 55,
						},
						[56160] = {
							["overheal"] = 0,
							["count"] = 2,
							["amount"] = 434,
							["school"] = 2,
							["max"] = 239,
							["targets"] = {
								["Myrony"] = {
									["overheal"] = 0,
									["amount"] = 239,
								},
								["Beardedrasta"] = {
									["overheal"] = 0,
									["amount"] = 195,
								},
							},
							["min"] = 195,
						},
						[139] = {
							["overheal"] = 597,
							["max"] = 168,
							["targets"] = {
								["Beardedrasta"] = {
									["overheal"] = 414,
									["amount"] = 138,
								},
								["Nianhong"] = {
									["overheal"] = 0,
									["amount"] = 636,
								},
								["Myrony"] = {
									["overheal"] = 183,
									["amount"] = 489,
								},
							},
							["min"] = 138,
							["casts"] = 4,
							["count"] = 12,
							["amount"] = 1263,
							["school"] = 2,
							["ishot"] = true,
						},
					},
					["damagetakenspells"] = {
						["Melee"] = {
							["total"] = 527,
							["hitmin"] = 164,
							["id"] = 6603,
							["sources"] = {
								["Deeprot Stomper"] = {
									["total"] = 164,
									["amount"] = 164,
								},
								["Corruptor"] = {
									["total"] = 191,
									["amount"] = 191,
								},
								["Putridus Satyr"] = {
									["total"] = 172,
									["amount"] = 172,
								},
							},
							["count"] = 3,
							["hit"] = 3,
							["school"] = 1,
							["hitmax"] = 191,
							["amount"] = 527,
							["hitamount"] = 527,
						},
						["Sinister Strike"] = {
							["total"] = 225,
							["hitmin"] = 225,
							["id"] = 15667,
							["sources"] = {
								["Putridus Satyr"] = {
									["total"] = 225,
									["amount"] = 225,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 1,
							["hitmax"] = 225,
							["amount"] = 225,
							["hitamount"] = 225,
						},
					},
					["heal"] = 2629,
					["name"] = "Nianhong",
					["damagespells"] = {
						["Retribution Aura"] = {
							["total"] = 39,
							["hitmin"] = 13,
							["id"] = 7294,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 13,
									["amount"] = 13,
								},
								["Corruptor"] = {
									["total"] = 13,
									["amount"] = 13,
								},
								["Putridus Satyr"] = {
									["total"] = 13,
									["amount"] = 13,
								},
							},
							["casts"] = 1,
							["count"] = 3,
							["hit"] = 3,
							["school"] = 2,
							["hitmax"] = 13,
							["amount"] = 39,
							["hitamount"] = 39,
						},
					},
					["totaldamage"] = 39,
					["role"] = "HEALER",
				}, -- [2]
				{
					["ccdonespells"] = {
						[31935] = {
							["count"] = 4,
							["targets"] = {
								["Deeprot Stomper"] = 1,
								["Poison Sprite"] = 1,
								["Corruptor"] = 1,
								["Putridus Satyr"] = 1,
							},
						},
					},
					["last"] = 10335.87,
					["flag"] = 1298,
					["class"] = "PALADIN",
					["auras"] = {
						[62124] = {
							["type"] = "DEBUFF",
							["count"] = 1,
							["school"] = 2,
							["targets"] = {
								["Deeprot Stomper"] = {
									["uptime"] = 3,
									["count"] = 1,
								},
							},
							["uptime"] = 3,
						},
						[31935] = {
							["type"] = "DEBUFF",
							["count"] = 4,
							["school"] = 2,
							["targets"] = {
								["Deeprot Stomper"] = {
									["uptime"] = 3,
									["count"] = 1,
								},
								["Poison Sprite"] = {
									["uptime"] = 3,
									["count"] = 1,
								},
								["Corruptor"] = {
									["uptime"] = 3,
									["count"] = 1,
								},
								["Putridus Satyr"] = {
									["uptime"] = 3,
									["count"] = 1,
								},
							},
							["uptime"] = 6,
						},
						[31790] = {
							["type"] = "DEBUFF",
							["count"] = 1,
							["school"] = 1,
							["targets"] = {
								["Poison Sprite"] = {
									["uptime"] = 3,
									["count"] = 1,
								},
							},
							["uptime"] = 3,
						},
						[31930] = {
							["type"] = "BUFF",
							["count"] = 4,
							["school"] = 2,
							["uptime"] = 31,
						},
						[17] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 2,
							["uptime"] = 15,
						},
						[139] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 2,
							["uptime"] = 12,
						},
						[93435] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 1,
							["uptime"] = 17,
						},
						[68055] = {
							["type"] = "DEBUFF",
							["count"] = 4,
							["school"] = 2,
							["targets"] = {
								["Deeprot Stomper"] = {
									["uptime"] = 15,
									["count"] = 2,
								},
								["Poison Sprite"] = {
									["uptime"] = 1,
									["count"] = 1,
								},
								["Putridus Satyr"] = {
									["uptime"] = 6,
									["count"] = 1,
								},
							},
							["uptime"] = 22,
						},
					},
					["totaldamage"] = 5721,
					["time"] = 34.78000000000001,
					["totaldamagetaken"] = 2046,
					["damage"] = 5721,
					["damagespells"] = {
						["Melee"] = {
							["total"] = 1332,
							["hitmin"] = 101,
							["id"] = 6603,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 679,
									["amount"] = 679,
								},
								["Poison Sprite"] = {
									["total"] = 106,
									["amount"] = 106,
								},
								["Putridus Satyr"] = {
									["total"] = 547,
									["amount"] = 547,
								},
							},
							["count"] = 12,
							["hit"] = 12,
							["school"] = 1,
							["hitmax"] = 128,
							["amount"] = 1332,
							["hitamount"] = 1332,
						},
						["Avenger's Shield"] = {
							["total"] = 1583,
							["hitmin"] = 315,
							["criticalamount"] = 610,
							["id"] = 31935,
							["hitmax"] = 341,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 315,
									["amount"] = 315,
								},
								["Poison Sprite"] = {
									["total"] = 341,
									["amount"] = 341,
								},
								["Corruptor"] = {
									["total"] = 610,
									["amount"] = 610,
								},
								["Putridus Satyr"] = {
									["total"] = 317,
									["amount"] = 317,
								},
							},
							["count"] = 4,
							["hit"] = 3,
							["casts"] = 2,
							["critical"] = 1,
							["amount"] = 1583,
							["school"] = 2,
							["criticalmin"] = 610,
							["criticalmax"] = 610,
							["hitamount"] = 973,
						},
						["Seal of Righteousness"] = {
							["total"] = 257,
							["hitmin"] = 16,
							["id"] = 25742,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 105,
									["amount"] = 105,
								},
								["Poison Sprite"] = {
									["total"] = 37,
									["amount"] = 37,
								},
								["Corruptor"] = {
									["total"] = 16,
									["amount"] = 16,
								},
								["Putridus Satyr"] = {
									["total"] = 99,
									["amount"] = 99,
								},
							},
							["casts"] = 1,
							["count"] = 14,
							["hit"] = 14,
							["school"] = 2,
							["hitmax"] = 21,
							["amount"] = 257,
							["hitamount"] = 257,
						},
						["Hammer of the Righteous (Physical)"] = {
							["total"] = 118,
							["hitmin"] = 23,
							["id"] = 53595,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 95,
									["amount"] = 95,
								},
								["Putridus Satyr"] = {
									["total"] = 23,
									["amount"] = 23,
								},
							},
							["blocked"] = 9,
							["casts"] = 1,
							["count"] = 4,
							["hit"] = 4,
							["school"] = 1,
							["hitmax"] = 36,
							["amount"] = 118,
							["hitamount"] = 118,
						},
						["Hammer of the Righteous"] = {
							["total"] = 1185,
							["hitmin"] = 137,
							["criticalamount"] = 451,
							["id"] = 88263,
							["criticalmin"] = 222,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 577,
									["amount"] = 577,
								},
								["Putridus Satyr"] = {
									["total"] = 608,
									["amount"] = 608,
								},
							},
							["criticalmax"] = 229,
							["critical"] = 2,
							["casts"] = 7,
							["count"] = 7,
							["hit"] = 5,
							["school"] = 2,
							["hitmax"] = 157,
							["amount"] = 1185,
							["hitamount"] = 734,
						},
						["Crusader Strike"] = {
							["total"] = 437,
							["hitmin"] = 215,
							["id"] = 35395,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 215,
									["amount"] = 215,
								},
								["Putridus Satyr"] = {
									["total"] = 222,
									["amount"] = 222,
								},
							},
							["casts"] = 2,
							["count"] = 2,
							["hit"] = 2,
							["school"] = 1,
							["hitmax"] = 222,
							["amount"] = 437,
							["hitamount"] = 437,
						},
						["Retribution Aura"] = {
							["total"] = 65,
							["hitmin"] = 13,
							["id"] = 7294,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 13,
									["amount"] = 13,
								},
								["Putridus Satyr"] = {
									["total"] = 39,
									["amount"] = 39,
								},
								["Corruptor"] = {
									["total"] = 13,
									["amount"] = 13,
								},
							},
							["casts"] = 1,
							["count"] = 5,
							["hit"] = 5,
							["school"] = 2,
							["hitmax"] = 13,
							["amount"] = 65,
							["hitamount"] = 65,
						},
						["Judgement of Righteousness"] = {
							["total"] = 744,
							["hitmin"] = 163,
							["id"] = 20187,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 356,
									["amount"] = 356,
								},
								["Poison Sprite"] = {
									["total"] = 187,
									["amount"] = 187,
								},
								["Putridus Satyr"] = {
									["total"] = 201,
									["amount"] = 201,
								},
							},
							["casts"] = 4,
							["count"] = 4,
							["hit"] = 4,
							["school"] = 2,
							["hitmax"] = 201,
							["amount"] = 744,
							["hitamount"] = 744,
						},
					},
					["damagetaken"] = 1106,
					["id"] = "0x00000000000447DB",
					["damagetakenspells"] = {
						["Strike"] = {
							["total"] = 207,
							["hitmin"] = 207,
							["id"] = 13446,
							["amount"] = 207,
							["sources"] = {
								["Deeprot Stomper"] = {
									["total"] = 207,
									["amount"] = 207,
								},
							},
							["casts"] = 3,
							["count"] = 3,
							["hit"] = 1,
							["school"] = 1,
							["hitmax"] = 207,
							["MISS"] = 2,
							["hitamount"] = 207,
						},
						["Melee"] = {
							["DODGE"] = 2,
							["total"] = 1622,
							["hitmin"] = 119,
							["id"] = 6603,
							["ABSORB"] = 5,
							["blocked"] = 51,
							["hitmax"] = 170,
							["PARRY"] = 9,
							["sources"] = {
								["Deeprot Stomper"] = {
									["total"] = 659,
									["amount"] = 151,
								},
								["Poison Sprite"] = {
									["total"] = 0,
									["amount"] = 0,
								},
								["Corruptor"] = {
									["total"] = 161,
									["amount"] = 161,
								},
								["Putridus Satyr"] = {
									["total"] = 802,
									["amount"] = 458,
								},
							},
							["count"] = 26,
							["amount"] = 770,
							["school"] = 1,
							["hit"] = 5,
							["MISS"] = 5,
							["hitamount"] = 770,
						},
						["Gouge"] = {
							["DODGE"] = 1,
							["total"] = 13,
							["hitmin"] = 13,
							["id"] = 12540,
							["PARRY"] = 1,
							["sources"] = {
								["Putridus Satyr"] = {
									["total"] = 13,
									["amount"] = 13,
								},
							},
							["casts"] = 3,
							["count"] = 3,
							["hit"] = 1,
							["school"] = 1,
							["hitmax"] = 13,
							["amount"] = 13,
							["hitamount"] = 13,
						},
						["War Stomp"] = {
							["total"] = 204,
							["hitmin"] = 116,
							["id"] = 11876,
							["sources"] = {
								["Deeprot Stomper"] = {
									["total"] = 204,
									["amount"] = 116,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 1,
							["hitmax"] = 116,
							["amount"] = 116,
							["hitamount"] = 116,
						},
					},
					["name"] = "Myrony",
					["ccdone"] = 4,
					["manaspells"] = {
						[84627] = 720,
						[31930] = 899,
					},
					["mana"] = 1619,
					["role"] = "TANK",
				}, -- [3]
				{
					["damagespells"] = {
						["Steady Shot"] = {
							["total"] = 735,
							["hitmin"] = 89,
							["id"] = 56641,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 367,
									["amount"] = 367,
								},
								["Poison Sprite"] = {
									["total"] = 93,
									["overkill"] = 71,
									["amount"] = 93,
								},
								["Putridus Satyr"] = {
									["total"] = 275,
									["amount"] = 275,
								},
							},
							["overkill"] = 71,
							["casts"] = 10,
							["count"] = 8,
							["hit"] = 8,
							["school"] = 1,
							["hitmax"] = 95,
							["amount"] = 735,
							["hitamount"] = 735,
						},
						["Explosive Shot (DoT)"] = {
							["total"] = 316,
							["hitmin"] = 158,
							["id"] = 53301,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 316,
									["amount"] = 316,
								},
							},
							["count"] = 2,
							["hit"] = 2,
							["school"] = 4,
							["hitmax"] = 158,
							["amount"] = 316,
							["hitamount"] = 316,
						},
						["Multi-Shot"] = {
							["criticalmin"] = 186,
							["total"] = 995,
							["hitmin"] = 83,
							["criticalamount"] = 376,
							["id"] = 2643,
							["criticalmax"] = 190,
							["targets"] = {
								["Putridus Satyr"] = {
									["total"] = 636,
									["overkill"] = 161,
									["amount"] = 636,
								},
								["Deeprot Stomper"] = {
									["total"] = 359,
									["amount"] = 359,
								},
							},
							["overkill"] = 161,
							["critical"] = 2,
							["casts"] = 3,
							["count"] = 9,
							["hit"] = 7,
							["school"] = 1,
							["hitmax"] = 99,
							["amount"] = 995,
							["hitamount"] = 619,
						},
						["Claw (Cat)"] = {
							["DODGE"] = 1,
							["hitmin"] = 84,
							["criticalmin"] = 170,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 340,
									["amount"] = 340,
								},
								["Poison Sprite"] = {
									["total"] = 84,
									["amount"] = 84,
								},
								["Putridus Satyr"] = {
									["total"] = 342,
									["amount"] = 342,
								},
							},
							["amount"] = 766,
							["MISS"] = 1,
							["total"] = 766,
							["criticalamount"] = 342,
							["id"] = 16827,
							["criticalmax"] = 172,
							["casts"] = 9,
							["hitmax"] = 86,
							["hit"] = 5,
							["school"] = 1,
							["critical"] = 2,
							["count"] = 9,
							["hitamount"] = 424,
						},
						["Auto Shot"] = {
							["total"] = 205,
							["hitmin"] = 97,
							["id"] = 75,
							["targets"] = {
								["Corruptor"] = {
									["total"] = 108,
									["overkill"] = 9,
									["amount"] = 108,
								},
								["Putridus Satyr"] = {
									["total"] = 97,
									["amount"] = 97,
								},
							},
							["overkill"] = 9,
							["casts"] = 1,
							["count"] = 2,
							["amount"] = 205,
							["school"] = 1,
							["hitmax"] = 108,
							["hit"] = 2,
							["hitamount"] = 205,
						},
						["Melee (Cat)"] = {
							["DODGE"] = 2,
							["hitmin"] = 49,
							["criticalmin"] = 98,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 615,
									["amount"] = 615,
								},
								["Poison Sprite"] = {
									["total"] = 56,
									["amount"] = 56,
								},
								["Putridus Satyr"] = {
									["total"] = 279,
									["overkill"] = 38,
									["amount"] = 279,
								},
							},
							["glancing"] = 2,
							["amount"] = 950,
							["total"] = 950,
							["criticalamount"] = 452,
							["id"] = 6603,
							["overkill"] = 38,
							["criticalmax"] = 128,
							["hitmax"] = 64,
							["hit"] = 7,
							["school"] = 1,
							["critical"] = 4,
							["count"] = 15,
							["hitamount"] = 390,
						},
						["Arcane Shot"] = {
							["total"] = 553,
							["hitmin"] = 130,
							["id"] = 3044,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 553,
									["amount"] = 553,
								},
							},
							["casts"] = 4,
							["count"] = 4,
							["hit"] = 4,
							["school"] = 64,
							["hitmax"] = 147,
							["amount"] = 553,
							["hitamount"] = 553,
						},
					},
					["last"] = 10336.321,
					["time"] = 31.26,
					["overkill"] = 279,
					["flag"] = 1298,
					["class"] = "HUNTER",
					["id"] = "0x00000000000477A3",
					["auras"] = {
						[53301] = {
							["type"] = "DEBUFF",
							["count"] = 1,
							["school"] = 4,
							["targets"] = {
								["Deeprot Stomper"] = {
									["uptime"] = 1,
									["count"] = 1,
								},
							},
							["uptime"] = 1,
						},
						[93435] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 1,
							["uptime"] = 17,
						},
					},
					["energyspells"] = {
						[91954] = 72,
					},
					["role"] = "DAMAGER",
					["name"] = "Macius",
					["totaldamage"] = 4520,
					["energy"] = 72,
					["damage"] = 4520,
				}, -- [4]
				{
					["last"] = 10320.086,
					["flag"] = 1297,
					["class"] = "WARLOCK",
					["auras"] = {
						[172] = {
							["type"] = "DEBUFF",
							["count"] = 3,
							["school"] = 32,
							["targets"] = {
								["Deeprot Stomper"] = {
									["uptime"] = 3,
									["count"] = 2,
								},
								["Putridus Satyr"] = {
									["uptime"] = 3,
									["count"] = 1,
								},
							},
							["uptime"] = 6,
						},
						[17] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 2,
							["uptime"] = 15,
						},
						[139] = {
							["type"] = "BUFF",
							["count"] = 2,
							["school"] = 2,
							["uptime"] = 13,
						},
						[93435] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 1,
							["uptime"] = 17,
						},
						[30108] = {
							["type"] = "DEBUFF",
							["count"] = 3,
							["school"] = 32,
							["targets"] = {
								["Deeprot Stomper"] = {
									["uptime"] = 3,
									["count"] = 2,
								},
								["Putridus Satyr"] = {
									["uptime"] = 3,
									["count"] = 1,
								},
							},
							["uptime"] = 6,
						},
					},
					["time"] = 3.65,
					["totaldamagetaken"] = 1777,
					["damage"] = 158,
					["damagespells"] = {
						["Corruption (DoT)"] = {
							["total"] = 44,
							["hitmin"] = 44,
							["id"] = 172,
							["targets"] = {
								["Putridus Satyr"] = {
									["total"] = 44,
									["amount"] = 44,
								},
							},
							["casts"] = 2,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 32,
							["hitmax"] = 44,
							["amount"] = 44,
							["hitamount"] = 44,
						},
						["Unstable Affliction (DoT)"] = {
							["total"] = 49,
							["hitmin"] = 49,
							["id"] = 30108,
							["targets"] = {
								["Putridus Satyr"] = {
									["total"] = 49,
									["amount"] = 49,
								},
							},
							["casts"] = 2,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 32,
							["hitmax"] = 49,
							["amount"] = 49,
							["hitamount"] = 49,
						},
						["Retribution Aura"] = {
							["total"] = 65,
							["hitmin"] = 13,
							["id"] = 7294,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 13,
									["amount"] = 13,
								},
								["Putridus Satyr"] = {
									["total"] = 39,
									["amount"] = 39,
								},
								["Corruptor"] = {
									["total"] = 13,
									["amount"] = 13,
								},
							},
							["casts"] = 1,
							["count"] = 5,
							["hit"] = 5,
							["school"] = 2,
							["hitmax"] = 13,
							["amount"] = 65,
							["hitamount"] = 65,
						},
					},
					["damagetaken"] = 1331,
					["id"] = "0x000000000004825C",
					["spec"] = 265,
					["healspells"] = {
						[63106] = {
							["overheal"] = 33,
							["count"] = 1,
							["amount"] = 0,
							["school"] = 32,
							["targets"] = {
								["Beardedrasta"] = {
									["overheal"] = 33,
									["amount"] = 0,
								},
							},
						},
					},
					["damagetakenspells"] = {
						["Melee"] = {
							["total"] = 1526,
							["hitmin"] = 188,
							["id"] = 6603,
							["ABSORB"] = 2,
							["amount"] = 1080,
							["sources"] = {
								["Deeprot Stomper"] = {
									["total"] = 220,
									["amount"] = 220,
								},
								["Putridus Satyr"] = {
									["total"] = 1066,
									["amount"] = 620,
								},
								["Corruptor"] = {
									["total"] = 240,
									["amount"] = 240,
								},
							},
							["count"] = 8,
							["hit"] = 5,
							["school"] = 1,
							["hitmax"] = 240,
							["MISS"] = 1,
							["hitamount"] = 1080,
						},
						["War Stomp"] = {
							["total"] = 251,
							["hitmin"] = 251,
							["id"] = 11876,
							["sources"] = {
								["Deeprot Stomper"] = {
									["total"] = 251,
									["amount"] = 251,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 1,
							["hitmax"] = 251,
							["amount"] = 251,
							["hitamount"] = 251,
						},
					},
					["heal"] = 0,
					["name"] = "Beardedrasta",
					["overheal"] = 33,
					["totaldamage"] = 158,
					["role"] = "DAMAGER",
				}, -- [5]
				{
					["last"] = 10306.252,
					["name"] = "Cat",
					["flag"] = 4370,
					["class"] = "PET",
					["id"] = "0xF142F90400000004",
					["time"] = 0,
				}, -- [6]
			},
			["type"] = "party",
			["damagetaken"] = 3720,
			["absorb"] = 1157,
			["energy"] = 72,
			["overheal"] = 2368,
			["overkill"] = 499,
			["edamagetaken"] = 19925,
			["heal"] = 3191,
			["name"] = "Deeprot Stomper (2)",
			["mobname"] = "Deeprot Stomper",
			["etotaldamage"] = 5106,
			["edamage"] = 3720,
			["last_action"] = 1689857205,
			["endtime"] = 1689857205,
		}, -- [14]
		{
			["mana"] = 207,
			["enemies"] = {
				{
					["damagespells"] = {
						[6603] = {
							["school"] = 1,
							["total"] = 569,
							["targets"] = {
								["Fragrance"] = {
									["total"] = 194,
									["amount"] = 194,
								},
								["Myrony"] = {
									["total"] = 375,
									["amount"] = 375,
								},
							},
							["amount"] = 569,
						},
						[13446] = {
							["school"] = 1,
							["total"] = 207,
							["targets"] = {
								["Myrony"] = {
									["total"] = 207,
									["amount"] = 207,
								},
							},
							["amount"] = 207,
						},
					},
					["damagetaken"] = 4640,
					["flag"] = 2632,
					["class"] = "MONSTER",
					["damagetakenspells"] = {
						[6603] = {
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 138,
									["amount"] = 138,
								},
								["Macius"] = {
									["total"] = 285,
									["amount"] = 285,
								},
								["Fragrance"] = {
									["total"] = 545,
									["overkill"] = 181,
									["amount"] = 545,
								},
								["Myrony"] = {
									["total"] = 212,
									["amount"] = 212,
								},
							},
							["amount"] = 1180,
							["school"] = 1,
							["total"] = 1180,
							["overkill"] = 181,
						},
						[7294] = {
							["school"] = 2,
							["total"] = 39,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 13,
									["amount"] = 13,
								},
								["Myrony"] = {
									["total"] = 26,
									["amount"] = 26,
								},
							},
							["amount"] = 39,
						},
						[16827] = {
							["school"] = 1,
							["total"] = 252,
							["sources"] = {
								["Macius"] = {
									["total"] = 252,
									["amount"] = 252,
								},
							},
							["amount"] = 252,
						},
						[3716] = {
							["school"] = 33,
							["total"] = 55,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 55,
									["amount"] = 55,
								},
							},
							["amount"] = 55,
						},
						[35395] = {
							["school"] = 1,
							["total"] = 846,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 673,
									["amount"] = 673,
								},
								["Myrony"] = {
									["total"] = 173,
									["amount"] = 173,
								},
							},
							["amount"] = 846,
						},
						[75] = {
							["school"] = 1,
							["total"] = 303,
							["sources"] = {
								["Macius"] = {
									["total"] = 303,
									["amount"] = 303,
								},
							},
							["amount"] = 303,
						},
						[25742] = {
							["sources"] = {
								["Fragrance"] = {
									["total"] = 104,
									["overkill"] = 19,
									["amount"] = 104,
								},
								["Myrony"] = {
									["total"] = 34,
									["amount"] = 34,
								},
							},
							["amount"] = 138,
							["school"] = 2,
							["total"] = 138,
							["overkill"] = 19,
						},
						[96172] = {
							["school"] = 2,
							["total"] = 2,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 2,
									["amount"] = 2,
								},
							},
							["amount"] = 2,
						},
						[3044] = {
							["school"] = 64,
							["total"] = 571,
							["sources"] = {
								["Macius"] = {
									["total"] = 571,
									["amount"] = 571,
								},
							},
							["amount"] = 571,
						},
						[56641] = {
							["school"] = 1,
							["total"] = 187,
							["sources"] = {
								["Macius"] = {
									["total"] = 187,
									["amount"] = 187,
								},
							},
							["amount"] = 187,
						},
						[30108] = {
							["school"] = 32,
							["total"] = 146,
							["sources"] = {
								["Beardedrasta"] = {
									["total"] = 146,
									["amount"] = 146,
								},
							},
							["amount"] = 146,
						},
						[53301] = {
							["school"] = 4,
							["total"] = 627,
							["sources"] = {
								["Macius"] = {
									["total"] = 627,
									["amount"] = 627,
								},
							},
							["amount"] = 627,
						},
						[20187] = {
							["school"] = 2,
							["total"] = 294,
							["sources"] = {
								["Fragrance"] = {
									["total"] = 107,
									["amount"] = 107,
								},
								["Myrony"] = {
									["total"] = 187,
									["amount"] = 187,
								},
							},
							["amount"] = 294,
						},
					},
					["name"] = "Deeprot Stomper",
					["totaldamage"] = 776,
					["totaldamagetaken"] = 4640,
					["id"] = "0xF130335500000002",
					["damage"] = 776,
				}, -- [1]
			},
			["totaldamage"] = 4640,
			["time"] = 10,
			["starttime"] = 1689857127,
			["totaldamagetaken"] = 776,
			["etotaldamagetaken"] = 4640,
			["damage"] = 4640,
			["players"] = {
				{
					["last"] = 10268.639,
					["flag"] = 1298,
					["class"] = "PALADIN",
					["auras"] = {
						[93435] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 1,
							["uptime"] = 9,
						},
					},
					["totaldamage"] = 1444,
					["time"] = 9.039999999999999,
					["totaldamagetaken"] = 194,
					["damage"] = 1444,
					["damagespells"] = {
						["Seal of Righteousness"] = {
							["total"] = 104,
							["hitmin"] = 26,
							["id"] = 25742,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 104,
									["overkill"] = 19,
									["amount"] = 104,
								},
							},
							["overkill"] = 19,
							["casts"] = 1,
							["count"] = 4,
							["hit"] = 4,
							["school"] = 2,
							["hitmax"] = 26,
							["amount"] = 104,
							["hitamount"] = 104,
						},
						["Crusader Strike"] = {
							["total"] = 673,
							["hitmin"] = 321,
							["id"] = 35395,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 673,
									["amount"] = 673,
								},
							},
							["casts"] = 2,
							["count"] = 2,
							["hit"] = 2,
							["school"] = 1,
							["hitmax"] = 352,
							["amount"] = 673,
							["hitamount"] = 673,
						},
						["Melee"] = {
							["total"] = 545,
							["hitmin"] = 146,
							["id"] = 6603,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 545,
									["overkill"] = 181,
									["amount"] = 545,
								},
							},
							["overkill"] = 181,
							["blocked"] = 62,
							["count"] = 3,
							["hit"] = 3,
							["school"] = 1,
							["hitmax"] = 218,
							["amount"] = 545,
							["hitamount"] = 545,
						},
						["Hand of Light"] = {
							["total"] = 2,
							["hitmin"] = 1,
							["id"] = 96172,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 2,
									["amount"] = 2,
								},
							},
							["casts"] = 1,
							["count"] = 2,
							["hit"] = 2,
							["school"] = 2,
							["hitmax"] = 1,
							["amount"] = 2,
							["hitamount"] = 2,
						},
						["Retribution Aura"] = {
							["total"] = 13,
							["hitmin"] = 13,
							["id"] = 7294,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 13,
									["amount"] = 13,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 2,
							["hitmax"] = 13,
							["amount"] = 13,
							["hitamount"] = 13,
						},
						["Judgement of Righteousness"] = {
							["total"] = 107,
							["hitmin"] = 107,
							["id"] = 20187,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 107,
									["amount"] = 107,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 2,
							["hitmax"] = 107,
							["amount"] = 107,
							["hitamount"] = 107,
						},
					},
					["damagetaken"] = 194,
					["id"] = "0x0000000000048007",
					["damagetakenspells"] = {
						["Melee"] = {
							["total"] = 194,
							["hitmin"] = 194,
							["id"] = 6603,
							["sources"] = {
								["Deeprot Stomper"] = {
									["total"] = 194,
									["amount"] = 194,
								},
							},
							["count"] = 1,
							["hit"] = 1,
							["school"] = 1,
							["hitmax"] = 194,
							["amount"] = 194,
							["hitamount"] = 194,
						},
					},
					["overkill"] = 200,
					["name"] = "Fragrance",
					["manaspells"] = {
						[89906] = 207,
					},
					["mana"] = 207,
					["role"] = "DAMAGER",
				}, -- [1]
				{
					["damagespells"] = {
						["Steady Shot"] = {
							["total"] = 187,
							["hitmin"] = 93,
							["id"] = 56641,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 187,
									["amount"] = 187,
								},
							},
							["casts"] = 2,
							["count"] = 2,
							["hit"] = 2,
							["school"] = 1,
							["hitmax"] = 94,
							["amount"] = 187,
							["hitamount"] = 187,
						},
						["Claw (Cat)"] = {
							["criticalmin"] = 168,
							["total"] = 252,
							["hitmin"] = 84,
							["criticalamount"] = 168,
							["id"] = 16827,
							["criticalmax"] = 168,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 252,
									["amount"] = 252,
								},
							},
							["critical"] = 1,
							["amount"] = 252,
							["casts"] = 3,
							["count"] = 3,
							["hit"] = 1,
							["school"] = 1,
							["hitmax"] = 84,
							["MISS"] = 1,
							["hitamount"] = 84,
						},
						["Auto Shot"] = {
							["total"] = 303,
							["hitmin"] = 100,
							["id"] = 75,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 303,
									["amount"] = 303,
								},
							},
							["casts"] = 1,
							["count"] = 3,
							["hit"] = 3,
							["school"] = 1,
							["hitmax"] = 102,
							["amount"] = 303,
							["hitamount"] = 303,
						},
						["Explosive Shot (DoT)"] = {
							["total"] = 627,
							["hitmin"] = 157,
							["criticalamount"] = 313,
							["id"] = 53301,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 627,
									["amount"] = 627,
								},
							},
							["hitmax"] = 157,
							["count"] = 3,
							["criticalmax"] = 313,
							["critical"] = 1,
							["amount"] = 627,
							["school"] = 4,
							["hit"] = 2,
							["criticalmin"] = 313,
							["hitamount"] = 314,
						},
						["Melee (Cat)"] = {
							["criticalmin"] = 118,
							["total"] = 285,
							["hitmin"] = 56,
							["criticalamount"] = 118,
							["id"] = 6603,
							["amount"] = 285,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 285,
									["amount"] = 285,
								},
							},
							["critical"] = 1,
							["glancing"] = 1,
							["criticalmax"] = 118,
							["count"] = 5,
							["hit"] = 2,
							["school"] = 1,
							["hitmax"] = 58,
							["MISS"] = 1,
							["hitamount"] = 114,
						},
						["Arcane Shot"] = {
							["total"] = 571,
							["hitmin"] = 131,
							["criticalamount"] = 298,
							["id"] = 3044,
							["criticalmin"] = 298,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 571,
									["amount"] = 571,
								},
							},
							["criticalmax"] = 298,
							["critical"] = 1,
							["casts"] = 3,
							["count"] = 3,
							["hit"] = 2,
							["school"] = 64,
							["hitmax"] = 142,
							["amount"] = 571,
							["hitamount"] = 273,
						},
					},
					["last"] = 10267.965,
					["flag"] = 1298,
					["id"] = "0x00000000000477A3",
					["class"] = "HUNTER",
					["totaldamage"] = 2225,
					["auras"] = {
						[93435] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 1,
							["uptime"] = 9,
						},
						[53301] = {
							["type"] = "DEBUFF",
							["count"] = 1,
							["school"] = 4,
							["targets"] = {
								["Deeprot Stomper"] = {
									["uptime"] = 2,
									["count"] = 1,
								},
							},
							["uptime"] = 2,
						},
					},
					["energyspells"] = {
						[91954] = 18,
						[34720] = 10,
					},
					["name"] = "Macius",
					["time"] = 8.359999999999999,
					["role"] = "DAMAGER",
					["energy"] = 28,
					["damage"] = 2225,
				}, -- [2]
				{
					["damagespells"] = {
						["Torment (Grimlos)"] = {
							["total"] = 55,
							["hitmin"] = 55,
							["id"] = 3716,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 55,
									["amount"] = 55,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 33,
							["hitmax"] = 55,
							["amount"] = 55,
							["hitamount"] = 55,
						},
						["Melee (Grimlos)"] = {
							["total"] = 138,
							["criticalamount"] = 138,
							["id"] = 6603,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 138,
									["amount"] = 138,
								},
							},
							["criticalmax"] = 138,
							["critical"] = 1,
							["amount"] = 138,
							["school"] = 1,
							["criticalmin"] = 138,
							["count"] = 1,
						},
						["Unstable Affliction (DoT)"] = {
							["total"] = 146,
							["hitmin"] = 49,
							["criticalamount"] = 97,
							["id"] = 30108,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 146,
									["amount"] = 146,
								},
							},
							["criticalmin"] = 97,
							["critical"] = 1,
							["criticalmax"] = 97,
							["count"] = 2,
							["hit"] = 1,
							["school"] = 32,
							["hitmax"] = 49,
							["amount"] = 146,
							["hitamount"] = 49,
						},
					},
					["last"] = 10267.84,
					["id"] = "0x000000000004825C",
					["class"] = "WARLOCK",
					["flag"] = 1297,
					["auras"] = {
						[93435] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 1,
							["uptime"] = 9,
						},
						[30108] = {
							["type"] = "DEBUFF",
							["count"] = 1,
							["school"] = 32,
							["targets"] = {
								["Deeprot Stomper"] = {
									["uptime"] = 6,
									["count"] = 1,
								},
							},
							["uptime"] = 6,
						},
						[172] = {
							["type"] = "DEBUFF",
							["count"] = 1,
							["school"] = 32,
							["targets"] = {
								["Deeprot Stomper"] = {
									["uptime"] = 2,
									["count"] = 1,
								},
							},
							["uptime"] = 2,
						},
						[74434] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 32,
							["uptime"] = 1,
						},
					},
					["totaldamage"] = 339,
					["role"] = "DAMAGER",
					["time"] = 6.44,
					["name"] = "Beardedrasta",
					["spec"] = 265,
					["damage"] = 339,
				}, -- [3]
				{
					["overheal"] = 0,
					["last"] = 10267.937,
					["flag"] = 1298,
					["class"] = "PRIEST",
					["healspells"] = {
						[63544] = {
							["overheal"] = 0,
							["count"] = 1,
							["amount"] = 67,
							["school"] = 2,
							["max"] = 67,
							["targets"] = {
								["Myrony"] = {
									["overheal"] = 0,
									["amount"] = 67,
								},
							},
							["min"] = 67,
						},
					},
					["auras"] = {
						[93435] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 1,
							["uptime"] = 9,
						},
					},
					["heal"] = 67,
					["role"] = "HEALER",
					["name"] = "Nianhong",
					["time"] = 3.5,
					["id"] = "0x00000000000467C0",
				}, -- [4]
				{
					["last"] = 10267.875,
					["flag"] = 1298,
					["class"] = "PALADIN",
					["auras"] = {
						[93435] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 1,
							["uptime"] = 9,
						},
						[31930] = {
							["type"] = "BUFF",
							["count"] = 1,
							["school"] = 2,
							["uptime"] = 1,
						},
						[68055] = {
							["type"] = "DEBUFF",
							["count"] = 1,
							["school"] = 2,
							["targets"] = {
								["Deeprot Stomper"] = {
									["uptime"] = 1,
									["count"] = 1,
								},
							},
							["uptime"] = 1,
						},
					},
					["totaldamage"] = 632,
					["time"] = 5.21,
					["totaldamagetaken"] = 582,
					["damage"] = 632,
					["damagespells"] = {
						["Melee"] = {
							["total"] = 212,
							["hitmin"] = 96,
							["id"] = 6603,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 212,
									["amount"] = 212,
								},
							},
							["count"] = 2,
							["hit"] = 2,
							["school"] = 1,
							["hitmax"] = 116,
							["amount"] = 212,
							["hitamount"] = 212,
						},
						["Seal of Righteousness"] = {
							["total"] = 34,
							["hitmin"] = 16,
							["id"] = 25742,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 34,
									["amount"] = 34,
								},
							},
							["casts"] = 1,
							["count"] = 2,
							["hit"] = 2,
							["school"] = 2,
							["hitmax"] = 18,
							["amount"] = 34,
							["hitamount"] = 34,
						},
						["Crusader Strike"] = {
							["total"] = 173,
							["hitmin"] = 173,
							["id"] = 35395,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 173,
									["amount"] = 173,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 1,
							["hitmax"] = 173,
							["amount"] = 173,
							["hitamount"] = 173,
						},
						["Retribution Aura"] = {
							["total"] = 26,
							["hitmin"] = 13,
							["id"] = 7294,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 26,
									["amount"] = 26,
								},
							},
							["casts"] = 1,
							["count"] = 2,
							["hit"] = 2,
							["school"] = 2,
							["hitmax"] = 13,
							["amount"] = 26,
							["hitamount"] = 26,
						},
						["Judgement of Righteousness"] = {
							["total"] = 187,
							["hitmin"] = 187,
							["id"] = 20187,
							["targets"] = {
								["Deeprot Stomper"] = {
									["total"] = 187,
									["amount"] = 187,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 2,
							["hitmax"] = 187,
							["amount"] = 187,
							["hitamount"] = 187,
						},
					},
					["damagetaken"] = 582,
					["id"] = "0x00000000000447DB",
					["damagetakenspells"] = {
						["Melee"] = {
							["total"] = 375,
							["hitmin"] = 184,
							["id"] = 6603,
							["sources"] = {
								["Deeprot Stomper"] = {
									["total"] = 375,
									["amount"] = 375,
								},
							},
							["count"] = 2,
							["hit"] = 2,
							["school"] = 1,
							["hitmax"] = 191,
							["amount"] = 375,
							["hitamount"] = 375,
						},
						["Strike"] = {
							["total"] = 207,
							["hitmin"] = 207,
							["id"] = 13446,
							["sources"] = {
								["Deeprot Stomper"] = {
									["total"] = 207,
									["amount"] = 207,
								},
							},
							["casts"] = 1,
							["count"] = 1,
							["hit"] = 1,
							["school"] = 1,
							["hitmax"] = 207,
							["amount"] = 207,
							["hitamount"] = 207,
						},
					},
					["name"] = "Myrony",
					["role"] = "TANK",
				}, -- [5]
			},
			["type"] = "party",
			["damagetaken"] = 776,
			["energy"] = 28,
			["overheal"] = 0,
			["overkill"] = 200,
			["edamagetaken"] = 4640,
			["heal"] = 67,
			["name"] = "Deeprot Stomper",
			["mobname"] = "Deeprot Stomper",
			["etotaldamage"] = 776,
			["edamage"] = 776,
			["last_action"] = 1689857137,
			["endtime"] = 1689857137,
		}, -- [15]
	},
	["version"] = 1875,
	["total"] = {
		["potion"] = 1,
		["mana"] = 21230,
		["death"] = 5,
		["overheal"] = 16580,
		["dispel"] = 6,
		["totaldamage"] = 236869,
		["time"] = 384,
		["totaldamagetaken"] = 49201,
		["damage"] = 236869,
		["starttime"] = 1689857117,
		["absorb"] = 8602,
		["damagetaken"] = 40233,
		["overkill"] = 7252,
		["heal"] = 28742,
		["name"] = "Total",
		["ccdone"] = 96,
		["energy"] = 851,
		["players"] = {
			{
				["flag"] = 1298,
				["mana"] = 6146,
				["totaldamage"] = 79844,
				["time"] = 293.5499999999999,
				["totaldamagetaken"] = 11770,
				["damage"] = 79844,
				["overheal"] = 4579,
				["damagetaken"] = 10259,
				["id"] = "0x0000000000048007",
				["overkill"] = 3413,
				["heal"] = 2834,
				["name"] = "Fragrance",
				["ccdone"] = 49,
				["death"] = 1,
				["class"] = "PALADIN",
				["role"] = "DAMAGER",
			}, -- [1]
			{
				["damagetaken"] = 2846,
				["id"] = "0x00000000000477A3",
				["class"] = "HUNTER",
				["flag"] = 4370,
				["overkill"] = 1210,
				["totaldamage"] = 60389,
				["role"] = "DAMAGER",
				["name"] = "Macius",
				["death"] = 1,
				["time"] = 298.44,
				["totaldamagetaken"] = 2846,
				["energy"] = 851,
				["damage"] = 60389,
			}, -- [2]
			{
				["flag"] = 1298,
				["mana"] = 12868,
				["role"] = "TANK",
				["time"] = 301.2199999999997,
				["totaldamagetaken"] = 23276,
				["damage"] = 63317,
				["overheal"] = 1446,
				["damagetaken"] = 17088,
				["id"] = "0x00000000000447DB",
				["overkill"] = 2010,
				["heal"] = 2844,
				["name"] = "Myrony",
				["ccdone"] = 47,
				["death"] = 1,
				["class"] = "PALADIN",
				["totaldamage"] = 63317,
			}, -- [3]
			{
				["flag"] = 4369,
				["class"] = "WARLOCK",
				["time"] = 239.1999999999999,
				["totaldamagetaken"] = 7060,
				["damage"] = 30695,
				["overheal"] = 1018,
				["damagetaken"] = 5791,
				["id"] = "0x000000000004825C",
				["spec"] = 265,
				["overkill"] = 600,
				["heal"] = 590,
				["name"] = "Beardedrasta",
				["death"] = 1,
				["mana"] = 1701,
				["totaldamage"] = 30695,
				["role"] = "DAMAGER",
			}, -- [4]
			{
				["flag"] = 1298,
				["class"] = "PRIEST",
				["dispel"] = 6,
				["role"] = "HEALER",
				["time"] = 268.2699999999999,
				["totaldamagetaken"] = 4249,
				["damage"] = 2624,
				["overheal"] = 9537,
				["absorb"] = 8602,
				["damagetaken"] = 4249,
				["id"] = "0x00000000000467C0",
				["overkill"] = 19,
				["heal"] = 22474,
				["name"] = "Nianhong",
				["death"] = 1,
				["mana"] = 515,
				["potion"] = 1,
				["totaldamage"] = 2624,
			}, -- [5]
		},
	},
}
