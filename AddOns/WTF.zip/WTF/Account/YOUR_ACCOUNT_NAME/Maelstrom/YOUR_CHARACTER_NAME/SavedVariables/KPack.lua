
KPackCharDB = {
	["Viewporter"] = {
		["enabled"] = true,
		["firstTime"] = false,
		["bottom"] = 0,
		["right"] = 299,
		["left"] = 0,
		["top"] = 0,
	},
	["Automate"] = {
		["groundmount"] = "",
		["sets"] = {
		},
		["flyingmount"] = "",
	},
}
