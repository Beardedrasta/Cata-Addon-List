
armode = 0
