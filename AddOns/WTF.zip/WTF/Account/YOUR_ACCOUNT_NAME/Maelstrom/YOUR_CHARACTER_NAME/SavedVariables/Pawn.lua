
PawnOptions = {
	["LastPlayerFullName"] = "Beardedrasta-Maelstrom",
	["LastKeybindingsSet"] = 1,
}
PawnWowheadScaleProviderOptions = {
	["LastClass"] = "WARLOCK",
	["LastAdded"] = 2,
}
