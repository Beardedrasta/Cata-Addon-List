
QuestHelper_KnownFlightRoutes = {
}
QuestHelper_Home = nil
QuestHelper_CharVersion = 1
QuestHelper_Flight_Updates = 0
