
XPerl_Admin = {
	["Transparency"] = 0.8,
	["ResistSort"] = "fr",
	["SavedRosters"] = {
	},
	["AutoHideShow"] = 1,
}
XPerl_CheckItems = {
	{
		["fixed"] = true,
		["link"] = "dur",
	}, -- [1]
	{
		["fixed"] = true,
		["link"] = "reg",
	}, -- [2]
	{
		["fixed"] = true,
		["link"] = "res",
	}, -- [3]
}
