
XLoot_Options = {
	["characters"] = {
		["Beardedrasta - Maelstrom"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["font_size_info"] = 10,
			["loot_texts_bind"] = true,
			["loot_color_backdrop"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0.9, -- [4]
			},
			["loot_color_info"] = {
				0.5, -- [1]
				0.5, -- [2]
				0.5, -- [3]
			},
			["autoloot_quest"] = "never",
			["linkall_show"] = "auto",
			["linkall_threshold"] = 2,
			["frame_snap_offset_y"] = 0,
			["loot_color_gradient"] = {
				0.5, -- [1]
				0.5, -- [2]
				0.5, -- [3]
				0.4, -- [4]
			},
			["frame_width"] = 150,
			["quality_color_frame"] = false,
			["skin"] = "smooth",
			["frame_draggable"] = true,
			["frame_color_border"] = {
				0.5, -- [1]
				0.5, -- [2]
				0.5, -- [3]
			},
			["linkall_channel"] = "RAID",
			["frame_color_backdrop"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0.7, -- [4]
			},
			["loot_texts_info"] = true,
			["loot_highlight"] = true,
			["loot_color_border"] = {
				0.5, -- [1]
				0.5, -- [2]
				0.5, -- [3]
			},
			["frame_color_gradient"] = {
				0.5, -- [1]
				0.5, -- [2]
				0.5, -- [3]
				0.3, -- [4]
			},
			["loot_collapse"] = false,
			["font_size_loot"] = 12,
			["frame_alpha"] = 1,
			["frame_scale"] = 1,
			["frame_position_y"] = 384,
			["loot_alpha"] = 1,
			["autoloot_coin"] = "never",
			["frame_snap_offset_x"] = 0,
			["quality_color_loot"] = true,
			["frame_width_automatic"] = true,
			["frame_position_x"] = 917.3333129882813,
			["frame_snap"] = true,
		},
	},
}
