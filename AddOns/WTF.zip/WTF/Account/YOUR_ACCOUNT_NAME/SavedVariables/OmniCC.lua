
OmniCC4Config = {
	["groups"] = {
	},
	["groupSettings"] = {
		["base"] = {
		},
	},
	["version"] = "4.3.2",
}
