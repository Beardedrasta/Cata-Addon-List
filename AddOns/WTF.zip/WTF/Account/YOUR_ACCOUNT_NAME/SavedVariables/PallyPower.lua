
PallyPowerDB = {
	["profileKeys"] = {
		["Beardedrasta - Maelstrom"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["disabled"] = true,
		},
	},
}
