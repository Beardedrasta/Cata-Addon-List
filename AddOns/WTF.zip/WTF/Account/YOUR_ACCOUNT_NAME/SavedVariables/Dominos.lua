
DominosDB = {
	["profileKeys"] = {
		["Beardedrasta - Maelstrom"] = "Warlock",
	},
	["profiles"] = {
		["Warlock"] = {
			["minimapPos"] = 174.3347399803221,
			["showMinimap"] = false,
			["frames"] = {
				{
					["point"] = "BOTTOMLEFT",
					["scale"] = 0.95,
					["y"] = 309.2552490234375,
					["x"] = 1206.667236328125,
					["spacing"] = 2,
					["padH"] = 1,
					["padW"] = 1,
					["pages"] = {
						["WARLOCK"] = {
							["page2"] = 1,
							["page5"] = 4,
							["page4"] = 3,
							["page3"] = 2,
							["page6"] = 5,
						},
					},
					["numButtons"] = 8,
				}, -- [1]
				{
					["point"] = "BOTTOMRIGHT",
					["scale"] = 0.95,
					["columns"] = 8,
					["y"] = 267.5644836425781,
					["x"] = -1347.226709585989,
					["pages"] = {
						["WARLOCK"] = {
						},
					},
					["spacing"] = 2,
					["anchor"] = "1BC",
					["padW"] = 1,
					["numButtons"] = 8,
					["padH"] = 1,
				}, -- [2]
				{
					["point"] = "BOTTOMRIGHT",
					["scale"] = 0.95,
					["columns"] = 6,
					["y"] = 191.5645294189453,
					["x"] = -1385.226709585989,
					["pages"] = {
						["WARLOCK"] = {
						},
					},
					["spacing"] = 2,
					["anchor"] = "2BC",
					["padW"] = 1,
					["numButtons"] = 12,
					["padH"] = 1,
				}, -- [3]
				{
					["point"] = "BOTTOMLEFT",
					["y"] = 0,
					["fadeAlpha"] = 0.1,
					["x"] = 0,
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["WARLOCK"] = {
						},
					},
					["numButtons"] = 12,
					["padW"] = 2,
				}, -- [4]
				{
					["point"] = "BOTTOMLEFT",
					["hidden"] = true,
					["y"] = 308.1375122070313,
					["x"] = 495.833740234375,
					["spacing"] = 4,
					["padH"] = 2,
					["padW"] = 2,
					["pages"] = {
						["WARLOCK"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [5]
				{
					["point"] = "BOTTOMLEFT",
					["hidden"] = true,
					["y"] = 329.729736328125,
					["x"] = 494.9994201660156,
					["spacing"] = 4,
					["padH"] = 2,
					["padW"] = 2,
					["pages"] = {
						["WARLOCK"] = {
						},
					},
					["numButtons"] = 12,
				}, -- [6]
				{
					["point"] = "BOTTOMLEFT",
					["hidden"] = true,
					["y"] = 348.1374816894531,
					["x"] = 495.833740234375,
					["anchor"] = "5TL",
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["WARLOCK"] = {
						},
					},
					["numButtons"] = 12,
					["padW"] = 2,
				}, -- [7]
				{
					["point"] = "BOTTOMLEFT",
					["hidden"] = true,
					["y"] = 369.7297668457031,
					["x"] = 494.9994201660156,
					["anchor"] = "6TC",
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["WARLOCK"] = {
						},
					},
					["numButtons"] = 12,
					["padW"] = 2,
				}, -- [8]
				{
					["point"] = "BOTTOMLEFT",
					["hidden"] = true,
					["y"] = 388.1375122070313,
					["x"] = 495.833740234375,
					["anchor"] = "7TL",
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["WARLOCK"] = {
						},
					},
					["numButtons"] = 12,
					["padW"] = 2,
				}, -- [9]
				{
					["point"] = "BOTTOMLEFT",
					["hidden"] = true,
					["y"] = 409.729736328125,
					["x"] = 494.9994201660156,
					["anchor"] = "8TL",
					["spacing"] = 4,
					["padH"] = 2,
					["pages"] = {
						["WARLOCK"] = {
						},
					},
					["numButtons"] = 12,
					["padW"] = 2,
				}, -- [10]
				["extra"] = {
					["y"] = 0,
					["x"] = 854.1678466796875,
					["point"] = "BOTTOMLEFT",
				},
				["class"] = {
					["y"] = 0,
					["x"] = 923.4995727539063,
					["point"] = "BOTTOMLEFT",
					["spacing"] = 2,
					["anchor"] = "vehicleRC",
					["numButtons"] = 0,
				},
				["pet"] = {
					["point"] = "BOTTOMRIGHT",
					["scale"] = 0.69,
					["padW"] = 1,
					["x"] = -1308.314364698955,
					["spacing"] = 2,
					["anchor"] = "3BC",
					["y"] = 155.61474609375,
					["padH"] = 1,
				},
				["cast"] = {
					["y"] = 30,
					["x"] = 0,
					["point"] = "CENTER",
					["hidden"] = true,
					["showText"] = true,
				},
				["menu"] = {
					["y"] = 372.535400390625,
					["x"] = 0.000244140625,
					["point"] = "BOTTOMRIGHT",
					["spacing"] = -2,
					["disabled"] = {
					},
				},
				["bags"] = {
					["y"] = 0,
					["x"] = -299.16162109375,
					["point"] = "BOTTOMRIGHT",
					["spacing"] = 2,
					["oneBag"] = 1,
					["numButtons"] = 1,
				},
				["vehicle"] = {
					["y"] = 0,
					["x"] = 833.4995727539063,
					["point"] = "BOTTOMLEFT",
					["numButtons"] = 3,
				},
				["xp"] = {
					["point"] = "TOP",
					["alpha"] = 0,
					["width"] = 0.75,
					["y"] = -32,
					["fadeAlpha"] = 0,
					["height"] = 14,
					["x"] = 0,
					["texture"] = "blizzard",
				},
				["roll"] = {
					["y"] = -219.50390625,
					["x"] = 615,
					["columns"] = 1,
					["spacing"] = 2,
					["numButtons"] = 4,
					["point"] = "TOPLEFT",
				},
			},
			["showgrid"] = 1,
		},
	},
}
DominosVersion = "4.3.4"
