
SkadaDB = {
	["namespaces"] = {
		["LibDualSpec-1.0"] = {
		},
	},
	["profileKeys"] = {
		["Beardedrasta - Maelstrom"] = "Default",
	},
	["global"] = {
		["version"] = 1875,
		["nicknames"] = {
			["cache"] = {
			},
			["reset"] = 1691110142,
		},
	},
	["profiles"] = {
		["Default"] = {
			["namedisplay"] = 2,
			["modules"] = {
				["sunderchannel"] = "SAY",
				["threat"] = {
					["soundfile"] = "Fel Nova",
					["ignorePets"] = true,
					["flash"] = true,
					["threshold"] = 90,
					["notankwarnings"] = true,
					["output"] = 1,
					["sound"] = true,
					["showAggroBar"] = true,
					["frequency"] = 2,
				},
				["failschannel"] = "AUTO",
				["deathlogevents"] = 14,
				["deathchannel"] = "AUTO",
				["interruptchannel"] = "SAY",
				["parrychannel"] = "AUTO",
				["deathlogthreshold"] = 2000,
			},
			["prepotion"] = true,
			["windows"] = {
				{
					["classcolorright"] = false,
					["barheight"] = 24,
					["barslocked"] = true,
					["background"] = {
						["height"] = 227.1731414794922,
						["borderthickness"] = 0,
						["bordercolor"] = {
							["a"] = 1,
							["r"] = 1,
							["g"] = 1,
							["b"] = 1,
						},
					},
					["numfont"] = "Zekton",
					["barfont"] = "Yanone",
					["combattimer"] = false,
					["hidden"] = false,
					["y"] = 200.7417907714844,
					["x"] = -0.0009765625,
					["title"] = {
						["color"] = {
							["r"] = 0.2392156862745098,
							["g"] = 0.2392156862745098,
							["b"] = 0.2392156862745098,
						},
						["bordertexture"] = "ArkInventory Square 2",
						["borderthickness"] = 1.4,
						["height"] = 23,
						["bordercolor"] = {
							["r"] = 0.2588235294117647,
							["g"] = 0.2588235294117647,
							["b"] = 0.2588235294117647,
						},
						["texture"] = "KPack",
					},
					["barfontflags"] = "OUTLINE",
					["numfontflags"] = "OUTLINE",
					["classcolortext"] = false,
					["barcolor"] = {
						["a"] = 0.85,
					},
					["barfontsize"] = 18,
					["roleicons"] = false,
					["mode"] = "Damage",
					["textcolor"] = {
						["a"] = 1,
						["r"] = 0.7450980392156863,
						["g"] = 0.7450980392156863,
						["b"] = 0.7450980392156863,
					},
					["barwidth"] = 289.9997253417969,
					["smoothing"] = true,
					["titleset"] = false,
					["moduleicons"] = true,
					["point"] = "RIGHT",
					["numfontsize"] = 15,
				}, -- [1]
			},
			["icon"] = {
				["minimapPos"] = 185.7583108213909,
			},
			["smartwait"] = 3,
			["firsthit"] = true,
			["combatlogfix"] = true,
		},
	},
}
