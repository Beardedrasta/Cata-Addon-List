
ZygorTalentAdvisorSettings = {
	["char"] = {
		["Beardedrasta - Maelstrom"] = {
			["debuglog"] = {
				"00:20:02> Viewer started. ---------------------------", -- [1]
				"00:20:03> |cff55ff00?|cffaaaaaa (Events.lua:37): |cffff88ddPLAYER_TALENT_UPDATE|r", -- [2]
				"00:20:03> > |cff55ff00LoadBuilds|cffaaaaaa (ZygorTalentAdvisor.lua:171): |cffff88ddLoading builds: BOTH|r", -- [3]
				"00:20:03>  | |cff55ff00PruneRegisteredBuilds|cffaaaaaa (ZygorTalentAdvisor.lua:1513): |cffff88ddPruned.|r", -- [4]
				"00:20:03>  | > |cff55ff00SetCurrentBuild|cffaaaaaa (ZygorTalentAdvisor.lua:1218): |cffff88ddActivating build '_' for: player|r", -- [5]
				"00:20:03>  |  | |cff55ff00ZygorTalentAdvisorPopout_Update|cffaaaaaa (Popout.lua:111): |cffff88ddpopout hidden, not updating|r", -- [6]
				"00:20:03>  | < |cff55ff00SetCurrentBuild|cffaaaaaa (ZygorTalentAdvisor.lua:1243): |cffff88dd|r", -- [7]
				"00:20:03>  | > |cff55ff00SetCurrentBuild|cffaaaaaa (ZygorTalentAdvisor.lua:1218): |cffff88ddActivating build '_' for: pet|r", -- [8]
				"00:20:03>  |  | |cff55ff00ZygorTalentAdvisorPopout_Update|cffaaaaaa (Popout.lua:111): |cffff88ddpopout hidden, not updating|r", -- [9]
				"00:20:03>  | < |cff55ff00SetCurrentBuild|cffaaaaaa (ZygorTalentAdvisor.lua:1243): |cffff88dd|r", -- [10]
				"00:20:03> < |cff55ff00LoadBuilds|cffaaaaaa (ZygorTalentAdvisor.lua:175): |cffff88dd|r", -- [11]
				"00:20:03> |cff55ff00?|cffaaaaaa (Events.lua:31): |cffff88ddPLAYER_ALIVE|r", -- [12]
				"00:20:03> > |cff55ff00LoadBuilds|cffaaaaaa (ZygorTalentAdvisor.lua:171): |cffff88ddLoading builds: BOTH|r", -- [13]
				"00:20:03>  | > |cff55ff00SetCurrentBuild|cffaaaaaa (ZygorTalentAdvisor.lua:1218): |cffff88ddActivating build '_' for: player|r", -- [14]
				"00:20:03>  |  | |cff55ff00ZygorTalentAdvisorPopout_Update|cffaaaaaa (Popout.lua:111): |cffff88ddpopout hidden, not updating|r", -- [15]
				"00:20:03>  | < |cff55ff00SetCurrentBuild|cffaaaaaa (ZygorTalentAdvisor.lua:1243): |cffff88dd|r", -- [16]
				"00:20:03>  | > |cff55ff00SetCurrentBuild|cffaaaaaa (ZygorTalentAdvisor.lua:1218): |cffff88ddActivating build '_' for: pet|r", -- [17]
				"00:20:03>  |  | |cff55ff00ZygorTalentAdvisorPopout_Update|cffaaaaaa (Popout.lua:111): |cffff88ddpopout hidden, not updating|r", -- [18]
				"00:20:03>  | < |cff55ff00SetCurrentBuild|cffaaaaaa (ZygorTalentAdvisor.lua:1243): |cffff88dd|r", -- [19]
				"00:20:03> < |cff55ff00LoadBuilds|cffaaaaaa (ZygorTalentAdvisor.lua:175): |cffff88dd|r", -- [20]
				"00:23:41> Viewer started. ---------------------------", -- [21]
				"00:23:41> |cff55ff00?|cffaaaaaa (Events.lua:37): |cffff88ddPLAYER_TALENT_UPDATE|r", -- [22]
				"00:23:41> > |cff55ff00LoadBuilds|cffaaaaaa (ZygorTalentAdvisor.lua:171): |cffff88ddLoading builds: BOTH|r", -- [23]
				"00:23:41>  | |cff55ff00PruneRegisteredBuilds|cffaaaaaa (ZygorTalentAdvisor.lua:1513): |cffff88ddPruned.|r", -- [24]
				"00:23:41>  | > |cff55ff00SetCurrentBuild|cffaaaaaa (ZygorTalentAdvisor.lua:1218): |cffff88ddActivating build '_' for: player|r", -- [25]
				"00:23:41>  |  | |cff55ff00ZygorTalentAdvisorPopout_Update|cffaaaaaa (Popout.lua:111): |cffff88ddpopout hidden, not updating|r", -- [26]
				"00:23:41>  | < |cff55ff00SetCurrentBuild|cffaaaaaa (ZygorTalentAdvisor.lua:1243): |cffff88dd|r", -- [27]
				"00:23:41>  | > |cff55ff00SetCurrentBuild|cffaaaaaa (ZygorTalentAdvisor.lua:1218): |cffff88ddActivating build '_' for: pet|r", -- [28]
				"00:23:41>  |  | |cff55ff00ZygorTalentAdvisorPopout_Update|cffaaaaaa (Popout.lua:111): |cffff88ddpopout hidden, not updating|r", -- [29]
				"00:23:41>  | < |cff55ff00SetCurrentBuild|cffaaaaaa (ZygorTalentAdvisor.lua:1243): |cffff88dd|r", -- [30]
				"00:23:41> < |cff55ff00LoadBuilds|cffaaaaaa (ZygorTalentAdvisor.lua:175): |cffff88dd|r", -- [31]
				"00:23:41> |cff55ff00?|cffaaaaaa (Events.lua:31): |cffff88ddPLAYER_ALIVE|r", -- [32]
				"00:23:41> > |cff55ff00LoadBuilds|cffaaaaaa (ZygorTalentAdvisor.lua:171): |cffff88ddLoading builds: BOTH|r", -- [33]
				"00:23:41>  | > |cff55ff00SetCurrentBuild|cffaaaaaa (ZygorTalentAdvisor.lua:1218): |cffff88ddActivating build '_' for: player|r", -- [34]
				"00:23:41>  |  | |cff55ff00ZygorTalentAdvisorPopout_Update|cffaaaaaa (Popout.lua:111): |cffff88ddpopout hidden, not updating|r", -- [35]
				"00:23:41>  | < |cff55ff00SetCurrentBuild|cffaaaaaa (ZygorTalentAdvisor.lua:1243): |cffff88dd|r", -- [36]
				"00:23:41>  | > |cff55ff00SetCurrentBuild|cffaaaaaa (ZygorTalentAdvisor.lua:1218): |cffff88ddActivating build '_' for: pet|r", -- [37]
				"00:23:41>  |  | |cff55ff00ZygorTalentAdvisorPopout_Update|cffaaaaaa (Popout.lua:111): |cffff88ddpopout hidden, not updating|r", -- [38]
				"00:23:41>  | < |cff55ff00SetCurrentBuild|cffaaaaaa (ZygorTalentAdvisor.lua:1243): |cffff88dd|r", -- [39]
				"00:23:41> < |cff55ff00LoadBuilds|cffaaaaaa (ZygorTalentAdvisor.lua:175): |cffff88dd|r", -- [40]
			},
			["currentPetBuildKey"] = {
				["_"] = "_",
				["_1"] = "_",
			},
		},
	},
	["profileKeys"] = {
		["Beardedrasta - Maelstrom"] = "Beardedrasta - Maelstrom",
	},
	["profiles"] = {
		["Beardedrasta - Maelstrom"] = {
		},
	},
}
