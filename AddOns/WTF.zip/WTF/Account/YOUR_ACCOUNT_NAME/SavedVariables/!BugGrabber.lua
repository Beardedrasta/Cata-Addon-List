
BugGrabberDB = {
	["session"] = 18,
	["lastSanitation"] = 3,
	["errors"] = {
		{
			["message"] = "Prat-3.0-3.3.26\\modules\\AltNames.lua:1030: Cannot find a library instance of \"LibAlts-1.0\".",
			["time"] = "2023/07/19 23:37:42",
			["stack"] = "Prat-3.0-3.3.26\\addon\\addon.lua:236: in function <Prat-3.0\\addon\\addon.lua:193>\n(tail call): ?\n<in C code>\n<string>:\"safecall Dispatcher[1]\":9: in function <string>:\"safecall Dispatcher[1]\":5\n(tail call): ?\nExternals\\Ace3-AceAddon\\AceAddon-3.0-11.lua:514: in function \"InitializeAddon\"\nExternals\\Ace3-AceAddon\\AceAddon-3.0-11.lua:629: in function <Externals\\Ace3-AceAddon\\AceAddon-3.0.lua:621>",
			["session"] = 2,
			["counter"] = 2,
		}, -- [1]
		{
			["message"] = "Usage: EmbedLibrary(addon, libname, silent, offset): \"libname\" - Cannot find a library instance of \"LibSink-2.0\".",
			["time"] = "2023/07/19 23:37:42",
			["stack"] = "Prat-3.0-3.3.26\\addon\\addon.lua:236: in function <Prat-3.0\\addon\\addon.lua:193>\n(tail call): ?\n<in C code>\n<string>:\"safecall Dispatcher[1]\":9: in function <string>:\"safecall Dispatcher[1]\":5\n(tail call): ?\nExternals\\Ace3-AceAddon\\AceAddon-3.0-11.lua:514: in function \"InitializeAddon\"\nExternals\\Ace3-AceAddon\\AceAddon-3.0-11.lua:629: in function <Externals\\Ace3-AceAddon\\AceAddon-3.0.lua:621>",
			["session"] = 2,
			["counter"] = 2,
		}, -- [2]
		{
			["message"] = "Prat-3.0-3.3.26\\modules\\PlayerNames.lua:1485: Cannot find a library instance of \"AceTab-3.0\".",
			["time"] = "2023/07/19 23:37:55",
			["stack"] = "<in C code>\nArkInventory-3.02.95\\Libs\\LibStub\\LibStub.lua:23: in function \"LibStub\"\nPrat-3.0-3.3.26\\modules\\PlayerNames.lua:1485: in function \"TabComplete\"\nPrat-3.0-3.3.26\\modules\\PlayerNames.lua:994: in function \"OnModuleEnable\"\nPrat-3.0-3.3.26\\addon\\modules.lua:189: in function <Prat-3.0\\addon\\modules.lua:181>\n(tail call): ?\n<in C code>\n<string>:\"safecall Dispatcher[1]\":9: in function <string>:\"safecall Dispatcher[1]\":5\n(tail call): ?\nExternals\\Ace3-AceAddon\\AceAddon-3.0-11.lua:543: in function \"EnableAddon\"\nExternals\\Ace3-AceAddon\\AceAddon-3.0-11.lua:556: in function \"EnableAddon\"\nExternals\\Ace3-AceAddon\\AceAddon-3.0-11.lua:636: in function <Externals\\Ace3-AceAddon\\AceAddon-3.0.lua:621>\n<in C code>\nFrameXML\\UIParent.lua:274: in function \"UIParentLoadAddOn\"\nFrameXML\\UIParent.lua:297: in function \"CombatLog_LoadUI\"\nFrameXML\\UIParent.lua:616: in function <FrameXML\\UIParent.lua:582>",
			["session"] = 2,
			["counter"] = 2,
		}, -- [3]
		{
			["message"] = "Prat-3.0-3.3.26\\services\\patterns.lua:179: bad argument #2 to \"gsub\" (string/function/table expected)",
			["time"] = "2023/07/19 23:37:56",
			["locals"] = "text = \"Joined Channel: |Hchannel:1|h[1. General - Dun Morogh]|h\"\nptype = nil\nmt = <table> {}\nk = \"@##1##@\"\n(for index) = 1\n(for limit) = 1\n(for step) = -1\nt = 1\nMatchTable = <table> {\n FRAME = <table> {}\n}\ndebug = <func> @Prat-3.0\\services\\patterns.lua:65\ntokennum = 1\ntostring = <func> =[C]:-1\n",
			["stack"] = "<in C code>\nPrat-3.0-3.3.26\\services\\patterns.lua:179: in function \"ReplaceMatches\"\nPrat-3.0-3.3.26\\addon\\addon.lua:601: in function <Prat-3.0\\addon\\addon.lua:523>\n(tail call): ?\nFrameXML\\ChatFrame.lua:2718: in function \"ChatFrame_OnEvent\"\n<string>:\"*:OnEvent\":1: in function <string>:\"*:OnEvent\":1",
			["session"] = 2,
			["counter"] = 28,
		}, -- [4]
		{
			["message"] = "Prat-3.0-3.3.26\\services\\classgenderfix.lua:35: Cannot find a library instance of \"LibBabble-Class-3.0\".",
			["time"] = "2023/07/19 23:37:58",
			["stack"] = "<in C code>\nArkInventory-3.02.95\\Libs\\LibStub\\LibStub.lua:23: in function <ArkInventory\\Libs\\LibStub\\LibStub.lua:21>\nPrat-3.0-3.3.26\\services\\classgenderfix.lua:35: in function <Prat-3.0\\services\\classgenderfix.lua:32>\nPrat-3.0-3.3.26\\services\\classgenderfix.lua:41: in function \"GetGenderNeutralClass\"\nPrat-3.0-3.3.26\\services\\classcolor.lua:26: in function \"GetClassGetColor\"\nPrat-3.0-3.3.26\\modules\\PlayerNames.lua:1285: in function <Prat-3.0\\modules\\PlayerNames.lua:1284>\n(tail call): ?\nPrat-3.0-3.3.26\\modules\\PlayerNames.lua:1194: in function \"Player\"\nPrat-3.0-3.3.26\\modules\\PlayerNames.lua:1336: in function \"FormatPlayer\"\nPrat-3.0-3.3.26\\modules\\PlayerNames.lua:1428: in function \"?\"\nLibs\\CallbackHandler-1.0\\CallbackHandler-1.0-6.lua:147: in function <Libs\\CallbackHandler-1.0\\CallbackHandler-1.0.lua:147>\n<string>:\"safecall Dispatcher[4]\":4: in function <string>:\"safecall Dispatcher[4]\":4\n<in C code>\n<string>:\"safecall Dispatcher[4]\":13: in function \"?\"\nLibs\\CallbackHandler-1.0\\CallbackHandler-1.0-6.lua:92: in function \"Fire\"\nPrat-3.0-3.3.26\\addon\\addon.lua:581: in function <Prat-3.0\\addon\\addon.lua:523>\n(tail call): ?\nFrameXML\\ChatFrame.lua:2718: in function \"ChatFrame_OnEvent\"\n<string>:\"*:OnEvent\":1: in function <string>:\"*:OnEvent\":1",
			["session"] = 2,
			["counter"] = 72,
		}, -- [5]
		{
			["message"] = "XLoot1.0-z31-beta3\\XLoot.lua:934: attempt to call global \"GetLootSlotType\" (a nil value)",
			["time"] = "2023/07/19 23:54:54",
			["locals"] = "self = XLootFrame {\n 0 = <userdata>\n Reskin = <func> @XLoot1.0\\Libs\\..\\LibXSkin.lua:215\n Highlight = <func> @XLoot1.0\\Libs\\..\\LibXSkin.lua:232\n close = XLootFrameClose {}\n _skins = <table> {}\n rows = <table> {}\n _default_skin = \"default\"\n slots_index = <table> {}\n RegisterMasqueTweak = <func> @XLoot1.0\\XLoot.lua:140\n slots = <table> {}\n built = true\n skin = <table> {}\n GetColor = <func> @XLoot1.0\\XLoot.lua:274\n UpdateHeight = <func> @XLoot1.0\\XLoot.lua:699\n UpdateAppearance = <func> @XLoot1.0\\XLoot.lua:746\n UpdateLinkButton = <func> @XLoot1.0\\XLoot.lua:713\n _skinned = <table> {}\n opt = <table> {}\n RegisterSkin = <func> @XLoot1.0\\XLoot.lua:122\n link = XLootFrameLink {}\n addon = <table> {}\n UpdateWidth = <func> @XLoot1.0\\XLoot.lua:705\n SizeAndColor = <func> @XLoot1.0\\XLoot.lua:733\n SetAlpha = <func> @XLoot1.0\\XLoot.lua:840\n SnapToCursor = <func> @XLoot1.0\\XLoot.lua:637\n _SetAlpha = <func> =[C]:-1\n RegisterPlugin = <func> @XLoot1.0\\XLoot.lua:157\n overlay = <unnamed> {}\n Skin = <func> @XLoot1.0\\Libs\\..\\LibXSkin.lua:225\n Update = <func> @XLoot1.0\\XLoot.lua:860\n row_height = 33\n _highlighted = <table> {}\n}\n",
			["stack"] = "XLoot1.0-z31-beta3\\XLoot.lua:934: in function \"Update\"\nXLoot1.0-z31-beta3\\XLoot.lua:993: in function \"?\"\nXLoot1.0-z31-beta3\\XLoot.lua:1049: in function <XLoot1.0\\XLoot.lua:1049>",
			["session"] = 5,
			["counter"] = 1,
		}, -- [6]
		{
			["message"] = "libs\\CallbackHandler-1.0\\CallbackHandler-1.0-8.lua:19: attempt to call upvalue \"securecallfunction\" (a nil value)",
			["time"] = "2023/07/20 00:20:02",
			["stack"] = "libs\\CallbackHandler-1.0\\CallbackHandler-1.0-8.lua:19: in function <libs\\CallbackHandler-1.0\\CallbackHandler-1.0.lua:15>\nlibs\\CallbackHandler-1.0\\CallbackHandler-1.0-8.lua:54: in function \"Fire\"\nSexyMap-v1.8.4\\Shapes.lua:296: in function \"ApplyShape\"\nSexyMap-v1.8.4\\Shapes.lua:266: in function <SexyMap\\Shapes.lua:263>\n(tail call): ?\n<in C code>\n<string>:\"safecall Dispatcher[1]\":9: in function <string>:\"safecall Dispatcher[1]\":5\n(tail call): ?\nExternals\\Ace3-AceAddon\\AceAddon-3.0-11.lua:543: in function \"EnableAddon\"\nExternals\\Ace3-AceAddon\\AceAddon-3.0-11.lua:556: in function \"EnableAddon\"\nExternals\\Ace3-AceAddon\\AceAddon-3.0-11.lua:636: in function <Externals\\Ace3-AceAddon\\AceAddon-3.0.lua:621>\n<in C code>\nFrameXML\\UIParent.lua:274: in function \"UIParentLoadAddOn\"\nFrameXML\\UIParent.lua:297: in function \"CombatLog_LoadUI\"\nFrameXML\\UIParent.lua:616: in function <FrameXML\\UIParent.lua:582>",
			["session"] = 10,
			["counter"] = 12,
		}, -- [7]
		{
			["message"] = "AceConfigDialog-3.0\\AceConfigDialog-3.0-86.lua:570: CreateFrame(): Couldn\"t find inherited node \"DialogBorderOpaqueTemplate\"",
			["time"] = "2023/07/20 00:19:55",
			["locals"] = "LibStub = <table> {\n NewLibrary = <func> @ArkInventory\\Libs\\..\\LibStub.lua:11\n minors = <table> {}\n minor = 2\n IterateLibraries = <func> @ArkInventory\\Libs\\..\\LibStub.lua:28\n GetLibrary = <func> @ArkInventory\\Libs\\..\\LibStub.lua:21\n libs = <table> {}\n}\ngui = <table> {\n objPools = <table> {}\n RegisterAsContainer = <func> @TomTom\\libs\\..\\AceGUI-3.0.lua:511\n RegisterWidgetType = <func> @TomTom\\libs\\..\\AceGUI-3.0.lua:549\n WidgetBase = <table> {}\n RegisterAsWidget = <func> @TomTom\\libs\\..\\AceGUI-3.0.lua:527\n counts = <table> {}\n SetFocus = <func> @TomTom\\libs\\..\\AceGUI-3.0.lua:233\n LayoutRegistry = <table> {}\n GetLayout = <func> @TomTom\\libs\\..\\AceGUI-3.0.lua:573\n GetWidgetVersion = <func> @TomTom\\libs\\..\\AceGUI-3.0.lua:603\n tooltip = AceGUITooltip {}\n Create = <func> @TomTom\\libs\\..\\AceGUI-3.0.lua:138\n GetWidgetCount = <func> @TomTom\\libs\\..\\AceGUI-3.0.lua:597\n GetNextWidgetNum = <func> @TomTom\\libs\\..\\AceGUI-3.0.lua:586\n WidgetRegistry = <table> {}\n WidgetVersions = <table> {}\n RegisterLayout = <func> @TomTom\\libs\\..\\AceGUI-3.0.lua:563\n Release = <func> @TomTom\\libs\\..\\AceGUI-3.0.lua:172\n ClearFocus = <func> @TomTom\\libs\\..\\AceGUI-3.0.lua:243\n WidgetContainerBase = <table> {}\n IsReleasing = <func> @TomTom\\libs\\..\\AceGUI-3.0.lua:213\n}\nreg = <table> {\n RegisterOptionsTable = <func> @TomTom\\libs\\AceConfig-3.0\\..\\AceConfigRegistry-3.0.lua:316\n validated = <table> {}\n tables = <table> {}\n callbacks = <table> {}\n RegisterCallback = <func> @ArkInventory\\Libs\\CallbackHandler\\CallbackHandler-1.0.lua:117\n GetOptionsTable = <func> @TomTom\\libs\\AceConfig-3.0\\..\\AceConfigRegistry-3.0.lua:361\n UnregisterCallback = <func> @ArkInventory\\Libs\\CallbackHandler\\CallbackHandler-1.0.lua:180\n IterateOptionsTables = <func> @TomTom\\libs\\AceConfig-3.0\\..\\AceConfigRegistry-3.0.lua:347\n NotifyChange = <func> @TomTom\\libs\\AceConfig-3.0\\..\\AceConfigRegistry-3.0.lua:290\n ValidateOptionsTable = <func> @TomTom\\libs\\AceConfig-3.0\\..\\AceConfigRegistry-3.0.lua:277\n UnregisterAllCallbacks = <func> @ArkInventory\\Libs\\CallbackHandler\\CallbackHandler-1.0.lua:201\n}\nMAJOR = \"AceConfigDialog-3.0\"\nMINOR = 86\nAceConfigDialog = <table> {\n ConfigTableChanged = <func> @ArkInventory\\Externals\\Ace3-AceConfig\\..\\AceConfigDialog-3.0.lua:1765\n CloseAll = <func> @ArkInventory\\Externals\\Ace3-AceConfig\\..\\AceConfigDialog-3.0.lua:1746\n Close = <func> @ArkInventory\\Externals\\Ace3-AceConfig\\..\\AceConfigDialog-3.0.lua:1756\n SetDefaultSize = <func> @ArkInventory\\Externals\\Ace3-AceConfig\\..\\AceConfigDialog-3.0.lua:1776\n tooltip = AceConfigDialogTooltip {}\n Open = <func> @ArkInventory\\Externals\\Ace3-AceConfig\\..\\AceConfigDialog-3.0.lua:1791\n popup = <unnamed> {}\n AddToBlizOptions = <func> @ArkInventory\\Externals\\Ace3-AceConfig\\..\\AceConfigDialog-3.0.lua:1914\n OpenFrames = <table> {}\n GetStatusTable = <func> @TomTom\\libs\\AceConfig-3.0\\..\\AceConfi",
			["stack"] = "<in C code>\nAceConfigDialog-3.0\\AceConfigDialog-3.0-86.lua:570: in main chunk",
			["session"] = 11,
			["counter"] = 5,
		}, -- [8]
		{
			["message"] = "TomTom-v3.5.1-release\\libs\\AceDB-3.0\\AceDB-3.0-28.lua:263: attempt to call global \"GetCurrentRegion\" (a nil value)",
			["time"] = "2023/07/20 00:19:55",
			["locals"] = "",
			["stack"] = "TomTom-v3.5.1-release\\libs\\AceDB-3.0\\AceDB-3.0-28.lua:263: in main chunk",
			["session"] = 11,
			["counter"] = 5,
		}, -- [9]
		{
			["message"] = "TomTom-v3.5.1-release\\libs\\HereBeDragons\\HereBeDragons-2.0-22.lua:152: attempt to call global \"CreateVector2D\" (a nil value)",
			["time"] = "2023/07/20 00:19:55",
			["locals"] = "",
			["stack"] = "TomTom-v3.5.1-release\\libs\\HereBeDragons\\HereBeDragons-2.0-22.lua:152: in main chunk",
			["session"] = 11,
			["counter"] = 5,
		}, -- [10]
		{
			["message"] = "libs\\HereBeDragons\\HereBeDragons-Pins-2.0-12.lua:23: attempt to call global \"CreateFramePool\" (a nil value)",
			["time"] = "2023/07/20 00:19:55",
			["locals"] = "",
			["stack"] = "libs\\HereBeDragons\\HereBeDragons-Pins-2.0-12.lua:23: in main chunk",
			["session"] = 11,
			["counter"] = 5,
		}, -- [11]
		{
			["message"] = "TomTom-v3.5.1-release\\AddonCore.lua:218: attempt to call local \"Mixin\" (a nil value)",
			["time"] = "2023/07/20 00:19:55",
			["locals"] = "",
			["stack"] = "TomTom-v3.5.1-release\\AddonCore.lua:218: in main chunk",
			["session"] = 11,
			["counter"] = 5,
		}, -- [12]
		{
			["message"] = "TomTom\\TomTom-v3.5.1-release.lua:1211: attempt to index global \"Enum\" (a nil value)",
			["time"] = "2023/07/20 00:19:55",
			["locals"] = "",
			["stack"] = "TomTom\\TomTom-v3.5.1-release.lua:1211: in main chunk",
			["session"] = 11,
			["counter"] = 5,
		}, -- [13]
		{
			["message"] = "TomTom-v3.5.1-release\\TomTom_CrazyArrow.lua:338: attempt to call method \"NewMenu\" (a nil value)",
			["time"] = "2023/07/20 00:19:55",
			["locals"] = "sformat = <func> =[C]:-1\nL = <table> {\n Player: --- = \"Player: ---\"\n Saved pages: %s = \"Saved pages: %s\"\n Allow control-right clicking on map to create new waypoint = \"Allow control-right clicking on map to create new waypoint\"\n Play a sound when arriving at a waypoint = \"Play a sound when arriving at a waypoint\"\n Minimap = \"Minimap\"\n Place the arrow in the HIGH strata = \"Place the arrow in the HIGH strata\"\n list = \"list\"\n Arrow locked = \"Arrow locked\"\n When you 'arrive' at a waypoint (this distance is controlled by the 'Arrival Distance' setting in this group) a sound can be played to indicate this.  You can enable or disable this sound using this setting. = \"When you 'arrive' at a waypoint (this distance is controlled by the 'Arrival Distance' setting in this group) a sound can be played to indicate this.  You can enable or disable this sound using this setting.\"\n TomTom can be configured to set waypoints for the quest objectives that are shown in the watch frame and on the world map.  These options can be used to configure these options. = \"TomTom can be configured to set waypoints for the quest objectives that are shown in the watch frame and on the world map.  These options can be used to configure these options.\"\n Border color = \"Border color\"\n Disable all mouse input = \"Disable all mouse input\"\n Alpha = \"Alpha\"\n Prompt before accepting sent waypoints = \"Prompt before accepting sent waypoints\"\n |cffffff78/wayb [desc] |r - Save the current position with optional description = \"|cffffff78/wayb [desc] |r - Save the current position with optional description\"\n   /ttpaste save [title] - Save the current contents of the window with the given name = \"  /ttpaste save [title] - Save the current contents of the window with the given name\"\n Icon Control = \"Icon Control\"\n Coordinate feed throttle = \"Coordinate feed throttle\"\n load = \"load\"\n   /ttpaste toggle - Show/hide the paste window = \"  /ttpaste toggle - Show/hide the paste window\"\n Player: %s = \"Player: %s\"\n This setting allows you to specify the scale of the title text. = \"This setting allows you to specify the scale of the title text.\"\n Good color = \"Good color\"\n |cffffff78TomTom:|r Selected waypoint (%s%s%s) in %s = \"|cffffff78TomTom:|r Selected waypoint (%s%s%s) in %s\"\n Show estimated time to arrival = \"Show estimated time to arrival\"\n Display Settings = \"Display Settings\"\n No contents to save = \"No contents to save\"\n   /ttpaste remove [title] - Remove a saved page = \"  /ttpaste remove [title] - Remove a saved page\"\n Background color = \"Background color\"\n Enables the automatic setting of quest objective waypoints based on which objective is closest to your current location.  This setting WILL override the setting of manual waypoints. = \"Enables the automatic setting of quest objective waypoints based on which objective is closest to your current location.  This setting WILL override the setting of manual waypoints.\"\n Show the distance to the waypoint = \"Show the distance to the waypoint\"\n New Purple Ring = \"New Purple Ring\"\n Arrow colors = \"Arrow colors\"\n Enables a floating block that displays your current position in the current zone = \"Enables a floating block that displays your current position in the current zone\"\n New Gold Purple Dot = \"New Gold Purple Dot\"\n Data Feed Options = \"Data Feed Options\"\n |cffffff78TomTom:|r CrazyArrow %s hijacked = \"|cffffff78TomTom:|r CrazyArrow %s hijacked\"\n Coordinate feed accuracy = \"Coordinate feed accuracy\"\n Scale = \"Scale\"\n |cffffff78TomTom:|r Could not find a closest waypoint in this continent. = \"|cffffff78TomTom:|r Could not find a closest waypoint in this continent.\"\n |cffffff78TomTom:|r CoordBlock %s visible = \"|cffffff78TomTom:|r CoordBlock %s visible\"\n The color to be displayed when you are moving in the exact direction of the active waypoint = \"The color to be displayed when you are moving in the exact direction of the active waypoint\"\n |cffffff78TomTom:|r Added a waypoint (%s%s%s) in %s = \"|cffffff78TomTom:|r Added a waypoint (%s%s%s) in %s\"\n New Gold Red Dot = \"New Gold Red Dot\"\n %s (%.2f, %.2f) = \"%s (%.",
			["stack"] = "TomTom-v3.5.1-release\\TomTom_CrazyArrow.lua:338: in function \"initDropdown\"\nTomTom-v3.5.1-release\\TomTom_CrazyArrow.lua:439: in main chunk",
			["session"] = 11,
			["counter"] = 5,
		}, -- [14]
		{
			["message"] = "TomTom-v3.5.1-release\\TomTom_Paste.lua:26: attempt to call global \"Mixin\" (a nil value)",
			["time"] = "2023/07/20 00:19:55",
			["locals"] = "",
			["stack"] = "TomTom-v3.5.1-release\\TomTom_Paste.lua:26: in main chunk",
			["session"] = 11,
			["counter"] = 5,
		}, -- [15]
		{
			["message"] = "TomTom-v3.5.1-release\\TomTom_POIIntegration.lua:277: hooksecurefunc(): QuestPOIButton_OnClick is not a function",
			["time"] = "2023/07/20 00:19:55",
			["locals"] = "addonName = \"TomTom\"\naddon = <table> {\n ProjectIsClassic = <func> @..\\AddonCore.lua:97\n Enable = <func> @..\\TomTom.lua:210\n ShowHideCrazyArrow = <func> @..\\TomTom_CrazyArrow.lua:273\n CreateWorldMapClickHandler = <func> @..\\TomTom.lua:509\n ClearAllWaypoints = <func> @..\\TomTom.lua:279\n GetDirectionToWaypoint = <func> @..\\TomTom_Waypoints.lua:275\n ResetWaypointOptions = <func> @..\\TomTom.lua:288\n GetKeyArgs = <func> @..\\TomTom.lua:231\n AddWaypointToCurrentZone = <func> @..\\TomTom.lua:890\n DefaultCallbacks = <func> @..\\TomTom.lua:910\n InitializeDropdown = <func> @..\\TomTom.lua:625\n IsDragonflight = <func> @..\\AddonCore.lua:109\n Printf = <func> @..\\AddonCore.lua:120\n ProjectIsRetail = <func> @..\\AddonCore.lua:93\n AddWaypoint = <func> @..\\TomTom.lua:966\n TEXTURE = \"ChatFrame\\ChatFrameBackground\"\n DebugListAllWaypoints = <func> @..\\TomTom.lua:1170\n IsCrazyArrowEmpty = <func> @..\\TomTom_CrazyArrow.lua:124\n version = \"v3.5.1-release\"\n Initialize = <func> @..\\TomTom.lua:31\n ClearWaypoint = <func> @..\\TomTom_Waypoints.lua:242\n SetCrazyArrow = <func> @..\\TomTom_CrazyArrow.lua:105\n GetDistanceToWaypoint = <func> @..\\TomTom_Waypoints.lua:267\n IsValidWaypoint = <func> @..\\TomTom.lua:1025\n GetCurrentPlayerPosition = <func> @..\\TomTom.lua:242\n hbd = <table> {}\n UpdateCoordFeedThrottle = <func> @..\\TomTom.lua:348\n WaypointExists = <func> @..\\TomTom.lua:1036\n DebugCoordBlock = <func> @..\\TomTom.lua:399\n ShowHideWorldCoords = <func> @..\\TomTom.lua:352\n GetKey = <func> @..\\TomTom.lua:226\n HideWaypoint = <func> @..\\TomTom_Waypoints.lua:215\n ProjectIsWrath = <func> @..\\AddonCore.lua:105\n GetCurrentCoords = <func> @..\\TomTom.lua:265\n ShowHideCoordBlock = <func> @..\\TomTom.lua:412\n SendWaypoint = <func> @..\\TomTom.lua:751\n ReparentMinimap = <func> @..\\TomTom_Waypoints.lua:65\n AddWaypointFromMapClick = <func> @..\\TomTom.lua:549\n eventFrame = TomTomEventFrame {}\n ReloadOptions = <func> @..\\TomTom.lua:270\n SetWaypoint = <func> @..\\TomTom_Waypoints.lua:75\n slashCommandUsage = <func> @..\\TomTom.lua:1188\n CreateConfigPanels = <func> @..\\TomTom_Config.lua:929\n DebugListLocalWaypoints = <func> @..\\TomTom.lua:1152\n CZWFromMapID = <table> {}\n APIIsTrue = <func> @..\\AddonCore.lua:74\n WOW_MAINLINE = true\n RemoveWaypoint = <func> @..\\TomTom.lua:869\n WOW_CLASSIC = true\n CHAT_MSG_ADDON = <func> @..\\TomTom.lua:759\n WOW_BURNING_CRUSADE_CLASSIC = true\n ReloadWaypoints = <func> @..\\TomTom.lua:304\n ProjectIsBCC = <func> @..\\AddonCore.lua:101\n ShowWaypoint = <func> @..\\TomTom_Waypoints.lua:230\n SetCustomWaypoint = <func> @..\\To",
			["stack"] = "<in C code>\nTomTom-v3.5.1-release\\TomTom_POIIntegration.lua:277: in main chunk",
			["session"] = 11,
			["counter"] = 5,
		}, -- [16]
		{
			["message"] = "TomTom-v3.5.1-release\\libs\\AceGUI-3.0\\AceGUI-3.0-41.lua:474: attempt to index local \"self\" (a nil value)",
			["time"] = "2023/07/20 00:19:55",
			["stack"] = "TomTom-v3.5.1-release\\libs\\AceGUI-3.0\\AceGUI-3.0-41.lua:474: in function <TomTom\\libs\\AceGUI-3.0\\AceGUI-3.0.lua:473>\n<in C code>\nTomTom-v3.5.1-release\\libs\\AceGUI-3.0\\AceGUI-3.0-41.lua:66: in function <TomTom\\libs\\AceGUI-3.0\\AceGUI-3.0.lua:64>\nTomTom-v3.5.1-release\\libs\\AceGUI-3.0\\AceGUI-3.0-41.lua:161: in function \"Create\"\nAceConfigDialog-3.0\\AceConfigDialog-3.0-86.lua:1927: in function \"AddToBlizOptions\"\nQuestHelper-4.3.0.244r\\config.lua:72: in function \"SetupGUI\"\nQuestHelper-4.3.0.244r\\config.lua:60: in function \"OnInit\"\nQuestHelper-4.3.0.244r\\config.lua:50: in function \"func\"\nQuestHelper-4.3.0.244r\\manager_event.lua:64: in function <QuestHelper\\manager_event.lua:28>\nQuestHelper-4.3.0.244r\\manager_event.lua:79: in function <QuestHelper\\manager_event.lua:73>",
			["session"] = 11,
			["counter"] = 163,
		}, -- [17]
		{
			["message"] = "TomTom-v3.5.1-release\\libs\\AceGUI-3.0\\AceGUI-3.0-41.lua:419: attempt to index local \"self\" (a nil value)",
			["time"] = "2023/07/20 00:19:55",
			["stack"] = "TomTom-v3.5.1-release\\libs\\AceGUI-3.0\\AceGUI-3.0-41.lua:419: in function <TomTom\\libs\\AceGUI-3.0\\AceGUI-3.0.lua:418>\n<in C code>\nTomTom-v3.5.1-release\\libs\\AceGUI-3.0\\AceGUI-3.0-41.lua:66: in function <TomTom\\libs\\AceGUI-3.0\\AceGUI-3.0.lua:64>\nTomTom-v3.5.1-release\\libs\\AceGUI-3.0\\AceGUI-3.0-41.lua:162: in function \"Create\"\nAceConfigDialog-3.0\\AceConfigDialog-3.0-86.lua:1927: in function \"AddToBlizOptions\"\nQuestHelper-4.3.0.244r\\config.lua:72: in function \"SetupGUI\"\nQuestHelper-4.3.0.244r\\config.lua:60: in function \"OnInit\"\nQuestHelper-4.3.0.244r\\config.lua:50: in function \"func\"\nQuestHelper-4.3.0.244r\\manager_event.lua:64: in function <QuestHelper\\manager_event.lua:28>\nQuestHelper-4.3.0.244r\\manager_event.lua:79: in function <QuestHelper\\manager_event.lua:73>",
			["session"] = 11,
			["counter"] = 163,
		}, -- [18]
		{
			["message"] = "TomTom-v3.5.1-release\\TomTom_CrazyArrow.lua:83: attempt to index field \"profile\" (a nil value)",
			["time"] = "2023/07/20 00:20:03",
			["locals"] = "",
			["stack"] = "TomTom-v3.5.1-release\\TomTom_CrazyArrow.lua:83: in function <TomTom\\TomTom_CrazyArrow.lua:76>",
			["session"] = 11,
			["counter"] = 5,
		}, -- [19]
		{
			["message"] = "TomTom-v3.5.1-release\\TomTom_POIIntegration.lua:46: attempt to index global \"C_Map\" (a nil value)",
			["time"] = "2023/07/20 00:20:03",
			["locals"] = "self = <unnamed> {\n 0 = <userdata>\n}\nevent = \"QUEST_LOG_UPDATE\"\nObjectivesChanged = <func> @TomTom\\TomTom_POIIntegration.lua:32\n",
			["stack"] = "TomTom-v3.5.1-release\\TomTom_POIIntegration.lua:46: in function <TomTom\\TomTom_POIIntegration.lua:32>\nTomTom-v3.5.1-release\\TomTom_POIIntegration.lua:161: in function <TomTom\\TomTom_POIIntegration.lua:157>",
			["session"] = 11,
			["counter"] = 5,
		}, -- [20]
		{
			["message"] = "DocsUI_Nameplates-5.1\\options.lua:91: attempt to index local \"list\" (a nil value)",
			["time"] = "2023/07/20 02:51:41",
			["locals"] = "self = <unnamed> {\n 0 = <userdata>\n}\nn = \"Unstable Affliction\"\ntext = \"Name\"\ndatabase = <table> {\n filterLow = true\n emphasize = false\n filterName = \"Unstable Affliction\"\n buffs = <table> {}\n debuffs = <table> {}\n filterOnlyMy = false\n}\nkey = \"filterName\"\nfilterAddOnClick = <func> @DocsUI_Nameplates\\options.lua:51\n",
			["stack"] = "DocsUI_Nameplates-5.1\\options.lua:91: in function <DocsUI_Nameplates\\options.lua:51>\nDocsUI_Nameplates-5.1\\options.lua:1337: in function <DocsUI_Nameplates\\options.lua:1330>",
			["session"] = 16,
			["counter"] = 1,
		}, -- [21]
		{
			["message"] = "Skinner-b4.15595.11\\UtilFuncs.lua:120: attempt to get length of local \"table\" (a nil value)",
			["time"] = "2023/07/20 02:40:14",
			["stack"] = "Skinner-b4.15595.11\\UtilFuncs.lua:120: in function \"add2Table\"\nSkinner-b4.15595.11\\modules\\UIButtons.lua:495: in function \"addButtonBorder\"\nSkinner-b4.15595.11\\CharacterFrames1.lua:58: in function <Skinner\\CharacterFrames1.lua:32>\n(tail call): ?\n<in C code>\nSkinner-b4.15595.11\\UtilFuncs.lua:106: in function <Skinner\\UtilFuncs.lua:104>\n(tail call): ?\nSkinner-b4.15595.11\\CharacterFrames1.lua:15: in function <Skinner\\CharacterFrames1.lua:6>\n(tail call): ?\n<in C code>\nSkinner-b4.15595.11\\UtilFuncs.lua:106: in function <Skinner\\UtilFuncs.lua:104>\n(tail call): ?\nSkinner-b4.15595.11\\AddonFrames.lua:17: in function <Skinner\\AddonFrames.lua:3>\n(tail call): ?\n<in C code>\n<string>:\"safecall Dispatcher[1]\":9: in function <string>:\"safecall Dispatcher[1]\":5\n(tail call): ?\n...\\WeakAuras\\Libs\\AceTimer-3.0\\AceTimer-3.0-1017.lua:307: in function <...\\WeakAuras\\Libs\\AceTimer-3.0\\AceTimer-3.0.lua:298>",
			["session"] = 17,
			["counter"] = 2,
		}, -- [22]
		{
			["message"] = "Prefix is too long",
			["time"] = "2023/07/20 05:01:51",
			["locals"] = "(*temporary) = \"LibGroupTalents-1.0\"\n(*temporary) = \"HELLO 65\"\n(*temporary) = \"PARTY\"\n(*temporary) = nil\n = <func> =[C]:-1\n = <func> @BugSack\\Libs\\AceComm-3.0\\ChatThrottleLib.lua:216\n",
			["stack"] = "<in C code>\n<in C code>\n...\\BugSack\\Libs\\18AceComm-3.0-7\\ChatThrottleLib-22.nil.lua:468: in function \"SendAddonMessage\"\nLibs\\LibGroupTalents-1.0\\LibGroupTalents-1.0-65.lua:1341: in function \"SendCommMessage\"\nLibs\\LibGroupTalents-1.0\\LibGroupTalents-1.0-65.lua:335: in function \"OnRaidRosterUpdate\"\nLibs\\LibGroupTalents-1.0\\LibGroupTalents-1.0-65.lua:168: in function <Libs\\LibGroupTalents-1.0\\LibGroupTalents-1.0.lua:165>",
			["session"] = 18,
			["counter"] = 2,
		}, -- [23]
		{
			["message"] = "<string>:\"code\":1: unexpected symbol near \"=\"",
			["time"] = "2023/07/19 23:37:56",
			["locals"] = "",
			["stack"] = "",
			["session"] = 18,
			["counter"] = 23,
		}, -- [24]
		{
			["message"] = "Blizzard_InspectUI\\InspectGuildFrame.lua:18: Usage: GetGuildInfo(\"unit\")",
			["time"] = "2023/07/20 05:27:00",
			["locals"] = "",
			["stack"] = "<in C code>\nBlizzard_InspectUI\\InspectGuildFrame.lua:18: in function \"InspectGuildFrame_Update\"\nBlizzard_InspectUI\\InspectGuildFrame.lua:8: in function <Blizzard_InspectUI\\InspectGuildFrame.lua:6>",
			["session"] = 18,
			["counter"] = 19,
		}, -- [25]
	},
}
