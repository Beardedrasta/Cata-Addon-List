
AUCTIONATOR_SAVEDVARS = {
	["_200000"] = 1000,
	["_50000"] = 500,
	["_10000"] = 200,
	["_1000000"] = 2500,
	["_5000000"] = 10000,
	["STARTING_DISCOUNT"] = 5,
	["_500"] = 5,
	["_2000"] = 100,
}
AUCTIONATOR_PRICING_HISTORY = {
	["Heavy Shortbow"] = {
		["is"] = "3036:0",
		["7871408"] = "199500:1",
	},
	["Mystic's Robe"] = {
		["is"] = "14371:0",
		["7871564"] = "50000:1",
	},
	["Edged Bastard Sword of the Eagle"] = {
		["is"] = "3196:843",
		["7871565"] = "50000:1",
	},
	["Infantry Leggings of the Bear"] = {
		["is"] = "6337:1179",
		["7871408"] = "50000:1",
	},
	["Precision Bow"] = {
		["is"] = "8183:0",
		["7871564"] = "30000:1",
	},
	["Scholarly Robes"] = {
		["is"] = "2034:0",
		["7871564"] = "50000:1",
	},
}
AUCTIONATOR_SHOPPING_LISTS = {
	{
		["items"] = {
		},
		["isRecents"] = 1,
		["name"] = "Recent Searches",
	}, -- [1]
	{
		["items"] = {
			"Greater Cosmic Essence", -- [1]
			"Infinite Dust", -- [2]
			"Dream Shard", -- [3]
			"Abyss Crystal", -- [4]
		},
		["name"] = "Sample Shopping List #1",
		["isSorted"] = false,
	}, -- [2]
}
AUCTIONATOR_PRICE_DATABASE = {
	["__dbversion"] = 4,
	["Maelstrom_Alliance"] = {
		["Heavy Shortbow"] = {
			["H4630"] = 200000,
			["cc"] = 1,
			["id"] = "3036",
			["sc"] = 3,
			["mr"] = 200000,
		},
		["Thorbia's Gauntlets"] = {
			["H4630"] = 999999,
			["cc"] = 2,
			["id"] = "12994",
			["sc"] = 4,
			["mr"] = 999999,
		},
	},
}
AUCTIONATOR_LAST_SCAN_TIME = nil
AUCTIONATOR_TOONS = {
	["Beardedrasta"] = {
		["firstSeen"] = 1689814141,
		["firstVersion"] = "3.0.0",
	},
}
AUCTIONATOR_STACKING_PREFS = {
}
AUCTIONATOR_SCAN_MINLEVEL = 1
AUCTIONATOR_DB_MAXITEM_AGE = 180
AUCTIONATOR_DB_MAXHIST_AGE = -1
AUCTIONATOR_DB_MAXHIST_DAYS = 5
AUCTIONATOR_DC_PAUSE = nil
AUCTIONATOR_DE_DATA = nil
AUCTIONATOR_DE_DATA_BAK = nil
