
Prat3DB = {
	["namespaces"] = {
		["Prat_ChatTabs"] = {
			["profiles"] = {
				["Default"] = {
					["displaymode"] = {
						["ChatFrame2"] = false,
					},
				},
			},
		},
		["Prat_AltNames"] = {
		},
		["Prat_PlayerNames"] = {
		},
		["Prat_Frames"] = {
			["profiles"] = {
				["Default"] = {
					["initialized"] = true,
					["maxchatheightdefault"] = 400,
					["maxchatheight"] = 673,
					["maxchatwidthdefault"] = 608,
					["minchatwidthdefault"] = 296,
				},
			},
		},
		["Prat_ChannelColorMemory"] = {
		},
		["Prat_Fading"] = {
			["profiles"] = {
				["Default"] = {
					["on"] = false,
				},
			},
		},
		["Prat_ChannelNames"] = {
		},
		["Prat_Bubbles"] = {
		},
		["Prat_Scroll"] = {
		},
		["Prat_Paragraph"] = {
		},
		["Prat_Alias"] = {
		},
		["Prat_OriginalButtons"] = {
		},
		["Prat_History"] = {
		},
		["Prat_TellTarget"] = {
		},
		["Prat_Sounds"] = {
		},
		["Prat_ChannelSticky"] = {
		},
		["Prat_ChatLog"] = {
		},
		["Prat_CopyChat"] = {
		},
		["Prat_Timestamps"] = {
		},
		["Prat_Font"] = {
			["profiles"] = {
				["Default"] = {
					["outlinemode"] = "OUTLINE",
					["fontface"] = "DorisPP",
					["rememberfont"] = true,
				},
			},
		},
		["Prat_Buttons"] = {
			["profiles"] = {
				["Default"] = {
					["showBnet"] = false,
					["showButtons"] = false,
					["showMenu"] = false,
				},
			},
		},
		["Prat_ServerNames"] = {
		},
		["Prat_UrlCopy"] = {
		},
	},
	["profileKeys"] = {
		["Beardedrasta - Maelstrom"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["modules"] = {
				["Fading"] = 2,
				["OriginalButtons"] = 2,
				["AltNames"] = 2,
				["Paragraph"] = 2,
				["Alias"] = 2,
				["Sounds"] = 2,
				["ChatLog"] = 2,
			},
		},
	},
}
