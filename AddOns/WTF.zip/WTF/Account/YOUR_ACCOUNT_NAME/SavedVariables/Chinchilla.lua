
Chinchilla2DB = {
	["namespaces"] = {
		["Ping"] = {
		},
		["Coordinates"] = {
			["profiles"] = {
				["Default"] = {
					["enabled"] = false,
				},
			},
		},
		["Appearance"] = {
			["profiles"] = {
				["Default"] = {
					["blipScale"] = 0.9500000000000001,
					["scale"] = 2,
					["borderStyle"] = "Thin",
					["borderColor"] = {
						0.2588235294117647, -- [1]
						0.2588235294117647, -- [2]
						0.2588235294117647, -- [3]
					},
					["shape"] = "SQUARE",
				},
			},
		},
		["QuestTracker"] = {
		},
		["AutoZoom"] = {
			["profiles"] = {
				["Default"] = {
					["enabled"] = false,
				},
			},
		},
		["TrackingDots"] = {
			["profiles"] = {
				["Default"] = {
					["trackingDotStyle"] = "NandiniNew",
				},
			},
		},
		["RangeCircle"] = {
		},
		["WheelZoom"] = {
		},
		["ShowHide"] = {
			["profiles"] = {
				["Default"] = {
					["track"] = false,
					["vehicleSeats"] = false,
					["voice"] = false,
					["boss"] = false,
					["clock"] = false,
					["map"] = false,
					["zoom"] = false,
					["locationText"] = false,
					["mail"] = false,
					["dayNight"] = false,
					["battleground"] = "mouseover",
				},
			},
		},
		["Position"] = {
			["profiles"] = {
				["Default"] = {
					["minimap"] = {
						nil, -- [1]
						14.28327941894531, -- [2]
						20.47768402099609, -- [3]
					},
					["questWatch"] = {
						nil, -- [1]
						-301.6674346923828, -- [2]
						-284.5688095092773, -- [3]
					},
					["minimapLock"] = true,
				},
			},
		},
		["Location"] = {
			["profiles"] = {
				["Default"] = {
					["enabled"] = false,
				},
			},
		},
		["Compass"] = {
		},
		["MoveButtons"] = {
		},
		["Expander"] = {
		},
	},
	["profileKeys"] = {
		["Beardedrasta - Maelstrom"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
