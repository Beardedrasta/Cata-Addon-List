
SexyMapDB = {
	["profileKeys"] = {
		["Beardedrasta - Maelstrom"] = "Beardedrasta - Maelstrom",
	},
	["namespaces"] = {
		["Ping"] = {
			["profiles"] = {
				["Beardedrasta - Maelstrom"] = {
					["showPing"] = true,
					["showAt"] = "map",
				},
			},
		},
		["Coordinates"] = {
			["profiles"] = {
				["Beardedrasta - Maelstrom"] = {
					["enabled"] = false,
					["fontColor"] = {
					},
					["borderColor"] = {
					},
					["locked"] = false,
					["backgroundColor"] = {
					},
				},
			},
		},
		["General"] = {
			["profiles"] = {
				["Beardedrasta - Maelstrom"] = {
					["clamp"] = true,
					["point"] = "TOPRIGHT",
					["relpoint"] = "TOPRIGHT",
					["autoZoom"] = 5,
					["y"] = -3.848286867141724,
					["x"] = -4.472974300384522,
					["lock"] = false,
					["scale"] = 2.05,
					["rightClickToConfig"] = true,
				},
			},
		},
		["Buttons"] = {
			["profiles"] = {
				["Beardedrasta - Maelstrom"] = {
					["radius"] = 10,
					["lockDragging"] = false,
					["allowDragging"] = true,
					["visibilitySettings"] = {
						["MinimapZoomIn"] = "never",
						["MiniMapMailFrame"] = "always",
						["MiniMapWorldMapButton"] = "never",
						["MinimapZoomOut"] = "never",
						["MinimapZoneTextButton"] = "never",
						["TimeManagerClockButton"] = "never",
					},
					["dragPositions"] = {
						["DBMMinimapButton"] = 214.8513077014842,
						["LibDBIcon10_WeakAuras"] = 202.8744798061092,
						["LibDBIcon10_Skada"] = 191.9333185466565,
						["DominosMinimapButton"] = 142.452126732991,
						["XPerl_MinimapButton_Frame"] = 166.5370369655473,
					},
					["controlVisibility"] = true,
				},
			},
		},
		["Shapes"] = {
			["profiles"] = {
				["Beardedrasta - Maelstrom"] = {
					["shape"] = "Interface\\BUTTONS\\WHITE8X8",
				},
			},
		},
		["Fader"] = {
			["profiles"] = {
				["Beardedrasta - Maelstrom"] = {
					["enabled"] = false,
					["normalOpacity"] = 1,
					["hoverOpacity"] = 0.25,
				},
			},
		},
		["HudMap"] = {
			["profiles"] = {
				["Beardedrasta - Maelstrom"] = {
					["useQuestHelper"] = true,
					["setNewScale"] = true,
					["useRoutes"] = true,
					["useGatherMate"] = true,
					["scale"] = 1.4,
					["textColor"] = {
						["a"] = 1,
						["r"] = 0.5,
						["g"] = 1,
						["b"] = 0.5,
					},
					["alpha"] = 0.7,
					["hudColor"] = {
					},
				},
			},
		},
		["Borders"] = {
			["global"] = {
				["userPresets"] = {
				},
			},
			["profiles"] = {
				["Beardedrasta - Maelstrom"] = {
					["shape"] = "Interface\\BUTTONS\\WHITE8X8",
					["applyPreset"] = false,
					["borders"] = {
					},
					["backdrop"] = {
						["show"] = true,
						["textureColor"] = {
						},
						["settings"] = {
							["bgFile"] = "Interface\\Tooltips\\UI-Tooltip-Background",
							["edgeFile"] = "Interface\\AddOns\\ArkInventory\\Images\\BorderSquare2.tga",
							["edgeSize"] = 17,
							["tile"] = false,
							["insets"] = {
								["top"] = 4,
								["right"] = 4,
								["left"] = 4,
								["bottom"] = 4,
							},
						},
						["borderColor"] = {
							["a"] = 1,
							["r"] = 0.2,
							["g"] = 0.2,
							["b"] = 0.2,
						},
						["scale"] = 1.05,
					},
					["hideBlizzard"] = true,
				},
			},
		},
		["Movers"] = {
			["profiles"] = {
				["Beardedrasta - Maelstrom"] = {
					["enabled"] = false,
					["framePositions"] = {
					},
					["lock"] = false,
				},
			},
		},
		["ZoneText"] = {
			["profiles"] = {
				["Beardedrasta - Maelstrom"] = {
					["bgColor"] = {
						["a"] = 0,
						["r"] = 0,
						["g"] = 0,
						["b"] = 0,
					},
					["font"] = "Electrofied",
					["fontColor"] = {
					},
					["borderColor"] = {
						["a"] = 0,
						["r"] = 0,
						["g"] = 0,
						["b"] = 0,
					},
					["xOffset"] = 0,
					["yOffset"] = 0,
				},
			},
		},
	},
}
