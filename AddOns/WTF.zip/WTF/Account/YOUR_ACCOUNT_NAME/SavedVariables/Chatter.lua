
ChatterDB = {
	["namespaces"] = {
		["PlayerNames"] = {
		},
		["AltLinks"] = {
		},
		["Scrollback"] = {
		},
		["Invite Links"] = {
			["profiles"] = {
				["Default"] = {
					["words"] = {
						["inv"] = "inv",
						["invite"] = "invite",
					},
				},
			},
		},
		["ChannelColors"] = {
			["profiles"] = {
				["Default"] = {
					["colors"] = {
						["RealID Conversation"] = {
							["r"] = 0,
							["g"] = 0.6941176652908325,
							["b"] = 0.9411765336990356,
						},
						["General"] = {
							["r"] = 1,
							["g"] = 0.7529412508010864,
							["b"] = 0.7529412508010864,
						},
						["WorldChat"] = {
							["r"] = 0,
							["g"] = 1,
							["b"] = 0.7725490927696228,
						},
						["Raid Leader"] = {
							["r"] = 1,
							["g"] = 0.2823529541492462,
							["b"] = 0.03529411926865578,
						},
						["LookingForGroup"] = {
							["b"] = 0.7529412508010864,
							["g"] = 0.7529412508010864,
							["r"] = 1,
						},
						["Party"] = {
							["r"] = 0.6666666865348816,
							["g"] = 0.6666666865348816,
							["b"] = 1,
						},
						["Whisper"] = {
							["r"] = 1,
							["g"] = 0.501960813999176,
							["b"] = 1,
						},
						["Raid"] = {
							["r"] = 1,
							["g"] = 0.4980392456054688,
							["b"] = 0,
						},
						["Battleground Leader"] = {
							["r"] = 1,
							["g"] = 0.8588235974311829,
							["b"] = 0.7176470756530762,
						},
						["Raid Warning"] = {
							["r"] = 1,
							["g"] = 0.2823529541492462,
							["b"] = 0,
						},
						["Party Leader"] = {
							["r"] = 0.4627451300621033,
							["g"] = 0.7843137979507446,
							["b"] = 1,
						},
						["Yell"] = {
							["r"] = 1,
							["g"] = 0.250980406999588,
							["b"] = 0.250980406999588,
						},
						["LocalDefense"] = {
							["r"] = 1,
							["g"] = 0.7529412508010864,
							["b"] = 0.7529412508010864,
						},
						["Trade"] = {
							["b"] = 0.7529412508010864,
							["g"] = 0.7529412508010864,
							["r"] = 1,
						},
						["Say"] = {
							["r"] = 1,
							["g"] = 1,
							["b"] = 1,
						},
						["Officer"] = {
							["r"] = 0.250980406999588,
							["g"] = 0.7529412508010864,
							["b"] = 0.250980406999588,
						},
						["Guild"] = {
							["r"] = 0.250980406999588,
							["g"] = 1,
							["b"] = 0.250980406999588,
						},
						["RealID Whisper"] = {
							["r"] = 0,
							["g"] = 1,
							["b"] = 0.9647059440612793,
						},
						["Battleground"] = {
							["r"] = 1,
							["g"] = 0.4980392456054688,
							["b"] = 0,
						},
					},
				},
			},
		},
		["StickyChannels"] = {
		},
		["RealIdPolish"] = {
		},
		["ChatFrameBorders"] = {
			["profiles"] = {
				["Default"] = {
					["frames"] = {
						["FRAME_1"] = {
							["enable"] = false,
						},
						["FRAME_9"] = {
							["enable"] = false,
						},
						["FRAME_6"] = {
							["enable"] = false,
						},
						["FRAME_5"] = {
							["enable"] = false,
						},
						["FRAME_8"] = {
							["enable"] = false,
						},
						["FRAME_7"] = {
							["enable"] = false,
						},
						["FRAME_3"] = {
							["enable"] = false,
						},
						["FRAME_4"] = {
							["enable"] = false,
						},
						["FRAME_10"] = {
							["enable"] = false,
						},
						["FRAME_2"] = {
							["enable"] = false,
						},
					},
				},
			},
		},
		["Buttons"] = {
		},
		["Server Positioning"] = {
		},
		["Mousewheel Scroll"] = {
		},
		["Timestamps"] = {
		},
		["EditBox"] = {
			["profiles"] = {
				["Default"] = {
					["edgeSize"] = 8,
					["attach"] = "TOP",
					["border"] = "ArkInventory Square 2",
					["font"] = "Yanone",
					["borderColor"] = {
						["b"] = 0.2117647058823529,
						["g"] = 0.2117647058823529,
						["r"] = 0.2117647058823529,
					},
				},
			},
		},
		["ChatFont"] = {
			["profiles"] = {
				["Default"] = {
					["frames"] = {
						["FRAME_1"] = {
							["outline"] = "OUTLINE",
							["font"] = "Yanone",
							["fontsize"] = 17,
						},
					},
				},
			},
		},
		["ChatTabs"] = {
		},
		["ChannelNames"] = {
			["profiles"] = {
				["Default"] = {
					["channels"] = {
						["worldchat"] = "[WC]",
					},
				},
			},
		},
		["CopyChat"] = {
		},
		["UrlCopy"] = {
		},
		["Editbox History"] = {
			["realm"] = {
				["Maelstrom"] = {
					["history"] = {
						"/dominos", -- [1]
						"/wave", -- [2]
						"/p coming just gotta get to body", -- [3]
						"/p al;most to body", -- [4]
						"/p rip", -- [5]
						"/p full spellcaster group rip", -- [6]
						"/p the fuck i didnt get the gloves", -- [7]
						"/p ripppp", -- [8]
						"/p do my dmg ever be big as lock in cata?", -- [9]
						"/1 cringe", -- [10]
						"/p ayo", -- [11]
						"/p quests for days here", -- [12]
						"/p i gave breath buff", -- [13]
						"/s fuck is this tank", -- [14]
						"/p so you can insta roll on gear but you cant participate in the dung", -- [15]
						"/p makes sense", -- [16]
						"/p yeahh /flex", -- [17]
						"/p wtfffff", -- [18]
						"/p i thought they reset i go back close to the room and get bombarded", -- [19]
						"/p what a fuckin bitch", -- [20]
						"/p well im not running back cause i got soulstone and hunter a lazy fuck so not sure if youll have the dps", -- [21]
						"/p healer could use some mana", -- [22]
						"/poke", -- [23]
						"/poke", -- [24]
						"/poke", -- [25]
						"/poke", -- [26]
						"/p kick hunter i guess", -- [27]
						"/p wtf i jump down with everyone else", -- [28]
						"/p how i pull", -- [29]
						"/p nope", -- [30]
						"/p dismissed it before jump", -- [31]
						"/p once agan ran same place you guys did but it pulled. Prob should just kill", -- [32]
					},
				},
			},
		},
		["Highlight"] = {
		},
		["JustifyText"] = {
		},
	},
	["profileKeys"] = {
		["Beardedrasta - Maelstrom"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["modules"] = {
				["Timestamps"] = false,
			},
			["welcomeMessaged"] = true,
		},
	},
}
