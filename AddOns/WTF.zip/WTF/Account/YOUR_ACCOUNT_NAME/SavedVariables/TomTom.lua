
TomTomDB = nil
TomTomWaypoints = nil
TomTomWaypointsM = nil
