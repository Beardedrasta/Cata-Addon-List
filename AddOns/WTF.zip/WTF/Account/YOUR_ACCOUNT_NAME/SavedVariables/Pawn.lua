
PawnCommon = {
	["ShowUpgradesOnTooltips"] = true,
	["ShowSpace"] = false,
	["AlignNumbersRight"] = false,
	["ShowItemID"] = false,
	["ShowAsterisks"] = 1,
	["ShowValuesForUpgradesOnly"] = true,
	["Debug"] = false,
	["ShowReforgingAdvisor"] = true,
	["ColorTooltipBorder"] = true,
	["ShowTooltipIcons"] = true,
	["ShowSocketingAdvisor"] = true,
	["Scales"] = {
		["\"Wowhead\":ShamanRestoration"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "6e95ff",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
			},
			["SmartGemSocketing"] = true,
			["LocalizedName"] = "Shaman: restoration",
			["UpgradesFollowSpecialization"] = true,
			["GemQualityLevel"] = 86,
			["UnenchantedColor"] = "526fbf",
		},
		["\"Wowhead\":ShamanEnhancement"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "6e95ff",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = true,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
			},
			["SmartGemSocketing"] = true,
			["LocalizedName"] = "Shaman: enhancement",
			["UpgradesFollowSpecialization"] = true,
			["GemQualityLevel"] = 86,
			["UnenchantedColor"] = "526fbf",
		},
		["\"Wowhead\":RogueSubtlety"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "fff569",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = true,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
			},
			["SmartGemSocketing"] = true,
			["LocalizedName"] = "Rogue: subtlety",
			["UpgradesFollowSpecialization"] = true,
			["GemQualityLevel"] = 86,
			["UnenchantedColor"] = "bfb74e",
		},
		["\"Wowhead\":MageFire"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "69ccf0",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
			},
			["SmartGemSocketing"] = true,
			["LocalizedName"] = "Mage: fire",
			["UpgradesFollowSpecialization"] = true,
			["GemQualityLevel"] = 86,
			["UnenchantedColor"] = "4e99b3",
		},
		["\"Wowhead\":RogueAssassination"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "fff569",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = true,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
			},
			["SmartGemSocketing"] = true,
			["LocalizedName"] = "Rogue: assassination",
			["UpgradesFollowSpecialization"] = true,
			["GemQualityLevel"] = 86,
			["UnenchantedColor"] = "bfb74e",
		},
		["\"Wowhead\":WarriorArms"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "c79c6e",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
			},
			["SmartGemSocketing"] = true,
			["LocalizedName"] = "Warrior: arms",
			["UpgradesFollowSpecialization"] = true,
			["GemQualityLevel"] = 86,
			["UnenchantedColor"] = "957552",
		},
		["\"Wowhead\":WarriorFury"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "c79c6e",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
			},
			["SmartGemSocketing"] = true,
			["LocalizedName"] = "Warrior: fury",
			["UpgradesFollowSpecialization"] = true,
			["GemQualityLevel"] = 86,
			["UnenchantedColor"] = "957552",
		},
		["\"Wowhead\":DruidFeralDps"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "ff7d0a",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = true,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
			},
			["SmartGemSocketing"] = true,
			["LocalizedName"] = "Druid: feral cat",
			["UpgradesFollowSpecialization"] = true,
			["GemQualityLevel"] = 86,
			["UnenchantedColor"] = "bf5d07",
		},
		["\"Wowhead\":DeathKnightFrostDps"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "ff4d6b",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
			},
			["SmartGemSocketing"] = true,
			["LocalizedName"] = "DK: frost",
			["UpgradesFollowSpecialization"] = true,
			["GemQualityLevel"] = 86,
			["UnenchantedColor"] = "bf3950",
		},
		["\"Wowhead\":WarlockDestruction"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "bca5ff",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
				["Beardedrasta-Maelstrom"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_HAND"] = {
							0.0005389382915656157, -- [1]
							14168, -- [2]
							0, -- [3]
						},
						["INVTYPE_FEET"] = {
							0.8084074373484236, -- [1]
							6998, -- [2]
							0, -- [3]
						},
						["INVTYPE_RANGED"] = {
							0.4203718674211803, -- [1]
							56681, -- [2]
							0, -- [3]
						},
						["INVTYPE_FINGER"] = {
							1.34842360549717, -- [1]
							56659, -- [2]
							0, -- [3]
							0.0002694691457828079, -- [4]
							6743, -- [5]
							0, -- [6]
						},
						["INVTYPE_2HWEAPON"] = {
							2.427917003503099, -- [1]
							56698, -- [2]
							0, -- [3]
						},
						["INVTYPE_WRIST"] = {
							1.347345728914039, -- [1]
							14177, -- [2]
							0, -- [3]
						},
						["INVTYPE_WAIST"] = {
							2.339800592832121, -- [1]
							51968, -- [2]
							0, -- [3]
						},
						["INVTYPE_NECK"] = {
							0.004311506332524926, -- [1]
							51996, -- [2]
							0, -- [3]
						},
						["INVTYPE_LEGS"] = {
							2.9655079493398, -- [1]
							6903, -- [2]
							0, -- [3]
						},
						["INVTYPE_CHEST"] = {
							1.888978711937483, -- [1]
							65912, -- [2]
							0, -- [3]
						},
						["INVTYPE_CLOAK"] = {
							0.2112638102937214, -- [1]
							51994, -- [2]
							0, -- [3]
						},
					},
				},
			},
			["SmartGemSocketing"] = true,
			["LocalizedName"] = "Warlock: destruction",
			["UpgradesFollowSpecialization"] = true,
			["GemQualityLevel"] = 86,
			["UnenchantedColor"] = "8d7bbf",
		},
		["\"Wowhead\":WarlockAffliction"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "bca5ff",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
				["Beardedrasta-Maelstrom"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_HAND"] = {
							0.0005600672080649679, -- [1]
							14168, -- [2]
							0, -- [3]
						},
						["INVTYPE_FEET"] = {
							0.8401008120974517, -- [1]
							6998, -- [2]
							0, -- [3]
						},
						["INVTYPE_RANGED"] = {
							0.4144497339680762, -- [1]
							56681, -- [2]
							0, -- [3]
						},
						["INVTYPE_FINGER"] = {
							1.401288154578549, -- [1]
							56659, -- [2]
							0, -- [3]
							0.0002800336040324839, -- [4]
							6743, -- [5]
							0, -- [6]
						},
						["INVTYPE_2HWEAPON"] = {
							2.52310277233268, -- [1]
							56698, -- [2]
							0, -- [3]
						},
						["INVTYPE_WRIST"] = {
							1.400168020162419, -- [1]
							14177, -- [2]
							0, -- [3]
						},
						["INVTYPE_WAIST"] = {
							2.465135816297956, -- [1]
							51968, -- [2]
							0, -- [3]
						},
						["INVTYPE_NECK"] = {
							0.004480537664519743, -- [1]
							51996, -- [2]
							0, -- [3]
						},
						["INVTYPE_LEGS"] = {
							3.081769812377485, -- [1]
							6903, -- [2]
							0, -- [3]
						},
						["INVTYPE_CHEST"] = {
							1.963035564267712, -- [1]
							65912, -- [2]
							0, -- [3]
						},
						["INVTYPE_CLOAK"] = {
							0.208345001400168, -- [1]
							51994, -- [2]
							0, -- [3]
						},
					},
				},
			},
			["SmartGemSocketing"] = true,
			["LocalizedName"] = "Warlock: affliction",
			["UpgradesFollowSpecialization"] = true,
			["GemQualityLevel"] = 86,
			["UnenchantedColor"] = "8d7bbf",
		},
		["\"Wowhead\":PaladinHoly"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "f58cba",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = true,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
			},
			["SmartGemSocketing"] = true,
			["LocalizedName"] = "Paladin: holy",
			["UpgradesFollowSpecialization"] = true,
			["GemQualityLevel"] = 86,
			["UnenchantedColor"] = "b7698b",
		},
		["\"Wowhead\":PaladinTank"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "f58cba",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = true,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
			},
			["SmartGemSocketing"] = true,
			["LocalizedName"] = "Paladin: tank",
			["UpgradesFollowSpecialization"] = true,
			["GemQualityLevel"] = 86,
			["UnenchantedColor"] = "b7698b",
		},
		["\"Wowhead\":WarlockDemonology"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "bca5ff",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
				["Beardedrasta-Maelstrom"] = {
					["Visible"] = true,
					["BestItems"] = {
						["INVTYPE_HAND"] = {
							0.0005062009617818274, -- [1]
							14168, -- [2]
							0, -- [3]
						},
						["INVTYPE_FEET"] = {
							0.759301442672741, -- [1]
							6998, -- [2]
							0, -- [3]
						},
						["INVTYPE_RANGED"] = {
							0.3948367501898253, -- [1]
							56681, -- [2]
							0, -- [3]
						},
						["INVTYPE_FINGER"] = {
							1.266514806378132, -- [1]
							56659, -- [2]
							0, -- [3]
							0.0002531004808909137, -- [4]
							6743, -- [5]
							0, -- [6]
						},
						["INVTYPE_2HWEAPON"] = {
							2.280435332827132, -- [1]
							56698, -- [2]
							0, -- [3]
						},
						["INVTYPE_WRIST"] = {
							1.265502404454568, -- [1]
							14177, -- [2]
							0, -- [3]
						},
						["INVTYPE_WAIST"] = {
							2.278663629460896, -- [1]
							51968, -- [2]
							0, -- [3]
						},
						["INVTYPE_NECK"] = {
							0.004049607694254619, -- [1]
							51996, -- [2]
							0, -- [3]
						},
						["INVTYPE_LEGS"] = {
							2.785370792204505, -- [1]
							6903, -- [2]
							0, -- [3]
						},
						["INVTYPE_CHEST"] = {
							1.774234371045305, -- [1]
							65912, -- [2]
							0, -- [3]
						},
						["INVTYPE_CLOAK"] = {
							0.1984307770184763, -- [1]
							51994, -- [2]
							0, -- [3]
						},
					},
				},
			},
			["SmartGemSocketing"] = true,
			["LocalizedName"] = "Warlock: demonology",
			["UpgradesFollowSpecialization"] = true,
			["GemQualityLevel"] = 86,
			["UnenchantedColor"] = "8d7bbf",
		},
		["\"Wowhead\":PriestShadow"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "ffffff",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
			},
			["SmartGemSocketing"] = true,
			["LocalizedName"] = "Priest: shadow",
			["UpgradesFollowSpecialization"] = true,
			["GemQualityLevel"] = 86,
			["UnenchantedColor"] = "bfbfbf",
		},
		["\"Wowhead\":DruidRestoration"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "ff7d0a",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
			},
			["SmartGemSocketing"] = true,
			["LocalizedName"] = "Druid: restoration",
			["UpgradesFollowSpecialization"] = true,
			["GemQualityLevel"] = 86,
			["UnenchantedColor"] = "bf5d07",
		},
		["\"Wowhead\":HunterBeastMastery"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "abd473",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
			},
			["SmartGemSocketing"] = true,
			["LocalizedName"] = "Hunter: beast mastery",
			["UpgradesFollowSpecialization"] = true,
			["GemQualityLevel"] = 86,
			["UnenchantedColor"] = "809f56",
		},
		["\"Wowhead\":HunterMarksman"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "abd473",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
			},
			["SmartGemSocketing"] = true,
			["LocalizedName"] = "Hunter: marksman",
			["UpgradesFollowSpecialization"] = true,
			["GemQualityLevel"] = 86,
			["UnenchantedColor"] = "809f56",
		},
		["\"Wowhead\":RogueCombat"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "fff569",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = true,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
			},
			["SmartGemSocketing"] = true,
			["LocalizedName"] = "Rogue: combat",
			["UpgradesFollowSpecialization"] = true,
			["GemQualityLevel"] = 86,
			["UnenchantedColor"] = "bfb74e",
		},
		["\"Wowhead\":ShamanElemental"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "6e95ff",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
			},
			["SmartGemSocketing"] = true,
			["LocalizedName"] = "Shaman: elemental",
			["UpgradesFollowSpecialization"] = true,
			["GemQualityLevel"] = 86,
			["UnenchantedColor"] = "526fbf",
		},
		["\"Wowhead\":PaladinRetribution"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "f58cba",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = true,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
			},
			["SmartGemSocketing"] = true,
			["LocalizedName"] = "Paladin: retribution",
			["UpgradesFollowSpecialization"] = true,
			["GemQualityLevel"] = 86,
			["UnenchantedColor"] = "b7698b",
		},
		["\"Wowhead\":MageArcane"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "69ccf0",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
			},
			["SmartGemSocketing"] = true,
			["LocalizedName"] = "Mage: arcane",
			["UpgradesFollowSpecialization"] = true,
			["GemQualityLevel"] = 86,
			["UnenchantedColor"] = "4e99b3",
		},
		["\"Wowhead\":DeathKnightUnholyDps"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "ff4d6b",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = true,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
			},
			["SmartGemSocketing"] = true,
			["LocalizedName"] = "DK: unholy ",
			["UpgradesFollowSpecialization"] = true,
			["GemQualityLevel"] = 86,
			["UnenchantedColor"] = "bf3950",
		},
		["\"Wowhead\":WarriorTank"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "c79c6e",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = true,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
			},
			["SmartGemSocketing"] = true,
			["LocalizedName"] = "Warrior: tank",
			["UpgradesFollowSpecialization"] = true,
			["GemQualityLevel"] = 86,
			["UnenchantedColor"] = "957552",
		},
		["\"Wowhead\":PriestDiscipline"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "ffffff",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
			},
			["SmartGemSocketing"] = true,
			["LocalizedName"] = "Priest: discipline",
			["UpgradesFollowSpecialization"] = true,
			["GemQualityLevel"] = 86,
			["UnenchantedColor"] = "bfbfbf",
		},
		["\"Wowhead\":DruidBalance"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "ff7d0a",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
			},
			["SmartGemSocketing"] = true,
			["LocalizedName"] = "Druid: balance",
			["UpgradesFollowSpecialization"] = true,
			["GemQualityLevel"] = 86,
			["UnenchantedColor"] = "bf5d07",
		},
		["\"Wowhead\":DeathKnightBloodTank"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "ff4d6b",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = true,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
			},
			["SmartGemSocketing"] = true,
			["LocalizedName"] = "DK: blood",
			["UpgradesFollowSpecialization"] = true,
			["GemQualityLevel"] = 86,
			["UnenchantedColor"] = "bf3950",
		},
		["\"Wowhead\":HunterSurvival"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "abd473",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
			},
			["SmartGemSocketing"] = true,
			["LocalizedName"] = "Hunter: survival",
			["UpgradesFollowSpecialization"] = true,
			["GemQualityLevel"] = 86,
			["UnenchantedColor"] = "809f56",
		},
		["\"Wowhead\":MageFrost"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "69ccf0",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
			},
			["SmartGemSocketing"] = true,
			["LocalizedName"] = "Mage: frost",
			["UpgradesFollowSpecialization"] = true,
			["GemQualityLevel"] = 86,
			["UnenchantedColor"] = "4e99b3",
		},
		["\"Wowhead\":PriestHoly"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "ffffff",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = false,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
			},
			["SmartGemSocketing"] = true,
			["LocalizedName"] = "Priest: holy",
			["UpgradesFollowSpecialization"] = true,
			["GemQualityLevel"] = 86,
			["UnenchantedColor"] = "bfbfbf",
		},
		["\"Wowhead\":DruidFeralTank"] = {
			["MetaGemQualityLevel"] = 86,
			["Color"] = "ff7d0a",
			["SmartMetaGemSocketing"] = true,
			["DoNotShow1HUpgrades"] = true,
			["NormalizationFactor"] = 1,
			["DoNotShow2HUpgrades"] = false,
			["Provider"] = "Wowhead",
			["CogwheelQualityLevel"] = 86,
			["PerCharacterOptions"] = {
			},
			["SmartGemSocketing"] = true,
			["LocalizedName"] = "Druid: feral bear",
			["UpgradesFollowSpecialization"] = true,
			["GemQualityLevel"] = 86,
			["UnenchantedColor"] = "bf5d07",
		},
	},
	["ShownGettingStarted"] = true,
	["ButtonPosition"] = 2,
	["LastVersion"] = 1.516,
	["ShowQuestUpgradeAdvisor"] = true,
	["Digits"] = 1,
	["ShowLootUpgradeAdvisor"] = true,
}
