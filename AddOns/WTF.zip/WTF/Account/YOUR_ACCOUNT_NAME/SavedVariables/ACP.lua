
ACP_Data = {
	["sorter"] = "Group By Name",
	["NoRecurse"] = false,
	["NoChildren"] = true,
	["collapsed"] = {
		["Blizzard Addons"] = true,
	},
	["ProtectedAddons"] = {
		["ACP"] = true,
	},
}
