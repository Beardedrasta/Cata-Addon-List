
ARKINVDB = {
	["char"] = {
		["Beardedrasta - Maelstrom"] = {
			["option"] = {
				["version"] = 3.0295,
			},
		},
	},
	["profileKeys"] = {
		["Beardedrasta - Maelstrom"] = "Default",
	},
	["realm"] = {
		["Maelstrom"] = {
			["player"] = {
				["version"] = 3.0295,
				["data"] = {
					["+G O T"] = {
						["info"] = {
							["guild"] = "G O T",
							["money"] = 0,
							["class"] = "GUILD",
							["player_id"] = "+G O T",
							["faction_local"] = "Alliance",
							["name"] = "G O T",
							["faction"] = "Alliance",
							["guild_id"] = "+G O T",
							["level"] = 1,
							["class_local"] = "Guild",
							["realm"] = "Maelstrom",
						},
					},
					["Beardedrasta"] = {
						["info"] = {
							["realm"] = "Maelstrom",
							["level"] = 21,
							["money"] = 215993,
							["class"] = "WARLOCK",
							["gender"] = 2,
							["class_local"] = "Warlock",
							["race"] = "Gnome",
							["name"] = "Beardedrasta",
							["faction"] = "Alliance",
							["race_local"] = "Gnome",
							["skills"] = {
								"TAILORING", -- [1]
							},
							["player_id"] = "Beardedrasta",
							["faction_local"] = "Alliance",
						},
						["location"] = {
							{
								["bag"] = {
									{
										["q"] = 1,
										["type"] = 1,
										["count"] = 16,
										["slot"] = {
											{
												["q"] = 1,
												["age"] = 28164118,
												["loc_id"] = 1,
												["slot_id"] = 1,
												["sb"] = true,
												["bag_id"] = 1,
												["h"] = "|cffffffff|Hitem:6948:0:0:0:0:0:0:0:21:0|h[Hearthstone]|h|r",
												["count"] = 1,
												["new"] = 1,
											}, -- [1]
											{
												["q"] = 3,
												["bag_id"] = 1,
												["h"] = "|cff0070dd|Hitem:12994:0:0:0:0:0:0:0:31:0|h[Thorbia's Gauntlets]|h|r",
												["slot_id"] = 2,
												["sb"] = false,
												["age"] = 28164282,
												["loc_id"] = 1,
												["count"] = 1,
												["new"] = 1,
											}, -- [2]
											{
												["q"] = 1,
												["age"] = 28164287,
												["loc_id"] = 1,
												["count"] = 1,
												["sb"] = false,
												["h"] = "|cffffffff|Hitem:1645:0:0:0:0:0:0:0:31:0|h[Moonberry Juice]|h|r",
												["bag_id"] = 1,
												["slot_id"] = 3,
												["new"] = 1,
											}, -- [3]
											{
												["q"] = 1,
												["bag_id"] = 1,
												["loc_id"] = 1,
												["count"] = 1,
												["sb"] = false,
												["age"] = 28164010,
												["h"] = "|cffffffff|Hitem:58253:0:0:0:0:0:0:0:13:0|h[Orbital Targeting Device]|h|r",
												["slot_id"] = 4,
												["new"] = 1,
											}, -- [4]
											{
												["q"] = 1,
												["bag_id"] = 1,
												["age"] = 28164298,
												["loc_id"] = 1,
												["slot_id"] = 5,
												["sb"] = false,
												["h"] = "|cffffffff|Hitem:4338:0:0:0:0:0:0:0:32:0|h[Mageweave Cloth]|h|r",
												["count"] = 9,
												["new"] = 2,
											}, -- [5]
											{
												["q"] = 2,
												["bag_id"] = 1,
												["h"] = "|cff1eff00|Hitem:10939:0:0:0:0:0:0:0:23:0|h[Greater Magic Essence]|h|r",
												["count"] = 1,
												["sb"] = false,
												["age"] = 28164164,
												["loc_id"] = 1,
												["slot_id"] = 6,
												["new"] = 1,
											}, -- [6]
											{
												["q"] = 0,
												["age"] = 28164287,
												["loc_id"] = 1,
												["count"] = 1,
												["sb"] = false,
												["h"] = "|cff9d9d9d|Hitem:3801:0:0:0:0:0:0:0:31:0|h[Hardened Leather Boots]|h|r",
												["bag_id"] = 1,
												["slot_id"] = 7,
												["new"] = 1,
											}, -- [7]
											{
												["q"] = 1,
												["age"] = 28164283,
												["loc_id"] = 1,
												["slot_id"] = 8,
												["sb"] = false,
												["bag_id"] = 1,
												["h"] = "|cffffffff|Hitem:2320:0:0:0:0:0:0:0:31:0|h[Coarse Thread]|h|r",
												["count"] = 11,
												["new"] = 3,
											}, -- [8]
											{
												["q"] = 1,
												["age"] = 28164165,
												["h"] = "|cffffffff|Hitem:10940:0:0:0:0:0:0:0:23:0|h[Strange Dust]|h|r",
												["slot_id"] = 9,
												["sb"] = false,
												["bag_id"] = 1,
												["loc_id"] = 1,
												["count"] = 3,
												["new"] = 1,
											}, -- [9]
											{
												["q"] = 1,
												["bag_id"] = 1,
												["h"] = "|cffffffff|Hitem:57549:0:0:0:0:0:0:0:21:0|h[Prospector's Bag]|h|r",
												["count"] = 1,
												["sb"] = true,
												["age"] = 28164118,
												["loc_id"] = 1,
												["slot_id"] = 10,
												["new"] = 1,
											}, -- [10]
											{
												["q"] = 1,
												["bag_id"] = 1,
												["loc_id"] = 1,
												["count"] = 1,
												["sb"] = false,
												["age"] = 28164270,
												["h"] = "|cffffffff|Hitem:929:0:0:0:0:0:0:0:31:0|h[Healing Potion]|h|r",
												["slot_id"] = 11,
												["new"] = 1,
											}, -- [11]
											{
												["q"] = 1,
												["bag_id"] = 1,
												["h"] = "|cffffffff|Hitem:4599:0:0:0:0:0:0:0:31:0|h[Cured Ham Steak]|h|r",
												["count"] = 1,
												["sb"] = false,
												["age"] = 28164288,
												["loc_id"] = 1,
												["slot_id"] = 12,
												["new"] = 1,
											}, -- [12]
											{
												["q"] = 1,
												["age"] = 28164294,
												["h"] = "|cffffffff|Hitem:3220:0:0:0:0:0:0:0:31:0|h[Blood Sausage]|h|r",
												["count"] = 1,
												["sb"] = false,
												["bag_id"] = 1,
												["loc_id"] = 1,
												["slot_id"] = 13,
												["new"] = 3,
											}, -- [13]
											{
												["q"] = 1,
												["age"] = 28164289,
												["loc_id"] = 1,
												["count"] = 1,
												["sb"] = false,
												["bag_id"] = 1,
												["h"] = "|cffffffff|Hitem:3914:0:0:0:0:0:0:0:31:0|h[Journeyman's Backpack]|h|r",
												["slot_id"] = 14,
												["new"] = 1,
											}, -- [14]
											{
												["q"] = 1,
												["age"] = 28164189,
												["h"] = "|cffffffff|Hitem:5339:0:0:0:0:0:0:0:25:0|h[Serpentbloom]|h|r",
												["count"] = 3,
												["sb"] = false,
												["bag_id"] = 1,
												["loc_id"] = 1,
												["slot_id"] = 15,
												["new"] = 2,
											}, -- [15]
											{
												["q"] = 1,
												["bag_id"] = 1,
												["h"] = "|cffffffff|Hitem:858:0:0:0:0:0:0:0:31:0|h[Lesser Healing Potion]|h|r",
												["count"] = 3,
												["sb"] = false,
												["age"] = 28164272,
												["loc_id"] = 1,
												["slot_id"] = 16,
												["new"] = 3,
											}, -- [16]
										},
										["status"] = -3,
										["texture"] = "Interface\\Icons\\INV_Misc_Bag_07_Green",
									}, -- [1]
									{
										["q"] = 1,
										["type"] = 1,
										["count"] = 6,
										["slot"] = {
											{
												["q"] = 1,
												["age"] = 28164294,
												["loc_id"] = 1,
												["count"] = 1,
												["sb"] = false,
												["h"] = "|cffffffff|Hitem:4306:0:0:0:0:0:0:0:31:0|h[Silk Cloth]|h|r",
												["bag_id"] = 2,
												["slot_id"] = 1,
												["new"] = 1,
											}, -- [1]
											{
												["q"] = 0,
												["bag_id"] = 2,
												["h"] = "|cff9d9d9d|Hitem:3779:0:0:0:0:0:0:0:32:0|h[Hefty War Axe]|h|r",
												["loc_id"] = 1,
												["slot_id"] = 2,
												["sb"] = false,
												["age"] = 28164297,
												["count"] = 1,
												["new"] = 1,
											}, -- [2]
											{
												["q"] = 0,
												["age"] = 28164299,
												["loc_id"] = 1,
												["count"] = 1,
												["sb"] = false,
												["bag_id"] = 2,
												["slot_id"] = 3,
												["new"] = false,
											}, -- [3]
											{
												["q"] = 0,
												["h"] = "|cff9d9d9d|Hitem:8748:0:0:0:0:0:0:0:32:0|h[Double Mail Coif]|h|r",
												["age"] = 28164298,
												["loc_id"] = 1,
												["count"] = 1,
												["sb"] = false,
												["bag_id"] = 2,
												["slot_id"] = 4,
												["new"] = 1,
											}, -- [4]
											{
												["q"] = 0,
												["age"] = 28164299,
												["loc_id"] = 1,
												["slot_id"] = 5,
												["sb"] = false,
												["bag_id"] = 2,
												["count"] = 1,
												["new"] = false,
											}, -- [5]
											{
												["q"] = 0,
												["age"] = 28164283,
												["loc_id"] = 1,
												["slot_id"] = 6,
												["sb"] = false,
												["bag_id"] = 2,
												["count"] = 1,
												["new"] = false,
											}, -- [6]
										},
										["status"] = -3,
										["empty"] = 3,
										["h"] = "|cffffffff|Hitem:4496:0:0:0:0:0:0:0:32:0|h[Small Brown Pouch]|h|r",
										["texture"] = "Interface\\Icons\\INV_Misc_Bag_09",
									}, -- [2]
									{
										["q"] = 1,
										["type"] = 1,
										["count"] = 6,
										["slot"] = {
											{
												["q"] = 0,
												["age"] = 28164281,
												["loc_id"] = 1,
												["slot_id"] = 1,
												["sb"] = false,
												["bag_id"] = 3,
												["count"] = 1,
												["new"] = false,
											}, -- [1]
											{
												["q"] = 0,
												["bag_id"] = 3,
												["loc_id"] = 1,
												["count"] = 1,
												["sb"] = false,
												["age"] = 28164281,
												["slot_id"] = 2,
												["new"] = false,
											}, -- [2]
											{
												["q"] = 0,
												["bag_id"] = 3,
												["loc_id"] = 1,
												["count"] = 1,
												["sb"] = false,
												["age"] = 28164281,
												["slot_id"] = 3,
												["new"] = false,
											}, -- [3]
											{
												["q"] = 0,
												["bag_id"] = 3,
												["loc_id"] = 1,
												["slot_id"] = 4,
												["sb"] = false,
												["age"] = 28164281,
												["count"] = 1,
												["new"] = false,
											}, -- [4]
											{
												["q"] = 0,
												["age"] = 28164283,
												["loc_id"] = 1,
												["count"] = 1,
												["sb"] = false,
												["bag_id"] = 3,
												["slot_id"] = 5,
												["new"] = false,
											}, -- [5]
											{
												["q"] = 0,
												["age"] = 28164281,
												["loc_id"] = 1,
												["slot_id"] = 6,
												["sb"] = false,
												["bag_id"] = 3,
												["count"] = 1,
												["new"] = false,
											}, -- [6]
										},
										["status"] = -3,
										["empty"] = 6,
										["h"] = "|cffffffff|Hitem:828:0:0:0:0:0:0:0:32:0|h[Small Blue Pouch]|h|r",
										["texture"] = "Interface\\Icons\\INV_Misc_Bag_09_Blue",
									}, -- [3]
									{
										["q"] = 1,
										["type"] = 1,
										["count"] = 6,
										["slot"] = {
											{
												["q"] = 0,
												["age"] = 28164281,
												["loc_id"] = 1,
												["slot_id"] = 1,
												["sb"] = false,
												["bag_id"] = 4,
												["count"] = 1,
												["new"] = false,
											}, -- [1]
											{
												["q"] = 1,
												["age"] = 28164281,
												["h"] = "|cffffffff|Hitem:2592:0:0:0:0:0:0:0:31:0|h[Wool Cloth]|h|r",
												["slot_id"] = 2,
												["sb"] = false,
												["bag_id"] = 4,
												["loc_id"] = 1,
												["count"] = 12,
												["new"] = 1,
											}, -- [2]
											{
												["q"] = 1,
												["age"] = 28164281,
												["loc_id"] = 1,
												["slot_id"] = 3,
												["sb"] = false,
												["bag_id"] = 4,
												["h"] = "|cffffffff|Hitem:2592:0:0:0:0:0:0:0:31:0|h[Wool Cloth]|h|r",
												["count"] = 20,
												["new"] = 1,
											}, -- [3]
											{
												["q"] = 0,
												["age"] = 28164282,
												["loc_id"] = 1,
												["count"] = 1,
												["sb"] = false,
												["bag_id"] = 4,
												["slot_id"] = 4,
												["new"] = false,
											}, -- [4]
											{
												["q"] = 0,
												["age"] = 28164285,
												["loc_id"] = 1,
												["slot_id"] = 5,
												["sb"] = false,
												["bag_id"] = 4,
												["count"] = 1,
												["new"] = false,
											}, -- [5]
											{
												["q"] = 0,
												["bag_id"] = 4,
												["loc_id"] = 1,
												["count"] = 1,
												["sb"] = false,
												["age"] = 28164284,
												["slot_id"] = 6,
												["new"] = false,
											}, -- [6]
										},
										["status"] = -3,
										["empty"] = 4,
										["h"] = "|cffffffff|Hitem:828:0:0:0:0:0:0:0:32:0|h[Small Blue Pouch]|h|r",
										["texture"] = "Interface\\Icons\\INV_Misc_Bag_09_Blue",
									}, -- [4]
									{
										["q"] = 1,
										["type"] = 1,
										["count"] = 6,
										["slot"] = {
											{
												["q"] = 0,
												["age"] = 28164284,
												["loc_id"] = 1,
												["slot_id"] = 1,
												["sb"] = false,
												["bag_id"] = 5,
												["count"] = 1,
												["new"] = false,
											}, -- [1]
											{
												["q"] = 0,
												["age"] = 28164284,
												["loc_id"] = 1,
												["slot_id"] = 2,
												["sb"] = false,
												["bag_id"] = 5,
												["count"] = 1,
												["new"] = false,
											}, -- [2]
											{
												["q"] = 1,
												["bag_id"] = 5,
												["h"] = "|cffffffff|Hitem:4306:0:0:0:0:0:0:0:31:0|h[Silk Cloth]|h|r",
												["count"] = 20,
												["sb"] = false,
												["age"] = 28164294,
												["loc_id"] = 1,
												["slot_id"] = 3,
												["new"] = 2,
											}, -- [3]
											{
												["q"] = 2,
												["bag_id"] = 5,
												["h"] = "|cff1eff00|Hitem:9881:0:0:0:0:0:863:0:31:0|h[Sorcerer Mantle of the Eagle]|h|r",
												["slot_id"] = 4,
												["sb"] = false,
												["age"] = 28164284,
												["loc_id"] = 1,
												["count"] = 1,
												["new"] = 1,
											}, -- [4]
											{
												["q"] = 2,
												["age"] = 28164280,
												["loc_id"] = 1,
												["count"] = 1,
												["sb"] = false,
												["bag_id"] = 5,
												["h"] = "|cff1eff00|Hitem:15946:0:0:0:0:0:0:0:31:0|h[Mystic's Sphere]|h|r",
												["slot_id"] = 5,
												["new"] = 1,
											}, -- [5]
											{
												["q"] = 1,
												["age"] = 28164009,
												["h"] = "|cffffffff|Hitem:56222:0:0:0:0:0:0:0:13:0|h[Runes of Return]|h|r",
												["slot_id"] = 6,
												["sb"] = false,
												["bag_id"] = 5,
												["loc_id"] = 1,
												["count"] = 1,
												["new"] = 1,
											}, -- [6]
										},
										["status"] = -3,
										["empty"] = 2,
										["h"] = "|cffffffff|Hitem:59053:0:0:0:0:0:0:0:32:0|h[Airfield Courier Bag]|h|r",
										["texture"] = "Interface\\Icons\\INV_Misc_Bag_10_Black",
									}, -- [5]
								},
								["slot_count"] = 40,
							}, -- [1]
							nil, -- [2]
							nil, -- [3]
							nil, -- [4]
							{
								["bag"] = {
									{
										["type"] = 15,
										["status"] = -3,
									}, -- [1]
								},
							}, -- [5]
							{
								["bag"] = {
									{
										["type"] = 14,
										["count"] = 19,
										["slot"] = {
											{
												["q"] = 0,
												["loc_id"] = 6,
												["count"] = 1,
												["sb"] = false,
												["slot_id"] = 1,
												["age"] = 28163569,
												["bag_id"] = 1,
											}, -- [1]
											{
												["q"] = 3,
												["age"] = 28164299,
												["bag_id"] = 1,
												["h"] = "|cff0070dd|Hitem:51996:0:0:0:0:0:-16:11:32:0|h[Tumultuous Necklace of Stamina]|h|r",
												["count"] = 1,
												["sb"] = true,
												["loc_id"] = 6,
												["slot_id"] = 2,
												["new"] = 1,
											}, -- [2]
											{
												["q"] = 0,
												["loc_id"] = 6,
												["count"] = 1,
												["sb"] = false,
												["slot_id"] = 3,
												["age"] = 28163569,
												["bag_id"] = 1,
											}, -- [3]
											{
												["q"] = 3,
												["age"] = 28164194,
												["h"] = "|cff0070dd|Hitem:51994:0:0:0:0:0:-56:8:26:0|h[Tumultuous Cloak of the Battle]|h|r",
												["count"] = 1,
												["sb"] = true,
												["bag_id"] = 1,
												["loc_id"] = 6,
												["slot_id"] = 4,
												["new"] = 1,
											}, -- [4]
											{
												["q"] = 3,
												["bag_id"] = 1,
												["h"] = "|cff0070dd|Hitem:65912:0:0:0:0:0:0:0:30:0|h[Robe of Kelris]|h|r",
												["count"] = 1,
												["sb"] = true,
												["age"] = 28164268,
												["loc_id"] = 6,
												["slot_id"] = 5,
												["new"] = 1,
											}, -- [5]
											{
												["q"] = 0,
												["loc_id"] = 6,
												["count"] = 1,
												["sb"] = false,
												["slot_id"] = 6,
												["age"] = 28163569,
												["bag_id"] = 1,
											}, -- [6]
											{
												["q"] = 0,
												["loc_id"] = 6,
												["count"] = 1,
												["sb"] = false,
												["slot_id"] = 7,
												["age"] = 28163569,
												["bag_id"] = 1,
											}, -- [7]
											{
												["q"] = 2,
												["age"] = 28164250,
												["h"] = "|cff1eff00|Hitem:14177:0:0:0:0:0:112:0:29:0|h[Watcher's Cuffs of Intellect]|h|r",
												["count"] = 1,
												["sb"] = true,
												["bag_id"] = 1,
												["loc_id"] = 6,
												["slot_id"] = 8,
												["new"] = 1,
											}, -- [8]
											{
												["q"] = 2,
												["bag_id"] = 1,
												["h"] = "|cff1eff00|Hitem:14168:0:0:0:0:0:1012:0:22:0|h[Buccaneer's Gloves of the Whale]|h|r",
												["count"] = 1,
												["sb"] = true,
												["age"] = 28164159,
												["loc_id"] = 6,
												["slot_id"] = 9,
												["new"] = 1,
											}, -- [9]
											{
												["q"] = 3,
												["age"] = 28164118,
												["loc_id"] = 6,
												["count"] = 1,
												["sb"] = true,
												["bag_id"] = 1,
												["h"] = "|cff0070dd|Hitem:51968:0:0:0:0:0:-53:10:21:0|h[Enumerated Wrap of the Vision]|h|r",
												["slot_id"] = 10,
												["new"] = 1,
											}, -- [10]
											{
												["q"] = 3,
												["age"] = 28164281,
												["h"] = "|cff0070dd|Hitem:6903:0:0:0:0:0:0:0:31:0|h[Gaze Dreamer Pants]|h|r",
												["count"] = 1,
												["sb"] = true,
												["bag_id"] = 1,
												["loc_id"] = 6,
												["slot_id"] = 11,
												["new"] = 1,
											}, -- [11]
											{
												["q"] = 2,
												["bag_id"] = 1,
												["h"] = "|cff1eff00|Hitem:6998:0:0:0:0:0:0:0:30:0|h[Nimbus Boots]|h|r",
												["count"] = 1,
												["sb"] = true,
												["age"] = 28164269,
												["loc_id"] = 6,
												["slot_id"] = 12,
												["new"] = 1,
											}, -- [12]
											{
												["q"] = 2,
												["bag_id"] = 1,
												["h"] = "|cff1eff00|Hitem:6743:0:0:0:0:0:0:0:31:0|h[Sustaining Ring]|h|r",
												["slot_id"] = 13,
												["sb"] = true,
												["age"] = 28164269,
												["loc_id"] = 6,
												["count"] = 1,
												["new"] = 1,
											}, -- [13]
											{
												["q"] = 3,
												["bag_id"] = 1,
												["h"] = "|cff0070dd|Hitem:56659:0:0:0:0:0:0:0:31:0|h[Gloaming Band]|h|r",
												["slot_id"] = 14,
												["sb"] = true,
												["age"] = 28164269,
												["loc_id"] = 6,
												["count"] = 1,
												["new"] = 1,
											}, -- [14]
											{
												["q"] = 0,
												["loc_id"] = 6,
												["count"] = 1,
												["sb"] = false,
												["slot_id"] = 15,
												["age"] = 28163569,
												["bag_id"] = 1,
											}, -- [15]
											{
												["q"] = 0,
												["loc_id"] = 6,
												["count"] = 1,
												["sb"] = false,
												["slot_id"] = 16,
												["age"] = 28163569,
												["bag_id"] = 1,
											}, -- [16]
											{
												["q"] = 3,
												["age"] = 28164268,
												["h"] = "|cff0070dd|Hitem:56698:0:0:0:0:0:0:0:30:0|h[Gift of the Enigmatic Tree]|h|r",
												["count"] = 1,
												["sb"] = true,
												["bag_id"] = 1,
												["loc_id"] = 6,
												["slot_id"] = 17,
												["new"] = 1,
											}, -- [17]
											{
												["q"] = 0,
												["loc_id"] = 6,
												["count"] = 1,
												["sb"] = false,
												["slot_id"] = 18,
												["age"] = 28163569,
												["bag_id"] = 1,
											}, -- [18]
											{
												["q"] = 3,
												["bag_id"] = 1,
												["loc_id"] = 6,
												["slot_id"] = 19,
												["sb"] = true,
												["age"] = 28164281,
												["h"] = "|cff0070dd|Hitem:56681:0:0:0:0:0:0:0:31:0|h[Searching Wand]|h|r",
												["count"] = 1,
												["new"] = 1,
											}, -- [19]
										},
										["status"] = -3,
										["empty"] = 7,
									}, -- [1]
								},
								["slot_count"] = 19,
							}, -- [6]
							{
								["bag"] = {
									{
										["type"] = 17,
										["status"] = -3,
									}, -- [1]
								},
							}, -- [7]
							{
								["slot_count"] = 1,
								["bag"] = {
									{
										["type"] = 18,
										["count"] = 1,
										["slot"] = {
											{
												["q"] = 1,
												["type"] = "MOUNT",
												["age"] = 28164118,
												["bag_id"] = 1,
												["loc_id"] = 8,
												["slot_id"] = 1,
												["sb"] = true,
												["h"] = "|cff71d5ff|Hspell:5784|h[Felsteed]|h|r",
												["count"] = 1,
												["texture"] = "Interface\\Icons\\Spell_Nature_Swiftness",
												["new"] = 1,
											}, -- [1]
										},
										["status"] = -3,
									}, -- [1]
								},
							}, -- [8]
							[10] = {
								["slot_count"] = 6,
								["bag"] = {
									{
										["type"] = 20,
										["count"] = 6,
										["slot"] = {
											{
												["q"] = 2,
												["bag_id"] = 1,
												["expires"] = 28164848,
												["loc_id"] = 10,
												["slot_id"] = 1,
												["sb"] = false,
												["age"] = 28164128,
												["h"] = "|cff1eff00|Hitem:6337:0:0:0:0:0:1179:0:21:0|h[Infantry Leggings of the Bear]|h|r",
												["count"] = 1,
												["new"] = 1,
											}, -- [1]
											{
												["q"] = 2,
												["bag_id"] = 1,
												["expires"] = 28164848,
												["loc_id"] = 10,
												["slot_id"] = 2,
												["sb"] = false,
												["age"] = 28164128,
												["h"] = "|cff1eff00|Hitem:3036:0:0:0:0:0:0:0:21:0|h[Heavy Shortbow]|h|r",
												["count"] = 1,
												["new"] = 1,
											}, -- [2]
											{
												["q"] = 2,
												["bag_id"] = 1,
												["expires"] = 28165004,
												["loc_id"] = 10,
												["slot_id"] = 3,
												["sb"] = false,
												["age"] = 28164284,
												["h"] = "|cff1eff00|Hitem:8183:0:0:0:0:0:0:0:31:0|h[Precision Bow]|h|r",
												["count"] = 1,
												["new"] = 1,
											}, -- [3]
											{
												["q"] = 2,
												["bag_id"] = 1,
												["expires"] = 28165004,
												["loc_id"] = 10,
												["slot_id"] = 4,
												["sb"] = false,
												["age"] = 28164284,
												["h"] = "|cff1eff00|Hitem:14371:0:0:0:0:0:0:0:31:0|h[Mystic's Robe]|h|r",
												["count"] = 1,
												["new"] = 1,
											}, -- [4]
											{
												["q"] = 2,
												["bag_id"] = 1,
												["expires"] = 28165004,
												["loc_id"] = 10,
												["slot_id"] = 5,
												["sb"] = false,
												["age"] = 28164284,
												["h"] = "|cff1eff00|Hitem:2034:0:0:0:0:0:0:0:31:0|h[Scholarly Robes]|h|r",
												["count"] = 1,
												["new"] = 1,
											}, -- [5]
											{
												["q"] = 2,
												["bag_id"] = 1,
												["expires"] = 28165005,
												["loc_id"] = 10,
												["slot_id"] = 6,
												["sb"] = false,
												["age"] = 28164285,
												["h"] = "|cff1eff00|Hitem:3196:0:0:0:0:0:843:0:31:0|h[Edged Bastard Sword of the Eagle]|h|r",
												["count"] = 1,
												["new"] = 1,
											}, -- [6]
										},
										["status"] = -3,
									}, -- [1]
								},
							},
						},
					},
				},
			},
		},
	},
	["global"] = {
		["option"] = {
			["version"] = 3.0295,
			["tracking"] = {
				["items"] = {
					[6265] = true,
				},
			},
			["sort"] = {
				["data"] = {
					[9998] = {
						["order"] = {
							nil, -- [1]
							nil, -- [2]
							nil, -- [3]
							nil, -- [4]
							"itemstatlevel", -- [5]
							"itemuselevel", -- [6]
							"itemage", -- [7]
							"itemtype", -- [8]
							"vendorprice", -- [9]
						},
					},
					[9995] = {
						["order"] = {
							"itemstatlevel", -- [1]
							"itemuselevel", -- [2]
							"itemage", -- [3]
							"itemtype", -- [4]
							"name", -- [5]
							"category", -- [6]
							"location", -- [7]
							"vendorprice", -- [8]
							"quality", -- [9]
						},
					},
					[9999] = {
						["order"] = {
							"itemstatlevel", -- [1]
							"itemuselevel", -- [2]
							"itemage", -- [3]
							"itemtype", -- [4]
							"name", -- [5]
							"category", -- [6]
							"location", -- [7]
							"vendorprice", -- [8]
							"quality", -- [9]
						},
					},
					[9996] = {
						["order"] = {
							nil, -- [1]
							"itemstatlevel", -- [2]
							"itemuselevel", -- [3]
							"itemage", -- [4]
							"itemtype", -- [5]
							"name", -- [6]
							"category", -- [7]
							"location", -- [8]
							"quality", -- [9]
						},
					},
					[9997] = {
						["order"] = {
							nil, -- [1]
							"itemstatlevel", -- [2]
							"itemuselevel", -- [3]
							"itemage", -- [4]
							"itemtype", -- [5]
							"category", -- [6]
							"location", -- [7]
							"vendorprice", -- [8]
							"quality", -- [9]
						},
					},
				},
			},
		},
	},
	["profiles"] = {
		["Default"] = {
			["option"] = {
				["version"] = 3.0295,
				["anchor"] = {
					{
						["b"] = -12.27190589904785,
						["l"] = 1952.002685546875,
						["r"] = 2570.002685546875,
						["t"] = 350.7281494140625,
					}, -- [1]
				},
				["location"] = {
					{
						["slot"] = {
							["data"] = {
								[16] = {
									["long"] = "WOW_SKILL_INSCRIPTION",
								},
								[10] = {
									["long"] = "WOW_SKILL_MINING",
								},
								[6] = {
									["long"] = "WOW_SKILL_HERBALISM",
								},
							},
						},
					}, -- [1]
					nil, -- [2]
					{
						["slot"] = {
							["data"] = {
								[16] = {
									["long"] = "WOW_SKILL_INSCRIPTION",
								},
								[10] = {
									["long"] = "WOW_SKILL_MINING",
								},
								[6] = {
									["long"] = "WOW_SKILL_HERBALISM",
								},
							},
						},
					}, -- [3]
					{
						["slot"] = {
							["data"] = {
								[16] = {
									["long"] = "WOW_SKILL_INSCRIPTION",
								},
								[10] = {
									["long"] = "WOW_SKILL_MINING",
								},
								[6] = {
									["long"] = "WOW_SKILL_HERBALISM",
								},
							},
						},
					}, -- [4]
					{
						["slot"] = {
							["data"] = {
								[16] = {
									["long"] = "WOW_SKILL_INSCRIPTION",
								},
								[10] = {
									["long"] = "WOW_SKILL_MINING",
								},
								[6] = {
									["long"] = "WOW_SKILL_HERBALISM",
								},
							},
						},
					}, -- [5]
					{
						["slot"] = {
							["data"] = {
								[16] = {
									["long"] = "WOW_SKILL_INSCRIPTION",
								},
								[10] = {
									["long"] = "WOW_SKILL_MINING",
								},
								[6] = {
									["long"] = "WOW_SKILL_HERBALISM",
								},
							},
						},
					}, -- [6]
					{
						["slot"] = {
							["data"] = {
								[16] = {
									["long"] = "WOW_SKILL_INSCRIPTION",
								},
								[10] = {
									["long"] = "WOW_SKILL_MINING",
								},
								[6] = {
									["long"] = "WOW_SKILL_HERBALISM",
								},
							},
						},
					}, -- [7]
					{
						["slot"] = {
							["data"] = {
								[16] = {
									["long"] = "WOW_SKILL_INSCRIPTION",
								},
								[10] = {
									["long"] = "WOW_SKILL_MINING",
								},
								[6] = {
									["long"] = "WOW_SKILL_HERBALISM",
								},
							},
						},
					}, -- [8]
					{
						["slot"] = {
							["data"] = {
								[16] = {
									["long"] = "WOW_SKILL_INSCRIPTION",
								},
								[10] = {
									["long"] = "WOW_SKILL_MINING",
								},
								[6] = {
									["long"] = "WOW_SKILL_HERBALISM",
								},
							},
						},
					}, -- [9]
					{
						["slot"] = {
							["data"] = {
								[16] = {
									["long"] = "WOW_SKILL_INSCRIPTION",
								},
								[10] = {
									["long"] = "WOW_SKILL_MINING",
								},
								[6] = {
									["long"] = "WOW_SKILL_HERBALISM",
								},
							},
						},
					}, -- [10]
					{
						["slot"] = {
							["data"] = {
								[16] = {
									["long"] = "WOW_SKILL_INSCRIPTION",
								},
								[10] = {
									["long"] = "WOW_SKILL_MINING",
								},
								[6] = {
									["long"] = "WOW_SKILL_HERBALISM",
								},
							},
						},
					}, -- [11]
					{
						["slot"] = {
							["data"] = {
								[16] = {
									["long"] = "WOW_SKILL_INSCRIPTION",
								},
								[10] = {
									["long"] = "WOW_SKILL_MINING",
								},
								[6] = {
									["long"] = "WOW_SKILL_HERBALISM",
								},
							},
						},
					}, -- [12]
					{
						["slot"] = {
							["data"] = {
								[16] = {
									["long"] = "WOW_SKILL_INSCRIPTION",
								},
								[10] = {
									["long"] = "WOW_SKILL_MINING",
								},
								[6] = {
									["long"] = "WOW_SKILL_HERBALISM",
								},
							},
						},
					}, -- [13]
				},
			},
		},
	},
}
