
ZygorGuidesViewerSettings = {
	["char"] = {
		["Beardedrasta - Maelstrom"] = {
			["maint_fetchquestdata"] = true,
			["ignoredguides"] = {
				["Leveling Guides\\Eastern Kingdoms 1-60\\Dun Morogh (1-10)\\Dun Morogh (5-8)"] = true,
			},
			["guidename"] = "Leveling Guides\\Eastern Kingdoms 1-60\\The Hinterlands (30-34)\\The Hinterlands (31-34)",
			["debuglog"] = {
				"08:43:14> 16 Tailoring recipes found", -- [1]
				"08:43:14> 16 Tailoring recipes found", -- [2]
				"08:43:14> 16 Tailoring recipes found", -- [3]
				"08:43:14> 16 Tailoring recipes found", -- [4]
				"08:43:14> 16 Tailoring recipes found", -- [5]
				"08:43:14> 16 Tailoring recipes found", -- [6]
				"08:43:19> 17 Tailoring recipes found", -- [7]
				"08:43:21> 18 Tailoring recipes found", -- [8]
				"08:43:49> ZGV:Frame_OnShow", -- [9]
				"08:43:49> WAY showing goal(s)", -- [10]
				"08:43:49> setting wayps, waypath=%s, cpt=%s", -- [11]
				"08:43:49> WAY arrowpoint=%s", -- [12]
				"08:43:49> showing DINFO 6845 in ZygorGuidesViewer_CreatureViewer_model2", -- [13]
				"08:45:14> PLAYER_ENTERING_WORLD (not dead)", -- [14]
				"08:45:14> PLAYER_ALIVE (not dead)", -- [15]
				"08:45:14> CacheQuestLog cached 16 quests", -- [16]
				"08:45:14> ZONE_CHANGED_NEW_AREA (not dead)", -- [17]
				"08:45:14> CacheQuestLog cached 16 quests", -- [18]
				"08:45:20> CacheQuestLog cached 16 quests", -- [19]
				"08:45:20> CacheQuestLog cached 17 quests", -- [20]
				"08:45:20> CacheQuestLog cached 17 quests", -- [21]
				"08:45:37> goal 2 set up macro 39: /target Doran Steelwing\n/run ZGV:MagicRaidMarker()", -- [22]
				"08:45:37> step 1 prepared.", -- [23]
				"08:46:45> goal 2 set up macro 39: /target Doran Steelwing\n/run ZGV:MagicRaidMarker()", -- [24]
				"08:46:45> step 1 prepared.", -- [25]
				"08:47:08> goal 2 set up macro 39: /target Doran Steelwing\n/run ZGV:MagicRaidMarker()", -- [26]
				"08:47:08> step 1 prepared.", -- [27]
				"08:47:26> goal 2 set up macro 39: /target Doran Steelwing\n/run ZGV:MagicRaidMarker()", -- [28]
				"08:47:26> step 1 prepared.", -- [29]
				"08:47:55> goal 2 set up macro 39: /target Doran Steelwing\n/run ZGV:MagicRaidMarker()", -- [30]
				"08:47:55> step 1 prepared.", -- [31]
				"08:48:19> goal 2 set up macro 39: /target Doran Steelwing\n/run ZGV:MagicRaidMarker()", -- [32]
				"08:48:19> step 1 prepared.", -- [33]
				"08:49:10> goal 2 set up macro 39: /target Doran Steelwing\n/run ZGV:MagicRaidMarker()", -- [34]
				"08:49:10> step 1 prepared.", -- [35]
				"08:49:33> goal 2 set up macro 39: /target Doran Steelwing\n/run ZGV:MagicRaidMarker()", -- [36]
				"08:49:33> step 1 prepared.", -- [37]
				"08:50:00> goal 2 set up macro 39: /target Doran Steelwing\n/run ZGV:MagicRaidMarker()", -- [38]
				"08:50:00> step 1 prepared.", -- [39]
				"08:50:48> goal 2 set up macro 39: /target Doran Steelwing\n/run ZGV:MagicRaidMarker()", -- [40]
				"08:50:48> step 1 prepared.", -- [41]
				"08:51:32> PLAYER_ENTERING_WORLD (dead)", -- [42]
				"08:51:32> SetCorpseArrow, mm/mf=101/0", -- [43]
				"08:51:32> SetCorpseArrow, corpse not found anywhere, will retry", -- [44]
				"08:51:32> PLAYER_ALIVE (dead)", -- [45]
				"08:51:32> SetCorpseArrow, mm/mf=101/0", -- [46]
				"08:51:32> SetCorpseArrow, corpse not found anywhere, will retry", -- [47]
				"08:51:32> CacheQuestLog cached 17 quests", -- [48]
				"08:51:32> SetCorpseArrow, mm/mf=101/0", -- [49]
				"08:51:32> SetCorpseArrow, corpse not found anywhere, will retry", -- [50]
				"08:51:32> SetCorpseArrow, mm/mf=101/0", -- [51]
				"08:51:32> SetCorpseArrow, corpse not found anywhere, will retry", -- [52]
				"08:51:32> CacheQuestLog cached 17 quests", -- [53]
				"08:51:32> SetCorpseArrow, mm/mf=101/0", -- [54]
				"08:51:32> SetCorpseArrow, Corpse found in system 13", -- [55]
				"08:51:32> SetCorpseArrow, Searching the best fit among 29 maps", -- [56]
				"08:51:32> SetCorpseArrow, Body found on 2 map/floor combinations", -- [57]
				"08:51:32> SetCorpseArrow, best fit map/floor: 101/0", -- [58]
				"08:51:32> ZONE_CHANGED_NEW_AREA (dead)", -- [59]
				"08:51:32> ZONE_CHANGED_NEW_AREA (dead)", -- [60]
				"08:53:33> PLAYER_ENTERING_WORLD (dead)", -- [61]
				"08:53:33> PLAYER_ALIVE (dead)", -- [62]
				"08:53:33> CacheQuestLog cached 17 quests", -- [63]
				"08:53:33> Player unghosted!", -- [64]
				"08:53:33> WAY showing goal(s)", -- [65]
				"08:53:33> setting wayps, waypath=%s, cpt=%s", -- [66]
				"08:53:33> WAY arrowpoint=%s", -- [67]
				"08:53:33> CacheQuestLog cached 17 quests", -- [68]
				"08:53:33> CacheQuestLog cached 17 quests", -- [69]
				"08:53:33> CacheQuestLog cached 18 quests", -- [70]
				"08:53:33> CacheQuestLog cached 18 quests", -- [71]
				"08:54:50> goal 2 set up macro 39: /target Doran Steelwing\n/run ZGV:MagicRaidMarker()", -- [72]
				"08:54:50> step 1 prepared.", -- [73]
				"08:55:40> goal 2 set up macro 39: /target Doran Steelwing\n/run ZGV:MagicRaidMarker()", -- [74]
				"08:55:40> step 1 prepared.", -- [75]
				"08:56:11> goal 2 set up macro 39: /target Doran Steelwing\n/run ZGV:MagicRaidMarker()", -- [76]
				"08:56:11> step 1 prepared.", -- [77]
				"08:56:27> goal 2 set up macro 39: /target Doran Steelwing\n/run ZGV:MagicRaidMarker()", -- [78]
				"08:56:27> step 1 prepared.", -- [79]
				"08:56:34> goal 2 set up macro 39: /target Doran Steelwing\n/run ZGV:MagicRaidMarker()", -- [80]
				"08:56:34> step 1 prepared.", -- [81]
				"08:56:54> goal 2 set up macro 39: /target Doran Steelwing\n/run ZGV:MagicRaidMarker()", -- [82]
				"08:56:54> step 1 prepared.", -- [83]
				"08:57:14> goal 2 set up macro 39: /target Doran Steelwing\n/run ZGV:MagicRaidMarker()", -- [84]
				"08:57:14> step 1 prepared.", -- [85]
				"08:57:44> goal 2 set up macro 39: /target Doran Steelwing\n/run ZGV:MagicRaidMarker()", -- [86]
				"08:57:44> step 1 prepared.", -- [87]
				"08:58:45> goal 2 set up macro 39: /target Doran Steelwing\n/run ZGV:MagicRaidMarker()", -- [88]
				"08:58:45> step 1 prepared.", -- [89]
				"08:58:45> CacheQuestLog cached 18 quests", -- [90]
				"08:59:11> PLAYER_ENTERING_WORLD (not dead)", -- [91]
				"08:59:11> PLAYER_ALIVE (not dead)", -- [92]
				"08:59:11> CacheQuestLog cached 18 quests", -- [93]
				"08:59:11> CacheQuestLog cached 18 quests", -- [94]
				"08:59:11> ZONE_CHANGED_NEW_AREA (not dead)", -- [95]
				"09:02:37> QUEST_COMPLETE Corruption in Maraudon##27697", -- [96]
				"09:02:37> CHAT_MSG_SYSTEM: completed Corruption in Maraudon", -- [97]
				"09:02:37> GetQuest: id of quest 'Corruption in Maraudon' = 27697", -- [98]
				"09:02:37> Completed Quest: Corruption in Maraudon##27697", -- [99]
				"09:02:37> CacheQuestLog cached 17 quests", -- [100]
			},
			["taxis_were_updated"] = true,
			["guides_history"] = {
				{
					"Leveling Guides\\Eastern Kingdoms 1-60\\The Hinterlands (30-34)\\The Hinterlands (31-34)", -- [1]
					1, -- [2]
				}, -- [1]
				{
					"Leveling Guides\\Eastern Kingdoms 1-60\\The Hinterlands (30-34)\\The Hinterlands (30-31)", -- [1]
					1, -- [2]
				}, -- [2]
				{
					"Leveling Guides\\Eastern Kingdoms 1-60\\Arathi Highlands (26-30)\\Arathi Highlands (27-30)", -- [1]
					1, -- [2]
				}, -- [3]
				{
					"Leveling Guides\\Eastern Kingdoms 1-60\\Arathi Highlands (26-30)\\Arathi Highlands (26-27)", -- [1]
					9, -- [2]
				}, -- [4]
				{
					"Leveling Guides\\Eastern Kingdoms 1-60\\Wetlands (19-26)\\Wetlands (25-26)", -- [1]
					1, -- [2]
				}, -- [5]
			},
			["RecipesKnown"] = {
				[3840] = true,
				[2385] = true,
				[2387] = true,
				[3755] = true,
				[2393] = true,
				[3914] = true,
				[2397] = true,
				[7623] = true,
				[2963] = true,
				[8465] = true,
				[8776] = true,
				[12045] = true,
				[7624] = true,
				[3841] = true,
				[2392] = true,
				[2394] = true,
				[3915] = true,
				[12044] = true,
			},
			["taxis"] = {
			},
			["maint_fetchitemdata"] = true,
		},
	},
	["profileKeys"] = {
		["Beardedrasta - Maelstrom"] = "Beardedrasta - Maelstrom",
	},
	["profiles"] = {
		["Beardedrasta - Maelstrom"] = {
			["fixblizzardautoaccept"] = true,
			["autoturnin"] = true,
			["magickey_bind"] = "",
			["autoaccept"] = true,
			["resizeup"] = true,
			["dispmode"] = {
				["hidecompletedinbrief"] = false,
			},
			["hidecompletedinbrief"] = false,
			["dispsecondary"] = {
				["nevershowborder"] = false,
				["hidecompletedinbrief"] = false,
			},
			["skipauxsteps"] = true,
			["detectcreatures"] = false,
			["framescale"] = 1.3,
			["contractmobs"] = true,
			["dispprimary"] = {
				["hidecompletedinbrief"] = false,
			},
		},
	},
}
