
SkinnerDB = {
	["namespaces"] = {
		["ViewPort"] = {
		},
		["MiddleFrames"] = {
		},
		["TopFrame"] = {
		},
		["UIButtons"] = {
		},
		["BottomFrame"] = {
		},
		["UnitFrames"] = {
		},
	},
	["profileKeys"] = {
		["Beardedrasta - Maelstrom"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["DropDownButtons"] = true,
			["TexturedDD"] = true,
			["StatusBar"] = {
				["texture"] = "KPack",
			},
			["MinimapIcon"] = {
				["minimapPos"] = 159.5308037351323,
				["hide"] = true,
			},
		},
	},
}
