
MasqueDB = {
	["namespaces"] = {
		["LibDualSpec-1.0"] = {
		},
	},
	["profileKeys"] = {
		["Beardedrasta - Maelstrom"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["Groups"] = {
				["Dominos"] = {
					["Colors"] = {
						["Backdrop"] = {
							0.1294117647058823, -- [1]
							0.1294117647058823, -- [2]
							0.1294117647058823, -- [3]
							1, -- [4]
						},
					},
					["SkinID"] = "Renaitre: Square",
					["Backdrop"] = true,
				},
				["Dominos_Action Bar"] = {
					["Colors"] = {
						["Backdrop"] = {
							0.1294117647058823, -- [1]
							0.1294117647058823, -- [2]
							0.1294117647058823, -- [3]
							1, -- [4]
						},
					},
					["SkinID"] = "Renaitre: Square",
					["Backdrop"] = true,
				},
				["Masque"] = {
					["Colors"] = {
						["Backdrop"] = {
							0.1294117647058823, -- [1]
							0.1294117647058823, -- [2]
							0.1294117647058823, -- [3]
							1, -- [4]
						},
					},
					["SkinID"] = "Renaitre: Square",
					["Backdrop"] = true,
				},
				["Dominos_Bag Bar"] = {
					["Colors"] = {
						["Backdrop"] = {
							0.1294117647058823, -- [1]
							0.1294117647058823, -- [2]
							0.1294117647058823, -- [3]
							1, -- [4]
						},
					},
					["SkinID"] = "Renaitre: Square",
					["Backdrop"] = true,
				},
				["Dominos_Pet Bar"] = {
					["Colors"] = {
						["Backdrop"] = {
							0.1294117647058823, -- [1]
							0.1294117647058823, -- [2]
							0.1294117647058823, -- [3]
							1, -- [4]
						},
					},
					["SkinID"] = "Renaitre: Square",
					["Backdrop"] = true,
				},
			},
		},
	},
}
