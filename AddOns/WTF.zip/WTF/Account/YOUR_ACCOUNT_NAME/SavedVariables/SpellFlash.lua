
SpellFlashAddonConfig = {
	["SERVER"] = {
		["logon.gamefreedom.org"] = {
			["REALM"] = {
				["Maelstrom"] = {
					["PLAYER"] = {
						["Beardedrasta"] = {
							["use_all_class_modules"] = true,
							["selected_class_module"] = "SpellFlash_Warlock",
							["MODULE"] = {
							},
						},
					},
				},
			},
		},
	},
}
