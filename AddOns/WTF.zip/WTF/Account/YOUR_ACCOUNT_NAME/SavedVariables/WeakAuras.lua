
WeakAurasSaved = {
	["dynamicIconCache"] = {
	},
	["editor_tab_spaces"] = 4,
	["displays"] = {
		["New"] = {
			["config"] = {
			},
			["selfPoint"] = "CENTER",
			["authorOptions"] = {
			},
			["load"] = {
				["size"] = {
					["multi"] = {
					},
				},
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["talent"] = {
					["multi"] = {
					},
				},
			},
			["mirror"] = false,
			["yOffset"] = -222.6442718505859,
			["anchorPoint"] = "CENTER",
			["xOffset"] = -142.0840606689453,
			["blendMode"] = "BLEND",
			["rotate"] = true,
			["regionType"] = "texture",
			["color"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["texture"] = "Interface\\AddOns\\WeakAuras\\Media\\Textures\\Square_FullWhite",
			["desaturate"] = false,
			["internalVersion"] = 44,
			["triggers"] = {
				{
					["trigger"] = {
						["type"] = "unit",
						["use_alwaystrue"] = true,
						["subeventSuffix"] = "_CAST_START",
						["event"] = "Conditions",
						["subeventPrefix"] = "SPELL",
						["spellIds"] = {
						},
						["use_unit"] = true,
						["names"] = {
						},
						["unit"] = "player",
						["debuffType"] = "HELPFUL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				["activeTriggerMode"] = -10,
			},
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["main"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
				["finish"] = {
					["type"] = "none",
					["easeStrength"] = 3,
					["duration_type"] = "seconds",
					["easeType"] = "none",
				},
			},
			["id"] = "New",
			["rotation"] = 0,
			["alpha"] = 1,
			["width"] = 290.8331604003906,
			["discrete_rotation"] = 0,
			["uid"] = "5g1eyq)O9Ci",
			["anchorFrameType"] = "SCREEN",
			["subRegions"] = {
			},
			["height"] = 93.06069946289063,
			["conditions"] = {
			},
			["information"] = {
			},
			["frameStrata"] = 2,
		},
	},
	["lastArchiveClear"] = 1689814132,
	["minimap"] = {
		["minimapPos"] = 204.9370514939574,
		["hide"] = true,
	},
	["lastUpgrade"] = 1689814141,
	["dbVersion"] = 44,
	["login_squelch_time"] = 10,
	["registered"] = {
	},
	["frame"] = {
		["xOffset"] = -414.999267578125,
		["width"] = 830.0001220703125,
		["height"] = 665,
		["yOffset"] = -355.15478515625,
	},
	["editor_theme"] = "Monokai",
}
