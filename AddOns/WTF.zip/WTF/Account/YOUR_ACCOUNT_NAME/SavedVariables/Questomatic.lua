
QOMDB = {
	["profileKeys"] = {
		["Beardedrasta - Maelstrom"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
