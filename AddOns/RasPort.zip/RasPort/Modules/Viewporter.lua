local core = RasPort
if not core then return end
core:AddModule("Viewporter", "Adds black bars at top/bottom/left/right side of the screen.", function(L)
	if core:IsDisabled("Viewporter") then return end

	local frame = CreateFrame("Frame")

	-- saved variables and defaults
	local DB, SetupDatabase

	local windowdefaults = {
		colour = {r = 0, g = 0, b = 0, a = 1}
	}

	local defaults = {
		enabled = false,
		left = 0,
		right = 0,
		top = 0,
		bottom = 0,
		firstTime = true,
		overlay = true,
		colour = {r = 0, g = 0, b = 0, a = 1}
	}

	-- needed locales
	local initialized
	local sides = {
		left = "left",
		right = "right",
		top = "top",
		bottom = "bottom",
		bot = "bottom"
	}

	-- module's print function
	local function Print(msg)
		if msg then
			core:Print(msg, "Viewporter")
		end
	end

	-- called everytime we need to make changes to the viewport
	local rpo
	local function Viewporter_Initialize()
		if initialized then return end
		if DB.enabled then
			local left, right, top, bottom = 0, 0, 0, 0
			left, right, top, bottom = DB.left, DB.right, DB.top, DB.bottom
			if DB.overlay then
				local xScale = 1050 / UIParent:GetWidth()
				local yScale = 768 / UIParent:GetHeight()
				if not rpo then
					rpo = CreateFrame("Frame", nil)
					rpo:SetAllPoints(UIParent)
					rpo:SetFrameLevel(0)
					rpo:SetFrameStrata("BACKGROUND")
					rpo:EnableMouse(false)
					rpo:SetMovable(false)
					rpo.top = rpo:CreateTexture(nil, "BACKGROUND")
					rpo.btm = rpo:CreateTexture(nil, "BACKGROUND")
					rpo.left = rpo:CreateTexture(nil, "BACKGROUND")
					rpo.right = rpo:CreateTexture(nil, "BACKGROUND")
				end
				rpo.top:SetTexture(DB.colour.r, DB.colour.g, DB.colour.b, DB.colour.a)
				rpo.btm:SetTexture(DB.colour.r, DB.colour.g, DB.colour.b, DB.colour.a)
				rpo.left:SetTexture(DB.colour.r, DB.colour.g, DB.colour.b, DB.colour.a)
				rpo.right:SetTexture(DB.colour.r, DB.colour.g, DB.colour.b, DB.colour.a)
				rpo.top:ClearAllPoints()
				rpo.top:SetPoint("TOPLEFT")
				rpo.top:SetPoint("BOTTOMRIGHT", rpo, "TOPRIGHT", 0, -(DB.top * yScale))
				rpo.btm:ClearAllPoints()
				rpo.btm:SetPoint("BOTTOMLEFT")
				rpo.btm:SetPoint("TOPRIGHT", rpo, "BOTTOMRIGHT", 0, (DB.bottom * yScale))
				rpo.left:ClearAllPoints()
				rpo.left:SetPoint("TOPLEFT", rpo, "TOPLEFT", 0, -(DB.top * yScale))
				rpo.left:SetPoint("BOTTOMRIGHT", rpo, "BOTTOMLEFT", (DB.left * yScale), (DB.bottom * yScale))
				rpo.right:ClearAllPoints()
				rpo.right:SetPoint("TOPRIGHT", rpo, "TOPRIGHT", 0, -(DB.top * yScale))
				rpo.right:SetPoint("BOTTOMLEFT", rpo, "BOTTOMRIGHT", -(DB.right * yScale), (DB.bottom * yScale))
				-- show the overlay frame
				rpo:Show()
			elseif rpo then
				rpo:Hide()
			end
			local scale = 768 / UIParent:GetHeight()
			WorldFrame:SetPoint("TOPLEFT", (left * scale), -(top * scale))
			WorldFrame:SetPoint("BOTTOMRIGHT", -(right * scale), (bottom * scale))
			initialized = true

		end

		if not DB.enabled then 
			WorldFrame:SetPoint("TOPLEFT", 0, 0)
			WorldFrame:SetPoint("BOTTOMRIGHT", 0, 0)
			rpo:Hide()
			initialized = true
		end

	end

	-- slash commands handler
	local function SlashCommandHandler(msg)
		local cmd, rest = strsplit(" ", msg, 2)
		cmd = cmd:lower()
		rest = rest and rest:trim() or ""

		if cmd == "toggle" then
			DB.enabled = not DB.enabled
			Print(DB.enabled and L["|cff00ff00enabled|r"] or L["|cffff0000disabled|r"])
			initialized = nil
			frame:Show()
		elseif cmd == "enable" or cmd == "on" then
			DB.enabled = true
			initialized = nil
			frame:Show()
			Print(L["|cff00ff00enabled|r"])
		elseif cmd == "disable" or cmd == "off" then
			DB.enabled = false
			initialized = nil
			frame:Show()
			Print(L["|cffff0000disabled|r"])
		elseif cmd == "reset" or cmd == "default" then
			wipe(core.char.Viewporter)
			DB = nil
			SetupDatabase()
			initialized = nil
			Print(L["module's settings reset to default."])
			frame:Show()
		elseif cmd == "config" or cmd == "options" then
			core:OpenConfig("General","Minimap")
		elseif sides[cmd] then
			local size = tonumber(rest)
			size = size or 0
			DB[sides[cmd]] = size
			initialized = nil
			frame:Show()
		else
			Print(L:F("Acceptable commands for: |caaf49141%s|r", "/rp"))
			print("|cff00FAAAtoggle|r", L["toggles viewporter status"])
			print("|cff00FAAAenable|r", L["enable module"])
			print("|cff00FAAAdisable|r", L["disable module"])
			print("|cff00FAAAconfig|r", L["Access module settings."])
			print("|cff00FAAAreset|r", L["Resets module settings to default."])
			print(L:F("|cff00FAAAExample|r: %s", "/rp bottom 120"))
			return
		end

		Viewporter_Initialize()
	end

	do
		local function Viewporter_OnUpdate(self, elapsed)
			SetupDatabase()
			if not (DB and DB.enabled) then
				Viewporter_Initialize()
				self:Hide()
				return
			end

			if DB.firstTime then
				DB.firstTime = false
			end
			Viewporter_Initialize()
			self:Hide()
		end

		core:RegisterForEvent("PLAYER_ENTERING_WORLD", function()
			frame:SetScript("OnUpdate", Viewporter_OnUpdate)
		end)
	end

	function OnEnable()
		if DB.enabled then self:adjustViewPort("init") end
	end

	function adjustViewPort(opt)

		--	print("adjustViewPort", opt)

		local xScale = 1050 / UIParent:GetWidth()
		local yScale = 768 / UIParent:GetHeight()
		
			if (opt == "enabled" and DB.enabled)
			or (opt == "top" and DB.enabled)
			or (opt == "bottom" and DB.enabled)
			or (opt == "left" and DB.enabled)
			or (opt == "right" and DB.enabled) then
				WorldFrame:ClearAllPoints()
				WorldFrame:SetPoint("TOPLEFT", (DB.left * xScale), -(DB.top * yScale))
				WorldFrame:SetPoint("BOTTOMRIGHT", -(DB.right * xScale), (DB.bottom * yScale))
				Viewporter_Initialize()
			elseif opt == "overlay"
			or opt == "colour"
			then
				Viewporter_Initialize()
			elseif opt == "enabled" and not DB.enabled
			then
				Viewporter_Initialize()
			end
		end

	function SetupDatabase()
		if not DB then
			if type(core.char.Viewporter) ~= "table" or next(core.char.Viewporter) == nil then
				core.char.Viewporter = CopyTable(defaults)
			end
			DB = core.char.Viewporter
		end
	end

	-- frame event handler
	core:RegisterForEvent("PLAYER_LOGIN", function()
		SetupDatabase()

		SlashCmdList["RASPORTVIEWPORTER"] = SlashCommandHandler
		SLASH_RASPORTVIEWPORTER1 = "/rp"
		SLASH_RASPORTVIEWPORTER2 = "/rasport"

		local disabled = function()
			return not DB.enabled
		end
		core.options.args.Options.args.Viewporter = {
			type = "group",
			name = L["Viewporter"],
			get = function(i) return DB[i[#i]] end,
			set = function(i, val)
				DB.enabled = true -- always enable if any option is changed.
				DB[i[#i]] = val
				initialized = nil
				frame:Show()
				adjustViewPort(i[#i])
			end,
			args = {
				enabled = {
					type = "toggle",
					name = L["Enable"],
					order = 0
				},
				reset = {
					type = "execute",
					name = RESET,
					order = 1,
					disabled = disabled,
					confirm = function()
						return L:F("Are you sure you want to reset %s to default?", L["Viewporter"])
					end,
					func = function()
						wipe(core.char.Viewporter)
						DB = nil
						SetupDatabase()
						Print(L["module's settings reset to default."])
						initialized = nil
						frame:Show()
					end
				},
				info = {
					type = "header",
					name = "Viewporter",
					order = 2,
					width = "full"
				},
				sep = {
					type = "description",
					name = " ",
					order = 3,
					width = "full"
				},
				left = {
					type = "range",
					name = L["Left"],
					order = 5,
					disabled = disabled,
					min = 0,
					max = 350,
					step = 0.1,
					bigStep = 1
				},
				right = {
					type = "range",
					name = L["Right"],
					order = 6,
					disabled = disabled,
					min = 0,
					max = 350,
					step = 0.1,
					bigStep = 1
				},
				top = {
					type = "range",
					name = L["Top"],
					order = 7,
					disabled = disabled,
					min = 0,
					max = 350,
					step = 0.1,
					bigStep = 1
				},
				bottom = {
					type = "range",
					name = L["Bottom"],
					order = 8,
					disabled = disabled,
					min = 0,
					max = 350,
					step = 0.1,
					bigStep = 1
				},

				list = {
					type = "group",
					name = "Overlay",
					order = 4,
					inline = true,
					args = {
						overlay = {
							type = "toggle",
							order = 1,
							disabled = disabled,
							name = L["ViewPort Overlay"],
							desc = L["Toggle the ViewPort Overlay"],
						},

						colour = {
							type = "color",
							order = 2,
							name = L["ViewPort Colors"],
							desc = L["Set ViewPort Colors"],
							hasAlpha = true,
							get = function()
								local c = DB.colour or windowdefaults.colour
								return c.r, c.g, c.b, c.a
							end,
							set = function(_, r, g, b, a)
								c = DB.colour or {}
								c.r, c.g, c.b, c.a = r, g, b, a
								adjustViewPort("colour")
							end,
						},

						instruction = {
							type = 'description',
							order = 3,
							name = L["Toggle the overlay on/off or /reload to update overlay color."],
							fontSize = 'medium',
							width = "full",
							order = 1
						},
					}
				}
			}
		}
	end)
end)