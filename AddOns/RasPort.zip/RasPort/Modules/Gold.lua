local core = RasPort
if not core then return end
core:AddModule("Money", "|cff00ff00/gg\nVisual display of gold obtained.", function(L)
	if core:IsDisabled("Money") then return end

	local DB, SetupDatabase

	local defaults = {
		enabled = true
	}

	-- needed locales
	local initialized

	function OnEnable()
		if DB.enabled then SetupDatabase() end
	end

	function SetupDatabase()
		if not DB then
			if type(core.char.Money) ~= "table" or next(core.char.Money) == nil then
				core.char.Money = CopyTable(defaults)
			end
			DB = core.char.Money
		end
	end

	local f = CreateFrame("Frame", "GetGoldDisplayFrame", UIParent, BackdropTemplateMixin and "BackdropTemplate")
	f:SetPoint("CENTER")
	f:SetMovable(true)
	f:SetUserPlaced(true)

	local CTData, CTName

	f:RegisterEvent("PLAYER_LOGIN")
	f:RegisterEvent("PLAYER_MONEY")
	f:SetScript("OnEvent", function(self, event)
		if event == "PLAYER_MONEY" then
			CTData.gold = GetMoney()
			return
		end
		DB = DB or { characters = {} }
		CTName = UnitName("player")
		CTData = CTName .. "-" .. GetRealmName()
		if not DB.characters[CTData] then
			DB.characters[CTData] = {}
		end
		CTData = DB.characters[CTData]
		CTData.gold = GetMoney()
	end)

	local TotalText = "Total Gold is:"
	local PlayerText = "Gold for %s:"

	local function ShowGold(self, playergold)
		local Total = 0
		if not playergold then
			self.Title:SetText(TotalText)
			self.GetFor:SetText(CTName)
			for k, v in pairs(DB.characters) do
				Total = Total + v.gold
			end
		else
			self.Title:SetText(format(PlayerText, CTName))
			Total = CTData.gold
			self.GetFor:SetText("All")
		end
		self.Text:SetText(GetMoneyString(Total, true))
		self.Text:HighlightText()
		self.Text:SetFocus()
		self:Show()
	end

	local function GetGold(msg)
		if f.Title then
			if f:IsShown() then
				f:Hide()
				return
			end
			ShowGold(f)
			return
		end
		local backdrop = {
			bgFile = "Interface/DialogFrame/UI-DialogBox-Background",
			edgeFile = "Interface/GLUES/Common/Glue-Tooltip-Border",
			tile = true,
			edgeSize = 8,
			tileSize = 8,
			insets = {
				left = 2,
				right = 2,
				top = 2,
				bottom = 2,
			},
		}
		f:EnableMouse(true)
		f:RegisterForDrag("LeftButton")
		f:SetClampedToScreen(true)
		f:SetScript("OnDragStart", function(self) self:StartMoving() end)
		f:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
		f:SetBackdrop(backdrop)
		f:SetSize(220, 100)
		f.Title = f:CreateFontString()
		f.Title:SetFontObject(GameFontNormal)
		f.Title:SetPoint("TOP", 0, -5)
		f.Title:SetText("Total Gold is:")
		f.Close = CreateFrame("Button", "$parentClose", f, "UIPanelCloseButton")
		f.Close:SetSize(24, 24)
		f.Close:SetPoint("TOPRIGHT")
		f.Text = CreateFrame("EditBox", nil, f)
		f.Text:SetFontObject(GameFontNormal)
		f.Text:SetSize(190, 24)
		f.Text:SetJustifyH("CENTER")
		f.Text:SetPoint("CENTER", 0, 10)
		f.Text:SetMultiLine(false)
		f.Text:SetScript("OnEscapePressed", function(self)
			self:ClearFocus()
			self:GetParent():Hide()
		end)
		f.GetFor = CreateFrame("Button", "$parentGetFor", f, "UIPanelButtonTemplate")
		f.GetFor:SetSize(100, 30)
		f.GetFor:SetText("All")
		f.GetFor:SetPoint("BOTTOM", 0, 10)
		f.GetFor:SetScript("OnClick", function(self)
			self.Player = not self.Player
			ShowGold(f, self.Player)
		end)
		ShowGold(f)
	end

	SLASH_GG1 = "/gg"
	SlashCmdList.GG = GetGold
end)

--[[    Notes
-- Using a text editor (eg. NotPad):
-- The following line will need to be added (after the other lines starting with ##) to the addons .TOC file located in the addons folder (THE ADDON WILL NOT WORK PROPERLY WITHOUT THIS):
## SavedVariables: GG_DATA

-- Will only show total gold for characters you have logged on to.
-- Will show gold for deleted character unless you edit the addons SavedVariables file and delete the characters information:
-- File Location:
[WoW folder]\[game version folder eg. _retail_]\WFT\Account\[your account name]\SavedVariables\[addon name].lua
]]
   --
