--[[ Credits:  LynStats ]]
local core = RasPort
if not core then return end
core:AddModule("FpsMonitor", "Shows your latency, fps, addons memory, mail.", function(L)
	if core:IsDisabled("FpsMonitor") then return end

	local frame = CreateFrame("Frame")

	-- CONFIG
	---------------------------------------------
	local movable = true
	local addonList = 25
	local textAlign = "CENTER"
	local position = {"BOTTOMLEFT", UIParent, "BOTTOMLEFT", 100, 0}
	local tooltipAnchor = "ANCHOR_TOPRIGHT"
	local useShadow = true
	local showMail = true
	local use12 = true


	local DB, SetupDatabase
	local defaults = {
		enabled = true,
		font = "Yanone",
		fontSize = 18,
		fontFlags = "OUTLINE",
		customColor = true,
		showClock = true,
		use12 = true,
		showDate = true,
		showMail = true
	}
	local initialized

	-- GLOBALS
	---------------------------------------------

	local CreateFrame, GetFramerate = CreateFrame, GetFramerate
	local HasNewMail = HasNewMail
	local UnitClass = UnitClass
	local select, format, lower = select, string.format, string.lower
	local floor, modf = math.floor, math.modf
	local tinsert, tsort = table.insert, table.sort
	local GetNumAddOns, GetAddOnInfo = GetNumAddOns, GetAddOnInfo
	local GetAddOnMemoryUsage, UpdateAddOnMemoryUsage = GetAddOnMemoryUsage, UpdateAddOnMemoryUsage
	local date, gcinfo, GetNetStats = date, gcinfo, GetNetStats
	local collectgarbage = collectgarbage

	-- CODE ITSELF
	---------------------------------------------

	local gradientColor = {0, 1, 0, 1, 1, 0, 1, 0, 0}
	local color

	-- http://www.wowwiki.com/ColorGradient
	local function ColorGradient(perc, ...)
		if (perc > 1) then
			local r, g, b = select(select("#", ...) - 2, ...)
			return r, g, b
		elseif (perc < 0) then
			local r, g, b = ...
			return r, g, b
		end

		local num = select("#", ...) / 3

		local segment, relperc = modf(perc * (num - 1))
		local r1, g1, b1, r2, g2, b2 = select((segment * 3) + 1, ...)

		return r1 + (r2 - r1) * relperc, g1 + (g2 - g1) * relperc, b1 + (b2 - b1) * relperc
	end

	local function RGBGradient(num)
		local r, g, b = ColorGradient(num, unpack(gradientColor))
		return r, g, b
	end

	local function RGBToHex(r, g, b)
		r = r <= 1 and r >= 0 and r or 0
		g = g <= 1 and g >= 0 and g or 0
		b = b <= 1 and b >= 0 and b or 0
		return format("|cff%02x%02x%02x", r * 255, g * 255, b * 255)
	end
	local StatsFrame = CreateFrame("Frame", "RasPortFpsMonitor", UIParent)
	StatsFrame:EnableMouse(true)
	StatsFrame:SetScript("OnEnter", function() 
		if IsAltKeyDown() then
			StatsFrame.text:SetTextColor(1, 0.2, 0.2)
		end
	end)
	StatsFrame:SetScript("OnLeave", function() 
		if not DB.customColor then
			altcolor = {r = 0, g = 1, b = 0.7}
		else
			altcolor = (CUSTOM_CLASS_COLORS or RAID_CLASS_COLORS)[core.class]
		end
		StatsFrame.text:SetTextColor(color.r, color.g, color.b)
	end)
	StatsFrame:SetScript("OnEvent", function(self, event)
		self:SetScript("OnUpdate", update)
	end)
	StatsFrame:RegisterEvent("PLAYER_LOGIN")
	if movable then
		StatsFrame:ClearAllPoints()
		StatsFrame:SetPoint(unpack(position))
		StatsFrame:SetMovable(true)
		StatsFrame:SetClampedToScreen(true)
		StatsFrame:SetUserPlaced(true)
		StatsFrame:SetScript("OnMouseDown", function(self, button)
			if IsAltKeyDown() then
				self.moving = true
				self:StartMoving()
			elseif button == "RightButton" then
				core:OpenConfig("Options","FpsMonitor")
			end
		end)
		StatsFrame:SetScript("OnMouseUp", function(self)
			if self.moving then
				self.moving = nil
				self:StopMovingOrSizing()
				return
			end
			clearGarbage()
		end)
	else
		StatsFrame:SetPoint(unpack(position))
	end
	StatsFrame:SetWidth(50)
	StatsFrame:SetHeight(defaults.fontSize)
	StatsFrame.text = StatsFrame:CreateFontString(nil, "BACKGROUND")
	StatsFrame.text:SetPoint(textAlign, StatsFrame)
	StatsFrame.text:SetFont(core:MediaFetch("font", defaults.font), defaults.fontSize, defaults.fontFlags)
	if useShadow then
		StatsFrame.text:SetShadowOffset(1, -1)
		StatsFrame.text:SetShadowColor(0, 0, 0)
	end
	StatsFrame:Show()

	local function memFormat(number)
		if number > 1024 then
			return format("%.2f mb", (number / 1024))
		else
			return format("%.1f kb", floor(number))
		end
	end

	local function numFormat(v)
		if v > 1E10 then
			return (floor(v / 1E9)) .. "b"
		elseif v > 1E9 then
			return (floor((v / 1E9) * 10) / 10) .. "b"
		elseif v > 1E7 then
			return (floor(v / 1E6)) .. "m"
		elseif v > 1E6 then
			return (floor((v / 1E6) * 10) / 10) .. "m"
		elseif v > 1E4 then
			return (floor(v / 1E3)) .. "k"
		elseif v > 1E3 then
			return (floor((v / 1E3) * 10) / 10) .. "k"
		else
			return v
		end
	end

	local function addonCompare(a, b)
		return a.memory > b.memory
	end

	local function clearGarbage()
		if InCombatLockdown() then
			core:Print("|cffffe02e" .. ERR_NOT_IN_COMBAT .. "|r", "FpsMonitor")
			return
		end

		UpdateAddOnMemoryUsage()
		local before = gcinfo()
		collectgarbage("collect")
		UpdateAddOnMemoryUsage()
		local after = gcinfo()
		print("|c0000ddffCleaned:|r " .. memFormat(before - after))
	end

	local function getFPS()
		return "|c00ffffff" .. floor(GetFramerate()) .. "|r fps"
	end

	local function getFpsMonitorRaw()
		return select(3, GetNetStats())
	end

	local function getFpsMonitor()
		return "|c00ffffff" .. getFpsMonitorRaw() .. "|r ms"
	end

	local function getMail()
		if HasNewMail() ~= nil then
			return "|c00ff00ffMail!|r"
		else
			return ""
		end
	end

	local function getTime()
		if DB.use12 then
			local t = date("%I:%M")
			local ampm = date("%p")
			return "|c00ffffff" .. t .. "|r " .. lower(ampm)
		else
			local t = date("%H:%M")
			return "|c00ffffff" .. t .. "|r"
		end
	end

	local function getDateLetters()
		local currentNoM = date("%d")
		local currentNoMString = string.len(currentNoM)
		local firstNumber = ""
		local decidingNumber = ""
		if (currentNoMString == 1) then
			firstNumber = currentNoM
			decidingNumber = firstNumber
		else
			firstNumber = string.sub(currentNoM, 1, 1)
			local secondNumber = string.sub(currentNoM, 2, 2)
			decidingNumber = secondNumber
		end
		if ((currentNoMString == 1) or ((currentNoMString == 2) and (firstNumber ~= 1))) then
			if (decidingNumber == "1") then
				return "st"
			elseif (decidingNumber == "2") then
				return "nd"
			elseif (decidingNumber == "3") then
				return "rd"
			else
				return "th"
			end
		end
	end

	local function getDateTotal()
		local dateletter = getDateLetters()
		return date("|c00ffffff%B|r ".."".."%d")..dateletter
	end

	local function FpsMonitor_Initialize()
		if initialized then return end
		if not DB.customColor then
			color = {r = 0, g = 1, b = 0.7}
		else
			color = (CUSTOM_CLASS_COLORS or RAID_CLASS_COLORS)[core.class]
		end
		if DB.enabled then
			StatsFrame:SetHeight(DB.fontSize)
			StatsFrame.text:SetFont(core:MediaFetch("font", DB.font), DB.fontSize, DB.fontFlags)
			StatsFrame.text:SetTextColor(color.r, color.g, color.b)
			StatsFrame:Show()
		elseif StatsFrame then
			StatsFrame:Hide()
		end
		initialized = true

		if not DB.enabled then
			StatsFrame:Hide()
			initialized = true
		end
	end

	-- nameplates OnUpdate handler
	local lastUpdate = 0

	local function update(self, elapsed)
		SetupDatabase()
		lastUpdate = lastUpdate + elapsed
		if lastUpdate > 1 then
			lastUpdate = 0
			local text = getFPS() .. "  " .. getFpsMonitor()
			if DB.showClock then
				text = text .. "  " .. getTime()
			end
			if DB.showDate then
				text = text .. "  " .. getDateTotal()
			end
			if DB.showMail then
				text = text .. "  " .. getMail()
			end
			StatsFrame.text:SetText(text)
			self:SetWidth(StatsFrame.text:GetStringWidth())
			self:SetHeight(StatsFrame.text:GetStringHeight())
		end
		if not (DB and DB.enabled) then
			FpsMonitor_Initialize()
			return
		end

		if DB.firstTime then
			DB.firstTime = false
		end

		FpsMonitor_Initialize()
	end
	core:RegisterForEvent("PLAYER_ENTERING_WORLD", function()
		frame:SetScript("OnUpdate", update)
	end)

	function OnEnable()
		if DB.enabled then self:adjustFont("init") end
	end

	function adjustFont(opt)
		if opt == "enabled" and DB.enabled then
			FpsMonitor_Initialize()
		elseif opt == "enabled" and not DB.enabled then
			FpsMonitor_Initialize()
		elseif opt == "colour" then
			FpsMonitor_Initialize()
		end
	end


	function SetupDatabase()
		if not DB then
			if type(core.char.FpsMonitor) ~= "table" or next(core.char.FpsMonitor) == nil then
				core.char.FpsMonitor = CopyTable(defaults)
			end
			DB = core.char.FpsMonitor
		end
		DB = core.char.FpsMonitor
	end

	core:RegisterForEvent("PLAYER_LOGIN", function()
		SetupDatabase()

		local disabled = function()
			return not DB.enabled
		end

		core.options.args.Options.args.FpsMonitor = {
			type = "group",
			name = L["FpsMonitor"],
			childGroups = "tab",
			get = function(i) return DB[i[#i]] end,
			set = function(i, val)
				DB.enabled = true
				DB[i[#i]] = val
				initialized = nil
				frame:Show()
				adjustFont(i[#i])
			end,
			args = {
				info = {
					type = "header",
					name = "Fps Monitor Extended",
					order = 2,
					width = "full"
				},
				enabled = {
					type = "toggle",
					name = L["Enable"],
					order = 0
				},
				reset = {
					type = "execute",
					name = RESET,
					order = 1,
					disabled = disabled,
					confirm = function()
						return L:F("Are you sure you want to %s to default values?", L["FpsMonitor"])
					end,
					func = function()
						wipe(core.char.FpsMonitor)
						DB = nil
						SetupDatabase()
						core:Print(L["Module has been reset to default."])
						initialized = nil
						frame:Show()
					end
				},
				sep = {
					type = "description",
					name = " ",
					order = 3,
					width = "full"
				},
				appearance = {
					type = "group",
					name = L["Font"],
					order = 10,
					args = {
						fontFlags = {
							type = "select",
							name = L["Font Outline"],
							order = 3,
							values = {
								[""] = NONE,
								["OUTLINE"] = L["Outline"],
								["THINOUTLINE"] = L["Thin outline"],
								["THICKOUTLINE"] = L["Thick outline"],
								["MONOCHROME"] = L["Monochrome"],
								["OUTLINEMONOCHROME"] = L["Outlined monochrome"]
							}
						},
						font = {
							type = "select",
							name = L["Font"],
							order = 1,
							dialogControl = "LSM30_Font",
							values = AceGUIWidgetLSMlists.font
						},
						fontSize = {
							type = "range",
							name = L["Font Size"],
							order = 2,
							min = 6,
							max = 60,
							step = 1
						},
						customColor = {
							type = "toggle",
							order = 3,
							name = L["Class Color"],
							desc = L["Applies class color to FpsMonitor."],
						}
					}
				},
				extras = {
					type = "group",
					name = L["Extras"],
					order = 20,
					args = {
						showClock = {
							type = "toggle",
							name = L["Clock"],
							desc = L["Time display."],
							order = 5
						},
						use12 = {
							type = "toggle",
							name = L["12 - Hour"],
							desc = L["Time display for AM / PM."],
							order = 6
						},
							showDate = {
							type = "toggle",
							name = L["Date"],
							desc = L["Date display."],
							order = 7
						},
							showMail = {
							type = "toggle",
							name = L["Mail"],
							desc = L["Mail notifications."],
							order = 7
						}
					}
				},
			}
		}
	end)
end)