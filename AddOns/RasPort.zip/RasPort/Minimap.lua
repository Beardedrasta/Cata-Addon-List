local folder, core = ...
if not core then return end

core:AddModule("General", "|cff00ff00/rpg, /rpgeneral|r\nGeneral options.\n |cff707070(Does not enable/disable minimap module)|r", function(L)

	local mod = core.General or {}
	core.General = mod
	mod.options = {
		type = "group",
		name = L["General"],
		order = 0,
		args = {}
	}

	RasPort.logo = [[Interface\AddOns\RasPort\Skins\icon]]
	local DB
	local defaultsDB = {
		minimapbutton = true
	}

	local function SetupDatabase()
		if not DB then
			if type(core.db.Minimap) ~= "table" or next(core.db.Minimap) == nil then
				core.db.Minimap = CopyTable(defaultsDB)
			end
			DB = core.db.Minimap
		end
	end


	local addon = LibStub("AceAddon-3.0"):NewAddon("RasPort", "AceConsole-3.0")
	local RasPortLDB = LibStub("LibDataBroker-1.1"):NewDataObject("RasPort", {
    type = "data source",
    text = "RasPort",
    icon = RasPort.logo,
    OnClick = function(_, button)
		if IsShiftKeyDown() and button == "LeftButton" then
			DB.minimapbutton = false
		elseif button == "LeftButton" then
			core:OpenConfig("General","Minimap")
		elseif button == "RightButton" then
			core:CloseConfig("Options","Automate" or "Viewporter" or "FpsMonitor" or "Minimap")
		end
	end, })
	local icon = LibStub("LibDBIcon-1.0")

	function RasPortLDB:OnEnter(ldb)
		self.tooltip = self.tooltip or GameTooltip
		self.tooltip:SetOwner(self, "ANCHOR_NONE")
		self.tooltip:SetPoint("TOPRIGHT", self, "BOTTOMRIGHT")
		self.tooltip:ClearLines()

		self.tooltip:AddDoubleLine("RasPort", "1.0.9" , 1, 1, 1)
		self.tooltip:AddLine(" ")
		self.tooltip:AddLine(L["|cffeda55fLeft-Click|r to open configuration."], 0.2, 1, 0.2)
		self.tooltip:AddLine(L["|cffeda55fRight-Click|r to close configuration."], 0.2, 1, 0.2)
		self.tooltip:AddLine(L["|cffeda55fShift+Left-Click|r to hide minimap button."], 0.2, 1, 0.2)
		self.tooltip:AddLine(" ")
		self.tooltip:AddDoubleLine(L["|cff707070Discord:|r"], L["|cff707070rasta0818|r"])

		self.tooltip:Show()
	end
	
	function RasPortLDB:OnLeave()
		self.tooltip:Hide()
	end
 
	function addon:OnInitialize()
    	-- Obviously you'll need a ## SavedVariables: BunniesDB line in your TOC, duh!
    	self.db = LibStub("AceDB-3.0"):New("RasPortDB", {
        	profile = {
            	minimap = {
                	hide = false,
            	},
        	},
    	})
    	icon:Register("RasPort", RasPortLDB, self.db.profile.minimap)
    	self:RegisterChatCommand("rasportminimap", "CommandTheBunnies")
	end


	local eveFrame = CreateFrame("Frame")
	eveFrame:SetScript("OnEvent", function(self, event)
		self:SetScript("OnUpdate", update)
	end)
	eveFrame:RegisterEvent("PLAYER_LOGIN")
	eveFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
	
	function update(self)
		SetupDatabase()
		if DB.minimapbutton then
			icon:Show("RasPort")
		else
			icon:Hide("RasPort")
		end
	end

	mod.options.args.Minimap = {
		type = "group",
		name = L["Minimap"],
		order = 0,
		get = function(i)
			return DB[i[#i]]
		end,
		set = function(i, val)
			DB[i[#i]] = val
		end,
		args = {
			minimapbutton = {
				type = "toggle",
				name = L["Minimap Button"],
				order = 0
			},
		}
	}
	core:RegisterForEvent("PLAYER_LOGIN", function()
		SetupDatabase()
		core.options.args.General = mod.options

		SLASH_RASPORTGENERAL1 = "/rpg"
		SLASH_RASPORTGENERAL2 = "/rpgeneral"
		SlashCmdList["RASPORTGENERAL"] = function()
			core:OpenConfig("Genral", "Minimap")
		end
	end)
end)